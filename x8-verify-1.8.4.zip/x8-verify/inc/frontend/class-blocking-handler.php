<?php
/**
 * Blocking Handler
 *
 * @package X8_EVS
 * @since 1.0.0
 */

// If this file is called directly, abort.
if (!defined('WPINC')) {
    die;
}

/**
 * X8 Verify Blocking Handler Class
 * 
 * Handles blocking users based on ID address and geolocation
 */
class X8_EVS_Blocking_Handler {

    /**
     * Singleton instance
     */
    private static $instance = null;

    /**
     * Get singleton instance
     */
    public static function get_instance() {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    /**
     * Initialize the blocking handler
     */
    private function __construct() {
        
        if (defined('WP_DEBUG') && WP_DEBUG) {
            $request_uri = $_SERVER['REQUEST_URI'] ?? 'unknown';
            error_log('X8 Verify: Blocking Handler constructor called for URI: ' . $request_uri);
        }
        
        // Re-verify access on blocked-state URL after user/session is loaded (admin may have allowed IP/country/state)
        add_action('template_redirect', array($this, 'recheck_blocked_state_page'), 0);
        // Hook into WordPress actions - use earlier hooks to avoid header conflicts
        add_action('template_redirect', array($this, 'check_blocking_redirect'), 1);
        add_action('wp', array($this, 'check_blocking_redirect'), 1);
        add_action('init', array($this, 'check_blocking_redirect'), 5);
        
        // Also check immediately if we're on homepage (but only if we're sure it's frontend)
        // Check if this looks like a frontend request
        $request_uri = $_SERVER['REQUEST_URI'] ?? '';
        $is_frontend_request = (
            strpos($request_uri, '/wp-admin') !== 0 &&
            strpos($request_uri, '/wp-json') !== 0 &&
            strpos($request_uri, '/wp-cron') !== 0 &&
            strpos($request_uri, '/wp-ajax') !== 0 &&
            strpos($request_uri, '/xmlrpc.php') !== 0 &&
            strpos($request_uri, 'wc-ajax=') === false && // Skip WooCommerce AJAX
            !isset($_REQUEST['action']) // Skip if it looks like an AJAX request
        );
        
        if ($is_frontend_request) {
            if (defined('WP_DEBUG') && WP_DEBUG) {
                error_log('X8 Verify: Running immediate blocking check from constructor for frontend request: ' . $request_uri);
            }
            $this->check_blocking_redirect();
        } else {
            if (defined('WP_DEBUG') && WP_DEBUG) {
                error_log('X8 Verify: Skipping immediate check - backend/admin/ajax request: ' . $request_uri);
            }
        }
        
        // Force blocking check for testing (add ?force_blocking=1 to any URL)
        if (isset($_GET['force_blocking']) && $_GET['force_blocking'] === '1') {
            if (defined('WP_DEBUG') && WP_DEBUG) {
                error_log('X8 Verify: Force blocking check triggered via URL parameter');
            }
            $this->check_blocking_redirect();
        }
        
        // Clear blocking cache when user data changes
        add_action('user_register', array($this, 'clear_user_blocking_cache_on_change'));
        add_action('profile_update', array($this, 'clear_user_blocking_cache_on_change'));
        add_action('updated_user_meta', array($this, 'clear_user_blocking_cache_on_meta_change'), 10, 4);
        
        // Add debug info display for testing
        add_action('wp_footer', array($this, 'display_debug_info'));

        // Register custom REST API endpoint
        add_action('rest_api_init', array($this, 'register_custom_endpoints'));

    }

    /**
     * Register custom REST API endpoints
     */
    public function register_custom_endpoints() {
        register_rest_route('user', '/ip', array(
            'methods' => 'GET',
            'callback' => array($this, 'get_user_ip_endpoint'),
            'permission_callback' => '__return_true' // Make it public
        ));
    }

    /**
     * Handle the /wp-json/user/ip endpoint
     */
    public function get_user_ip_endpoint($request) {
        $ip_address = $this->get_user_ip();
        
        $response_data = array(
            'ip' => $ip_address,
            'timestamp' => current_time('mysql'),
            'success' => !empty($ip_address)
        );
        
        // Add geolocation data if available
        if (!empty($ip_address)) {
            $geo_data = $this->get_geolocation_data($ip_address);
            if ($geo_data) {
                $response_data['location'] = array(
                    'country' => $geo_data['country'] ?? '',
                    'state' => $geo_data['state'] ?? '',
                    'city' => $geo_data['city'] ?? '',
                    'region' => $geo_data['region'] ?? ''
                );
            }
        }
        
        return new WP_REST_Response($response_data, 200);
    }

    /**
     * True when the request is for the blocked-state page (path), not merely ?reason= on another URL.
     *
     * @return bool
     */
    private function is_blocked_state_request() {
        $request_uri = $_SERVER['REQUEST_URI'] ?? '';
        $clean_uri     = strtok($request_uri, '?');
        return (
            strpos($clean_uri, '/blocked-state') !== false ||
            (isset($_GET['x8_evs_page']) && sanitize_text_field(wp_unslash($_GET['x8_evs_page'])) === 'blocked-state')
        );
    }

    /**
     * On /blocked-state: clear stale block cache and redirect home if user is no longer blocked.
     * Runs on template_redirect priority 0 so auth is available.
     */
    public function recheck_blocked_state_page() {
        if (!$this->is_blocked_state_request()) {
            return;
        }

        $request_uri = $_SERVER['REQUEST_URI'] ?? '';
        if (
            strpos($request_uri, '/wp-admin') === 0 ||
            strpos($request_uri, '/wp-json') === 0 ||
            strpos($request_uri, '/wp-cron') === 0 ||
            strpos($request_uri, 'wc-ajax=') !== false ||
            isset($_REQUEST['action'])
        ) {
            return;
        }

        static $rechecked = false;
        if ($rechecked) {
            return;
        }
        $rechecked = true;

        if (!class_exists('X8_EVS_Admin_Settings')) {
            wp_safe_redirect(home_url('/'));
            exit;
        }

        // Blocking turned off entirely — allow access
        if (!X8_EVS_Admin_Settings::has_blocking_options_enabled()) {
            wp_safe_redirect(home_url('/'));
            exit;
        }

        $ip_address = $this->get_user_ip();
        if (!empty($ip_address) && X8_EVS_Admin_Settings::is_ip_whitelisted($ip_address)) {
            wp_safe_redirect(home_url('/'));
            exit;
        }

        if (X8_EVS_Admin_Settings::is_google_bots_allowed() && X8_EVS_Admin_Settings::is_google_bot()) {
            wp_safe_redirect(home_url('/'));
            exit;
        }

        if (is_user_logged_in()) {
            $current_user = wp_get_current_user();
            if (user_can($current_user, 'manage_options')) {
                wp_safe_redirect(home_url('/'));
                exit;
            }
            self::clear_user_blocking_cache($current_user->ID);
            $block_reason = $this->get_cached_blocking_result($current_user->ID);
            if (empty($block_reason)) {
                wp_safe_redirect(home_url('/'));
                exit;
            }
            return;
        }

        if (empty($ip_address)) {
            return;
        }

        self::clear_ip_blocking_cache($ip_address);
        $block_reason = $this->get_cached_blocking_result_for_ip();
        if (empty($block_reason)) {
            wp_safe_redirect(home_url('/'));
            exit;
        }
    }

    /**
     * Check if user should be blocked and redirected
     */
    public function check_blocking_redirect() {
        // Only check on frontend - use direct URI checking instead of WordPress functions
        $request_uri = $_SERVER['REQUEST_URI'] ?? '';
        $is_backend_request = (
            strpos($request_uri, '/wp-admin') === 0 ||
            strpos($request_uri, '/wp-json') === 0 ||
            strpos($request_uri, '/wp-cron') === 0 ||
            strpos($request_uri, '/wp-ajax') === 0 ||
            strpos($request_uri, '/xmlrpc.php') === 0 ||
            strpos($request_uri, 'wc-ajax=') !== false || // Skip WooCommerce AJAX
            isset($_REQUEST['action']) // Skip if it looks like an AJAX request
        );
        
        if ($is_backend_request) {
            if (defined('WP_DEBUG') && WP_DEBUG) {
                error_log('X8 Verify: Skipping blocking check - backend request: ' . $request_uri);
            }
            return;
        }

        // Prevent multiple executions per request
        static $checked = false;
        if ($checked) {
            if (defined('WP_DEBUG') && WP_DEBUG) {
                error_log('X8 Verify: Blocking check already performed, skipping');
            }
            return;
        }
        $checked = true;

        // Debug logging
        if (defined('WP_DEBUG') && WP_DEBUG) {
            $request_uri = $_SERVER['REQUEST_URI'] ?? '';
            $is_front_page = function_exists('is_front_page') ? is_front_page() : false;
            $is_home = function_exists('is_home') ? is_home() : false;
            $current_action = function_exists('current_action') ? current_action() : 'none';
            $is_admin_check = function_exists('is_admin') ? is_admin() : 'unknown';
            error_log("X8 Verify: check_blocking_redirect called for URI: {$request_uri}, is_front_page: " . ($is_front_page ? 'YES' : 'NO') . ", is_home: " . ($is_home ? 'YES' : 'NO') . ", action: {$current_action}, is_admin: " . ($is_admin_check ? 'YES' : 'NO'));
        }

        // Don't check if already on blocked page to prevent redirect loops
        if ($this->is_on_blocked_page()) {
            if (defined('WP_DEBUG') && WP_DEBUG) {
                error_log("X8 Verify: Already on blocked page, skipping redirect check");
            }
            return;
        }

        // Check if IP is whitelisted (bypass all blocking)
        $ip_address = $this->get_user_ip();
        if (!empty($ip_address) && class_exists('X8_EVS_Admin_Settings')) {
            if (X8_EVS_Admin_Settings::is_ip_whitelisted($ip_address)) {
                if (defined('WP_DEBUG') && WP_DEBUG) {
                    error_log("X8 Verify: IP {$ip_address} is whitelisted, skipping blocking check");
                }
                return;
            }
        }

        // Check if Google bots are allowed and this is a Google bot
        if (class_exists('X8_EVS_Admin_Settings') && X8_EVS_Admin_Settings::is_google_bots_allowed()) {
            if (X8_EVS_Admin_Settings::is_google_bot()) {
                if (defined('WP_DEBUG') && WP_DEBUG) {
                    error_log("X8 Verify: Google bot detected and allowed, skipping blocking check");
                }
                return;
            }
        }

        // Check if any blocking options are enabled
        if (!class_exists('X8_EVS_Admin_Settings') || !X8_EVS_Admin_Settings::has_blocking_options_enabled()) {
            if (defined('WP_DEBUG') && WP_DEBUG) {
                error_log("X8 Verify: Blocking options not enabled, skipping");
            }
            return;
        }

        // Handle logged-in users
        if (is_user_logged_in()) {
            $current_user = wp_get_current_user();
            
            // Skip for administrators
            if (user_can($current_user, 'manage_options')) {
                if (defined('WP_DEBUG') && WP_DEBUG) {
                    error_log("X8 Verify: User is administrator, skipping");
                }
                return;
            }

            // Check if user should be blocked (with caching)
            $block_reason = $this->get_cached_blocking_result($current_user->ID);
            
            if ($block_reason) {
                if (defined('WP_DEBUG') && WP_DEBUG) {
                    error_log("X8 Verify: User {$current_user->ID} should be blocked, redirecting");
                }
                $this->redirect_to_blocked_page($block_reason);
            } else {
                if (defined('WP_DEBUG') && WP_DEBUG) {
                    error_log("X8 Verify: User {$current_user->ID} is not blocked");
                }
            }
        } else {
            // Handle logged-out users - check based on IP address only
            $block_reason = $this->get_cached_blocking_result_for_ip();

            if ($block_reason) {
                if (defined('WP_DEBUG') && WP_DEBUG) {
                    error_log("X8 Verify: IP should be blocked, redirecting");
                }
                $this->redirect_to_blocked_page($block_reason);
            } else {
                if (defined('WP_DEBUG') && WP_DEBUG) {
                    error_log("X8 Verify: IP is not blocked");
                }
            }
        }
    }

    
    /**
     * Check if user should be blocked based on ID address
     */
    private function should_user_be_blocked($user_id) {
        // First check ID address blocking (priority)
        if (X8_EVS_Admin_Settings::is_block_by_id_address_enabled()) {
            $id_address_block = $this->check_id_address_blocking($user_id);
            if ($id_address_block) {
                return $id_address_block;
            }
        }

        // When EVS AssureLocate is the location provider, IP-based VPN and
        // geolocation blocking are handled by the AssureLocate portal flow instead.
        // A failed AssureLocate verification still counts as blocked so the
        // blocked-state page recheck doesn't bounce the user back and forth.
        if ($this->is_assurelocate_provider()) {
            if (!class_exists('X8_EVS_AssureLocate_Handler')) {
                require_once X8_EVS_PLUGIN_PATH . 'inc/frontend/class-assurelocate-handler.php';
            }

            return X8_EVS_AssureLocate_Handler::get_block_reason_for_user($user_id, $this->get_user_ip());
        }

        // Then check VPN blocking
        if (X8_EVS_Admin_Settings::is_vpn_blocking_enabled()) {
            $vpn_block = $this->check_vpn_blocking($user_id);

            if ($vpn_block) {
                return $vpn_block;
            }
        }

        // Then check geolocation blocking
        if (X8_EVS_Admin_Settings::is_block_by_geolocation_enabled()) {
            $geo_block = $this->check_geolocation_blocking($user_id);

            if ($geo_block) {
                return $geo_block;
            }
        }

        return false;
    }

    /**
     * Check if IP address should be blocked (for logged-out users)
     */
    private function should_ip_be_blocked($ip_address) {
        // When EVS AssureLocate is the location provider, IP-based VPN and
        // geolocation blocking are handled by the AssureLocate portal flow instead.
        // In global trigger mode a failed guest verification still counts as
        // blocked so the blocked-state page recheck doesn't redirect-loop.
        if ($this->is_assurelocate_provider()) {
            if (!class_exists('X8_EVS_AssureLocate_Handler')) {
                require_once X8_EVS_PLUGIN_PATH . 'inc/frontend/class-assurelocate-handler.php';
            }

            return X8_EVS_AssureLocate_Handler::get_block_reason_for_ip($ip_address);
        }

        // Check VPN blocking first
        if (X8_EVS_Admin_Settings::is_vpn_blocking_enabled()) {
            $vpn_block = $this->check_vpn_blocking_for_ip($ip_address);
            if ($vpn_block) {
                return $vpn_block;
            }
        }

        // Then check geolocation blocking
        if (X8_EVS_Admin_Settings::is_block_by_geolocation_enabled()) {
            $geo_block = $this->check_geolocation_blocking_for_ip($ip_address);

            if ($geo_block) {
                return $geo_block;
            }
        }

        return false;
    }

    /**
     * Whether EVS AssureLocate is the selected location detection service
     */
    private function is_assurelocate_provider() {
        return get_option('x8_evs_location_provider', 'ipapi_co') === 'evs_assurelocate';
    }

    /**
     * Whether a cached block reason is IP-based (VPN/geolocation) and should be
     * ignored because EVS AssureLocate now handles location verification.
     */
    private function is_stale_ip_based_block_reason($reason) {
        if (!$this->is_assurelocate_provider()) {
            return false;
        }

        $type = is_array($reason) ? ($reason['type'] ?? '') : '';

        return in_array($type, array('vpn', 'geolocation_country', 'geolocation_state'), true);
    }

    /**
     * Check if user should be blocked based on ID document address
     */
    private function check_id_address_blocking($user_id) {
        // Get verification data from user meta
        $verification_data = get_user_meta($user_id, 'verification_webhook_data', true);
        
        if (!$verification_data) {
            return false;
        }

        // Parse the JSON data
        $data = json_decode($verification_data, true);
        if (!$data || !isset($data['data']['assureCard']['documentAddress'])) {
            return false;
        }

        // Get the state from the document address
        $document_address = $data['data']['assureCard']['documentAddress'];
        $state = $document_address['state'] ?? '';

        if (empty($state)) {
            return false;
        }

        // Check if the state is blocked
        if (X8_EVS_Admin_Settings::is_state_blocked($state)) {
            return array(
                'type' => 'id_address',
                'state' => $state,
                'state_name' => $this->get_state_name($state),
                'message' => sprintf(
                    __('Your ID document shows an address in %s, which is not allowed.', 'x8-evs'),
                    $this->get_state_name($state)
                )
            );
        }

        return false;
    }

    /**
     * Check if IP should be blocked based on VPN usage (for logged-out users)
     */
    private function check_vpn_blocking_for_ip($ip_address) {
        // For testing purposes, allow manual IP override
        if (defined('WP_DEBUG') && WP_DEBUG && isset($_GET['test_ip'])) {
            $test_ip = sanitize_text_field($_GET['test_ip']);
            if (filter_var($test_ip, FILTER_VALIDATE_IP) !== false) {
                $ip_address = $test_ip;
            }
        }
        
        if (empty($ip_address)) {
            return false;
        }

        // Get VPN detection data for the IP
        $vpn_data = $this->get_vpn_detection_data($ip_address);

        if (!$vpn_data) {
            return false;
        }

        // Check if the IP is detected as VPN/proxy
        if ($vpn_data['is_vpn'] || $vpn_data['is_proxy']) {
            return array(
                'type' => 'vpn',
                'ip' => $ip_address,
                'vpn_type' => $vpn_data['vpn_type'] ?? 'Unknown',
                'isp' => $vpn_data['isp'] ?? 'Unknown',
                'message' => sprintf(
                    __('VPN or proxy usage is not allowed. Detected: %s', 'x8-evs'),
                    $vpn_data['vpn_type'] ?? 'VPN/Proxy'
                )
            );
        }

        return false;
    }

    /**
     * Check if IP should be blocked based on geolocation (for logged-out users)
     */
    private function check_geolocation_blocking_for_ip($ip_address) {
        // For testing purposes, allow manual IP override
        if (defined('WP_DEBUG') && WP_DEBUG && isset($_GET['test_ip'])) {
            $test_ip = sanitize_text_field($_GET['test_ip']);
            if (filter_var($test_ip, FILTER_VALIDATE_IP) !== false) {
                $ip_address = $test_ip;
            }
        }
        
        if (empty($ip_address)) {
            return false;
        }

        // Get geolocation data for the IP
        $geo_data = $this->get_geolocation_data($ip_address);

        if(!$geo_data["state"]){
            $geo_data["state"] = $geo_data["region"];
        }
        
        if (!$geo_data || (!isset($geo_data['state']) && !isset($geo_data['country']))) {
            return false;
        }

        // Check country blocking first (if country filtering is enabled)
        if (X8_EVS_Admin_Settings::is_country_filtering_enabled() && isset($geo_data['country'])) {
            $country = $geo_data['country'];
            
            if (!X8_EVS_Admin_Settings::is_country_allowed($country)) {
                return array(
                    'type' => 'geolocation_country',
                    'country' => $country,
                    'country_name' => $this->get_country_name($country),
                    'service' => $geo_data['service'] ?? null,
                    'message' => sprintf(
                        __('Your country (%s) is not allowed.', 'x8-evs'),
                        $this->get_country_name($country)
                    )
                );
            }
        }




        // Check state blocking (if state data is available)
        if (isset($geo_data['state'])) {
            $state = $geo_data['state'];

            // Check if the state is blocked
            if (X8_EVS_Admin_Settings::is_state_blocked($state)) {
                return array(
                    'type' => 'geolocation_state',
                    'state' => $state,
                    'state_name' => $this->get_state_name($state),
                    'service' => $geo_data['service'] ?? null,
                    'message' => sprintf(
                        __('Your location (%s) is not allowed.', 'x8-evs'),
                        $this->get_state_name($state)
                    )
                );
            }
        }

        return false;
    }

    /**
     * Check if user should be blocked based on geolocation
     */
    private function check_geolocation_blocking($user_id) {
        // Get user's IP address
        $ip_address = $this->get_user_ip();

        
        // For testing purposes, allow manual IP override
        if (defined('WP_DEBUG') && WP_DEBUG && isset($_GET['test_ip'])) {
            $test_ip = sanitize_text_field($_GET['test_ip']);
            if (filter_var($test_ip, FILTER_VALIDATE_IP) !== false) {
                $ip_address = $test_ip;
            }
        }
        
        if (empty($ip_address)) {
            return false;
        }

        // Get geolocation data for the IP
        $geo_data = $this->get_geolocation_data($ip_address);


        if(!$geo_data["state"]){
            $geo_data["state"] = $geo_data["region"];
        }
        
        if (!$geo_data || (!isset($geo_data['state']) && !isset($geo_data['country']))) {
            return false;
        }

        // Check country blocking first (if country filtering is enabled)
        if (X8_EVS_Admin_Settings::is_country_filtering_enabled() && isset($geo_data['country'])) {
            $country = $geo_data['country'];
            
            if (!X8_EVS_Admin_Settings::is_country_allowed($country)) {
                return array(
                    'type' => 'geolocation_country',
                    'country' => $country,
                    'country_name' => $this->get_country_name($country),
                    'service' => $geo_data['service'] ?? null,
                    'message' => sprintf(
                        __('Your country (%s) is not allowed.', 'x8-evs'),
                        $this->get_country_name($country)
                    )
                );
            }
        }

        // Check state blocking (if state data is available)
        if (isset($geo_data['state'])) {
            $state = $geo_data['state'];

            // Check if the state is blocked
            if (X8_EVS_Admin_Settings::is_state_blocked($state)) {
                return array(
                    'type' => 'geolocation_state',
                    'state' => $state,
                    'state_name' => $this->get_state_name($state),
                    'service' => $geo_data['service'] ?? null,
                    'message' => sprintf(
                        __('Your location (%s) is not allowed.', 'x8-evs'),
                        $this->get_state_name($state)
                    )
                );
            }
        }

        return false;
    }

    /**
     * Check if user should be blocked based on VPN usage
     */
    private function check_vpn_blocking($user_id) {
        // Get user's IP address
        $ip_address = $this->get_user_ip();

        // For testing purposes, allow manual IP override
        if (defined('WP_DEBUG') && WP_DEBUG && isset($_GET['test_ip'])) {
            $test_ip = sanitize_text_field($_GET['test_ip']);
            if (filter_var($test_ip, FILTER_VALIDATE_IP) !== false) {
                $ip_address = $test_ip;
            }
        }
        
        if (empty($ip_address)) {
            return false;
        }

        // Get VPN detection data for the IP
        $vpn_data = $this->get_vpn_detection_data($ip_address);

        if (!$vpn_data) {
            return false;
        }

        // Check if the IP is detected as VPN/proxy
        if ($vpn_data['is_vpn'] || $vpn_data['is_proxy']) {
            return array(
                'type' => 'vpn',
                'ip' => $ip_address,
                'vpn_type' => $vpn_data['vpn_type'] ?? 'Unknown',
                'isp' => $vpn_data['isp'] ?? 'Unknown',
                'message' => sprintf(
                    __('VPN or proxy usage is not allowed. Detected: %s', 'x8-evs'),
                    $vpn_data['vpn_type'] ?? 'VPN/Proxy'
                )
            );
        }

        return false;
    }

    /**
     * Normalize cached blocking payloads (handles legacy cache shapes)
     *
     * @param string $cache_key
     * @return array{hit:bool, blocked:bool, reason:mixed, stale:bool, raw:mixed}
     */
    private function normalize_block_cache_entry($cache_key) {
        $cached_value = get_transient($cache_key);

        if ($cached_value === false) {
            return array(
                'hit' => false,
                'blocked' => false,
                'reason' => false,
                'stale' => false,
                'raw' => false,
            );
        }

        if (is_array($cached_value) && isset($cached_value['version']) && isset($cached_value['blocked'])) {
            return array(
                'hit' => true,
                'blocked' => (bool) $cached_value['blocked'],
                'reason' => $cached_value['reason'] ?? false,
                'stale' => false,
                'raw' => $cached_value,
            );
        }

        // Legacy cache entries stored the block reason array directly.
        if (is_array($cached_value)) {
            return array(
                'hit' => true,
                'blocked' => true,
                'reason' => $cached_value,
                'stale' => true,
                'raw' => $cached_value,
            );
        }

        return array(
            'hit' => true,
            'blocked' => false,
            'reason' => false,
            'stale' => true,
            'raw' => $cached_value,
        );
    }

    /**
     * Store a blocking decision in the cache with configurable TTLs.
     *
     * @param string $cache_key
     * @param mixed  $block_reason
     * @param string $context     Either 'user' or 'ip' (used for filter/contextual logging)
     * @return void
     */
    private function persist_block_cache_entry($cache_key, $block_reason, $context = 'ip') {
        $is_blocked = !empty($block_reason);

        $payload = array(
            'version'   => 1,
            'blocked'   => $is_blocked,
            'reason'    => $is_blocked ? $block_reason : false,
            'cached_at' => time(),
        );

        $default_allowed_ttl = 5 * MINUTE_IN_SECONDS;
        $default_blocked_ttl = 10 * MINUTE_IN_SECONDS;

        if ($context === 'user') {
            $cache_duration = $is_blocked
                ? apply_filters('x8_evs_user_block_cache_ttl_blocked', $default_blocked_ttl, $block_reason, $cache_key, $payload)
                : apply_filters('x8_evs_user_block_cache_ttl_allowed', $default_allowed_ttl, $block_reason, $cache_key, $payload);
        } else {
            $cache_duration = $is_blocked
                ? apply_filters('x8_evs_ip_block_cache_ttl_blocked', $default_blocked_ttl, $block_reason, $cache_key, $payload)
                : apply_filters('x8_evs_ip_block_cache_ttl_allowed', $default_allowed_ttl, $block_reason, $cache_key, $payload);
        }

        // Ensure a sane minimum TTL of 60 seconds
        $cache_duration = max(60, (int) $cache_duration);

        set_transient($cache_key, $payload, $cache_duration);

        if (defined('WP_DEBUG') && WP_DEBUG) {
            $state = $is_blocked ? 'blocked' : 'allowed';
            error_log("X8 Verify: Cached {$context} {$state} result for {$cache_key} ({$cache_duration}s TTL)");
        }
    }

    /**
     * Get cached blocking result for user
     */
    private function get_cached_blocking_result($user_id) {
        $cache_key = 'x8_evs_blocking_result_' . $user_id;
        $cache_entry = $this->normalize_block_cache_entry($cache_key);

        if ($cache_entry['hit'] && !$cache_entry['stale']) {
            $cached_reason = $cache_entry['blocked'] ? $cache_entry['reason'] : false;

            // Ignore stale IP-based block results when AssureLocate handles location
            if (!$this->is_stale_ip_based_block_reason($cached_reason)) {
                if (defined('WP_DEBUG') && WP_DEBUG) {
                    error_log("X8 Verify: Using cached blocking result for user {$user_id}");
                }

                return $cached_reason;
            }
        }

        if ($cache_entry['hit'] && $cache_entry['stale'] && defined('WP_DEBUG') && WP_DEBUG) {
            error_log("X8 Verify: Legacy blocking cache detected for user {$user_id}, refreshing decision");
        }

        if (defined('WP_DEBUG') && WP_DEBUG) {
            error_log("X8 Verify: Cache miss - performing blocking check for user {$user_id}");
        }

        $block_reason = $this->should_user_be_blocked($user_id);

        $this->persist_block_cache_entry($cache_key, $block_reason, 'user');

        return $block_reason;
    }

    /**
     * Get cached blocking result for IP address (for logged-out users)
     */
    private function get_cached_blocking_result_for_ip() {
        $ip_address = $this->get_user_ip();

        if (empty($ip_address)) {
            return false;
        }

        $cache_key = 'x8_evs_blocking_result_ip_' . md5($ip_address);
        $cache_entry = $this->normalize_block_cache_entry($cache_key);

        if ($cache_entry['hit'] && !$cache_entry['stale']) {
            $cached_reason = $cache_entry['blocked'] ? $cache_entry['reason'] : false;

            // Ignore stale IP-based block results when AssureLocate handles location
            if (!$this->is_stale_ip_based_block_reason($cached_reason)) {
                if (defined('WP_DEBUG') && WP_DEBUG) {
                    error_log("X8 Verify: Using cached blocking result for IP {$ip_address}");
                }

                return $cached_reason;
            }
        }

        if ($cache_entry['hit'] && $cache_entry['stale'] && defined('WP_DEBUG') && WP_DEBUG) {
            error_log("X8 Verify: Legacy blocking cache detected for IP {$ip_address}, refreshing decision");
        }

        if (defined('WP_DEBUG') && WP_DEBUG) {
            error_log("X8 Verify: Cache miss - performing blocking check for IP {$ip_address}");
        }

        $block_reason = $this->should_ip_be_blocked($ip_address);

        $this->persist_block_cache_entry($cache_key, $block_reason, 'ip');

        return $block_reason;
    }

    /**
     * Clear blocking cache for a specific user
     */
    public static function clear_user_blocking_cache($user_id) {
        $cache_key = 'x8_evs_blocking_result_' . $user_id;
        delete_transient($cache_key);
        
        if (defined('WP_DEBUG') && WP_DEBUG) {
            error_log("X8 Verify: Cleared blocking cache for user {$user_id}");
        }
    }

    /**
     * Clear blocking cache for a specific IP address
     */
    public static function clear_ip_blocking_cache($ip_address) {
        $cache_key = 'x8_evs_blocking_result_ip_' . md5($ip_address);
        delete_transient($cache_key);
        
        if (defined('WP_DEBUG') && WP_DEBUG) {
            error_log("X8 Verify: Cleared blocking cache for IP {$ip_address}");
        }
    }

    /**
     * Clear all blocking cache
     */
    public static function clear_all_blocking_cache() {
        global $wpdb;
        
        // Get all transients that start with our blocking cache prefix (both user and IP based)
        $cache_keys = $wpdb->get_col(
            $wpdb->prepare(
                "SELECT option_name FROM {$wpdb->options} WHERE option_name LIKE %s OR option_name LIKE %s",
                '_transient_x8_evs_blocking_result_%',
                '_transient_x8_evs_blocking_result_ip_%'
            )
        );
        
        $cleared_count = 0;
        foreach ($cache_keys as $cache_key) {
            $transient_name = str_replace('_transient_', '', $cache_key);
            if (delete_transient($transient_name)) {
                $cleared_count++;
            }
        }
        
        if (defined('WP_DEBUG') && WP_DEBUG) {
            error_log("X8 Verify: Cleared {$cleared_count} blocking cache entries");
        }
        
        return $cleared_count;
    }

    /**
     * Clear blocking cache when user data changes
     */
    public function clear_user_blocking_cache_on_change($user_id) {
        self::clear_user_blocking_cache($user_id);
    }

    /**
     * Clear blocking cache when user meta changes (especially verification data)
     */
    public function clear_user_blocking_cache_on_meta_change($meta_id, $user_id, $meta_key, $meta_value) {
        // Clear cache for verification-related meta changes
        $verification_meta_keys = array(
            'verification_webhook_data',
            'account_status',
            'verification_status'
        );
        
        if (in_array($meta_key, $verification_meta_keys)) {
            self::clear_user_blocking_cache($user_id);
            
            if (defined('WP_DEBUG') && WP_DEBUG) {
                error_log("X8 Verify: Cleared blocking cache due to {$meta_key} change for user {$user_id}");
            }
        }
    }

    /**
     * Get blocking cache statistics
     */
    public static function get_blocking_cache_stats() {
        global $wpdb;
        
        // Get user-based cache keys
        $user_cache_keys = $wpdb->get_col(
            $wpdb->prepare(
                "SELECT option_name FROM {$wpdb->options} WHERE option_name LIKE %s",
                '_transient_x8_evs_blocking_result_%'
            )
        );
        
        // Get IP-based cache keys
        $ip_cache_keys = $wpdb->get_col(
            $wpdb->prepare(
                "SELECT option_name FROM {$wpdb->options} WHERE option_name LIKE %s",
                '_transient_x8_evs_blocking_result_ip_%'
            )
        );
        
        $total_user_cached = count($user_cache_keys);
        $total_ip_cached = count($ip_cache_keys);
        $total_cached = $total_user_cached + $total_ip_cached;
        $cache_size = 0;
        $blocked_users = 0;
        $allowed_users = 0;
        $blocked_ips = 0;
        $allowed_ips = 0;
        
        // Process user cache
        foreach ($user_cache_keys as $cache_key) {
            $transient_name = str_replace('_transient_', '', $cache_key);
            $cached_data = get_transient($transient_name);
            if ($cached_data) {
                $cache_size += strlen(serialize($cached_data));
                if ($cached_data === false) {
                    $allowed_users++;
                } else {
                    $blocked_users++;
                }
            }
        }
        
        // Process IP cache
        foreach ($ip_cache_keys as $cache_key) {
            $transient_name = str_replace('_transient_', '', $cache_key);
            $cached_data = get_transient($transient_name);
            if ($cached_data) {
                $cache_size += strlen(serialize($cached_data));
                if ($cached_data === false) {
                    $allowed_ips++;
                } else {
                    $blocked_ips++;
                }
            }
        }
        
        return array(
            'total_cached_users' => $total_user_cached,
            'total_cached_ips' => $total_ip_cached,
            'total_cached_entries' => $total_cached,
            'blocked_users' => $blocked_users,
            'allowed_users' => $allowed_users,
            'blocked_ips' => $blocked_ips,
            'allowed_ips' => $allowed_ips,
            'cache_size_bytes' => $cache_size,
            'cache_size_mb' => round($cache_size / 1024 / 1024, 2)
        );
    }

    /**
     * Get user's IP address
     */
    private function get_user_ip() {
        // Array of possible IP headers (in order of preference)
        $ip_headers = array(
            'HTTP_CF_CONNECTING_IP',     // Cloudflare
            'HTTP_CLIENT_IP',            // Client IP
            'HTTP_X_FORWARDED_FOR',      // Forwarded IP
            'HTTP_X_FORWARDED',          // Forwarded IP (alternative)
            'HTTP_X_CLUSTER_CLIENT_IP',  // Cluster client IP
            'HTTP_FORWARDED_FOR_IP',     // Forwarded for IP
            'HTTP_FORWARDED',            // Forwarded
            'HTTP_X_REAL_IP',            // Real IP
            'HTTP_X_FORWARDED_FOR_IP',   // Forwarded for IP (alternative)
            'REMOTE_ADDR'                // Remote address (fallback)
        );
        
        foreach ($ip_headers as $header) {
            if (!empty($_SERVER[$header])) {
                $ip_list = explode(',', $_SERVER[$header]);
                foreach ($ip_list as $ip) {
                    $ip = trim($ip);
                    
                    // Skip empty IPs
                    if (empty($ip)) {
                        continue;
                    }
                    
                    // For development/testing, allow localhost IPs
                    if (defined('WP_DEBUG') && WP_DEBUG) {
                        if (filter_var($ip, FILTER_VALIDATE_IP) !== false) {
                            return $ip;
                        }
                    } else {
                        // In production, filter out private ranges
                        if (filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE) !== false) {
                            return $ip;
                        }
                    }
                }
            }
        }
        
        // Fallback to REMOTE_ADDR
        $fallback_ip = $_SERVER['REMOTE_ADDR'] ?? '';
        
        // For development, return the fallback even if it's localhost
        if (defined('WP_DEBUG') && WP_DEBUG) {
            return $fallback_ip;
        }
        
        // In production, only return if it's not a private IP
        if (!empty($fallback_ip) && filter_var($fallback_ip, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE) !== false) {
            return $fallback_ip;
        }
        
        return '';
    }

    /**
     * Get geolocation data for an IP address with caching
     */
    private function get_geolocation_data($ip_address) {
        $cache_key = 'x8_evs_geo_' . md5($ip_address);
        $cache_entry = $this->get_cached_geolocation_entry($cache_key, $ip_address);

        if ($cache_entry['hit'] && !$cache_entry['stale']) {
            return $cache_entry['data'];
        }

        // Force a refresh when the cached payload is stale/legacy or missing.
        if ($cache_entry['hit'] && $cache_entry['stale']) {
            delete_transient($cache_key);
            if (defined('WP_DEBUG') && WP_DEBUG) {
                error_log("X8 Verify: Discarded stale geolocation cache for IP: {$ip_address}");
            }
        }

        // Try multiple geolocation services
        $geo_data = $this->call_multiple_geolocation_services($ip_address);

        if ($geo_data) {
            // Cache the result with the new format
            $this->cache_geolocation_data($cache_key, $geo_data, $ip_address);
            return $geo_data;
        }

        // If we failed to refresh but have stale data, fall back to it as a best effort.
        if ($cache_entry['hit'] && $cache_entry['stale'] && !empty($cache_entry['data'])) {
            if (defined('WP_DEBUG') && WP_DEBUG) {
                error_log("X8 Verify: Falling back to stale geolocation data for IP: {$ip_address}");
            }
            return $cache_entry['data'];
        }

        return false;
    }

    /**
     * Retrieve and normalize cached geolocation data.
     *
     * @param string $cache_key
     * @param string $ip_address
     * @return array{hit:bool, data:mixed, stale:bool}
     */
    private function get_cached_geolocation_entry($cache_key, $ip_address) {
        $cached_value = get_transient($cache_key);

        if ($cached_value === false) {
            return array(
                'hit' => false,
                'data' => false,
                'stale' => false,
            );
        }

        if (is_array($cached_value) && isset($cached_value['version']) && isset($cached_value['data'])) {
            // Check if cached data has the 'service' field (required for tracking)
            // If it doesn't have service, treat as stale to force refresh
            $has_service = isset($cached_value['data']['service']) && !empty($cached_value['data']['service']);
            
            if ($has_service) {
                if (defined('WP_DEBUG') && WP_DEBUG) {
                    error_log("X8 Verify: Geolocation cache hit for IP: {$ip_address}");
                }

                return array(
                    'hit' => true,
                    'data' => $cached_value['data'],
                    'stale' => false,
                );
            } else {
                // Cached data doesn't have service field, treat as stale
                if (defined('WP_DEBUG') && WP_DEBUG) {
                    error_log("X8 Verify: Geolocation cache missing service field for IP: {$ip_address}, will refresh");
                }
                return array(
                    'hit' => true,
                    'data' => $cached_value['data'],
                    'stale' => true,
                );
            }
        }

        // Legacy format - treat as stale so we can refresh it.
        return array(
            'hit' => true,
            'data' => is_array($cached_value) ? $cached_value : false,
            'stale' => true,
        );
    }

    /**
     * Cache geolocation data
     *
     * @param string $cache_key
     * @param array  $geo_data
     * @param string $ip_address
     */
    private function cache_geolocation_data($cache_key, $geo_data, $ip_address) {
        $payload = array(
            'version'   => 1,
            'data'      => $geo_data,
            'cached_at' => time(),
        );

        $default_ttl = 10 * MINUTE_IN_SECONDS;
        $cache_duration = apply_filters('x8_evs_geo_cache_ttl', $default_ttl, $ip_address, $geo_data, $cache_key, $payload);
        $cache_duration = max(300, (int) $cache_duration); // enforce a minimum of 5 minutes

        set_transient($cache_key, $payload, $cache_duration);

        if (defined('WP_DEBUG') && WP_DEBUG) {
            error_log("X8 Verify: Cached geolocation data for IP: {$ip_address} ({$cache_duration}s TTL)");
        }
    }

    /**
     * Call multiple geolocation services for redundancy
     */
    private function call_multiple_geolocation_services($ip_address) {
        $provider = get_option('x8_evs_location_provider', 'ipapi_co');

        // First priority: ipapi.co (when selected and API key is configured)
        $ipapi_co_api_key = get_option('x8_evs_ipapi_co_api', '');
        if ($provider === 'ipapi_co' && !empty($ipapi_co_api_key)) {
            $ipapi_co_url = 'https://ipapi.co/' . rawurlencode($ip_address) . '/json/?key=' . rawurlencode($ipapi_co_api_key);
            $response = wp_remote_get($ipapi_co_url, array(
                'timeout' => 5,
                'user-agent' => 'X8-EVS-Plugin/1.0'
            ));

            if (!is_wp_error($response)) {
                $body = wp_remote_retrieve_body($response);
                $data = json_decode($body, true);
                if ($data) {
                    $parsed_data = $this->parse_ipapi_response($data);
                    if ($parsed_data && isset($parsed_data['country']) && !empty($parsed_data['country'])) {
                        if (defined('WP_DEBUG') && WP_DEBUG) {
                            error_log("X8 Verify: Geolocation data from ipapi.co for IP: {$ip_address}");
                        }
                        return $parsed_data;
                    }
                }
            } elseif (defined('WP_DEBUG') && WP_DEBUG) {
                error_log('X8 Verify: ipapi.co failed for IP: ' . $ip_address . ' - ' . $response->get_error_message());
            }
        }

        // IPGeolocation.io (when selected and API key is configured)
        $ipgeolocation_api_key = get_option('x8_evs_ipgeolocation_api', '');
        
        if ($provider === 'ipgeolocation' && !empty($ipgeolocation_api_key)) {
            $ipgeolocation_url = "https://api.ipgeolocation.io/v2/ipgeo?apiKey=" . urlencode($ipgeolocation_api_key) . "&ip=" . urlencode($ip_address);
            
            $response = wp_remote_get($ipgeolocation_url, array(
                'timeout' => 5,
                'user-agent' => 'X8-EVS-Plugin/1.0'
            ));

            if (!is_wp_error($response)) {
                $body = wp_remote_retrieve_body($response);
                $data = json_decode($body, true);

                if ($data && isset($data['location'])) {
                    $parsed_data = $this->parse_ipgeolocation_response($data);
                    if ($parsed_data && isset($parsed_data['country']) && !empty($parsed_data['country'])) {
                        if (defined('WP_DEBUG') && WP_DEBUG) {
                            error_log("X8 Verify: Geolocation data from ipgeolocation for IP: {$ip_address}");
                        }
                        return $parsed_data;
                    }
                }
            }
            
            // Log error if IPGeolocation failed but continue to other services
            if (defined('WP_DEBUG') && WP_DEBUG) {
                $error_msg = is_wp_error($response) ? $response->get_error_message() : 'Invalid response';
                error_log("X8 Verify: IPGeolocation service failed for IP: {$ip_address} - {$error_msg}, trying fallback services");
            }
        }

        // Fallback services
        $services = array(
            'ip-api' => array(
                'url' => "http://ip-api.com/json/{$ip_address}",
                'parser' => 'parse_ip_api_response'
            ),
            'ipapi' => array(
                'url' => "https://ipapi.co/{$ip_address}/json/",
                'parser' => 'parse_ipapi_response'
            )
        );

        foreach ($services as $service_name => $service_config) {
            $response = wp_remote_get($service_config['url'], array(
                'timeout' => 5,
                'user-agent' => 'X8-EVS-Plugin/1.0'
            ));

            if (is_wp_error($response)) {
                continue;
            }

            $body = wp_remote_retrieve_body($response);
            $data = json_decode($body, true);

            if ($data) {
                $parsed_data = $this->{$service_config['parser']}($data);
                if ($parsed_data && isset($parsed_data['country']) && !empty($parsed_data['country'])) {
                    if (defined('WP_DEBUG') && WP_DEBUG) {
                        error_log("X8 Verify: Geolocation data from {$service_name} for IP: {$ip_address}");
                    }
                    return $parsed_data;
                }
            }
        }

        if (defined('WP_DEBUG') && WP_DEBUG) {
            error_log("X8 Verify: All geolocation services failed for IP: {$ip_address}");
        }

        return false;
    }

    /**
     * Parse IP-API response
     */
    private function parse_ip_api_response($data) {
        if (!isset($data['status']) || $data['status'] !== 'success') {
            return false;
        }

        return array(
            'state' => $data['regionCode'] ?? $data['region'],
            'country' => $data['countryCode'] ?? '',
            'city' => $data['city'] ?? '',
            'region' => $data['regionName'] ?? '',
            'isp' => $data['isp'] ?? '',
            'timezone' => $data['timezone'] ?? '',
            'service' => 'ip-api'
        );
    }

    /**
     * Parse IPAPI (ipapi.co) response.
     * Documented shape: country + country_code are ISO-3166 alpha-2; country_name is the display name;
     * region is the region name, region_code is the subdivision code (e.g. US state).
     *
     * @param array $data Decoded JSON from https://ipapi.co/{ip}/json/
     */
    private function parse_ipapi_response($data) {
        if (!is_array($data)) {
            return false;
        }
        if (!empty($data['error']) || !empty($data['reserved']) || !empty($data['bogon'])) {
            return false;
        }

        $country_code = '';
        if (!empty($data['country_code'])) {
            $country_code = (string) $data['country_code'];
        } elseif (!empty($data['country']) && strlen((string) $data['country']) === 2) {
            // ipapi.co sets "country" to the same ISO code as country_code in many responses
            $country_code = (string) $data['country'];
        }
        if ($country_code === '') {
            return false;
        }

        return array(
            'state' => $data['region_code'] ?? $data['region'] ?? '',
            'country' => $country_code,
            'city' => $data['city'] ?? '',
            'region' => $data['region'] ?? '',
            'isp' => $data['org'] ?? '',
            'timezone' => $data['timezone'] ?? '',
            'service' => 'ipapi'
        );
    }

    /**
     * Parse IPGeolocation response
     */
    private function parse_ipgeolocation_response($data) {
        if (!isset($data['location']) || empty($data['location'])) {
            return false;
        }

        $location = $data['location'];
        
        // Extract state code from "US-CA" format to just "CA"
        $state_code = '';
        if (!empty($location['state_code'])) {
            $state_parts = explode('-', $location['state_code']);
            $state_code = end($state_parts); // Get last part (e.g., "CA" from "US-CA")
        } elseif (!empty($location['state_prov'])) {
            $state_code = $location['state_prov'];
        }

        return array(
            'state' => $state_code,
            'country' => $location['country_code2'] ?? '',
            'city' => $location['city'] ?? '',
            'region' => $location['state_prov'] ?? '',
            'isp' => '', // IPGeolocation doesn't provide ISP in this response
            'timezone' => '', // IPGeolocation doesn't provide timezone in this response
            'latitude' => $location['latitude'] ?? '',
            'longitude' => $location['longitude'] ?? '',
            'service' => 'ipgeolocation'
        );
    }

    /**
     * Get state name from state code
     */
    private function get_state_name($state_code) {
        $states = array(
            'AL' => 'Alabama', 'AK' => 'Alaska', 'AZ' => 'Arizona', 'AR' => 'Arkansas',
            'CA' => 'California', 'CO' => 'Colorado', 'CT' => 'Connecticut', 'DE' => 'Delaware',
            'FL' => 'Florida', 'GA' => 'Georgia', 'HI' => 'Hawaii', 'ID' => 'Idaho',
            'IL' => 'Illinois', 'IN' => 'Indiana', 'IA' => 'Iowa', 'KS' => 'Kansas',
            'KY' => 'Kentucky', 'LA' => 'Louisiana', 'ME' => 'Maine', 'MD' => 'Maryland',
            'MA' => 'Massachusetts', 'MI' => 'Michigan', 'MN' => 'Minnesota', 'MS' => 'Mississippi',
            'MO' => 'Missouri', 'MT' => 'Montana', 'NE' => 'Nebraska', 'NV' => 'Nevada',
            'NH' => 'New Hampshire', 'NJ' => 'New Jersey', 'NM' => 'New Mexico', 'NY' => 'New York',
            'NC' => 'North Carolina', 'ND' => 'North Dakota', 'OH' => 'Ohio', 'OK' => 'Oklahoma',
            'OR' => 'Oregon', 'PA' => 'Pennsylvania', 'RI' => 'Rhode Island', 'SC' => 'South Carolina',
            'SD' => 'South Dakota', 'TN' => 'Tennessee', 'TX' => 'Texas', 'UT' => 'Utah',
            'VT' => 'Vermont', 'VA' => 'Virginia', 'WA' => 'Washington', 'WV' => 'West Virginia',
            'WI' => 'Wisconsin', 'WY' => 'Wyoming', 'DC' => 'District of Columbia'
        );

        return $states[strtoupper($state_code)] ?? $state_code;
    }

    /**
     * Get country name from country code
     */
    private function get_country_name($country_code) {
        $countries = array(
            'US' => 'United States', 'CA' => 'Canada', 'GB' => 'United Kingdom', 'AU' => 'Australia', 'DE' => 'Germany',
            'FR' => 'France', 'IT' => 'Italy', 'ES' => 'Spain', 'NL' => 'Netherlands', 'BE' => 'Belgium',
            'CH' => 'Switzerland', 'AT' => 'Austria', 'SE' => 'Sweden', 'NO' => 'Norway', 'DK' => 'Denmark',
            'FI' => 'Finland', 'IE' => 'Ireland', 'PT' => 'Portugal', 'LU' => 'Luxembourg', 'IS' => 'Iceland',
            'MT' => 'Malta', 'CY' => 'Cyprus', 'GR' => 'Greece', 'PL' => 'Poland', 'CZ' => 'Czech Republic',
            'HU' => 'Hungary', 'SK' => 'Slovakia', 'SI' => 'Slovenia', 'HR' => 'Croatia', 'BG' => 'Bulgaria',
            'RO' => 'Romania', 'LT' => 'Lithuania', 'LV' => 'Latvia', 'EE' => 'Estonia', 'JP' => 'Japan',
            'KR' => 'South Korea', 'SG' => 'Singapore', 'HK' => 'Hong Kong', 'TW' => 'Taiwan', 'NZ' => 'New Zealand',
            'BR' => 'Brazil', 'AR' => 'Argentina', 'CL' => 'Chile', 'CO' => 'Colombia', 'MX' => 'Mexico',
            'PE' => 'Peru', 'VE' => 'Venezuela', 'UY' => 'Uruguay', 'PY' => 'Paraguay', 'BO' => 'Bolivia',
            'EC' => 'Ecuador', 'GY' => 'Guyana', 'SR' => 'Suriname', 'GF' => 'French Guiana', 'FK' => 'Falkland Islands',
            'ZA' => 'South Africa', 'EG' => 'Egypt', 'NG' => 'Nigeria', 'KE' => 'Kenya', 'GH' => 'Ghana',
            'MA' => 'Morocco', 'TN' => 'Tunisia', 'DZ' => 'Algeria', 'LY' => 'Libya', 'SD' => 'Sudan',
            'ET' => 'Ethiopia', 'UG' => 'Uganda', 'TZ' => 'Tanzania', 'ZW' => 'Zimbabwe', 'BW' => 'Botswana',
            'NA' => 'Namibia', 'SZ' => 'Swaziland', 'LS' => 'Lesotho', 'MW' => 'Malawi', 'ZM' => 'Zambia',
            'AO' => 'Angola', 'MZ' => 'Mozambique', 'MG' => 'Madagascar', 'MU' => 'Mauritius', 'SC' => 'Seychelles',
            'CN' => 'China', 'IN' => 'India', 'ID' => 'Indonesia', 'TH' => 'Thailand', 'VN' => 'Vietnam',
            'PH' => 'Philippines', 'MY' => 'Malaysia', 'BN' => 'Brunei', 'KH' => 'Cambodia', 'LA' => 'Laos',
            'MM' => 'Myanmar', 'BD' => 'Bangladesh', 'LK' => 'Sri Lanka', 'MV' => 'Maldives', 'NP' => 'Nepal',
            'BT' => 'Bhutan', 'PK' => 'Pakistan', 'AF' => 'Afghanistan', 'IR' => 'Iran', 'IQ' => 'Iraq',
            'SA' => 'Saudi Arabia', 'AE' => 'United Arab Emirates', 'QA' => 'Qatar', 'KW' => 'Kuwait', 'BH' => 'Bahrain',
            'OM' => 'Oman', 'YE' => 'Yemen', 'JO' => 'Jordan', 'LB' => 'Lebanon', 'SY' => 'Syria',
            'IL' => 'Israel', 'PS' => 'Palestine', 'TR' => 'Turkey', 'RU' => 'Russia', 'UA' => 'Ukraine',
            'BY' => 'Belarus', 'MD' => 'Moldova', 'GE' => 'Georgia', 'AM' => 'Armenia', 'AZ' => 'Azerbaijan',
            'KZ' => 'Kazakhstan', 'UZ' => 'Uzbekistan', 'TM' => 'Turkmenistan', 'TJ' => 'Tajikistan', 'KG' => 'Kyrgyzstan',
            'MN' => 'Mongolia', 'KP' => 'North Korea', 'FJ' => 'Fiji', 'PG' => 'Papua New Guinea', 'SB' => 'Solomon Islands',
            'VU' => 'Vanuatu', 'NC' => 'New Caledonia', 'PF' => 'French Polynesia', 'WS' => 'Samoa', 'TO' => 'Tonga',
            'KI' => 'Kiribati', 'TV' => 'Tuvalu', 'NR' => 'Nauru', 'PW' => 'Palau', 'FM' => 'Micronesia',
            'MH' => 'Marshall Islands', 'AS' => 'American Samoa', 'GU' => 'Guam', 'MP' => 'Northern Mariana Islands',
            'VI' => 'U.S. Virgin Islands', 'PR' => 'Puerto Rico', 'DO' => 'Dominican Republic', 'HT' => 'Haiti',
            'JM' => 'Jamaica', 'CU' => 'Cuba', 'BS' => 'Bahamas', 'BB' => 'Barbados', 'TT' => 'Trinidad and Tobago',
            'GD' => 'Grenada', 'LC' => 'Saint Lucia', 'VC' => 'Saint Vincent and the Grenadines', 'AG' => 'Antigua and Barbuda',
            'KN' => 'Saint Kitts and Nevis', 'DM' => 'Dominica', 'BZ' => 'Belize', 'GT' => 'Guatemala', 'HN' => 'Honduras',
            'SV' => 'El Salvador', 'NI' => 'Nicaragua', 'CR' => 'Costa Rica', 'PA' => 'Panama'
        );

        return $countries[strtoupper($country_code)] ?? $country_code;
    }

    /**
     * Get VPN detection data for an IP address with caching
     */
    private function get_vpn_detection_data($ip_address) {
        // Check cache first
        $cached_data = $this->get_cached_vpn_detection($ip_address);
        if ($cached_data !== false) {
            return $cached_data;
        }

        // Try multiple VPN detection services
        $vpn_data = $this->call_multiple_vpn_detection_services($ip_address);
        
        if ($vpn_data) {
            // Cache the result for 48 hours
            $this->cache_vpn_detection_data($ip_address, $vpn_data);
            return $vpn_data;
        }

        return false;
    }

    /**
     * Get cached VPN detection data
     */
    private function get_cached_vpn_detection($ip_address) {
        $cache_key = 'x8_evs_vpn_' . md5($ip_address);
        $cached_data = get_transient($cache_key);
        
        if ($cached_data !== false) {
            // Add cache hit indicator for debugging
            if (defined('WP_DEBUG') && WP_DEBUG) {
                error_log("X8 Verify: VPN detection cache hit for IP: {$ip_address}");
            }
            return $cached_data;
        }
        
        return false;
    }

    /**
     * Cache VPN detection data
     */
    private function cache_vpn_detection_data($ip_address, $vpn_data) {
        $cache_key = 'x8_evs_vpn_' . md5($ip_address);
        $cache_duration = 48 * HOUR_IN_SECONDS; // 48 hours
        
        set_transient($cache_key, $vpn_data, $cache_duration);
        
        if (defined('WP_DEBUG') && WP_DEBUG) {
            error_log("X8 Verify: Cached VPN detection data for IP: {$ip_address}");
        }
    }

    /**
     * Call multiple VPN detection services for redundancy
     */
    private function call_multiple_vpn_detection_services($ip_address) {
        $services = array();

        $ipapi_co_api_key = get_option('x8_evs_ipapi_co_api', '');
        if (!empty($ipapi_co_api_key)) {
            $services['ipapi-co'] = array(
                'url' => 'https://ipapi.co/' . rawurlencode($ip_address) . '/json/?key=' . rawurlencode($ipapi_co_api_key),
                'parser' => 'parse_ipapi_vpn_response'
            );
        }

        $services['ip-api-proxy'] = array(
            'url' => "http://ip-api.com/json/{$ip_address}?fields=status,message,proxy,hosting,query,isp,org,as",
            'parser' => 'parse_ip_api_proxy_response'
        );
        $services['ip-api'] = array(
            'url' => "http://ip-api.com/json/{$ip_address}",
            'parser' => 'parse_ip_api_vpn_response'
        );
        $services['ipapi'] = array(
            'url' => "https://ipapi.co/{$ip_address}/json/",
            'parser' => 'parse_ipapi_vpn_response'
        );

        foreach ($services as $service_name => $service_config) {
            $response = wp_remote_get($service_config['url'], array(
                'timeout' => 5,
                'user-agent' => 'X8-EVS-Plugin/1.0'
            ));

            if (is_wp_error($response)) {
                continue;
            }

            $body = wp_remote_retrieve_body($response);
            $data = json_decode($body, true);

            if ($data) {
                $parsed_data = $this->{$service_config['parser']}($data);
                if ($parsed_data && isset($parsed_data['is_vpn'])) {
                    if (defined('WP_DEBUG') && WP_DEBUG) {
                        error_log("X8 Verify: VPN detection data from {$service_name} for IP: {$ip_address}");
                    }
                    return $parsed_data;
                }
            }
        }

        if (defined('WP_DEBUG') && WP_DEBUG) {
            error_log("X8 Verify: All VPN detection services failed for IP: {$ip_address}");
        }

        return false;
    }

    /**
     * Parse IP-API proxy detection response (with fields parameter)
     */
    private function parse_ip_api_proxy_response($data) {
        if (!isset($data['status']) || $data['status'] !== 'success') {
            return false;
        }

        // Direct proxy detection from IP-API
        $is_proxy = isset($data['proxy']) ? (bool) $data['proxy'] : false;
        $is_hosting = isset($data['hosting']) ? (bool) $data['hosting'] : false;
        $isp = $data['isp'] ?? '';
        $org = $data['org'] ?? '';
        $as = $data['as'] ?? '';
        
        // Determine VPN type based on detection
        $vpn_type = '';
        if ($is_proxy && $is_hosting) {
            $vpn_type = 'Hosting/Proxy Service';
        } elseif ($is_proxy) {
            $vpn_type = 'Proxy Service';
        } elseif ($is_hosting) {
            $vpn_type = 'Hosting Service';
        }

        // Also check for VPN indicators in ISP/Org for additional detection
        $vpn_indicators = array(
            // 🔒 Popular VPN Providers
            'vpn', 'proxy', 'tor', 'anonymizer',
            'nordvpn', 'expressvpn', 'surfshark', 'cyberghost',
            'private internet access', 'pia', 'windscribe', 'protonvpn',
            'tunnelbear', 'ipvanish', 'hotspot shield', 'vyprvpn', 'purevpn',
            'hidemyass', 'strongvpn', 'zenmate', 'mullvad', 'hola vpn',
            'avast secureline', 'opera vpn', 'ivacy', 'ibvpn', 'betternet',
            'securevpn', 'fastestvpn', 'hide.me', 'privatevpn', 'hide my ip',
        
            // 🏢 Hosting / Cloud Providers (often used by VPNs/proxies)
            'leaseweb', 'm247', 'contabo', 'ovh', 'digitalocean', 'linode',
            'aws', 'amazon', 'azure', 'google', 'gcp', 'oracle cloud',
            'kimsufi', 'hetzner', 'vultr', 'scaleway', 'upcloud', 'gcore',
            'choopa', 'nocix', 'colo', 'colo4', 'soyoustart', 'frantech',
            'datashack', 'netcup', 'packet', 'cloudsigma', 'akamaitechnologies',
            'stackpath', 'docebo', 'rackspace', 'ionos', 'ovhcloud', 'cloudways',
            'cloud', 'datacenter', 'data center', 'hosting', 'host', 'server',
        
            // 🌍 Residential Proxy Providers
            'brightdata', 'oxylabs', 'smartproxy', 'residential proxy',
            'luminati', 'soax', 'shifter', 'packetstream', 'iproyal', 'geosurf',
            'netnut', 'stormproxies', 'rayobyte', 'proxyrack', 'scraperapi',
        
            // 🔍 Known ASN or Org Patterns (some partial)
            'AS-LEASEWEB', 'LEASEWEB', 'AS-M247', 'M247', 'OVH SAS',
            'DIGITALOCEAN-ASN', 'AMAZON-02', 'GOOGLE-CLOUD', 'HETZNER-ONLINE',
            'SCALAXY', 'VULTR', 'CLOUDFLARENET', 'FASTLY', 'RESELLER',
            'CDN77', 'CLOUDFRONT', 'CLOUDBLOCK', 'TOR-EXIT', 'TOR-RELAY'
        );
        
        $additional_vpn_detected = false;
        foreach ($vpn_indicators as $indicator) {
            if (stripos($isp, $indicator) !== false || 
                stripos($org, $indicator) !== false || 
                stripos($as, $indicator) !== false) {
                $additional_vpn_detected = true;
                if (empty($vpn_type)) {
                    $vpn_type = 'VPN/Proxy Service';
                }
                break;
            }
        }

        // Consider it a VPN/proxy if either direct detection or ISP-based detection found it
        $is_vpn = $is_proxy || $is_hosting || $additional_vpn_detected;

        return array(
            'is_vpn' => $is_vpn,
            'is_proxy' => $is_proxy,
            'is_hosting' => $is_hosting,
            'vpn_type' => $vpn_type,
            'isp' => $isp,
            'org' => $org,
            'as' => $as,
            'service' => 'ip-api-proxy'
        );
    }

    /**
     * Parse IP-API VPN detection response
     */
    private function parse_ip_api_vpn_response($data) {
        if (!isset($data['status']) || $data['status'] !== 'success') {
            return false;
        }

        // IP-API doesn't directly provide VPN detection, but we can infer from ISP/organization
        $isp = $data['isp'] ?? '';
        $org = $data['org'] ?? '';
        $as = $data['as'] ?? '';
        
        // Common VPN/Proxy indicators
        $vpn_indicators = array(
            // 🔒 Popular VPN Providers
            'vpn', 'proxy', 'tor', 'anonymizer',
            'nordvpn', 'expressvpn', 'surfshark', 'cyberghost',
            'private internet access', 'pia', 'windscribe', 'protonvpn',
            'tunnelbear', 'ipvanish', 'hotspot shield', 'vyprvpn', 'purevpn',
            'hidemyass', 'strongvpn', 'zenmate', 'mullvad', 'hola vpn',
            'avast secureline', 'opera vpn', 'ivacy', 'ibvpn', 'betternet',
            'securevpn', 'fastestvpn', 'hide.me', 'privatevpn', 'hide my ip',
        
            // 🏢 Hosting / Cloud Providers (often used by VPNs/proxies)
            'leaseweb', 'm247', 'contabo', 'ovh', 'digitalocean', 'linode',
            'aws', 'amazon', 'azure', 'google', 'gcp', 'oracle cloud',
            'kimsufi', 'hetzner', 'vultr', 'scaleway', 'upcloud', 'gcore',
            'choopa', 'nocix', 'colo', 'colo4', 'soyoustart', 'frantech',
            'datashack', 'netcup', 'packet', 'cloudsigma', 'akamaitechnologies',
            'stackpath', 'docebo', 'rackspace', 'ionos', 'ovhcloud', 'cloudways',
            'cloud', 'datacenter', 'data center', 'hosting', 'host', 'server',
        
            // 🌍 Residential Proxy Providers
            'brightdata', 'oxylabs', 'smartproxy', 'residential proxy',
            'luminati', 'soax', 'shifter', 'packetstream', 'iproyal', 'geosurf',
            'netnut', 'stormproxies', 'rayobyte', 'proxyrack', 'scraperapi',
        
            // 🔍 Known ASN or Org Patterns (some partial)
            'AS-LEASEWEB', 'LEASEWEB', 'AS-M247', 'M247', 'OVH SAS',
            'DIGITALOCEAN-ASN', 'AMAZON-02', 'GOOGLE-CLOUD', 'HETZNER-ONLINE',
            'SCALAXY', 'VULTR', 'CLOUDFLARENET', 'FASTLY', 'RESELLER',
            'CDN77', 'CLOUDFRONT', 'CLOUDBLOCK', 'TOR-EXIT', 'TOR-RELAY'
        );
        
        $is_vpn = false;
        $vpn_type = '';
        
        foreach ($vpn_indicators as $indicator) {
            if (stripos($isp, $indicator) !== false || 
                stripos($org, $indicator) !== false || 
                stripos($as, $indicator) !== false) {
                $is_vpn = true;
                $vpn_type = 'VPN/Proxy Service';
                break;
            }
        }

        return array(
            'is_vpn' => $is_vpn,
            'is_proxy' => $is_vpn, // Treat VPN as proxy for blocking purposes
            'vpn_type' => $vpn_type,
            'isp' => $isp,
            'org' => $org,
            'as' => $as,
            'service' => 'ip-api'
        );
    }

    /**
     * Parse IPAPI VPN detection response
     */
    private function parse_ipapi_vpn_response($data) {
        if (!is_array($data)) {
            return false;
        }
        if (!empty($data['error']) || !empty($data['reserved']) || !empty($data['bogon'])) {
            return false;
        }

        $org = $data['org'] ?? '';
        $asn = $data['asn'] ?? '';
        
        // Common VPN/Proxy indicators
        $vpn_indicators = array(
            // 🔒 Popular VPN Providers
            'vpn', 'proxy', 'tor', 'anonymizer',
            'nordvpn', 'expressvpn', 'surfshark', 'cyberghost',
            'private internet access', 'pia', 'windscribe', 'protonvpn',
            'tunnelbear', 'ipvanish', 'hotspot shield', 'vyprvpn', 'purevpn',
            'hidemyass', 'strongvpn', 'zenmate', 'mullvad', 'hola vpn',
            'avast secureline', 'opera vpn', 'ivacy', 'ibvpn', 'betternet',
            'securevpn', 'fastestvpn', 'hide.me', 'privatevpn', 'hide my ip',
        
            // 🏢 Hosting / Cloud Providers (often used by VPNs/proxies)
            'leaseweb', 'm247', 'contabo', 'ovh', 'digitalocean', 'linode',
            'aws', 'amazon', 'azure', 'google', 'gcp', 'oracle cloud',
            'kimsufi', 'hetzner', 'vultr', 'scaleway', 'upcloud', 'gcore',
            'choopa', 'nocix', 'colo', 'colo4', 'soyoustart', 'frantech',
            'datashack', 'netcup', 'packet', 'cloudsigma', 'akamaitechnologies',
            'stackpath', 'docebo', 'rackspace', 'ionos', 'ovhcloud', 'cloudways',
            'cloud', 'datacenter', 'data center', 'hosting', 'host', 'server',
        
            // 🌍 Residential Proxy Providers
            'brightdata', 'oxylabs', 'smartproxy', 'residential proxy',
            'luminati', 'soax', 'shifter', 'packetstream', 'iproyal', 'geosurf',
            'netnut', 'stormproxies', 'rayobyte', 'proxyrack', 'scraperapi',
        
            // 🔍 Known ASN or Org Patterns (some partial)
            'AS-LEASEWEB', 'LEASEWEB', 'AS-M247', 'M247', 'OVH SAS',
            'DIGITALOCEAN-ASN', 'AMAZON-02', 'GOOGLE-CLOUD', 'HETZNER-ONLINE',
            'SCALAXY', 'VULTR', 'CLOUDFLARENET', 'FASTLY', 'RESELLER',
            'CDN77', 'CLOUDFRONT', 'CLOUDBLOCK', 'TOR-EXIT', 'TOR-RELAY'
        );
        
        $is_vpn = false;
        $vpn_type = '';
        
        foreach ($vpn_indicators as $indicator) {
            if (stripos($org, $indicator) !== false || 
                stripos($asn, $indicator) !== false) {
                $is_vpn = true;
                $vpn_type = 'VPN/Proxy Service';
                break;
            }
        }

        return array(
            'is_vpn' => $is_vpn,
            'is_proxy' => $is_vpn, // Treat VPN as proxy for blocking purposes
            'vpn_type' => $vpn_type,
            'org' => $org,
            'asn' => $asn,
            'service' => 'ipapi'
        );
    }

    /**
     * Redirect user to blocked state page
     */
    private function redirect_to_blocked_page($block_reason) {
        // Prevent multiple executions per request
        static $redirected = false;
        if ($redirected) {
            if (defined('WP_DEBUG') && WP_DEBUG) {
                error_log('X8 Verify: Already redirected in this request, skipping duplicate redirect');
            }
            return;
        }
        
        // Don't redirect if already on blocked page
        if ($this->is_on_blocked_page()) {
            if (defined('WP_DEBUG') && WP_DEBUG) {
                error_log('X8 Verify: Already on blocked page, skipping redirect');
            }
            return;
        }

        // Mark as redirected to prevent duplicate tracking
        $redirected = true;

        // Clear any existing output to prevent header issues
        if (ob_get_level()) {
            ob_end_clean();
        }

        // Create blocked page URL with reason
        $blocked_page_url = home_url('/blocked-state');
        $query_args = array(
            'reason' => urlencode($block_reason['type']),
            'message' => urlencode($block_reason['message'])
        );
        
        // Add state data if available
        if (isset($block_reason['state']) && isset($block_reason['state_name'])) {
            $query_args['state'] = urlencode($block_reason['state']);
            $query_args['state_name'] = urlencode($block_reason['state_name']);
        }
        
        // Add country data if available
        if (isset($block_reason['country']) && isset($block_reason['country_name'])) {
            $query_args['country'] = urlencode($block_reason['country']);
            $query_args['country_name'] = urlencode($block_reason['country_name']);
        }
        
        $blocked_page_url = add_query_arg($query_args, $blocked_page_url);

        // Log the block for debugging
        $this->log_block($block_reason);
        
        // Track the blocked user in database
        $this->track_blocked_user($block_reason);

        if (defined('WP_DEBUG') && WP_DEBUG) {
            error_log('X8 Verify: Redirecting to blocked page: ' . $blocked_page_url);
        }

        // Use JavaScript redirect as fallback if headers already sent
        if (headers_sent()) {
            if (defined('WP_DEBUG') && WP_DEBUG) {
                error_log('X8 Verify: Headers already sent, using JavaScript redirect');
            }
            echo '<script type="text/javascript">window.location.href = "' . esc_js($blocked_page_url) . '";</script>';
            echo '<noscript><meta http-equiv="refresh" content="0;url=' . esc_attr($blocked_page_url) . '"></noscript>';
            exit;
        }

        wp_redirect($blocked_page_url);
        exit;
    }

    /**
     * Check if user is currently on the blocked state page
     */
    private function is_on_blocked_page() {
        $request_uri = $_SERVER['REQUEST_URI'] ?? '';
        
        // Remove query parameters for comparison
        $clean_uri = strtok($request_uri, '?');
        
        // Check if we're on the blocked page
        $is_blocked_page = (
            strpos($clean_uri, '/blocked-state') !== false ||
            $clean_uri === '/blocked-state' ||
            strpos($request_uri, '/blocked-state') !== false
        );
        
        // Also check if we have blocking reason parameters
        $has_blocking_reason = isset($_GET['reason']) && in_array($_GET['reason'], [
            'geolocation_country', 
            'geolocation_state', 
            'id_address', 
            'vpn'
        ]);
        
        // Debug logging
        if (defined('WP_DEBUG') && WP_DEBUG) {
            error_log("X8 Verify: Checking blocked page - URI: {$request_uri}, Clean URI: {$clean_uri}, Is blocked: " . ($is_blocked_page ? 'YES' : 'NO') . ", Has reason: " . ($has_blocking_reason ? 'YES' : 'NO'));
        }
        
        return $is_blocked_page || $has_blocking_reason;
    }

    /**
     * Log block for debugging purposes
     */
    private function log_block($block_reason) {
        $current_user = wp_get_current_user();
        
        // Only log if WP_DEBUG is enabled
        if (defined('WP_DEBUG') && WP_DEBUG) {
            if ($block_reason['type'] === 'vpn') {
                error_log(sprintf(
                    'X8 Verify: Blocking user %d (%s) due to %s - IP: %s, VPN Type: %s',
                    $current_user->ID,
                    $current_user->user_email,
                    $block_reason['type'],
                    $block_reason['ip'],
                    $block_reason['vpn_type']
                ));
            } elseif ($block_reason['type'] === 'geolocation_country') {
                error_log(sprintf(
                    'X8 Verify: Blocking user %d (%s) due to %s - Country: %s',
                    $current_user->ID,
                    $current_user->user_email,
                    $block_reason['type'],
                    $block_reason['country']
                ));
            } elseif (isset($block_reason['state'])) {
                error_log(sprintf(
                    'X8 Verify: Blocking user %d (%s) due to %s - State: %s',
                    $current_user->ID,
                    $current_user->user_email,
                    $block_reason['type'],
                    $block_reason['state']
                ));
            } else {
                error_log(sprintf(
                    'X8 Verify: Blocking user %d (%s) due to %s',
                    $current_user->ID,
                    $current_user->user_email,
                    $block_reason['type']
                ));
            }
        }
    }

    /**
     * Get block reason from URL parameters
     */
    public static function get_block_reason() {
        if (!isset($_GET['reason'])) {
            return false;
        }

        $block_reason = array(
            'type' => sanitize_text_field($_GET['reason']),
            'message' => isset($_GET['message']) ? sanitize_text_field($_GET['message']) : ''
        );

        // Add state data if available
        if (isset($_GET['state']) && isset($_GET['state_name'])) {
            $block_reason['state'] = sanitize_text_field($_GET['state']);
            $block_reason['state_name'] = sanitize_text_field($_GET['state_name']);
        }

        // Add country data if available
        if (isset($_GET['country']) && isset($_GET['country_name'])) {
            $block_reason['country'] = sanitize_text_field($_GET['country']);
            $block_reason['country_name'] = sanitize_text_field($_GET['country_name']);
        }

        return $block_reason;
    }

    /**
     * Full debug payload for the blocked-state page (IP, geo, headers) for support tickets.
     *
     * @return array
     */
    public static function get_blocked_page_debug_payload() {
        return self::get_instance()->collect_blocked_page_debug_payload();
    }

    /**
     * @return array
     */
    private function collect_blocked_page_debug_payload() {
        $ip = $this->get_user_ip();
        $geo = !empty($ip) ? $this->get_geolocation_data($ip) : false;

        $block_reason = self::get_block_reason();

        $ip_headers = array();
        foreach (array(
            'HTTP_CF_CONNECTING_IP',
            'HTTP_CLIENT_IP',
            'HTTP_X_FORWARDED_FOR',
            'HTTP_X_FORWARDED',
            'HTTP_X_CLUSTER_CLIENT_IP',
            'HTTP_FORWARDED_FOR_IP',
            'HTTP_FORWARDED',
            'HTTP_X_REAL_IP',
            'REMOTE_ADDR',
        ) as $header) {
            if (!empty($_SERVER[$header])) {
                $ip_headers[$header] = sanitize_text_field(wp_unslash($_SERVER[$header]));
            }
        }

        $payload = array(
            'timestamp_utc'     => gmdate('c'),
            'timestamp_local'   => current_time('mysql'),
            'timezone'          => function_exists('wp_timezone_string') ? wp_timezone_string() : '',
            'detected_client_ip' => $ip,
            'ip_headers'        => $ip_headers,
            'geolocation'       => is_array($geo) ? $geo : array('_note' => 'Geolocation lookup returned no data.'),
            'block_reason_from_url' => is_array($block_reason) ? $block_reason : array(),
            'request_uri'       => isset($_SERVER['REQUEST_URI']) ? sanitize_text_field(wp_unslash($_SERVER['REQUEST_URI'])) : '',
            'user_agent'        => isset($_SERVER['HTTP_USER_AGENT']) ? sanitize_text_field(wp_unslash($_SERVER['HTTP_USER_AGENT'])) : '',
            'user_id'           => is_user_logged_in() ? (int) get_current_user_id() : 0,
            'user_email'        => is_user_logged_in() ? wp_get_current_user()->user_email : '',
        );

        return apply_filters('x8_evs_blocked_page_debug_payload', $payload);
    }

    /**
     * Clear all geolocation cache
     */
    public static function clear_geolocation_cache() {
        global $wpdb;
        
        // Get all transients that start with our geolocation cache prefix
        $cache_keys = $wpdb->get_col(
            $wpdb->prepare(
                "SELECT option_name FROM {$wpdb->options} WHERE option_name LIKE %s",
                '_transient_x8_evs_geo_%'
            )
        );
        
        $cleared_count = 0;
        foreach ($cache_keys as $cache_key) {
            $transient_name = str_replace('_transient_', '', $cache_key);
            if (delete_transient($transient_name)) {
                $cleared_count++;
            }
        }
        
        return $cleared_count;
    }

    /**
     * Clear all VPN detection cache
     */
    public static function clear_vpn_cache() {
        global $wpdb;
        
        // Get all transients that start with our VPN cache prefix
        $cache_keys = $wpdb->get_col(
            $wpdb->prepare(
                "SELECT option_name FROM {$wpdb->options} WHERE option_name LIKE %s",
                '_transient_x8_evs_vpn_%'
            )
        );
        
        $cleared_count = 0;
        foreach ($cache_keys as $cache_key) {
            $transient_name = str_replace('_transient_', '', $cache_key);
            if (delete_transient($transient_name)) {
                $cleared_count++;
            }
        }
        
        return $cleared_count;
    }

    /**
     * Get geolocation cache statistics
     */
    public static function get_geolocation_cache_stats() {
        global $wpdb;
        
        $cache_keys = $wpdb->get_col(
            $wpdb->prepare(
                "SELECT option_name FROM {$wpdb->options} WHERE option_name LIKE %s",
                '_transient_x8_evs_geo_%'
            )
        );
        
        $total_cached = count($cache_keys);
        $cache_size = 0;
        
        foreach ($cache_keys as $cache_key) {
            $transient_name = str_replace('_transient_', '', $cache_key);
            $cached_data = get_transient($transient_name);
            if ($cached_data) {
                $cache_size += strlen(serialize($cached_data));
            }
        }
        
        return array(
            'total_cached_ips' => $total_cached,
            'cache_size_bytes' => $cache_size,
            'cache_size_mb' => round($cache_size / 1024 / 1024, 2)
        );
    }

    /**
     * Get VPN detection cache statistics
     */
    public static function get_vpn_cache_stats() {
        global $wpdb;
        
        $cache_keys = $wpdb->get_col(
            $wpdb->prepare(
                "SELECT option_name FROM {$wpdb->options} WHERE option_name LIKE %s",
                '_transient_x8_evs_vpn_%'
            )
        );
        
        $total_cached = count($cache_keys);
        $cache_size = 0;
        
        foreach ($cache_keys as $cache_key) {
            $transient_name = str_replace('_transient_', '', $cache_key);
            $cached_data = get_transient($transient_name);
            if ($cached_data) {
                $cache_size += strlen(serialize($cached_data));
            }
        }
        
        return array(
            'total_cached_ips' => $total_cached,
            'cache_size_bytes' => $cache_size,
            'cache_size_mb' => round($cache_size / 1024 / 1024, 2)
        );
    }

    /**
     * Display debug information for testing (only when WP_DEBUG is enabled)
     */
    public function display_debug_info() {
        // Only show on frontend and when WP_DEBUG is enabled
        if (is_admin() || !defined('WP_DEBUG') || !WP_DEBUG) {
            return;
        }

        $ip_address = $this->get_user_ip();
        $geo_data = $this->get_geolocation_data($ip_address);
        $vpn_data = $this->get_vpn_detection_data($ip_address);
        
        // Check if user is logged in
        $is_logged_in = is_user_logged_in();
        $user_info = '';
        if ($is_logged_in) {
            $current_user = wp_get_current_user();
            $user_info = "User ID: {$current_user->ID}, Email: {$current_user->user_email}";
        } else {
            $user_info = "Not logged in";
        }

        echo '<div id="x8-evs-debug-info" style="
            position: fixed;
            bottom: 10px;
            right: 10px;
            background: #000;
            color: #fff;
            padding: 15px;
            border-radius: 5px;
            font-family: monospace;
            font-size: 12px;
            max-width: 400px;
            z-index: 9999;
            box-shadow: 0 2px 10px rgba(0,0,0,0.5);
        ">';
        
        echo '<h4 style="margin: 0 0 10px 0; color: #00ff00;">X8 Verify Debug Info</h4>';
        echo '<div style="margin-bottom: 8px;"><strong>Login Status:</strong> ' . ($is_logged_in ? 'Logged In' : 'Logged Out') . '</div>';
        echo '<div style="margin-bottom: 8px;"><strong>User Info:</strong> ' . esc_html($user_info) . '</div>';
        echo '<div style="margin-bottom: 8px;"><strong>IP Address:</strong> ' . esc_html($ip_address ?: 'Unable to detect') . '</div>';
        
        if ($geo_data) {
            echo '<div style="margin-bottom: 8px;"><strong>Location:</strong> ';
            if (isset($geo_data['country'])) {
                echo esc_html($geo_data['country']);
            }
            if (isset($geo_data['state'])) {
                echo ', ' . esc_html($geo_data['state']);
            }
            if (isset($geo_data['city'])) {
                echo ', ' . esc_html($geo_data['city']);
            }
            echo '</div>';
        }
        
        if ($vpn_data) {
            echo '<div style="margin-bottom: 8px;"><strong>VPN Detection:</strong> ';
            echo ($vpn_data['is_vpn'] || $vpn_data['is_proxy']) ? 'YES' : 'NO';
            if (($vpn_data['is_vpn'] || $vpn_data['is_proxy']) && isset($vpn_data['vpn_type'])) {
                echo ' (' . esc_html($vpn_data['vpn_type']) . ')';
            }
            echo '</div>';
        }
        
        // Show blocking status
        $block_reason = false;
        if ($is_logged_in) {
            $current_user = wp_get_current_user();
            $block_reason = $this->get_cached_blocking_result($current_user->ID);
        } else {
            $block_reason = $this->get_cached_blocking_result_for_ip();
        }
        
        echo '<div style="margin-bottom: 8px;"><strong>Blocking Status:</strong> ';
        if ($block_reason) {
            echo '<span style="color: #ff6b6b;">BLOCKED - ' . esc_html($block_reason['type']) . '</span>';
        } else {
            echo '<span style="color: #51cf66;">ALLOWED</span>';
        }
        echo '</div>';
        
        echo '<div style="font-size: 10px; color: #888; margin-top: 10px;">
            This debug info only shows when WP_DEBUG is enabled.
        </div>';
        
        echo '</div>';
    }

    /**
     * Get real user IP address (not proxy IP)
     * This method prioritizes headers that contain the actual client IP
     */
    private function get_real_user_ip() {
        // Array of possible IP headers (in order of preference for real IP)
        $ip_headers = array(
            'HTTP_CF_CONNECTING_IP',     // Cloudflare (real client IP)
            'HTTP_X_REAL_IP',            // Real IP (often set by reverse proxy)
            'HTTP_X_FORWARDED_FOR',      // Forwarded IP (first IP is usually real)
            'HTTP_CLIENT_IP',            // Client IP
            'HTTP_X_FORWARDED',          // Forwarded IP (alternative)
            'HTTP_X_CLUSTER_CLIENT_IP',  // Cluster client IP
            'HTTP_FORWARDED_FOR_IP',     // Forwarded for IP
            'HTTP_FORWARDED',            // Forwarded
            'REMOTE_ADDR'                // Remote address (fallback)
        );
        
        foreach ($ip_headers as $header) {
            if (!empty($_SERVER[$header])) {
                $ip_list = explode(',', $_SERVER[$header]);
                // Get the first IP (usually the real client IP)
                $ip = trim($ip_list[0]);
                
                // Skip empty IPs
                if (empty($ip)) {
                    continue;
                }
                
                // Validate IP
                if (filter_var($ip, FILTER_VALIDATE_IP) !== false) {
                    // In production, prefer public IPs, but allow private for development
                    if (defined('WP_DEBUG') && WP_DEBUG) {
                        return $ip;
                    } else {
                        // In production, filter out private ranges
                        if (filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE) !== false) {
                            return $ip;
                        }
                    }
                }
            }
        }
        
        // Fallback to REMOTE_ADDR
        $fallback_ip = $_SERVER['REMOTE_ADDR'] ?? '';
        
        if (!empty($fallback_ip) && filter_var($fallback_ip, FILTER_VALIDATE_IP) !== false) {
            if (defined('WP_DEBUG') && WP_DEBUG) {
                return $fallback_ip;
            } else {
                if (filter_var($fallback_ip, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE) !== false) {
                    return $fallback_ip;
                }
            }
        }
        
        return '';
    }

    /**
     * Track blocked user in database
     */
    private function track_blocked_user($block_reason) {
        global $wpdb;
        
        // Prevent duplicate tracking in the same request
        static $tracked = false;
        if ($tracked) {
            if (defined('WP_DEBUG') && WP_DEBUG) {
                error_log('X8 Verify: Already tracked in this request, skipping duplicate tracking');
            }
            return;
        }
        $tracked = true;
        
        $table_name = $wpdb->prefix . 'x8_evs_track_traffic';
        
        // Ensure table exists
        $this->ensure_track_traffic_table_exists();
        
        // Get IP addresses
        $ip_address = $this->get_user_ip();
        $real_ip_address = $this->get_real_user_ip();
        
        // Check if we already tracked this IP + block_type within the last 5 seconds (prevent rapid duplicates)
        // Only check if we have a valid IP address
        if (!empty($ip_address)) {
            // Use cached table existence check (avoid SHOW TABLES on every request)
            static $table_exists_cache = null;
            if ($table_exists_cache === null) {
                $table_exists_cache = ($wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $table_name)) === $table_name);
            }
            
            if ($table_exists_cache) {
                // Optimized query with index usage
                $recent_track = $wpdb->get_var($wpdb->prepare(
                    "SELECT id FROM {$table_name} 
                    WHERE ip_address = %s 
                    AND block_type = %s 
                    AND created_at > DATE_SUB(NOW(), INTERVAL 5 SECOND)
                    LIMIT 1",
                    $ip_address,
                    $block_reason['type']
                ));
                
                if ($recent_track) {
                    if (defined('WP_DEBUG') && WP_DEBUG) {
                        error_log('X8 Verify: Recent track found for IP ' . $ip_address . ' and type ' . $block_reason['type'] . ', skipping duplicate');
                    }
                    return;
                }
            }
        }
        
        // Get geolocation data - always fetch fresh to ensure we have the service field
        // Even if block_reason has geo data, we need to get fresh geo_data to capture the service
        $geo_data = false;
        if (!empty($ip_address)) {
            // Always fetch fresh geolocation data to get the service field
            // This uses cached geolocation data if available, but ensures service is included
            $geo_data = $this->get_geolocation_data($ip_address);
            
            // If block_reason has geo data but geo_data fetch failed, reconstruct from block_reason
            if (!$geo_data && (isset($block_reason['country']) || isset($block_reason['state']))) {
                $geo_data = array(
                    'country' => $block_reason['country'] ?? null,
                    'state' => $block_reason['state'] ?? null,
                    'city' => null,
                    'region' => null,
                    'isp' => null,
                    'service' => $block_reason['service'] ?? null
                );
            }
        }
        
        // Get user information
        $user_id = null;
        $user_email = null;
        if (is_user_logged_in()) {
            $current_user = wp_get_current_user();
            $user_id = $current_user->ID;
            $user_email = $current_user->user_email;
        }
        
        // Get user agent and request URI
        $user_agent = $_SERVER['HTTP_USER_AGENT'] ?? '';
        $request_uri = $_SERVER['REQUEST_URI'] ?? '';
        
        // Determine geolocation service - prioritize block_reason, then geo_data
        $geolocation_service = null;
        if (isset($block_reason['service']) && !empty($block_reason['service'])) {
            $geolocation_service = $block_reason['service'];
        } elseif (isset($geo_data['service']) && !empty($geo_data['service'])) {
            $geolocation_service = $geo_data['service'];
        }
        
        // Prepare data for insertion
        $data = array(
            'ip_address' => $ip_address,
            'real_ip_address' => $real_ip_address,
            'country' => $geo_data['country'] ?? null,
            'country_name' => isset($geo_data['country']) ? $this->get_country_name($geo_data['country']) : null,
            'state' => $geo_data['state'] ?? null,
            'state_name' => isset($geo_data['state']) ? $this->get_state_name($geo_data['state']) : null,
            'city' => $geo_data['city'] ?? null,
            'region' => $geo_data['region'] ?? null,
            'isp' => $geo_data['isp'] ?? null,
            'geolocation_service' => $geolocation_service,
            'block_type' => $block_reason['type'],
            'block_reason' => $block_reason['message'] ?? '',
            'user_id' => $user_id,
            'user_email' => $user_email,
            'user_agent' => $user_agent,
            'request_uri' => $request_uri,
            'is_blocked' => 1,
            'created_at' => current_time('mysql')
        );
        
        // Add state/country data from block reason if available (overrides geo_data)
        if (isset($block_reason['state'])) {
            $data['state'] = $block_reason['state'];
        }
        if (isset($block_reason['state_name'])) {
            $data['state_name'] = $block_reason['state_name'];
        }
        if (isset($block_reason['country'])) {
            $data['country'] = $block_reason['country'];
        }
        if (isset($block_reason['country_name'])) {
            $data['country_name'] = $block_reason['country_name'];
        }
        
        // Debug logging
        if (defined('WP_DEBUG') && WP_DEBUG) {
            error_log('X8 Verify: Tracking traffic - Service: ' . ($geolocation_service ?: 'NULL') . ', Block reason service: ' . (isset($block_reason['service']) ? $block_reason['service'] : 'NOT SET') . ', Geo data service: ' . (isset($geo_data['service']) ? $geo_data['service'] : 'NOT SET'));
        }
        
        // Insert into database asynchronously if possible, or use low priority
        // For now, we'll do a direct insert but it's only called once per block due to static flag
        $result = $wpdb->insert($table_name, $data);
        
        if ($result === false) {
            // Log error if insert failed
            if (defined('WP_DEBUG') && WP_DEBUG) {
                error_log('X8 Verify: Failed to track blocked user - Error: ' . $wpdb->last_error);
                error_log('X8 Verify: Data attempted: ' . print_r($data, true));
            }
        } else {
            if (defined('WP_DEBUG') && WP_DEBUG) {
                error_log('X8 Verify: Tracked blocked user - IP: ' . $ip_address . ', Real IP: ' . $real_ip_address . ', Type: ' . $block_reason['type'] . ', ID: ' . $wpdb->insert_id);
            }
        }
        
        // Note: Database insert is fast, but if you want to make it even faster,
        // you could use wp_schedule_single_event() to do it asynchronously,
        // but that adds complexity and might lose data if cron fails
    }

    /**
     * Ensure track traffic table exists, create if it doesn't
     */
    private function ensure_track_traffic_table_exists() {
        global $wpdb;
        
        $table_name = $wpdb->prefix . 'x8_evs_track_traffic';
        
        // Cache table existence check to avoid repeated queries
        static $table_exists_cache = null;
        if ($table_exists_cache === null) {
            $table_exists = $wpdb->get_var($wpdb->prepare(
                "SHOW TABLES LIKE %s",
                $table_name
            ));
            $table_exists_cache = ($table_exists === $table_name);
        }
        
        if (!$table_exists_cache) {
            $charset_collate = $wpdb->get_charset_collate();
            
            $track_sql = "CREATE TABLE $table_name (
                id bigint(20) NOT NULL AUTO_INCREMENT,
                ip_address varchar(45) NOT NULL,
                real_ip_address varchar(45) DEFAULT NULL,
                country varchar(10) DEFAULT NULL,
                country_name varchar(100) DEFAULT NULL,
                state varchar(10) DEFAULT NULL,
                state_name varchar(100) DEFAULT NULL,
                city varchar(100) DEFAULT NULL,
                region varchar(100) DEFAULT NULL,
                isp varchar(255) DEFAULT NULL,
                geolocation_service varchar(50) DEFAULT NULL,
                block_type varchar(50) NOT NULL,
                block_reason text,
                user_id bigint(20) DEFAULT NULL,
                user_email varchar(255) DEFAULT NULL,
                user_agent text,
                request_uri text,
                is_blocked tinyint(1) DEFAULT 1,
                created_at datetime DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY (id),
                KEY ip_address (ip_address),
                KEY real_ip_address (real_ip_address),
                KEY block_type (block_type),
                KEY created_at (created_at),
                KEY user_id (user_id)
            ) $charset_collate;";
            
            require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
            dbDelta($track_sql);
            
            // Update cache after creation
            $table_exists_cache = true;
            
            if (defined('WP_DEBUG') && WP_DEBUG) {
                error_log('X8 Verify: Created track traffic table');
            }
        } else {
            // Check if geolocation_service column exists, add it if not
            $column_check = $wpdb->get_var($wpdb->prepare(
                "SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA = %s AND TABLE_NAME = %s AND COLUMN_NAME = 'geolocation_service'",
                DB_NAME,
                $table_name
            ));
            
            if (empty($column_check) || $column_check == 0) {
                $result = $wpdb->query("ALTER TABLE {$table_name} ADD COLUMN geolocation_service varchar(50) DEFAULT NULL AFTER isp");
                
                if (defined('WP_DEBUG') && WP_DEBUG) {
                    if ($result !== false) {
                        error_log('X8 Verify: Added geolocation_service column to track traffic table');
                    } else {
                        error_log('X8 Verify: Failed to add geolocation_service column - ' . $wpdb->last_error);
                    }
                }
            }
        }
    }
}

// Initialize the blocking handler using singleton
X8_EVS_Blocking_Handler::get_instance(); 