<?php
/**
 * EVS AssureLocate Handler Class
 *
 * Handles location verification via the EVS AssureLocate web portal flow.
 * Each user's IP is stored in a custom table. As long as the IP stays the
 * same as the last passed verification, no re-verification is required.
 * When the IP changes, a new AssureLocate deferred request link is generated
 * and the customer is redirected to the EVS portal to verify their location.
 *
 * @package X8_EVS
 * @since 1.6.0
 */

// If this file is called directly, abort.
if (!defined('WPINC')) {
    die;
}

class X8_EVS_AssureLocate_Handler {

    /**
     * AssureLocate service URL
     */
    const SERVICE_URL = 'https://blueassure.evssolutions.com/WebServices/Integrated/Main/V300/AssureLocate';

    /**
     * How long a generated portal link stays reusable (seconds)
     */
    const LINK_TTL = 1800; // 30 minutes

    /**
     * Grace period after the customer submitted their location while we
     * wait for the webhook callback with the result (seconds)
     */
    const SUBMITTED_GRACE = 600; // 10 minutes

    /**
     * Query arg used for the return redirect from the EVS portal
     */
    const RETURN_ARG = 'x8_evs_al_return';

    /**
     * Instance of this class
     */
    private static $instance = null;

    /**
     * Get singleton instance
     */
    public static function get_instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    /**
     * Constructor
     */
    private function __construct() {
        // Hooks are registered unconditionally so the ?x8_al_debug=1 debug
        // mode can report when the provider option is not set correctly.
        // check_location_verification() bails early when not enabled.
        add_action('template_redirect', array($this, 'maybe_handle_return'), 1);
        add_action('template_redirect', array($this, 'check_location_verification'), 2);
    }

    /**
     * Whether EVS AssureLocate is the selected location detection service
     */
    public static function is_enabled() {
        return get_option('x8_evs_location_provider', 'ipapi_co') === 'evs_assurelocate';
    }

    /**
     * Get the location trigger mode: 'after_login' (logged-in customers only)
     * or 'global' (every visitor, guests tracked by IP).
     */
    public static function get_trigger() {
        $trigger = get_option('x8_evs_assurelocate_trigger', 'after_login');
        return in_array($trigger, array('after_login', 'global'), true) ? $trigger : 'after_login';
    }

    /**
     * Get the custom table name
     */
    public static function get_table_name() {
        global $wpdb;
        return $wpdb->prefix . 'x8_evs_user_locations';
    }

    /**
     * Create the user locations table
     */
    public static function create_table() {
        global $wpdb;

        $table_name = self::get_table_name();
        $charset_collate = $wpdb->get_charset_collate();

        $sql = "CREATE TABLE $table_name (
            id bigint(20) NOT NULL AUTO_INCREMENT,
            user_id bigint(20) NOT NULL,
            ip_address varchar(45) NOT NULL,
            verified_ip varchar(45) DEFAULT NULL,
            status varchar(20) NOT NULL DEFAULT 'pending',
            deferred_link text,
            transaction_id varchar(64) DEFAULT NULL,
            workflow_outcome varchar(10) DEFAULT NULL,
            vpn_probability varchar(10) DEFAULT NULL,
            vpn_description varchar(255) DEFAULT NULL,
            webhook_response longtext,
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            submitted_at datetime DEFAULT NULL,
            verified_at datetime DEFAULT NULL,
            PRIMARY KEY (id),
            KEY user_id (user_id),
            KEY ip_address (ip_address),
            KEY status (status),
            KEY user_status (user_id, status)
        ) $charset_collate;";

        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
        dbDelta($sql);
    }

    /**
     * Ensure the table exists (self-healing for plugin updates)
     */
    private static function ensure_table_exists() {
        global $wpdb;

        $table_name = self::get_table_name();
        $table_exists = $wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $table_name));

        if ($table_exists !== $table_name) {
            self::create_table();
        }
    }

    /**
     * Handle the customer returning from the EVS portal
     * (?x8_evs_al_return=success|error)
     */
    public function maybe_handle_return() {
        if (!isset($_GET[self::RETURN_ARG])) {
            return;
        }

        // Guests are only part of the flow in "global" trigger mode
        if (!is_user_logged_in() && self::get_trigger() !== 'global') {
            return;
        }

        global $wpdb;
        self::ensure_table_exists();

        $user_id = get_current_user_id();
        $result = sanitize_text_field(wp_unslash($_GET[self::RETURN_ARG]));
        $table_name = self::get_table_name();

        if ($user_id > 0) {
            // Find the user's latest pending record
            $record = $wpdb->get_row($wpdb->prepare(
                "SELECT * FROM $table_name WHERE user_id = %d AND status = 'pending' ORDER BY id DESC LIMIT 1",
                $user_id
            ));
        } else {
            // Guest: identified by IP address
            $current_ip = $this->get_user_ip();
            $record = empty($current_ip) ? null : $wpdb->get_row($wpdb->prepare(
                "SELECT * FROM $table_name WHERE user_id = 0 AND ip_address = %s AND status = 'pending' ORDER BY id DESC LIMIT 1",
                $current_ip
            ));
        }

        if ($record) {
            if ($result === 'success') {
                // Location submitted on the portal; final result arrives via webhook.
                // Also refresh the stored IP to the current one, since some networks
                // (e.g. Cloudflare/iCloud relay) rotate IPs between requests.
                $update = array('status' => 'submitted', 'submitted_at' => current_time('mysql'));
                $current_ip = $this->get_user_ip();
                if (!empty($current_ip)) {
                    $update['ip_address'] = $current_ip;
                }
                $wpdb->update(
                    $table_name,
                    $update,
                    array('id' => $record->id),
                    null,
                    array('%d')
                );
            } else {
                // Something went wrong on the portal; a new link will be generated on next check
                $wpdb->update(
                    $table_name,
                    array('status' => 'error'),
                    array('id' => $record->id),
                    array('%s'),
                    array('%d')
                );
            }
        }

        // Clean the query arg off the URL
        wp_safe_redirect(remove_query_arg(self::RETURN_ARG));
        exit;
    }

    /**
     * Main gate: verify the current user's IP against their last passed
     * location verification and redirect to the EVS portal when needed.
     */
    public function check_location_verification() {
        // Debug trace (requires WP_DEBUG): append ?x8_al_debug=1 to a frontend
        // URL to see the full decision trace instead of being redirected.
        $debug = isset($_GET['x8_al_debug']) && defined('WP_DEBUG') && WP_DEBUG;
        $trace = array();

        $trace['provider_option'] = get_option('x8_evs_location_provider', 'ipapi_co');
        if (!self::is_enabled()) {
            $this->debug_dump($debug, 'STOPPED: provider option is not "evs_assurelocate" - handler inactive', $trace);
            return;
        }

        $check_reason = '';
        if (!$this->should_check($check_reason)) {
            $trace['should_check_failed_because'] = $check_reason;
            $this->debug_dump($debug, 'STOPPED: should_check() returned false', $trace);
            return;
        }

        $user_id = get_current_user_id();
        $is_guest = ($user_id === 0);
        $current_ip = $this->get_user_ip();
        $trace['user_id'] = $user_id;
        $trace['is_guest'] = $is_guest;
        $trace['trigger'] = self::get_trigger();
        $trace['current_ip'] = $current_ip;

        if (empty($current_ip)) {
            $this->debug_dump($debug, 'STOPPED: could not detect a usable IP address', $trace);
            return;
        }

        global $wpdb;
        self::ensure_table_exists();
        $table_name = self::get_table_name();

        // 1. If the current IP matches the latest passed verification, allow.
        if ($is_guest) {
            // Guests are identified by their IP address (user_id = 0)
            $passed = $wpdb->get_row($wpdb->prepare(
                "SELECT * FROM $table_name WHERE user_id = 0 AND status = 'passed' AND (ip_address = %s OR verified_ip = %s) ORDER BY id DESC LIMIT 1",
                $current_ip,
                $current_ip
            ));
        } else {
            $passed = $wpdb->get_row($wpdb->prepare(
                "SELECT * FROM $table_name WHERE user_id = %d AND status = 'passed' ORDER BY id DESC LIMIT 1",
                $user_id
            ));
        }
        $trace['latest_passed_record'] = $passed;

        if ($passed) {
            $verified_ip = !empty($passed->verified_ip) ? $passed->verified_ip : $passed->ip_address;
            if ($verified_ip === $current_ip || $passed->ip_address === $current_ip) {
                $this->debug_dump($debug, 'ALLOWED: current IP matches last passed verification', $trace);
                return; // Same IP as last passed verification - nothing to do
            }

            // Grace window after a recent pass: some networks (Cloudflare/iCloud
            // relay) rotate IPs between requests, which would otherwise force
            // an immediate re-verification right after passing.
            if (!empty($passed->verified_at) && (time() - strtotime($passed->verified_at)) < self::SUBMITTED_GRACE) {
                $this->debug_dump($debug, 'ALLOWED: recent pass grace window (IP rotated after passing)', $trace);
                return;
            }
        }

        // 2. IP changed (or never verified) - look at the latest record.
        // For logged-in users this is deliberately NOT filtered by IP: an
        // in-flight verification (pending/submitted) must be honored even if
        // the IP rotated mid-flow, otherwise the user gets stuck in a loop.
        // Guests have no identity beyond their IP, so their lookup stays
        // IP-filtered to avoid matching other visitors' records.
        if ($is_guest) {
            $record = $wpdb->get_row($wpdb->prepare(
                "SELECT * FROM $table_name WHERE user_id = 0 AND ip_address = %s ORDER BY id DESC LIMIT 1",
                $current_ip
            ));
        } else {
            $record = $wpdb->get_row($wpdb->prepare(
                "SELECT * FROM $table_name WHERE user_id = %d ORDER BY id DESC LIMIT 1",
                $user_id
            ));
        }
        $trace['latest_record'] = $record;

        if ($record) {
            $age = time() - strtotime($record->created_at);
            $trace['latest_record_age_seconds'] = $age;

            // Location submitted, waiting for the webhook result - grace period.
            if ($record->status === 'submitted') {
                $submitted_age = !empty($record->submitted_at) ? (time() - strtotime($record->submitted_at)) : $age;
                if ($submitted_age < self::SUBMITTED_GRACE) {
                    $this->debug_dump($debug, 'ALLOWED: location submitted, waiting for webhook result (grace period)', $trace);
                    return;
                }
            }

            // Pending with a still-fresh portal link - reuse it.
            if ($record->status === 'pending' && !empty($record->deferred_link) && $age < self::LINK_TTL) {
                $this->debug_dump($debug, 'WOULD REDIRECT: reusing existing fresh portal link (no API call)', $trace);
                $this->redirect_to_portal($record->deferred_link);
                return;
            }

            // Failed verification for this IP - block access. A failed result
            // from a different IP falls through to a fresh verification instead.
            if ($record->status === 'failed'
                && ($record->ip_address === $current_ip || $record->verified_ip === $current_ip)) {
                $this->debug_dump($debug, 'WOULD BLOCK: failed verification for this IP', $trace);
                $this->redirect_to_blocked_page($record);
                return;
            }
        }

        // 3. Generate a fresh portal link and send the customer there.
        $api_debug = array();
        $link = $this->generate_location_link($user_id, $current_ip, $api_debug);
        $trace['api_call'] = $api_debug;
        $trace['generated_link'] = $link;

        if ($link) {
            $this->debug_dump($debug, 'WOULD REDIRECT: new portal link generated successfully', $trace);
            $this->redirect_to_portal($link);
        } else {
            // If link generation failed, fail open (do not lock the user out).
            $this->debug_dump($debug, 'STOPPED: link generation FAILED - failing open, user allowed through (see api_call for details)', $trace);
        }
    }

    /**
     * TEMPORARY DEBUG: print the decision trace and stop, when ?x8_al_debug=1
     */
    private function debug_dump($enabled, $decision, $trace) {
        if (!$enabled) {
            return;
        }

        if (ob_get_level()) {
            ob_end_clean();
        }
        status_header(200);
        nocache_headers();
        header('Content-Type: text/html; charset=utf-8');

        echo '<h1>X8 EVS AssureLocate - Decision Debug</h1>';
        echo '<h2 style="color:#d63638;">' . esc_html($decision) . '</h2>';
        echo '<pre style="background:#f5f5f5;padding:15px;font-size:13px;overflow:auto;">';
        var_dump($trace);
        echo '</pre>';
        echo '<p><strong>Debug mode:</strong> no redirect was performed and nothing was changed except possibly a new pending record if a link was generated.</p>';
        exit;
    }

    /**
     * Decide whether the location gate should run for this request
     */
    private function should_check(&$reason = '') {
        // In "after_login" mode only logged-in customers are checked;
        // in "global" mode guests are checked too (tracked by IP).
        if (!is_user_logged_in() && self::get_trigger() !== 'global') {
            $reason = 'user is not logged in (trigger is "after_login")';
            return false;
        }

        if (is_admin() || wp_doing_ajax() || wp_doing_cron()) {
            $reason = 'admin/ajax/cron request';
            return false;
        }

        if (defined('REST_REQUEST') && REST_REQUEST) {
            $reason = 'REST API request';
            return false;
        }

        // Skip administrators
        if (current_user_can('manage_options')) {
            $reason = 'user is an administrator (manage_options)';
            return false;
        }

        // Skip blocked-state page to avoid redirect loops
        $request_uri = $_SERVER['REQUEST_URI'] ?? '';
        if (strpos($request_uri, 'blocked-state') !== false) {
            $reason = 'on blocked-state page';
            return false;
        }

        // Skip login/logout related requests
        if (strpos($request_uri, 'wp-login.php') !== false) {
            $reason = 'on wp-login.php';
            return false;
        }

        return true;
    }

    /**
     * Call the AssureLocate API (DeferredRequestLink mode) and store the
     * pending record. Returns the portal link or false on failure.
     */
    private function generate_location_link($user_id, $ip_address, &$api_debug = array()) {
        $username = get_option('x8_evs_username', '');
        $password = get_option('x8_evs_password', '');

        $api_debug['credentials_configured'] = array(
            'username_set' => !empty($username),
            'password_set' => !empty($password)
        );

        if (empty($username) || empty($password)) {
            $api_debug['result'] = 'FAILED: API credentials (x8_evs_username / x8_evs_password) not configured';
            error_log('X8 EVS AssureLocate: API credentials not configured, skipping location verification');
            return false;
        }

        // Guests (user_id 0) get a reference derived from their IP so the
        // webhook callback can be matched back to the right record.
        $customer_reference = $user_id > 0 ? (string)$user_id : 'g' . md5($ip_address);

        $request_data = array(
            'meta' => array(
                'credentials' => array(
                    'username' => $username,
                    'password' => $password
                ),
                'customerReference' => $customer_reference
            ),
            'data' => array(
                'scanMode' => 'DeferredRequestLink',
                'redirectUrl' => add_query_arg(self::RETURN_ARG, 'success', home_url('/')),
                'errorRedirectUrl' => add_query_arg(self::RETURN_ARG, 'error', home_url('/')),
                'redirectDelay' => 3
            )
        );

        // Debug copy of the request with the password masked
        $masked_request = $request_data;
        $masked_request['meta']['credentials']['password'] = '***MASKED***';
        $api_debug['service_url'] = self::SERVICE_URL;
        $api_debug['request_body'] = $masked_request;

        $response = wp_remote_post(self::SERVICE_URL, array(
            'headers' => array(
                'Content-Type' => 'application/json'
            ),
            'body' => json_encode($request_data),
            'timeout' => 30
        ));

        if (is_wp_error($response)) {
            $api_debug['result'] = 'FAILED: wp_remote_post error';
            $api_debug['wp_error'] = $response->get_error_message();
            error_log('X8 EVS AssureLocate: API request failed - ' . $response->get_error_message());
            return false;
        }

        $body = wp_remote_retrieve_body($response);
        $data = json_decode($body, true);

        $api_debug['http_status'] = wp_remote_retrieve_response_code($response);
        $api_debug['raw_response_body'] = $body;
        $api_debug['decoded_response'] = $data;

        if (!$data || empty($data['data']['deferredRequestLink'])) {
            $api_debug['result'] = 'FAILED: no deferredRequestLink in response';
            error_log('X8 EVS AssureLocate: No deferredRequestLink in response - ' . substr($body, 0, 500));
            return false;
        }

        $api_debug['result'] = 'SUCCESS';

        $link = $data['data']['deferredRequestLink'];

        global $wpdb;
        $wpdb->insert(
            self::get_table_name(),
            array(
                'user_id' => $user_id,
                'ip_address' => $ip_address,
                'status' => 'pending',
                'deferred_link' => $link,
                'transaction_id' => isset($data['meta']['transactionId']) ? (string)$data['meta']['transactionId'] : null,
                'created_at' => current_time('mysql')
            ),
            array('%d', '%s', '%s', '%s', '%s', '%s')
        );

        if ($user_id > 0 && class_exists('X8_EVS_Admin_Settings')) {
            X8_EVS_Admin_Settings::log_customer_activity($user_id, 'assurelocate_link_generated', array(
                'ip_address' => $ip_address,
                'deferred_link' => $link
            ));
        }

        return $link;
    }

    /**
     * Map an AssureLocate failure to the same block types the IP VPN page uses.
     */
    private static function block_type_for_record($record, $message = '') {
        $probability = strtoupper(trim((string) ($record->vpn_probability ?? '')));
        $text = strtolower(trim((string) $message . ' ' . ($record->vpn_description ?? '')));
        if (
            in_array($probability, array('H', 'M'), true)
            || strpos($text, 'vpn') !== false
            || strpos($text, 'proxy') !== false
            || strpos($text, 'tor') !== false
        ) {
            return 'vpn';
        }

        return 'location_verification';
    }

    /**
     * Get an active AssureLocate block reason for a user, if any.
     * Used by the blocking handler so the blocked-state page recheck knows
     * the user is still blocked (prevents redirect loops).
     *
     * @return array|false Block reason array compatible with the blocking handler, or false.
     */
    public static function get_block_reason_for_user($user_id, $current_ip) {
        if (!self::is_enabled() || empty($user_id) || empty($current_ip)) {
            return false;
        }

        global $wpdb;
        self::ensure_table_exists();
        $table_name = self::get_table_name();

        $record = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM $table_name WHERE user_id = %d ORDER BY id DESC LIMIT 1",
            $user_id
        ));

        if (!$record || $record->status !== 'failed') {
            return false;
        }

        // Only block while the user is still on the IP that failed
        if ($record->ip_address !== $current_ip && $record->verified_ip !== $current_ip) {
            return false;
        }

        $message = !empty($record->vpn_description)
            ? $record->vpn_description
            : __('Your location verification did not pass.', 'x8-evs');

        return array(
            'type' => self::block_type_for_record($record, $message),
            'ip' => $current_ip,
            'message' => $message
        );
    }

    /**
     * Get an active AssureLocate block reason for a guest IP (global trigger
     * mode). Used by the blocking handler for logged-out visitors.
     *
     * @return array|false
     */
    public static function get_block_reason_for_ip($current_ip) {
        if (!self::is_enabled() || self::get_trigger() !== 'global' || empty($current_ip)) {
            return false;
        }

        global $wpdb;
        self::ensure_table_exists();
        $table_name = self::get_table_name();

        $record = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM $table_name WHERE user_id = 0 AND (ip_address = %s OR verified_ip = %s) ORDER BY id DESC LIMIT 1",
            $current_ip,
            $current_ip
        ));

        if (!$record || $record->status !== 'failed') {
            return false;
        }

        $message = !empty($record->vpn_description)
            ? $record->vpn_description
            : __('Your location verification did not pass.', 'x8-evs');

        return array(
            'type' => self::block_type_for_record($record, $message),
            'ip' => $current_ip,
            'message' => $message
        );
    }

    /**
     * Whether a webhook payload belongs to AssureLocate (location) rather than
     * identity verification. Detection is intentionally broad: productName is
     * matched case-insensitively, the locate block is found regardless of key
     * casing, and known AssureLocate transaction IDs are recognized even on
     * image-only or error-only callbacks that omit the locate data block.
     */
    public static function is_locate_webhook($webhook_data) {
        if (!is_array($webhook_data)) {
            return false;
        }

        $product = strtolower(trim((string) ($webhook_data['meta']['productName'] ?? '')));
        $product_compact = str_replace(array(' ', '-', '_'), '', $product);
        if ($product_compact !== '' && strpos($product_compact, 'assurelocate') !== false) {
            return true;
        }

        if (!empty(self::get_locate_data($webhook_data))) {
            return true;
        }

        $transaction_id = trim((string) ($webhook_data['meta']['transactionId'] ?? ''));
        if ($transaction_id !== '' && self::transaction_belongs_to_locate($transaction_id)) {
            return true;
        }

        return false;
    }

    /**
     * Extract the AssureLocate data block from a webhook, ignoring key casing.
     *
     * @return array
     */
    public static function get_locate_data($webhook_data) {
        $data = isset($webhook_data['data']) && is_array($webhook_data['data']) ? $webhook_data['data'] : array();

        foreach ($data as $key => $value) {
            if (strtolower((string) $key) === 'assurelocate' && is_array($value)) {
                return $value;
            }
        }

        return array();
    }

    /**
     * Whether this EVS transaction ID was created for an AssureLocate request.
     */
    public static function transaction_belongs_to_locate($transaction_id) {
        $transaction_id = trim((string) $transaction_id);
        if ($transaction_id === '') {
            return false;
        }

        global $wpdb;
        self::ensure_table_exists();
        $table_name = self::get_table_name();

        $found = $wpdb->get_var($wpdb->prepare(
            "SELECT id FROM $table_name WHERE transaction_id = %s LIMIT 1",
            $transaction_id
        ));

        return !empty($found);
    }

    /**
     * Process an AssureLocate webhook by its customerReference.
     * Numeric references are user IDs; references starting with "g" are
     * guest verifications matched by IP hash (global trigger mode).
     *
     * @return array|WP_Error processed data or error
     */
    public static function process_webhook_reference($reference, $webhook_data) {
        $reference = trim((string)$reference);

        if (is_numeric($reference) && intval($reference) > 0) {
            return self::process_webhook(intval($reference), $webhook_data);
        }

        if (strpos($reference, 'g') === 0) {
            global $wpdb;
            self::ensure_table_exists();
            $table_name = self::get_table_name();
            $ip_hash = substr($reference, 1);

            $record = $wpdb->get_row($wpdb->prepare(
                "SELECT * FROM $table_name WHERE user_id = 0 AND MD5(ip_address) = %s AND status IN ('pending', 'submitted') ORDER BY id DESC LIMIT 1",
                $ip_hash
            ));

            if (!$record) {
                return new WP_Error('record_not_found', 'No open AssureLocate verification found for guest reference', array('status' => 404));
            }

            return self::apply_webhook_result($record, $webhook_data);
        }

        return new WP_Error('invalid_reference', 'Unrecognized AssureLocate customer reference', array('status' => 400));
    }

    /**
     * Process an AssureLocate webhook callback for a user.
     * Called by X8_EVS_Webhook_Handler when the payload contains
     * AssureLocate data.
     *
     * @return array|WP_Error processed data or error
     */
    public static function process_webhook($user_id, $webhook_data) {
        global $wpdb;
        self::ensure_table_exists();
        $table_name = self::get_table_name();

        // Match the latest open record for this user
        $record = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM $table_name WHERE user_id = %d AND status IN ('pending', 'submitted') ORDER BY id DESC LIMIT 1",
            $user_id
        ));

        if (!$record) {
            return new WP_Error('record_not_found', 'No open AssureLocate verification found for user', array('status' => 404));
        }

        return self::apply_webhook_result($record, $webhook_data);
    }

    /**
     * Apply an AssureLocate webhook result to a location record
     * (shared between the user and guest webhook paths).
     *
     * @return array|WP_Error processed data or error
     */
    private static function apply_webhook_result($record, $webhook_data) {
        global $wpdb;
        $table_name = self::get_table_name();
        $user_id = (int)$record->user_id;

        // Error webhook: mark the record so a new link gets generated
        if (isset($webhook_data['errors']) && !empty($webhook_data['errors'])) {
            $wpdb->update(
                $table_name,
                array(
                    'status' => 'error',
                    'webhook_response' => wp_json_encode($webhook_data),
                    'verified_at' => current_time('mysql')
                ),
                array('id' => $record->id),
                array('%s', '%s', '%s'),
                array('%d')
            );

            return array('assurelocate' => 'error', 'record_id' => (int)$record->id);
        }

        $outcome_code = strtoupper(trim($webhook_data['data']['workflowOutcome']['code'] ?? ''));
        $assurelocate = self::get_locate_data($webhook_data);
        $vpn_code = strtoupper(trim($assurelocate['vpnProbability']['code'] ?? ''));
        $vpn_description = $assurelocate['vpnProbability']['description'] ?? '';
        $ip_location = $assurelocate['ipLocation'] ?? array();
        $device_location = $assurelocate['deviceLocation'] ?? array();
        $verified_ip = $ip_location['ipAddress'] ?? '';

        $fail_reason = '';

        if ($outcome_code !== '') {
            // Workflow configured on the EVS account: trust its outcome
            $passed = ($outcome_code === 'P');
            if (!$passed) {
                $fail_reason = $webhook_data['data']['workflowOutcome']['description'] ?? '';
            }
        } else {
            // Workflow disabled on the EVS account ("Workflow Disabled"):
            // evaluate the result against the plugin's own blocking settings,
            // so disabled options (VPN blocking, geolocation blocking) are skipped.
            $passed = true;
            $settings = class_exists('X8_EVS_Admin_Settings');

            // VPN blocking (only when the "Block VPN Connections" option is on)
            if ($settings && X8_EVS_Admin_Settings::is_vpn_blocking_enabled()) {
                $vpn_detected = ($vpn_code === 'H')
                    || !empty($ip_location['isVpn'])
                    || !empty($ip_location['isProxy'])
                    || !empty($ip_location['torDetected']);

                if ($vpn_detected) {
                    $passed = false;
                    $fail_reason = $vpn_description ?: __('VPN or proxy usage detected.', 'x8-evs');
                }
            }

            // Geolocation blocking (only when "Block by GeoLocation" is on):
            // checks the device location collected by the EVS portal against
            // the Allowed Countries and Blocked States settings.
            if ($passed && $settings && X8_EVS_Admin_Settings::is_block_by_geolocation_enabled()) {
                $country = strtoupper(trim($device_location['country'] ?? ''));
                if ($country !== ''
                    && X8_EVS_Admin_Settings::is_country_filtering_enabled()
                    && !X8_EVS_Admin_Settings::is_country_allowed($country)) {
                    $passed = false;
                    $fail_reason = sprintf(__('Your country (%s) is not allowed.', 'x8-evs'), $country);
                }

                if ($passed) {
                    $state = trim($device_location['province'] ?? '');

                    // Fallback: derive the state from the IP location's
                    // regionCode (e.g. "US-NY" -> "NY") when the device
                    // location has no province.
                    if ($state === '') {
                        $region_code = trim($ip_location['regionCode'] ?? '');
                        if (strpos($region_code, '-') !== false) {
                            $state = substr($region_code, strpos($region_code, '-') + 1);
                        }
                    }

                    if ($state !== '' && X8_EVS_Admin_Settings::is_state_blocked($state)) {
                        $passed = false;
                        $fail_reason = sprintf(__('Your location (%s) is not allowed.', 'x8-evs'), $state);
                    }
                }
            }
        }

        $wpdb->update(
            $table_name,
            array(
                'status' => $passed ? 'passed' : 'failed',
                'verified_ip' => $verified_ip ?: null,
                'transaction_id' => isset($webhook_data['meta']['transactionId']) ? (string)$webhook_data['meta']['transactionId'] : $record->transaction_id,
                'workflow_outcome' => $outcome_code,
                'vpn_probability' => $vpn_code,
                'vpn_description' => $passed ? $vpn_description : ($fail_reason ?: $vpn_description),
                'webhook_response' => wp_json_encode($webhook_data),
                'verified_at' => current_time('mysql')
            ),
            array('id' => $record->id),
            array('%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s'),
            array('%d')
        );

        if ($user_id > 0 && class_exists('X8_EVS_Admin_Settings')) {
            X8_EVS_Admin_Settings::log_customer_activity($user_id, 'assurelocate_result', array(
                'result' => $passed ? 'passed' : 'failed',
                'fail_reason' => $fail_reason,
                'workflow_outcome' => $outcome_code,
                'vpn_probability' => $vpn_code,
                'ip_address' => $verified_ip ?: $record->ip_address
            ));
        }

        return array(
            'assurelocate' => $passed ? 'passed' : 'failed',
            'record_id' => (int)$record->id,
            'vpn_probability' => $vpn_code
        );
    }

    /**
     * Show a warning page with a countdown, then redirect the customer
     * to the EVS AssureLocate portal link.
     */
    private function redirect_to_portal($link) {
        // Clear any existing output to prevent header issues
        if (ob_get_level()) {
            ob_end_clean();
        }

        $countdown = 10; // seconds
        $site_name = get_bloginfo('name');

        status_header(200);
        nocache_headers();
        header('Content-Type: text/html; charset=utf-8');
        ?>
<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?php esc_html_e('Location Verification Required', 'x8-evs'); ?></title>
    <style>
        * { box-sizing: border-box; margin: 0; padding: 0; }

        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', sans-serif;
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 24px;
            background: radial-gradient(ellipse at 20% -10%, #2b3a67 0%, #1b2340 45%, #10142a 100%);
        }

        .x8-al-card {
            position: relative;
            background: #ffffff;
            border-radius: 20px;
            box-shadow: 0 24px 64px rgba(8, 12, 34, .45);
            max-width: 460px;
            width: 100%;
            padding: 44px 40px 36px;
            text-align: center;
            overflow: hidden;
            animation: x8-al-rise .5s cubic-bezier(.2, .9, .3, 1.2) both;
        }

        @keyframes x8-al-rise {
            from { opacity: 0; transform: translateY(24px) scale(.97); }
            to   { opacity: 1; transform: translateY(0) scale(1); }
        }

        .x8-al-card::before {
            content: '';
            position: absolute;
            top: 0; left: 0; right: 0;
            height: 5px;
            background: linear-gradient(90deg, #4f8ef7, #6c5ce7, #4f8ef7);
            background-size: 200% 100%;
            animation: x8-al-shimmer 3s linear infinite;
        }

        @keyframes x8-al-shimmer {
            from { background-position: 0% 0; }
            to   { background-position: 200% 0; }
        }

        .x8-al-icon-wrap {
            width: 84px;
            height: 84px;
            margin: 0 auto 22px;
            border-radius: 50%;
            background: linear-gradient(135deg, #eef3ff, #e6e9ff);
            display: flex;
            align-items: center;
            justify-content: center;
            position: relative;
        }

        .x8-al-icon-wrap::after {
            content: '';
            position: absolute;
            inset: -8px;
            border-radius: 50%;
            border: 2px solid rgba(108, 92, 231, .35);
            animation: x8-al-pulse 2s ease-out infinite;
        }

        @keyframes x8-al-pulse {
            0%   { transform: scale(.9); opacity: 1; }
            100% { transform: scale(1.25); opacity: 0; }
        }

        .x8-al-icon-wrap svg { width: 40px; height: 40px; }

        h1 {
            font-size: 23px;
            font-weight: 700;
            color: #171c30;
            letter-spacing: -.02em;
            margin-bottom: 12px;
        }

        .x8-al-text {
            color: #5b6272;
            font-size: 15px;
            line-height: 1.65;
            margin-bottom: 28px;
        }

        .x8-al-timer {
            position: relative;
            width: 108px;
            height: 108px;
            margin: 0 auto 8px;
        }

        .x8-al-timer svg { transform: rotate(-90deg); }

        .x8-al-timer .x8-al-ring-bg {
            fill: none;
            stroke: #edf0f7;
            stroke-width: 7;
        }

        .x8-al-timer .x8-al-ring {
            fill: none;
            stroke: url(#x8AlGradient);
            stroke-width: 7;
            stroke-linecap: round;
            transition: stroke-dashoffset 1s linear;
        }

        .x8-al-timer-num {
            position: absolute;
            inset: 0;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 36px;
            font-weight: 800;
            color: #2b3a67;
            font-variant-numeric: tabular-nums;
        }

        .x8-al-timer-label {
            color: #9aa1b3;
            font-size: 12.5px;
            text-transform: uppercase;
            letter-spacing: .09em;
            font-weight: 600;
            margin-bottom: 28px;
        }

        .x8-al-btn {
            display: block;
            width: 100%;
            background: linear-gradient(135deg, #4f8ef7, #6c5ce7);
            color: #fff;
            text-decoration: none;
            padding: 15px 28px;
            border-radius: 12px;
            font-size: 16px;
            font-weight: 700;
            letter-spacing: .01em;
            box-shadow: 0 10px 24px rgba(79, 142, 247, .35);
            transition: transform .15s ease, box-shadow .15s ease;
        }

        .x8-al-btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 14px 30px rgba(79, 142, 247, .45);
        }

        .x8-al-btn:active { transform: translateY(0); }

        .x8-al-note {
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 7px;
            margin-top: 20px;
            color: #9aa1b3;
            font-size: 13px;
        }

        .x8-al-note svg { width: 14px; height: 14px; flex-shrink: 0; }

        .x8-al-brand {
            margin-top: 26px;
            padding-top: 18px;
            border-top: 1px solid #eef0f5;
            color: #b4bac8;
            font-size: 12.5px;
        }

        @media (max-width: 480px) {
            .x8-al-card { padding: 36px 24px 28px; }
            h1 { font-size: 20px; }
        }
    </style>
</head>
<body>
    <div class="x8-al-card">
        <div class="x8-al-icon-wrap">
            <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M12 21s7-5.1 7-11a7 7 0 1 0-14 0c0 5.9 7 11 7 11z" stroke="#6c5ce7" stroke-width="1.8" stroke-linejoin="round" fill="rgba(108,92,231,.12)"/>
                <circle cx="12" cy="10" r="2.6" stroke="#4f8ef7" stroke-width="1.8" fill="#fff"/>
            </svg>
        </div>

        <h1><?php esc_html_e('Location Verification Required', 'x8-evs'); ?></h1>
        <p class="x8-al-text"><?php esc_html_e('It looks like you\'re browsing from a new location or IP address. For your security, please verify your location through our secure verification portal before continuing.', 'x8-evs'); ?></p>

        <div class="x8-al-timer">
            <svg width="108" height="108" viewBox="0 0 108 108">
                <defs>
                    <linearGradient id="x8AlGradient" x1="0%" y1="0%" x2="100%" y2="100%">
                        <stop offset="0%" stop-color="#4f8ef7"/>
                        <stop offset="100%" stop-color="#6c5ce7"/>
                    </linearGradient>
                </defs>
                <circle class="x8-al-ring-bg" cx="54" cy="54" r="48"/>
                <circle class="x8-al-ring" id="x8-al-ring" cx="54" cy="54" r="48"/>
            </svg>
            <div class="x8-al-timer-num" id="x8-al-count"><?php echo (int) $countdown; ?></div>
        </div>
        <div class="x8-al-timer-label"><?php esc_html_e('Redirecting automatically', 'x8-evs'); ?></div>

        <a class="x8-al-btn" href="<?php echo esc_url($link); ?>"><?php esc_html_e('Verify My Location Now', 'x8-evs'); ?></a>

        <div class="x8-al-note">
            <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M12 2l7 3v6c0 5-3.2 8.7-7 10-3.8-1.3-7-5-7-10V5l7-3z" stroke="currentColor" stroke-width="2" stroke-linejoin="round"/>
                <path d="M9 12l2 2 4-4" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            </svg>
            <span><?php esc_html_e('You\'ll be returned here automatically once verified.', 'x8-evs'); ?></span>
        </div>

        <?php if (!empty($site_name)): ?>
            <div class="x8-al-brand"><?php echo esc_html($site_name); ?></div>
        <?php endif; ?>
    </div>

    <script>
        (function() {
            var total = <?php echo (int) $countdown; ?>;
            var remaining = total;
            var numEl = document.getElementById('x8-al-count');
            var ring = document.getElementById('x8-al-ring');
            var circumference = 2 * Math.PI * 48;

            ring.style.strokeDasharray = circumference;
            ring.style.strokeDashoffset = 0;

            function tick() {
                remaining--;
                numEl.textContent = Math.max(remaining, 0);
                ring.style.strokeDashoffset = circumference * (1 - remaining / total);
                if (remaining <= 0) {
                    clearInterval(timer);
                    window.location.href = <?php echo wp_json_encode($link); ?>;
                }
            }

            var timer = setInterval(tick, 1000);
        })();
    </script>
    <noscript><meta http-equiv="refresh" content="<?php echo (int) $countdown; ?>;url=<?php echo esc_attr($link); ?>"></noscript>
</body>
</html>
        <?php
        exit;
    }

    /**
     * Redirect to the blocked-state page when the location verification failed
     */
    private function redirect_to_blocked_page($record) {
        $request_uri = $_SERVER['REQUEST_URI'] ?? '';
        if (strpos($request_uri, 'blocked-state') !== false) {
            return;
        }

        if (ob_get_level()) {
            ob_end_clean();
        }

        $message = !empty($record->vpn_description)
            ? $record->vpn_description
            : __('Your location verification did not pass.', 'x8-evs');

        $blocked_page_url = add_query_arg(array(
            'reason' => 'location_verification',
            'message' => urlencode($message)
        ), home_url('/blocked-state'));

        if (headers_sent()) {
            echo '<script type="text/javascript">window.location.href = "' . esc_js($blocked_page_url) . '";</script>';
            echo '<noscript><meta http-equiv="refresh" content="0;url=' . esc_attr($blocked_page_url) . '"></noscript>';
            exit;
        }

        wp_redirect($blocked_page_url);
        exit;
    }

    /**
     * Get the user's real IP address
     */
    private function get_user_ip() {
        $ip_headers = array(
            'HTTP_CF_CONNECTING_IP',
            'HTTP_CLIENT_IP',
            'HTTP_X_FORWARDED_FOR',
            'HTTP_X_FORWARDED',
            'HTTP_X_CLUSTER_CLIENT_IP',
            'HTTP_FORWARDED_FOR_IP',
            'HTTP_FORWARDED',
            'HTTP_X_REAL_IP',
            'HTTP_X_FORWARDED_FOR_IP',
            'REMOTE_ADDR'
        );

        foreach ($ip_headers as $header) {
            if (!empty($_SERVER[$header])) {
                $ip_list = explode(',', $_SERVER[$header]);
                foreach ($ip_list as $ip) {
                    $ip = trim($ip);

                    if (empty($ip)) {
                        continue;
                    }

                    if (defined('WP_DEBUG') && WP_DEBUG) {
                        if (filter_var($ip, FILTER_VALIDATE_IP) !== false) {
                            return $ip;
                        }
                    } else {
                        if (filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE) !== false) {
                            return $ip;
                        }
                    }
                }
            }
        }

        $fallback_ip = $_SERVER['REMOTE_ADDR'] ?? '';

        if (defined('WP_DEBUG') && WP_DEBUG) {
            return $fallback_ip;
        }

        if (!empty($fallback_ip) && filter_var($fallback_ip, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE) !== false) {
            return $fallback_ip;
        }

        return '';
    }
}
