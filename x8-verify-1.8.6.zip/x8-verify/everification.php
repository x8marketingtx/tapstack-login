<?php
/**
 * Plugin Name: X8 Verify
 * Plugin URI: https://example.com/x8-evs
 * Description: X8 Electronic Verification System (EVS) plugin for WordPress.
 * Version: 1.8.6
 * Author: X8
 * Author URI: https://example.com
 * License: GPL v2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: x8-evs
 * Domain Path: /languages
 */

// If this file is called directly, abort.
if (!defined('WPINC')) {
    die;
}

// Define plugin constants
define('X8_EVS_VERSION', '1.8.6');
define('X8_EVS_PLUGIN_URL', plugin_dir_url(__FILE__));
define('X8_EVS_PLUGIN_PATH', plugin_dir_path(__FILE__));
define('X8_EVS_PLUGIN_BASENAME', plugin_basename(__FILE__));

/**
 * Main X8 Verify Plugin Class
 */
class X8_EVS_Plugin {
    
    /**
     * Instance of this class
     */
    private static $instance = null;
    
    /**
     * Get singleton instance
     */
    public static function get_instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    /**
     * Constructor
     */
    private function __construct() {
        add_action('init', array($this, 'init'));
        register_activation_hook(__FILE__, array($this, 'activate'));
        register_deactivation_hook(__FILE__, array($this, 'deactivate'));
        
        // Ensure tables exist on init (for updates)
        add_action('admin_init', array($this, 'maybe_create_tables'));
        
        // Schedule pending-users cleanup cron when option is set
        add_action('init', array($this, 'maybe_schedule_pending_cleanup_cron'));
        add_action('x8_evs_cleanup_pending_users', array($this, 'run_pending_cleanup_cron'));
        
        // Load blocking handler very early
        add_action('plugins_loaded', array($this, 'load_early_blocking'), 1);
        
        // Load admin settings
        $this->load_admin_settings();
    }
    
    /**
     * Schedule daily cron to delete pending users if the option is set (1–60 days).
     */
    public function maybe_schedule_pending_cleanup_cron() {
        $days = (int) get_option('x8_evs_pending_auto_delete_days', 0);
        if ($days < 1) {
            wp_clear_scheduled_hook('x8_evs_cleanup_pending_users');
            return;
        }
        if (!wp_next_scheduled('x8_evs_cleanup_pending_users')) {
            wp_schedule_event(time(), 'daily', 'x8_evs_cleanup_pending_users');
        }
    }

    /**
     * Cron callback: delegates to admin settings cleanup.
     */
    public function run_pending_cleanup_cron() {
        if (class_exists('X8_EVS_Admin_Settings')) {
            X8_EVS_Admin_Settings::run_pending_users_cleanup();
        }
    }

    /**
     * Check and create tables if they don't exist
     */
    public function maybe_create_tables() {
        global $wpdb;
        
        $track_table_name = $wpdb->prefix . 'x8_evs_track_traffic';
        
        // Check if table exists using SHOW TABLES (more reliable)
        $table_exists = $wpdb->get_var($wpdb->prepare(
            "SHOW TABLES LIKE %s",
            $track_table_name
        ));
        
        if ($table_exists !== $track_table_name) {
            $this->create_tables();
        }
    }
    
    /**
     * Load blocking handler very early
     */
    public function load_early_blocking() {
        // Only load on frontend
        if (is_admin() || wp_doing_ajax() || wp_doing_cron()) {
            return;
        }
        
        if (defined('WP_DEBUG') && WP_DEBUG) {
            error_log('X8 Verify: load_early_blocking called');
        }
        
        // Load admin settings first (needed for blocking checks)
        require_once X8_EVS_PLUGIN_PATH . 'inc/settings/class-admin-settings.php';
        
        // Check if blocking options are enabled before loading
        if (class_exists('X8_EVS_Admin_Settings') && X8_EVS_Admin_Settings::has_blocking_options_enabled()) {
            if (defined('WP_DEBUG') && WP_DEBUG) {
                error_log('X8 Verify: Blocking options enabled, loading blocking handler early');
            }
            
            // Load blocking handler
            require_once X8_EVS_PLUGIN_PATH . 'inc/frontend/class-blocking-handler.php';
            
            // Initialize immediately using singleton
            if (class_exists('X8_EVS_Blocking_Handler')) {
                X8_EVS_Blocking_Handler::get_instance();
            }
        } else {
            if (defined('WP_DEBUG') && WP_DEBUG) {
                error_log('X8 Verify: Blocking options not enabled, skipping early loading');
            }
        }
    }
    
    /**
     * Load admin settings
     */
    private function load_admin_settings() {
        // Debug logger is used by the webhook handler and admin settings
        require_once X8_EVS_PLUGIN_PATH . 'inc/class-debug-logger.php';
        // Always load the admin settings class since webhook handler needs its static methods
        require_once X8_EVS_PLUGIN_PATH . 'inc/settings/class-admin-settings.php';
        // Load email notifications (hooks run both admin and frontend)
        require_once X8_EVS_PLUGIN_PATH . 'inc/settings/class-email-notifications.php';
        if (class_exists('X8_EVS_Email_Notifications')) {
            X8_EVS_Email_Notifications::init();
        }
        
        // Only initialize admin functionality when in admin context
        if (is_admin()) {
            new X8_EVS_Admin_Settings();
            
            // Load customer tracker for admin
            require_once X8_EVS_PLUGIN_PATH . 'inc/settings/class-customer-tracker.php';
            X8_EVS_Customer_Tracker::get_instance();
        }
    }
    
    /**
     * Initialize the plugin
     */
    public function init() {
        // Load text domain for translations
        load_plugin_textdomain('x8-evs', false, dirname(X8_EVS_PLUGIN_BASENAME) . '/languages');
        
        // Load webhook handler
        $this->load_webhook_handler();
        
        // Load frontend functionality
        $this->load_frontend();
        
        // Initialize WooCommerce integration early to ensure AJAX handlers are registered
        $this->init_woocommerce_integration();
        
        // Hook into WordPress login/logout for activity tracking
        $this->setup_activity_hooks();
    }
    
    /**
     * Load webhook handler
     */
    private function load_webhook_handler() {
        require_once X8_EVS_PLUGIN_PATH . 'inc/webhook/class-webhook-handler.php';
        // The class initializes itself
    }
    
    /**
     * Load frontend functionality
     */
    private function load_frontend() {
        // Load verification classes for both frontend and AJAX requests
        require_once X8_EVS_PLUGIN_PATH . 'inc/frontend/class-verification-redirect.php';
        require_once X8_EVS_PLUGIN_PATH . 'inc/frontend/class-verification-form.php';
        require_once X8_EVS_PLUGIN_PATH . 'inc/frontend/class-blocking-handler.php';
        require_once X8_EVS_PLUGIN_PATH . 'inc/frontend/class-template-loader.php';
        // Note: Blocking handler is already loaded early, don't instantiate again
        
        // Load EVS AssureLocate location verification handler
        require_once X8_EVS_PLUGIN_PATH . 'inc/frontend/class-assurelocate-handler.php';
        X8_EVS_AssureLocate_Handler::get_instance();
        
        // Load WooCommerce integration
        $this->load_woocommerce_integration();
    }

    /**
     * Load WooCommerce integration
     */
    private function load_woocommerce_integration() {
        // Load WooCommerce integration with proper timing
        require_once X8_EVS_PLUGIN_PATH . 'inc/woo/class-woocommerce-integration.php';
    }
    
    /**
     * Setup activity tracking hooks
     */
    private function setup_activity_hooks() {
        // Track user login
        add_action('wp_login', array($this, 'track_user_login'), 10, 2);
        
        // Track user logout
        add_action('wp_logout', array($this, 'track_user_logout'));
        
        // Track user registration
        add_action('user_register', array($this, 'track_user_registration'));
        
        // Track verification form access
        add_action('wp', array($this, 'track_verification_page_access'));
    }
    
    /**
     * Track user login activity
     */
    public function track_user_login($user_login, $user) {
        if (class_exists('X8_EVS_Admin_Settings')) {
            // Check for any blocking conditions
            $blocking_status = X8_EVS_Admin_Settings::check_blocking_status($user->ID);
            
            X8_EVS_Admin_Settings::log_customer_activity($user->ID, 'login', array(
                'user_login' => $user_login,
                'blocking_status' => $blocking_status
            ));
        }
    }
    
    /**
     * Track user logout activity
     */
    public function track_user_logout() {
        $user_id = get_current_user_id();
        if ($user_id && class_exists('X8_EVS_Admin_Settings')) {
            X8_EVS_Admin_Settings::log_customer_activity($user_id, 'logout', array());
        }
    }
    
    /**
     * Track user registration
     */
    public function track_user_registration($user_id) {
        if (class_exists('X8_EVS_Admin_Settings')) {
            X8_EVS_Admin_Settings::log_customer_activity($user_id, 'registration', array(
                'registration_method' => 'website'
            ));
        }
    }
    
    /**
     * Track verification page access
     */
    public function track_verification_page_access() {
        // Only track if user is logged in and we're on verification-related pages
        if (!is_user_logged_in()) {
            return;
        }
        
        $user_id = get_current_user_id();
        
        // Check if this is a verification page
        if (is_page() && (has_shortcode(get_post()->post_content, 'x8_verification_form') || 
                         strpos(get_post()->post_content, 'x8_verification_form') !== false)) {
            
            if (class_exists('X8_EVS_Admin_Settings')) {
                // Check for blocking status when accessing verification
                $blocking_status = X8_EVS_Admin_Settings::check_blocking_status($user_id);
                
                X8_EVS_Admin_Settings::log_customer_activity($user_id, 'verification_page_access', array(
                    'page_id' => get_the_ID(),
                    'page_title' => get_the_title(),
                    'blocking_status' => $blocking_status
                ));
            }
        }
        
        // WooCommerce integration is now initialized in init() method
    }
    
    /**
     * Initialize WooCommerce integration
     */
    public function init_woocommerce_integration() {
  
        // Only initialize if WooCommerce is active
        if (class_exists('WooCommerce')) {
            new X8_EVS_WooCommerce_Integration();
        }
    }
    
    /**
     * Plugin activation
     */
    public function activate() {
        // Create database tables if needed
        $this->create_tables();
        
        // Set default options
        add_option('x8_evs_username', '');
        add_option('x8_evs_password', '');
        add_option('x8_evs_document_type', 'DriversLicense');
        add_option('x8_evs_api_url', 'https://api.x8evs.com');
        
        // Mark when verification was first enabled (for grandfathering existing clients)
        if (get_option('x8_evs_verification_start_date') === false) {
            add_option('x8_evs_verification_start_date', current_time('mysql'));
        }
        
        // Flush rewrite rules
        flush_rewrite_rules();
    }
    
    /**
     * Plugin deactivation
     */
    public function deactivate() {
        wp_clear_scheduled_hook('x8_evs_cleanup_pending_users');
        flush_rewrite_rules();
    }
    
    /**
     * Create database tables
     */
    private function create_tables() {
        global $wpdb;
        
        $table_name = $wpdb->prefix . 'x8_evs_logs';
        
        $charset_collate = $wpdb->get_charset_collate();
        
        $sql = "CREATE TABLE $table_name (
            id mediumint(9) NOT NULL AUTO_INCREMENT,
            verification_code varchar(100) NOT NULL,
            document_number varchar(100) NOT NULL,
            status varchar(20) NOT NULL,
            ip_address varchar(45),
            user_agent text,
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id)
        ) $charset_collate;";
        
        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
        dbDelta($sql);
        
        // Create track traffic table
        $track_table_name = $wpdb->prefix . 'x8_evs_track_traffic';
        
        $track_sql = "CREATE TABLE $track_table_name (
            id bigint(20) NOT NULL AUTO_INCREMENT,
            ip_address varchar(45) NOT NULL,
            real_ip_address varchar(45) DEFAULT NULL,
            country varchar(10) DEFAULT NULL,
            country_name varchar(100) DEFAULT NULL,
            state varchar(10) DEFAULT NULL,
            state_name varchar(100) DEFAULT NULL,
            city varchar(100) DEFAULT NULL,
            region varchar(100) DEFAULT NULL,
            isp varchar(255) DEFAULT NULL,
            block_type varchar(50) NOT NULL,
            block_reason text,
            user_id bigint(20) DEFAULT NULL,
            user_email varchar(255) DEFAULT NULL,
            user_agent text,
            request_uri text,
            is_blocked tinyint(1) DEFAULT 1,
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            KEY ip_address (ip_address),
            KEY real_ip_address (real_ip_address),
            KEY block_type (block_type),
            KEY created_at (created_at),
            KEY user_id (user_id)
        ) $charset_collate;";
        
        dbDelta($track_sql);
        
        // Create user locations table (EVS AssureLocate IP tracking)
        if (!class_exists('X8_EVS_AssureLocate_Handler')) {
            require_once X8_EVS_PLUGIN_PATH . 'inc/frontend/class-assurelocate-handler.php';
        }
        X8_EVS_AssureLocate_Handler::create_table();
    }
}

// Initialize the plugin
add_action('plugins_loaded', function() {
    X8_EVS_Plugin::get_instance();
});
// Add custom capabilities to specified roles
add_action('admin_init', 'x8ve_add_custom_capabilities');
function x8ve_add_custom_capabilities() {
    // List of roles to add capabilities to
    $roles = array('administrator');
    // List of capabilities to add
    $capabilities = array('x8_verify_access');
    // Loop through each role
    foreach ($roles as $role_name) {
        $role = get_role($role_name);
        if ($role) {
            // Loop through each capability
            foreach ($capabilities as $cap) {
                // Add the capability only if it doesn't exist
                if (!$role->has_cap($cap)) {
                    $role->add_cap($cap);
                }
            }
        }
    }
}







add_action('rest_api_init', function () {
    register_rest_route('x8-evs/v1', '/blacklist', [
        'methods'  => 'GET',
        'callback' => 'x8_evs_get_blacklist',
        'permission_callback' => '__return_true', // Public; adjust if needed
    ]);
});

function x8_evs_get_blacklist(WP_REST_Request $request) {
    global $wpdb;

    $table = $wpdb->prefix . 'wc_blacklist';

    // Fetch all blocked entries
    $blocked_entries = $wpdb->get_results(
        "SELECT * FROM {$table} WHERE is_blocked = 1 ORDER BY date_added DESC"
    );

    if (empty($blocked_entries)) {
        return [
            'success' => true,
            'message' => 'No blocked entries found',
            'data' => [],
        ];
    }

    return [
        'success' => true,
        'count' => count($blocked_entries),
        'data' => $blocked_entries,
    ];
}
