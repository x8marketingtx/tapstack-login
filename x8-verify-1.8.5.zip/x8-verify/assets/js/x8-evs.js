jQuery(document).ready(function($) {
    'use strict';
    
    // Tab functionality
    function initTabs() {
        console.log('X8 Verify: Initializing tabs...');
        console.log('X8 Verify: Found tabs:', $('.x8-evs-tab').length);
        console.log('X8 Verify: Found panels:', $('.x8-evs-tab-panel').length);
        
        // Log all tab data
        $('.x8-evs-tab').each(function() {
            console.log('X8 Verify: Tab found:', $(this).data('tab'), 'Text:', $(this).text().trim());
        });
        
        // Log all panel IDs
        $('.x8-evs-tab-panel').each(function() {
            console.log('X8 Verify: Panel found:', $(this).attr('id'), 'Classes:', $(this).attr('class'));
        });
        
        $('.x8-evs-tab').on('click', function(e) {
            e.preventDefault();
            console.log('X8 Verify: Tab clicked:', $(this).data('tab'));
            
            var $tab = $(this);
            var targetTab = $tab.data('tab');
            
            // Remove active class from all tabs and panels
            $('.x8-evs-tab').removeClass('active');
            $('.x8-evs-tab-panel').removeClass('active');
            
            // Add active class to clicked tab and corresponding panel
            $tab.addClass('active');
            var $targetPanel = $('#' + targetTab);
            console.log('X8 Verify: Target panel:', targetTab, 'Found:', $targetPanel.length);
            
            if ($targetPanel.length === 0) {
                console.error('X8 Verify: Target panel not found for tab:', targetTab);
                return;
            }
            
            $targetPanel.addClass('active');
            console.log('X8 Verify: Tab switched successfully to:', targetTab);
            
            // Store active tab in localStorage
            localStorage.setItem('x8_evs_active_tab', targetTab);
        });
        
        // Restore active tab from localStorage
        var activeTab = localStorage.getItem('x8_evs_active_tab');
        if (activeTab && $('#' + activeTab).length) {
            console.log('X8 Verify: Restoring active tab:', activeTab);
            $('.x8-evs-tab[data-tab="' + activeTab + '"]').trigger('click');
        }
    }
    
    /**
     * Initialize Integration modal interactions
     */
    function initIntegrationModal() {
        var $modal = $('#x8-evs-integration-modal');
        var $trigger = $('#x8-evs-sync-blocklist');
        var $tableBody = $modal.find('#x8-evs-blacklist-rows');
        var $statusNotice = $('#x8-evs-blacklist-status');
        var $refreshButton = $('#x8-evs-refresh-blacklist');
        var $syncAllButton = $('#x8-evs-sync-all-blacklist');
        var isLoading = false;
        var hasLoaded = false;

        if (!$modal.length || !$trigger.length) {
            return;
        }

        var openModal = function(e) {
            if (e) {
                e.preventDefault();
            }
            $modal.fadeIn(150);
            if (!hasLoaded) {
                fetchBlacklistEntries();
            }
        };

        var closeModal = function(e) {
            if (e) {
                e.preventDefault();
            }
            $modal.fadeOut(150);
            clearStatusNotice();
        };

        var clearStatusNotice = function() {
            if ($statusNotice.length) {
                $statusNotice.removeClass('success error info').hide().empty();
            }
        };

        var setStatusNotice = function(type, message) {
            if (!$statusNotice.length) {
                return;
            }

            var icon = 'info';
            switch (type) {
                case 'success':
                    icon = 'yes-alt';
                    break;
                case 'error':
                    icon = 'warning';
                    break;
            }

            $statusNotice
                .removeClass('success error info')
                .addClass(type || 'info')
                .html('<span class="dashicons dashicons-' + icon + '"></span>' + message)
                .show();
        };

        var formatStatusBadge = function(status) {
            if (!status) {
                return '<span class="status-badge status-missing">—</span>';
            }

            var label = status.replace(/_/g, ' ');
            label = label.charAt(0).toUpperCase() + label.slice(1);

            return '<span class="status-badge status-' + status + '">' + label + '</span>';
        };

        var renderRows = function(entries) {
            if (!$tableBody.length) {
                return;
            }

            if (!entries.length) {
                $tableBody.html(
                    '<tr><td colspan="6" style="text-align:center;">' +
                    x8_evs_ajax.strings.blacklist_empty +
                    '</td></tr>'
                );
                return;
            }

            var matchTypeLabels = {
                email: x8_evs_ajax.strings.blacklist_match_email,
                phone: x8_evs_ajax.strings.blacklist_match_phone
            };

            var rowsHtml = '';

            entries.forEach(function(entry) {
                var recordMeta = [];
                if (entry.order_id) {
                    recordMeta.push(x8_evs_ajax.strings.blacklist_order_prefix + entry.order_id);
                }
                if (entry.sources) {
                    recordMeta.push(entry.sources);
                }
                if (entry.date_added) {
                    recordMeta.push(entry.date_added);
                }

                var recordColumn = '<td><strong>' +
                    (entry.blacklist_id ? '#' + entry.blacklist_id : '&mdash;') +
                    '</strong>';
                if (recordMeta.length) {
                    recordColumn += '<div class="x8-evs-blacklist-meta">' + recordMeta.join(' · ') + '</div>';
                }
                recordColumn += '</td>';

                var customerColumn;
                if (entry.customer_id) {
                    customerColumn = '<td><strong>#' + entry.customer_id + '</strong>';
                    if (entry.match_type && matchTypeLabels[entry.match_type]) {
                        customerColumn += '<div class="x8-evs-blacklist-meta">' +
                            matchTypeLabels[entry.match_type] +
                            '</div>';
                    }
                    customerColumn += '</td>';
                } else {
                    customerColumn = '<td><span class="x8-evs-blacklist-no-match">' +
                        x8_evs_ajax.strings.blacklist_no_customer_id +
                        '</span></td>';
                }

                var nameColumn = '<td>' +
                    (entry.customer_name || entry.name || x8_evs_ajax.strings.blacklist_unknown) +
                    '</td>';

                var contactParts = [];
                if (entry.email) {
                    contactParts.push('<div><span class="dashicons dashicons-email"></span> ' + entry.email + '</div>');
                }
                if (entry.phone) {
                    contactParts.push('<div><span class="dashicons dashicons-phone"></span> ' + entry.phone + '</div>');
                }
                var contactColumn = '<td>' + (contactParts.join('') || '<span class="x8-evs-blacklist-no-match">—</span>') + '</td>';

                var statusColumn = '<td class="x8-evs-status-cell">' + formatStatusBadge(entry.account_status) + '</td>';

                var actionColumn;
                if (entry.customer_id) {
                    if (entry.account_status && entry.account_status === 'block') {
                        actionColumn = '<td><div class="x8-evs-blacklist-actions">' +
                            '<span class="dashicons dashicons-yes"></span>' +
                            '<span>' + x8_evs_ajax.strings.blacklist_already_synced + '</span>' +
                            '</div></td>';
                    } else {
                        actionColumn = '<td>' +
                            '<button type="button" class="button button-primary x8-evs-sync-row" data-customer-id="' + entry.customer_id + '" data-blacklist-id="' + (entry.blacklist_id || 0) + '">' +
                            x8_evs_ajax.strings.blacklist_sync_button +
                            '</button>' +
                            '</td>';
                    }
                } else {
                    actionColumn = '<td><span class="x8-evs-blacklist-no-match">' +
                        x8_evs_ajax.strings.blacklist_no_match +
                        '</span></td>';
                }

                rowsHtml += '<tr data-blacklist-id="' + (entry.blacklist_id || '') + '">' +
                    recordColumn +
                    customerColumn +
                    nameColumn +
                    contactColumn +
                    statusColumn +
                    actionColumn +
                    '</tr>';
            });

            $tableBody.html(rowsHtml);
        };

        var fetchBlacklistEntries = function(force) {
            if (isLoading && !force) {
                return;
            }

            isLoading = true;
            clearStatusNotice();

            if ($tableBody.length) {
                $tableBody.html(
                    '<tr class="x8-evs-blacklist-loading">' +
                    '<td colspan="6" style="text-align:center;">' +
                    '<span class="dashicons dashicons-update spin"></span> ' +
                    x8_evs_ajax.strings.blacklist_loading +
                    '</td></tr>'
                );
            }

            $.ajax({
                url: x8_evs_ajax.ajax_url,
                type: 'POST',
                dataType: 'json',
                data: {
                    action: 'x8_evs_fetch_blacklist_entries',
                    nonce: x8_evs_ajax.nonce
                }
            }).done(function(response) {
                if (response.success) {
                    hasLoaded = true;
                    var entries = (response.data && response.data.entries) ? response.data.entries : [];
                    renderRows(entries);
                    if (entries.length) {
                        setStatusNotice('info', x8_evs_ajax.strings.blacklist_loaded.replace('%d', entries.length));
                    }
                } else {
                    renderRows([]);
                    var message = response.data && response.data.message ?
                        response.data.message :
                        x8_evs_ajax.strings.blacklist_error_generic;
                    setStatusNotice('error', message);
                }
            }).fail(function() {
                renderRows([]);
                setStatusNotice('error', x8_evs_ajax.strings.blacklist_error_generic);
            }).always(function() {
                isLoading = false;
            });
        };

        var syncCustomerStatus = function($button) {
            if (!$button.length || $button.prop('disabled')) {
                return;
            }

            var originalText = $button.text();
            var customerId = $button.data('customer-id');
            var blacklistId = $button.data('blacklist-id');

            $button.prop('disabled', true).text(x8_evs_ajax.strings.blacklist_syncing);
            clearStatusNotice();

            $.ajax({
                url: x8_evs_ajax.ajax_url,
                type: 'POST',
                dataType: 'json',
                data: {
                    action: 'x8_evs_sync_blacklist_status',
                    nonce: x8_evs_ajax.nonce,
                    customer_id: customerId,
                    blacklist_id: blacklistId
                }
            }).done(function(response) {
                if (response.success) {
                    var newStatus = response.data && response.data.new_status ? response.data.new_status : 'block';
                    var $row = $button.closest('tr');
                    $row.find('.x8-evs-status-cell').html(formatStatusBadge(newStatus));
                    $button.replaceWith('<div class="x8-evs-blacklist-actions">' +
                        '<span class="dashicons dashicons-yes"></span>' +
                        '<span>' + x8_evs_ajax.strings.blacklist_synced + '</span>' +
                        '</div>');

                    var message = (response.data && response.data.message) ?
                        response.data.message :
                        x8_evs_ajax.strings.blacklist_synced;

                    setStatusNotice('success', message);
                } else {
                    var errorMessage = response.data && response.data.message ?
                        response.data.message :
                        x8_evs_ajax.strings.blacklist_error_generic;
                    setStatusNotice('error', errorMessage);
                    $button.prop('disabled', false).text(originalText);
                }
            }).fail(function() {
                setStatusNotice('error', x8_evs_ajax.strings.blacklist_error_generic);
                $button.prop('disabled', false).text(originalText);
            });
        };

        $trigger.on('click', openModal);
        $('#x8-evs-close-integration-modal, #x8-evs-dismiss-integration-modal').on('click', closeModal);
        if ($refreshButton.length) {
            $refreshButton.on('click', function(e) {
                e.preventDefault();
                fetchBlacklistEntries(true);
            });
        }

        if ($syncAllButton.length) {
            $syncAllButton.on('click', function(e) {
                e.preventDefault();

                if (!$tableBody.length || $tableBody.find('.x8-evs-sync-row').length === 0) {
                    setStatusNotice('info', x8_evs_ajax.strings.blacklist_sync_all_none);
                    return;
                }

                if (!window.confirm(x8_evs_ajax.strings.blacklist_sync_all_confirm)) {
                    return;
                }

                $syncAllButton.prop('disabled', true).text(x8_evs_ajax.strings.blacklist_sync_all_running);
                clearStatusNotice();

                $.ajax({
                    url: x8_evs_ajax.ajax_url,
                    type: 'POST',
                    dataType: 'json',
                    data: {
                        action: 'x8_evs_sync_all_blacklist_status',
                        nonce: x8_evs_ajax.nonce
                    }
                }).done(function(response) {
                    if (response.success) {
                        var updated = response.data && response.data.updated ? response.data.updated : 0;
                        var already = response.data && response.data.already ? response.data.already : 0;
                        if (updated === 0 && already === 0) {
                            setStatusNotice('info', x8_evs_ajax.strings.blacklist_sync_all_none);
                        } else {
                            setStatusNotice(
                                'success',
                                x8_evs_ajax.strings.blacklist_sync_all_success
                                    .replace('%1$d', updated)
                                    .replace('%2$d', already)
                            );
                        }
                        fetchBlacklistEntries(true);
                    } else {
                        var message = response.data && response.data.message ?
                            response.data.message :
                            x8_evs_ajax.strings.blacklist_sync_all_error;
                        setStatusNotice('error', message);
                    }
                }).fail(function() {
                    setStatusNotice('error', x8_evs_ajax.strings.blacklist_sync_all_error);
                }).always(function() {
                    $syncAllButton.prop('disabled', false).text(x8_evs_ajax.strings.blacklist_sync_all);
                });
            });
        }

        $modal.on('click', function(e) {
            if ($(e.target).is('#x8-evs-integration-modal')) {
                closeModal();
            }
        });

        $(document).on('keydown', function(e) {
            if (e.key === 'Escape' && $modal.is(':visible')) {
                closeModal();
            }
        });

        if ($tableBody.length) {
            $tableBody.on('click', '.x8-evs-sync-row', function(e) {
                e.preventDefault();
                syncCustomerStatus($(this));
            });
        }
    }

    // Email verification functionality
    function initEmailVerification() {
        $('.x8-evs-verify-form .button-primary').on('click', function(e) {
            e.preventDefault();
            
            var $button = $(this);
            var $input = $button.siblings('input[type="email"]');
            var email = $input.val().trim();
            
            // Validate email
            if (!email || !isValidEmail(email)) {
                showNotification('error', x8_evs_ajax.strings.invalid_email);
                $input.focus();
                return;
            }
            
            // Show loading state
            var originalText = $button.text();
            $button.prop('disabled', true).text(x8_evs_ajax.strings.verifying);
            
            // Make AJAX request
            $.ajax({
                url: x8_evs_ajax.ajax_url,
                type: 'POST',
                data: {
                    action: 'x8_evs_verify_email',
                    nonce: x8_evs_ajax.nonce,
                    email: email
                },
                dataType: 'json',
                success: function(response) {
                    if (response.success) {
                        showNotification('success', 'Email verified successfully!');
                        $input.val('');
                        // Optionally refresh verification table
                        refreshVerificationTable();
                    } else {
                        showNotification('error', response.data || 'Verification failed');
                    }
                },
                error: function() {
                    showNotification('error', 'Network error. Please try again.');
                },
                complete: function() {
                    $button.prop('disabled', false).text(originalText);
                }
            });
        });
        
        // Allow Enter key to submit
        $('.x8-evs-verify-form input[type="email"]').on('keypress', function(e) {
            if (e.which === 13) {
                $(this).siblings('.button-primary').trigger('click');
            }
        });
    }
    
    // Notification system
    function showNotification(type, message) {
        // Remove existing notifications
        $('.x8-evs-notification').remove();
        
        var iconClass = '';
        switch(type) {
            case 'success':
                iconClass = 'dashicons-yes-alt';
                break;
            case 'error':
                iconClass = 'dashicons-dismiss';
                break;
            case 'warning':
                iconClass = 'dashicons-warning';
                break;
            default:
                iconClass = 'dashicons-info';
        }
        
        var notification = $('<div class="x8-evs-notification ' + type + '">' +
            '<span class="dashicons ' + iconClass + '"></span>' +
            '<span>' + message + '</span>' +
            '<button class="x8-evs-notification-close">&times;</button>' +
            '</div>');
        
        $('body').append(notification);
        
        // Show notification
        setTimeout(function() {
            notification.addClass('show');
        }, 100);
        
        // Auto-hide after 5 seconds
        setTimeout(function() {
            hideNotification(notification);
        }, 5000);
        
        // Close button functionality
        notification.find('.x8-evs-notification-close').on('click', function() {
            hideNotification(notification);
        });
    }
    
    function hideNotification(notification) {
        notification.removeClass('show');
        setTimeout(function() {
            notification.remove();
        }, 300);
    }
    
    // Refresh verification table
    function refreshVerificationTable() {
        var $tableContainer = $('.x8-evs-table-container');
        if ($tableContainer.length) {
            // Add loading state
            $tableContainer.addClass('loading');
            
            $.ajax({
                url: x8_evs_ajax.ajax_url,
                type: 'POST',
                data: {
                    action: 'x8_evs_get_verifications',
                    nonce: x8_evs_ajax.nonce
                },
                success: function(response) {
                    if (response.success) {
                        $tableContainer.html(response.data);
                    }
                },
                complete: function() {
                    $tableContainer.removeClass('loading');
                }
            });
        }
    }
    
    // Email validation
    function isValidEmail(email) {
        var emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        return emailRegex.test(email);
    }
    
    // Settings form handling
    function initSettingsForm() {
        // Handle checkbox changes
        $('.x8-evs-settings-content input[type="checkbox"]').on('change', function() {
            var $checkbox = $(this);
            var setting = $checkbox.attr('name');
            var value = $checkbox.is(':checked') ? 1 : 0;
            
            // Auto-save setting
            $.ajax({
                url: x8_evs_ajax.ajax_url,
                type: 'POST',
                data: {
                    action: 'x8_evs_save_setting',
                    nonce: x8_evs_ajax.nonce,
                    setting: setting,
                    value: value
                },
                success: function(response) {
                    if (response.success) {
                        showNotification('success', 'Setting saved!');
                    }
                }
            });
        });
    }
    
    // Log controls
    function initLogControls() {
        $('.x8-evs-log-controls .button').on('click', function(e) {
            e.preventDefault();
            
            var $button = $(this);
            var action = $button.text().toLowerCase().includes('clear') ? 'clear_logs' : 'download_logs';
            
            if (action === 'clear_logs') {
                if (!confirm('Are you sure you want to clear all logs?')) {
                    return;
                }
            }
            
            var originalText = $button.text();
            $button.prop('disabled', true).text('Processing...');
            
            if (action === 'download_logs') {
                // Create download link
                var downloadUrl = x8_evs_ajax.ajax_url + '?action=x8_evs_download_logs&nonce=' + x8_evs_ajax.nonce;
                window.location.href = downloadUrl;
                $button.prop('disabled', false).text(originalText);
            } else {
                $.ajax({
                    url: x8_evs_ajax.ajax_url,
                    type: 'POST',
                    data: {
                        action: 'x8_evs_clear_logs',
                        nonce: x8_evs_ajax.nonce
                    },
                    success: function(response) {
                        if (response.success) {
                            $('.x8-evs-log-content').html('<p style="text-align: center; padding: 40px; color: #646970;">No log entries available.</p>');
                            showNotification('success', 'Logs cleared successfully!');
                        } else {
                            showNotification('error', 'Failed to clear logs.');
                        }
                    },
                    complete: function() {
                        $button.prop('disabled', false).text(originalText);
                    }
                });
            }
        });
    }
    
    // Animate numbers on dashboard
    function animateNumbers() {
        $('.x8-evs-stat-number').each(function() {
            var $this = $(this);
            var target = parseInt($this.text().replace(/[^\d]/g, ''));
            
            if (!isNaN(target)) {
                var current = 0;
                var increment = target / 30; // 30 frames
                
                var timer = setInterval(function() {
                    current += increment;
                    if (current >= target) {
                        current = target;
                        clearInterval(timer);
                    }
                    
                    var displayValue = Math.floor(current);
                    if ($this.text().includes('%')) {
                        displayValue += '%';
                    }
                    $this.text(displayValue);
                }, 50);
            }
        });
    }
    
    // Handle status card animations
    function initStatusCards() {
        $('.x8-evs-status-card, .x8-evs-stat-card').on('mouseenter', function() {
            $(this).addClass('hover');
        }).on('mouseleave', function() {
            $(this).removeClass('hover');
        });
    }
    
    // Search functionality for tables
    function initTableSearch() {
        if ($('.x8-evs-table-search').length) {
            $('.x8-evs-table-search').on('input', function() {
                var searchTerm = $(this).val().toLowerCase();
                var $table = $(this).closest('.x8-evs-table-container').find('table');
                
                $table.find('tbody tr').each(function() {
                    var $row = $(this);
                    var text = $row.text().toLowerCase();
                    
                    if (text.includes(searchTerm)) {
                        $row.show();
                    } else {
                        $row.hide();
                    }
                });
            });
        }
    }
    
    /**
     * Toggle location provider API key fields based on the selected service
     */
    function initLocationProviderSelect() {
        var $select = $('#x8_evs_location_provider');
        if (!$select.length) {
            return;
        }
        
        function toggleProviderFields() {
            var provider = $select.val();
            $('.x8-evs-location-provider-field').each(function() {
                var $row = $(this);
                $row.toggle($row.data('provider') === provider);
            });
        }
        
        $select.on('change', toggleProviderFields);
        toggleProviderFields();
    }
    
    // Initialize all functionality
    function init() {
        console.log('X8 Verify: Initializing admin functionality...');
        console.log('X8 Verify: Admin container found:', $('.x8-evs-admin-container').length);
        console.log('X8 Verify: Single customer page found:', $('.x8-evs-single-customer').length);
        
        // Check if we're on the X8 Verify admin page or single customer page
        if ($('.x8-evs-admin-container').length || $('.x8-evs-single-customer').length) {
            console.log('X8 Verify: On admin page or single customer page, initializing components...');
            initTabs();
            initEmailVerification();
            initSettingsForm();
            initLogControls();
            initStatusCards();
            initTableSearch();
            initCredentialsUpdate();
            initCustomerManagement();
            initSingleCustomerPage();
            initBlockedStatesControls();
            initAllowedCountriesControls();
            initAgeRequirements();
            initVerificationPageSelect();
            initCacheManagement();
            initIntegrationModal();
            initThresholdSliders();
            initDocumentTypesTable();
            initLocationProviderSelect();
            
            // Animate numbers on dashboard load
            if ($('#dashboard').hasClass('active')) {
                setTimeout(animateNumbers, 500);
            }
            
            // Animate numbers when dashboard tab is clicked
            $('.x8-evs-tab[data-tab="dashboard"]').on('click', function() {
                setTimeout(animateNumbers, 300);
            });
            
            // Load customers when customers tab is clicked
            $('.x8-evs-tab[data-tab="customers"]').on('click', function() {
                setTimeout(function() {
                    if ($('.x8-evs-customers-table').length) {
                        filterCustomers(1);
                    }
                }, 100);
            });
        } else {
            console.log('X8 Verify: Not on admin page or single customer page');
        }
    }
    
    // Credentials update functionality
    function initCredentialsUpdate() {
        // Close popup when clicking outside
        $(document).on('click', function(e) {
            var $popup = $('.x8-evs-credentials-update');
            var $button = $('.x8-evs-header-actions .button-secondary');
            
            if ($popup.is(':visible') && 
                !$popup.is(e.target) && 
                $popup.has(e.target).length === 0 && 
                !$button.is(e.target)) {
                $popup.hide();
            }
        });
        
        // Close popup with escape key
        $(document).on('keydown', function(e) {
            if (e.key === 'Escape' && $('.x8-evs-credentials-update').is(':visible')) {
                $('.x8-evs-credentials-update').hide();
            }
        });
        
        // Add form validation
        $('.x8-evs-credentials-form-inline').on('submit', function(e) {
            var $form = $(this);
            var username = $form.find('input[name="x8_evs_username"]').val().trim();
            var password = $form.find('input[name="x8_evs_password"]').val().trim();
            
            if (!username || !password) {
                e.preventDefault();
                showNotification('error', 'Please fill in both username and password fields.');
                return false;
            }
            
            // Show loading state
            var $submitBtn = $form.find('input[type="submit"]');
            var originalText = $submitBtn.val();
            $submitBtn.prop('disabled', true).val('Updating...');
            
            // Note: The form will submit normally, but we show loading state
            setTimeout(function() {
                $submitBtn.prop('disabled', false).val(originalText);
            }, 3000);
        });
    }
    
    // Initialize when document is ready
    init();
    
    // Re-initialize on AJAX complete (for dynamic content)
    $(document).ajaxComplete(function() {
        initTableSearch();
    });
    
    // Customer management functionality
    function initCustomerManagement() {
        // Customer Search
        $('.x8-evs-customer-search').on('input', debounce(function() {
            filterCustomers();
        }, 300));
        
        // Status Filter
        $('.x8-evs-status-filter').on('change', function() {
            filterCustomers();
        });
        
        // Export to Excel
        $(document).on('click', '.x8-evs-export-excel', function(e) {
            e.preventDefault();
            if (typeof x8_evs_ajax === 'undefined' || !x8_evs_ajax.export_url || !x8_evs_ajax.export_nonce) return;
            var statusFilter = $('#x8-evs-export-status').val() || '';
            var searchTerm = $('.x8-evs-customer-search').val() || '';
            var url = x8_evs_ajax.export_url + '&_wpnonce=' + encodeURIComponent(x8_evs_ajax.export_nonce) + '&status_filter=' + encodeURIComponent(statusFilter);
            if (searchTerm) url += '&search_term=' + encodeURIComponent(searchTerm);
            window.location = url;
        });
        
        // Initialize events for current content
        initCustomerManagementEvents();
        
        // Pagination handler
        $(document).on('click', '.x8-evs-page-btn', function(e) {
            e.preventDefault();
            var page = $(this).data('page');
            filterCustomers(page);
        });
        
        // Load initial data if we're on the customers tab
        if ($('#customers').hasClass('active') && $('.x8-evs-customers-table').length) {
            filterCustomers(1);
        }
    }
    
    // Initialize customer management events (for dynamic content)
    function initCustomerManagementEvents() {
        // Select All Checkbox
        $('.x8-evs-select-all').off('change.customer-mgmt').on('change.customer-mgmt', function() {
            var isChecked = $(this).is(':checked');
            $('.x8-evs-customers-table input[name="customer[]"]').prop('checked', isChecked);
            updateSelectAllState();
        });
        
        // Individual Checkboxes (already using document delegation, so no need to re-bind)
        $(document).off('change.customer-mgmt', '.x8-evs-customers-table input[name="customer[]"]').on('change.customer-mgmt', '.x8-evs-customers-table input[name="customer[]"]', function() {
            updateSelectAllState();
        });
        
        // Edit Customer (already using document delegation, so no need to re-bind)
        $(document).off('click.customer-mgmt', '.x8-evs-edit-customer').on('click.customer-mgmt', '.x8-evs-edit-customer', function(e) {
            e.preventDefault();
            var customerId = $(this).data('id');
            editCustomer(customerId);
        });
        
        // Delete Customer (already using document delegation, so no need to re-bind)
        $(document).off('click.customer-mgmt', '.x8-evs-delete-customer').on('click.customer-mgmt', '.x8-evs-delete-customer', function(e) {
            e.preventDefault();
            var customerId = $(this).data('id');
            if (confirm('Are you sure you want to delete this customer?')) {
                deleteCustomer(customerId);
            }
        });
    }
    
    // Filter customers based on search and status using AJAX
    function filterCustomers(page) {
        page = page || 1; // Default to page 1 if not provided
        console.log('X8 Verify: filterCustomers called with page:', page);
        var searchTerm = $('.x8-evs-customer-search').val();
        var statusFilter = $('.x8-evs-status-filter').val();
        console.log('X8 Verify: Search term:', searchTerm, 'Status filter:', statusFilter);
        
        // Show loading state
        var $tableBody = $('.x8-evs-customers-table tbody');
        var $pagination = $('.x8-evs-pagination');
        
        $tableBody.html('<tr><td colspan="8" style="text-align: center; padding: 40px;"><span class="dashicons dashicons-update" style="animation: spin 1s linear infinite; font-size: 20px;"></span> Loading customers...</td></tr>');
        $pagination.html('');
        
        // Make AJAX request
        $.ajax({
            url: x8_evs_ajax.ajax_url,
            type: 'POST',
            data: {
                action: 'x8_evs_filter_customers',
                nonce: x8_evs_ajax.nonce,
                search_term: searchTerm,
                status_filter: statusFilter,
                page: page
            },
            dataType: 'json',
            success: function(response) {
                console.log('X8 Verify: AJAX response received', response);
                if (response.success) {
                    // Update table rows
                    $tableBody.html(response.data.table_rows);
                    
                    // Update pagination
                    if (response.data.pagination) {
                        $pagination.html(response.data.pagination);
                    }
                    
                    // Re-initialize customer management functionality for new content
                    initCustomerManagementEvents();
                    
                    console.log('X8 Verify: Customer table updated successfully');
                    
                } else {
                    console.error('X8 Verify: Error in response', response.data);
                    $tableBody.html('<tr><td colspan="8" style="text-align: center; padding: 40px; color: #dc2626;">Error loading customers: ' + (response.data || 'Unknown error') + '</td></tr>');
                }
            },
            error: function(xhr, textStatus, errorThrown) {
                console.error('X8 Verify: AJAX error', textStatus, errorThrown);
                $tableBody.html('<tr><td colspan="8" style="text-align: center; padding: 40px; color: #dc2626;">Network error. Please try again.</td></tr>');
            }
        });
    }
    
    // Update select all checkbox state
    function updateSelectAllState() {
        var $selectAll = $('.x8-evs-select-all');
        var $checkboxes = $('.x8-evs-customers-table input[name="customer[]"]:visible');
        var $checkedBoxes = $checkboxes.filter(':checked');
        
        if ($checkedBoxes.length === 0) {
            $selectAll.prop('checked', false).prop('indeterminate', false);
        } else if ($checkedBoxes.length === $checkboxes.length) {
            $selectAll.prop('checked', true).prop('indeterminate', false);
        } else {
            $selectAll.prop('checked', false).prop('indeterminate', true);
        }
    }
    
    // Edit customer
    function editCustomer(customerId) {
        // This could open a modal with customer data pre-filled
        // For now, we'll show a notification
        showNotification('info', 'Edit customer functionality coming soon!');
    }
    
    // Delete customer
    function deleteCustomer(customerId) {
        $.ajax({
            url: x8_evs_ajax.ajax_url,
            type: 'POST',
            data: {
                action: 'x8_evs_delete_customer',
                nonce: x8_evs_ajax.nonce,
                customer_id: customerId
            },
            success: function(response) {
                if (response.success) {
                    showNotification('success', 'Customer deleted successfully!');
                    refreshCustomerTable();
                } else {
                    showNotification('error', response.data || 'Failed to delete customer.');
                }
            },
            error: function() {
                showNotification('error', 'Network error. Please try again.');
            }
        });
    }
    
    // Refresh customer table
    function refreshCustomerTable() {
        // Use the filter function to refresh the current view
        filterCustomers(1); // Reset to first page
    }
    
    // Debounce function for search
    function debounce(func, wait) {
        var timeout;
        return function executedFunction() {
            var context = this;
            var args = arguments;
            var later = function() {
                timeout = null;
                func.apply(context, args);
            };
            clearTimeout(timeout);
            timeout = setTimeout(later, wait);
        };
    }
    
    // Single Customer Page functionality
    function initSingleCustomerPage() {
        console.log('X8 Verify: Initializing single customer page functionality...');
        console.log('X8 Verify: Update status button found:', $('#x8-evs-update-status-btn').length);
        console.log('X8 Verify: Status modal found:', $('#x8-evs-status-modal').length);
        
        // Status update modal functionality
        $('#x8-evs-update-status-btn').on('click', function(e) {
            e.preventDefault();
            console.log('X8 Verify: Update status button clicked');
            var $modal = $('#x8-evs-status-modal');
            console.log('X8 Verify: Modal element found:', $modal.length);
            $modal.show().addClass('show');
        });
        
        // Fallback: Also bind to document for dynamic content
        $(document).on('click', '#x8-evs-update-status-btn', function(e) {
            e.preventDefault();
            console.log('X8 Verify: Update status button clicked (document binding)');
            var $modal = $('#x8-evs-status-modal');
            console.log('X8 Verify: Modal element found (document binding):', $modal.length);
            $modal.show().addClass('show');
        });
        
        // Request New Documents button functionality
        $('#x8-evs-request-documents-btn').on('click', function(e) {
            e.preventDefault();
            console.log('X8 Verify: Request documents button clicked');
            
            // Show confirmation dialog
            if (confirm('Are you sure you want to request new documents from this user? This will ask them to upload new KYC documents and go through verification again.')) {
                requestNewDocuments();
            }
        });
        
        // Fallback: Also bind to document for dynamic content
        $(document).on('click', '#x8-evs-request-documents-btn', function(e) {
            e.preventDefault();
            console.log('X8 Verify: Request documents button clicked (document binding)');
            
            // Show confirmation dialog
            if (confirm('Are you sure you want to request new documents from this user? This will ask them to upload new KYC documents and go through verification again.')) {
                requestNewDocuments();
            }
        });
        
        // Close modal
        $('.x8-evs-modal-close, #x8-evs-close-status-modal, #x8-evs-cancel-status').on('click', function() {
            $('#x8-evs-status-modal').hide().removeClass('show');
        });
        
        // Close modal when clicking outside
        $('#x8-evs-status-modal').on('click', function(e) {
            if ($(e.target).is('#x8-evs-status-modal')) {
                $(this).hide().removeClass('show');
            }
        });
        
        // Close modal with escape key
        $(document).on('keydown', function(e) {
            if (e.key === 'Escape' && $('#x8-evs-status-modal').is(':visible')) {
                $('#x8-evs-status-modal').hide().removeClass('show');
            }
        });
        
        // Show/hide additional data fields based on status selection
        $('#new_status').on('change', function() {
            var selectedStatus = $(this).val();
            var $additionalData = $('#x8-evs-additional-data');
            var $verificationMethodRow = $('#x8-evs-verification-method-row');


            $additionalData.hide();
            
            
            if (selectedStatus === 'verified') {
                // Show verification method selection for verified status
                $verificationMethodRow.show();
                
                // Always show additional data fields for verified status
                //$additionalData.show();
                $('#x8-evs-status-modal .x8-evs-modal-header h3').html(
                    '<span class="dashicons dashicons-update"></span>' +
                    'Update Customer Status - Document Upload'
                );
                
                // Always show document upload fields
                $('#document_front_image').closest('.x8-evs-form-group').show();
                $('#document_back_image').closest('.x8-evs-form-group').show();
                $('#document_portrait_image').closest('.x8-evs-form-group').show();
                
                // Always show address fields
                $('.x8-evs-address-fields').closest('.x8-evs-form-group').show();
            } else {
                // Hide verification method and additional data fields for other statuses
                $verificationMethodRow.hide();
                $additionalData.hide();
                $('#x8-evs-status-modal .x8-evs-modal-header h3').html(
                    '<span class="dashicons dashicons-update"></span>' +
                    'Update Customer Status'
                );
            }
        });
        
        // Initialize file uploads
        initFileUploads();
        
        // Handle file upload functionality
        function initFileUploads() {
            // Front document upload
            $('#document_front_image').on('change', function(e) {
                handleFileUpload(e, 'front');
            });
            
            // Back document upload
            $('#document_back_image').on('change', function(e) {
                handleFileUpload(e, 'back');
            });
            
            // Portrait document upload
            $('#document_portrait_image').on('change', function(e) {
                handleFileUpload(e, 'portrait');
            });
            
            // Remove file buttons
            $(document).on('click', '.x8-evs-remove-file', function() {
                var target = $(this).data('target');
                removeFile(target);
            });
            
            // Drag and drop functionality
            $('.x8-evs-file-upload-area').on('dragover', function(e) {
                e.preventDefault();
                $(this).addClass('dragover');
            });
            
            $('.x8-evs-file-upload-area').on('dragleave', function(e) {
                e.preventDefault();
                $(this).removeClass('dragover');
            });
            
            $('.x8-evs-file-upload-area').on('drop', function(e) {
                e.preventDefault();
                $(this).removeClass('dragover');
                var files = e.originalEvent.dataTransfer.files;
                var target = $(this).attr('id').replace('-upload-area', '');
                if (files.length > 0) {
                    handleFileUpload({ target: { files: files } }, target);
                }
            });
        }
        
        function handleFileUpload(e, target) {
            var file = e.target.files[0];
            if (!file) return;
            
            // Validate file type
            if (!file.type.match('image.*')) {
                showNotification('error', 'Please select an image file.');
                return;
            }
            
            // Validate file size (5MB)
            if (file.size > 5 * 1024 * 1024) {
                showNotification('error', 'File size must be less than 5MB.');
                return;
            }
            
            // Create preview
            var reader = new FileReader();
            reader.onload = function(e) {
                $('#' + target + '-preview').show();
                $('#' + target + '-preview img').attr('src', e.target.result);
                $('#' + target + '-upload-area').hide();
            };
            reader.readAsDataURL(file);
        }
        
        function removeFile(target) {
            $('#' + target + '-preview').hide();
            $('#' + target + '-upload-area').show();
            $('#' + target + '_image').val('');
        }
        
        // Handle status form submission
        $('#x8-evs-status-form').on('submit', function(e) {
            e.preventDefault();
            
            var $form = $(this);
            var customerId = $form.find('input[name="customer_id"]').val();
            var newStatus = $form.find('select[name="new_status"]').val();
            var notes = $form.find('textarea[name="status_notes"]').val();
            
            // Show loading state
            var $submitBtn = $form.find('button[type="submit"]');
            var originalText = $submitBtn.text();
            $submitBtn.prop('disabled', true).text('Updating...');
            
            // Make AJAX request
            $.ajax({
                url: x8_evs_ajax.ajax_url,
                type: 'POST',
                data: {
                    action: 'x8_evs_update_customer_status',
                    nonce: x8_evs_ajax.nonce,
                    customer_id: customerId,
                    new_status: newStatus,
                    notes: notes
                },
                dataType: 'json',
                success: function(response) {
                    if (response.success) {
                        showNotification('success', 'Customer status updated successfully!');
                        $('#x8-evs-status-modal').hide();
                        
                        // Update the status badge on the page
                        updateStatusBadge(newStatus);
                        
                        // Update verification details if notes changed
                        if (notes) {
                            $('.x8-evs-info-item:contains("Verification Notes") span').text(notes);
                        }
                        
                        // Update verification date
                        var currentDate = new Date().toLocaleDateString('en-US', {
                            year: 'numeric',
                            month: 'long',
                            day: 'numeric',
                            hour: '2-digit',
                            minute: '2-digit'
                        });
                        $('.x8-evs-info-item:contains("Verification Date") span').text(currentDate);
                        
                    } else {
                        showNotification('error', response.data || 'Failed to update customer status.');
                    }
                },
                error: function() {
                    showNotification('error', 'Network error. Please try again.');
                },
                complete: function() {
                    $submitBtn.prop('disabled', false).text(originalText);
                }
            });
        });



        

        
        // Handle verification method change to show/hide address fields
        $('#verification_method').on('change', function() {
            var verificationMethod = $(this).val();
            var $addressFields = $('.x8-evs-address-section');
            var $additionalData = $('#x8-evs-additional-data');


            $additionalData.hide();
            $addressFields.hide();


            if (verificationMethod === 'api') {
               // $addressFields.hide();
                $additionalData.show();
            }
            else if(verificationMethod === 'manual'){
                $additionalData.show();
                $addressFields.show();
            }

            
            // if (verificationMethod === 'api') {
            //     $addressFields.hide();
            //     $additionalData.show();
            //     console.log('X8 Verify: Address fields hidden for API verification');
            // } else if (verificationMethod === 'approve') {
            //     $addressFields.hide();
            //     $additionalData.hide();
            //     console.log('X8 Verify: Address fields and additional data hidden for Approve verification');
            // } else {
            //     $addressFields.show();
            //     console.log('X8 Verify: Address fields shown for manual verification');
            // }



        });
        
        // Initialize address fields visibility based on current verification method
        function initializeAddressFieldsVisibility() {
            var verificationMethod = $('#verification_method').val();
            var $addressFields = $('.x8-evs-address-fields');
            var $additionalData = $('#x8-evs-additional-data');
            
            if (verificationMethod === 'api') {
                $addressFields.hide();
                $additionalData.show();
                console.log('X8 Verify: Address fields initialized as hidden for API verification');
            } else if (verificationMethod === 'approve') {
                $addressFields.hide();
                $additionalData.hide();
                console.log('X8 Verify: Address fields and additional data initialized as hidden for Approve verification');
            } else {
                $addressFields.show();
                $additionalData.hide();
                console.log('X8 Verify: Address fields initialized as shown for manual verification');
            }
        }
        
        // Call initialization when page loads
        initializeAddressFieldsVisibility();
        
        // Handle inline status change form submission
        $('#x8-evs-status-change-form').on('submit', function(e) {
            e.preventDefault();
            console.log('X8 Verify: Status change form submitted');
            
            var $form = $(this);
            var customerId = $form.find('input[name="customer_id"]').val();
            var newStatus = $form.find('select[name="new_status"]').val();
            var notes = $form.find('textarea[name="status_notes"]').val().trim();
            var verificationMethod = $form.find('select[name="verification_method"]').val();
            
            if (!newStatus) {
                showNotification('error', 'Please select a status to change to.');
                return;
            }
            
            // Validate verification method for verified status
            if (newStatus === 'verified' && !verificationMethod) {
                showNotification('error', 'Please select a verification method.');
                $form.find('select[name="verification_method"]').focus();
                return;
            }
            
            if (!notes) {
                showNotification('error', 'Please add notes about this status change.');
                $form.find('textarea[name="status_notes"]').focus();
                return;
            }

            if (newStatus === 'manual_review' && notes.length < 10) {
                showNotification('error', 'Please provide at least 10 characters explaining why this customer requires manual review.');
                $form.find('textarea[name="status_notes"]').focus();
                return;
            }
            
            // Validate required fields based on verification method
            if (newStatus === 'verified' && verificationMethod !== 'approve') {
                // Portrait image is only required if selfie is enabled in settings
                var requireSelfie = $form.find('input[name="x8_evs_require_selfie"]').val() === '1' || 
                                   $form.find('input[name="x8_evs_require_selfie"]').val() === 'true';
                
                // Check if portrait field exists (it won't exist if selfie is disabled)
                var portraitFieldExists = $form.find('input[name="document_portrait_image"]').length > 0;
                var portraitFile = null;
                
                if (portraitFieldExists) {
                    portraitFile = $form.find('input[name="document_portrait_image"]')[0].files[0];
                }
                

            }
            
            // Get additional data if provided
            var documentAddressStreet = $form.find('input[name="document_address_street"]').val() || '';
            var documentAddressCity = $form.find('input[name="document_address_city"]').val() || '';
            var documentAddressState = $form.find('select[name="document_address_state"]').val() || '';
            var documentAddressPostcode = $form.find('input[name="document_address_postcode"]').val() || '';
            var documentAddressCountry = $form.find('input[name="document_address_country"]').val() || '';
            
            // Show loading state
            var $submitBtn = $form.find('button[type="submit"]');
            var originalText = $submitBtn.html();
            $submitBtn.prop('disabled', true).html('<span class="dashicons dashicons-update" style="margin-right: 5px; animation: spin 1s linear infinite;"></span>Updating...');
            
            // Show message
            var $message = $form.find('#x8-evs-status-message');
            $message.html('<span style="color: #2271b1;">Updating status...</span>');
            
            // Create FormData for file uploads
            var formData = new FormData();
            formData.append('action', 'x8_evs_update_customer_status');
            formData.append('nonce', x8_evs_ajax.nonce);
            formData.append('customer_id', customerId);
            formData.append('new_status', newStatus);
            formData.append('notes', notes);
            formData.append('verification_method', verificationMethod);
            formData.append('document_address_street', documentAddressStreet);
            formData.append('document_address_city', documentAddressCity);
            formData.append('document_address_state', documentAddressState);
            formData.append('document_address_postcode', documentAddressPostcode);
            formData.append('document_address_country', documentAddressCountry);
            
            // Add files if they exist
            var frontFile = $form.find('input[name="document_front_image"]')[0].files[0];
            var backFile = $form.find('input[name="document_back_image"]')[0].files[0];
            
            if (frontFile) {
                formData.append('document_front_image', frontFile);
            }
            if (backFile) {
                formData.append('document_back_image', backFile);
            }
            
            // Only process portrait file if the field exists (selfie enabled)
            var portraitField = $form.find('input[name="document_portrait_image"]');
            if (portraitField.length > 0) {
                var portraitFile = portraitField[0].files[0];
                if (portraitFile) {
                    formData.append('document_portrait_image', portraitFile);
                }
            }
            
            // Make AJAX request
            $.ajax({
                url: x8_evs_ajax.ajax_url,
                type: 'POST',
                data: formData,
                processData: false,
                contentType: false,
                dataType: 'json',
                success: function(response) {
                    if (response.success) {
                        // Prefer the status the server actually applied (API verification
                        // may result in waiting/manual_review/block instead of the selection)
                        var appliedStatus = newStatus;
                        if (response.data) {
                            appliedStatus = response.data.verification_status || response.data.new_status || newStatus;
                        }
                        var serverMessage = (response.data && response.data.message) ? response.data.message : 'Customer status updated successfully!';
                        showNotification('success', serverMessage);
                        
                        // Update the status badge on the page
                        updateStatusBadge(appliedStatus);
                        
                        // Update verification details if notes changed
                        var finalNotes = notes;
                        if (!finalNotes && response.data && response.data.admin_note) {
                            finalNotes = response.data.admin_note;
                        }
                        if (finalNotes) {
                            $('.x8-evs-info-item:contains("Verification Notes") span').text(finalNotes);
                        }
                        
                        // Update verification date
                        var currentDate = new Date().toLocaleDateString('en-US', {
                            year: 'numeric',
                            month: 'long',
                            day: 'numeric',
                            hour: '2-digit',
                            minute: '2-digit'
                        });
                        $('.x8-evs-info-item:contains("Verification Date") span').text(currentDate);
                        
                        // Show success message
                        $message.html('<span style="color: #10b981;">✓ Status updated successfully!</span>');
                        
                        // Reset form
                        $form.find('select[name="new_status"]').val('');
                        $form.find('textarea[name="status_notes"]').val('');
                        $form.find('input[name="document_address_street"]').val('');
                        $form.find('input[name="document_address_city"]').val('');
                        $form.find('select[name="document_address_state"]').val('');
                        $form.find('input[name="document_address_postcode"]').val('');
                        $form.find('input[name="document_address_country"]').val('');
                        
                        // Refresh status history
                        refreshStatusHistory();
                        
                        // Close modal after a short delay
                        setTimeout(function() {
                            $('#x8-evs-status-modal').hide();
                        }, 1500);
                        
                    } else {
                        // Check if this is a missing data error
                        if (response.data && response.data.requires_additional_data) {
                            showNotification('warning', response.data.message);
                            $message.html('<span style="color: #f59e0b;">⚠ ' + response.data.message + '</span>');
                            
                            // Show additional data fields
                            $('#x8-evs-additional-data').show();
                            
                            // Update modal title to indicate additional data is needed
                            $('#x8-evs-status-modal .x8-evs-modal-header h3').html(
                                '<span class="dashicons dashicons-update"></span>' +
                                'Update Customer Status - Additional Data Required'
                            );
                            
                            // Focus on the first additional field
                            $('#document_front_image').focus();
                        } else {
                            showNotification('error', response.data || 'Failed to update customer status.');
                            $message.html('<span style="color: #dc2626;">✗ ' + (response.data || 'Update failed') + '</span>');
                        }
                    }
                },
                error: function() {
                    showNotification('error', 'Network error. Please try again.');
                    $message.html('<span style="color: #dc2626;">✗ Network error. Please try again.</span>');
                },
                complete: function() {
                    $submitBtn.prop('disabled', false).html(originalText);
                    
                    // Clear message after 3 seconds
                    setTimeout(function() {
                        $message.html('');
                    }, 3000);
                }
            });
        });
        
        // KYC Image interactions
        $('.x8-evs-kyc-image').on('click', function() {
            var imageSrc = $(this).attr('src');
            openImageLightbox(imageSrc);
        });
        
        // Image loading error handling
        $('.x8-evs-kyc-image').on('error', function() {
            $(this).closest('.x8-evs-image-container').html(
                '<div class="x8-evs-no-image">' +
                '<span class="dashicons dashicons-format-image"></span>' +
                '<p>Image failed to load</p>' +
                '</div>'
            );
        });
        
        // Image loading success
        $('.x8-evs-kyc-image').on('load', function() {
            $(this).closest('.x8-evs-image-container').removeClass('loading');
        });
    }
    
    // Update status badge
    function updateStatusBadge(newStatus) {
        var statusText = '';
        var statusClass = '';
        
        switch(newStatus) {
            case 'verified':
                statusText = 'Verified';
                statusClass = 'verified';
                break;
            case 'block':
            case 'blocked':
                statusText = 'Blocked';
                statusClass = 'blocked';
                break;
            case 'manual_review':
                statusText = 'Manual Review';
                statusClass = 'manual_review';
                break;
            case 'waiting':
                statusText = 'Waiting for API Result';
                statusClass = 'pending';
                break;
            case 'error':
                statusText = 'Verification Error';
                statusClass = 'error';
                break;
            default:
                statusText = 'Pending';
                statusClass = 'pending';
        }
        
        // Update header badge
        $('.x8-evs-customer-title .x8-evs-badge')
            .removeClass('verified blocked pending manual_review')
            .addClass(statusClass)
            .text(statusText);
        
        // Update info section badge
        $('.x8-evs-info-item:contains("Verification Status") .x8-evs-badge')
            .removeClass('verified blocked pending manual_review')
            .addClass(statusClass)
            .text(statusText);
    }
    
    // Request new documents from user
    function requestNewDocuments() {
        console.log('X8 Verify: Requesting new documents...');
        
        // Get customer ID from the page
        var customerId = $('input[name="customer_id"]').val() || window.location.search.match(/customer_id=(\d+)/)?.[1];
        
        if (!customerId) {
            showNotification('error', 'Customer ID not found.');
            return;
        }
        
        // Show loading state
        var $btn = $('#x8-evs-request-documents-btn');
        var originalText = $btn.html();
        $btn.prop('disabled', true).html('<span class="dashicons dashicons-update" style="margin-right: 5px; animation: spin 1s linear infinite;"></span>Requesting...');
        
        // Make AJAX request
        $.ajax({
            url: x8_evs_ajax.ajax_url,
            type: 'POST',
            data: {
                action: 'x8_evs_request_new_documents',
                nonce: x8_evs_ajax.nonce,
                customer_id: customerId
            },
            dataType: 'json',
            success: function(response) {
                if (response.success) {
                    showNotification('success', 'Document request sent successfully! The user will be notified to upload new documents.');
                    
                    // Update status to pending if needed
                    if (response.data && response.data.status_updated) {
                        updateStatusBadge('pending');
                    }
                } else {
                    showNotification('error', response.data || 'Failed to send document request.');
                }
            },
            error: function() {
                showNotification('error', 'Network error. Please try again.');
            },
            complete: function() {
                $btn.prop('disabled', false).html(originalText);
            }
        });
    }
    
    // Refresh status history
    function refreshStatusHistory() {
        // Reload the page to get updated status history
        // This is the simplest approach to ensure we get the latest data
        setTimeout(function() {
            location.reload();
        }, 1000);
    }
    
    // Image lightbox functionality
    function openImageLightbox(imageSrc) {
        // Create lightbox overlay
        var lightbox = $('<div class="x8-evs-lightbox">' +
            '<div class="x8-evs-lightbox-content">' +
            '<img src="' + imageSrc + '" alt="KYC Document" />' +
            '<button class="x8-evs-lightbox-close">' +
            '<span class="dashicons dashicons-no-alt"></span>' +
            '</button>' +
            '</div>' +
            '</div>');
        
        $('body').append(lightbox);
        
        // Show lightbox
        setTimeout(function() {
            lightbox.addClass('show');
        }, 50);
        
        // Close lightbox
        lightbox.on('click', function(e) {
            if ($(e.target).is('.x8-evs-lightbox') || $(e.target).closest('.x8-evs-lightbox-close').length) {
                lightbox.removeClass('show');
                setTimeout(function() {
                    lightbox.remove();
                }, 300);
            }
        });
        
        // Close with escape key
        $(document).on('keydown.lightbox', function(e) {
            if (e.key === 'Escape') {
                lightbox.find('.x8-evs-lightbox-close').trigger('click');
                $(document).off('keydown.lightbox');
            }
        });
    }
    
    // Blocked States Controls with Select2
    function initBlockedStatesControls() {
        // Initialize Select2 for blocked states
        $('#x8_evs_blocked_states').select2({
            placeholder: x8_evs_ajax.strings.select_states,
            allowClear: true,
            width: '100%',
            closeOnSelect: false,
            templateResult: formatStateOption,
            templateSelection: formatStateSelection,
            escapeMarkup: function(markup) {
                return markup;
            },
            language: {
                noResults: function() {
                    return "No states found matching your search";
                },
                searching: function() {
                    return "Searching states...";
                }
            },
            maximumSelectionLength: 51, // All 50 states + DC
            maximumSelectionLengthMessage: function() {
                return "You can only select up to 51 states (all US states and DC)";
            }
        });
        
        // Select All button
        $('.x8-evs-select-all-states').on('click', function(e) {
            e.preventDefault();
            var $select = $('#x8_evs_blocked_states');
            $select.find('option').prop('selected', true);
            $select.trigger('change');
            updateStateStatus();
        });
        
        // Clear All button
        $('.x8-evs-clear-states').on('click', function(e) {
            e.preventDefault();
            var $select = $('#x8_evs_blocked_states');
            $select.val(null).trigger('change');
            updateStateStatus();
        });
        
        // Toggle Selection button
        $('.x8-evs-toggle-states').on('click', function(e) {
            e.preventDefault();
            var $select = $('#x8_evs_blocked_states');
            var $options = $select.find('option');
            var selectedCount = $select.find('option:selected').length;
            var totalCount = $options.length;
            
            if (selectedCount === 0) {
                // If none selected, select all
                $options.prop('selected', true);
            } else if (selectedCount === totalCount) {
                // If all selected, clear all
                $select.val(null);
            } else {
                // If some selected, select the unselected ones
                $options.prop('selected', function() {
                    return !$(this).is(':selected');
                });
            }
            
            $select.trigger('change');
            updateStateStatus();
        });
        
        // Update status when selection changes
        $('#x8_evs_blocked_states').on('change', function() {
            updateStateStatus();
        });
        
        // Initialize status
        updateStateStatus();
        
        // Add custom styling for Select2
        addSelect2CustomStyling();
        
        // Add keyboard shortcuts
        addKeyboardShortcuts();
        
        // Add accessibility features
        addAccessibilityFeatures();
    }
    
    // Allowed Countries Controls with Select2
    function initAllowedCountriesControls() {
        // Initialize Select2 for allowed countries
        $('#x8_evs_allowed_countries').select2({
            placeholder: x8_evs_ajax.strings.select_countries || 'Select countries...',
            allowClear: true,
            width: '100%',
            closeOnSelect: false,
            templateResult: formatCountryOption,
            templateSelection: formatCountrySelection,
            escapeMarkup: function(markup) {
                return markup;
            },
            language: {
                noResults: function() {
                    return "No countries found matching your search";
                },
                searching: function() {
                    return "Searching countries...";
                }
            },
            maximumSelectionLength: 200, // Allow selection of many countries
            maximumSelectionLengthMessage: function() {
                return "You can select up to 200 countries";
            }
        });
        
        // Select All button
        $('.x8-evs-select-all-countries').on('click', function(e) {
            e.preventDefault();
            var $select = $('#x8_evs_allowed_countries');
            $select.find('option').prop('selected', true);
            $select.trigger('change');
            updateCountryStatus();
        });
        
        // Clear All button
        $('.x8-evs-clear-countries').on('click', function(e) {
            e.preventDefault();
            var $select = $('#x8_evs_allowed_countries');
            $select.val(null).trigger('change');
            updateCountryStatus();
        });
        
        // Toggle Selection button
        $('.x8-evs-toggle-countries').on('click', function(e) {
            e.preventDefault();
            var $select = $('#x8_evs_allowed_countries');
            var $options = $select.find('option');
            var selectedCount = $select.find('option:selected').length;
            var totalCount = $options.length;
            
            if (selectedCount === 0) {
                // If none selected, select all
                $options.prop('selected', true);
            } else if (selectedCount === totalCount) {
                // If all selected, clear all
                $select.val(null);
            } else {
                // If some selected, select the unselected ones
                $options.prop('selected', function() {
                    return !$(this).is(':selected');
                });
            }
            
            $select.trigger('change');
            updateCountryStatus();
        });
        
        // Update status when selection changes
        $('#x8_evs_allowed_countries').on('change', function() {
            updateCountryStatus();
        });
        
        // Initialize status
        updateCountryStatus();
        
        // Add custom styling for Select2
        addSelect2CustomStyling();
        
        // Add keyboard shortcuts for countries
        addCountryKeyboardShortcuts();
        
        // Add accessibility features for countries
        addCountryAccessibilityFeatures();
    }
    
    // Format state option for Select2 dropdown
    function formatStateOption(state) {
        if (!state.id) {
            return state.text;
        }
        
        var $option = $(state.element);
        var stateCode = state.id;
        var stateName = state.text.replace(' (' + stateCode + ')', '');
        
        return '<div class="x8-evs-state-option">' +
               '<span class="x8-evs-state-name">' + stateName + '</span>' +
               '<span class="x8-evs-state-code">' + stateCode + '</span>' +
               '</div>';
    }
    
    // Format state selection for Select2 tags
    function formatStateSelection(state) {
        if (!state.id) {
            return state.text;
        }
        
        var stateCode = state.id;
        var stateName = state.text.replace(' (' + stateCode + ')', '');
        
        return '<span class="x8-evs-state-tag">' + stateName + ' (' + stateCode + ')</span>';
    }
    
    // Format country option for Select2 dropdown
    function formatCountryOption(country) {
        if (!country.id) {
            return country.text;
        }
        
        var $option = $(country.element);
        var countryCode = country.id;
        var countryName = country.text.replace(' (' + countryCode + ')', '');
        
        return '<div class="x8-evs-country-option">' +
               '<span class="x8-evs-country-name">' + countryName + '</span>' +
               '<span class="x8-evs-country-code">' + countryCode + '</span>' +
               '</div>';
    }
    
    // Format country selection for Select2 tags
    function formatCountrySelection(country) {
        if (!country.id) {
            return country.text;
        }
        
        var countryCode = country.id;
        var countryName = country.text.replace(' (' + countryCode + ')', '');
        
        return '<span class="x8-evs-country-tag">' + countryName + ' (' + countryCode + ')</span>';
    }
    
    // Update state selection status
    function updateStateStatus() {
        var $select = $('#x8_evs_blocked_states');
        var selectedCount = $select.find('option:selected').length;
        var totalCount = $select.find('option').length;
        var $statusText = $('.x8-evs-status-text');
        
        var statusMessage = '';
        var statusClass = '';
        
        if (selectedCount === 0) {
            statusMessage = x8_evs_ajax.strings.no_states_selected;
            statusClass = 'x8-evs-status-none';
        } else if (selectedCount === totalCount) {
            statusMessage = x8_evs_ajax.strings.all_states_blocked;
            statusClass = 'x8-evs-status-all';
        } else {
            statusMessage = selectedCount + ' ' + x8_evs_ajax.strings.states_blocked;
            statusClass = 'x8-evs-status-partial';
        }
        
        $statusText.text(statusMessage).removeClass('x8-evs-status-none x8-evs-status-all x8-evs-status-partial').addClass(statusClass);
    }
    
    // Update country selection status
    function updateCountryStatus() {
        var $select = $('#x8_evs_allowed_countries');
        var selectedCount = $select.find('option:selected').length;
        var totalCount = $select.find('option').length;
        var $statusText = $select.closest('.x8-evs-select2-container').find('.x8-evs-status-text');
        
        var statusMessage = '';
        var statusClass = '';
        
        if (selectedCount === 0) {
            statusMessage = 'No countries selected (all countries allowed)';
            statusClass = 'x8-evs-status-none';
        } else if (selectedCount === totalCount) {
            statusMessage = 'All countries selected';
            statusClass = 'x8-evs-status-all';
        } else {
            statusMessage = selectedCount + ' countries selected';
            statusClass = 'x8-evs-status-partial';
        }
        
        $statusText.text(statusMessage).removeClass('x8-evs-status-none x8-evs-status-all x8-evs-status-partial').addClass(statusClass);
    }
    
    // Add custom styling for Select2
    function addSelect2CustomStyling() {
        // Add custom CSS for better styling
        var customCSS = `
            <style>
                .x8-evs-select2-container .select2-container--default .select2-selection--multiple {
                    border: 1px solid #8c8f94;
                    border-radius: 4px;
                    min-height: 35px;
                    padding: 5px;
                }
                
                .x8-evs-select2-container .select2-container--default.select2-container--focus .select2-selection--multiple {
                    border-color: #2271b1;
                    box-shadow: 0 0 0 1px #2271b1;
                }
                
                .x8-evs-select2-container .select2-container--default .select2-selection--multiple .select2-selection__choice {
                    background-color: #2271b1;
                    color: white;
                    border: none;
                    border-radius: 3px;
                    padding: 2px 8px;
                    margin: 2px;
                    font-size: 12px;
                }
                
                .x8-evs-select2-container .select2-container--default .select2-selection--multiple .select2-selection__choice__remove {
                    color: white;
                    margin-right: 5px;
                    font-weight: bold;
                }
                
                .x8-evs-select2-container .select2-container--default .select2-selection--multiple .select2-selection__choice__remove:hover {
                    color: #ff6b6b;
                }
                
                .x8-evs-select2-container .select2-dropdown {
                    border: 1px solid #8c8f94;
                    border-radius: 4px;
                    box-shadow: 0 2px 6px rgba(0,0,0,0.1);
                }
                
                .x8-evs-select2-container .select2-results__option {
                    padding: 8px 12px;
                    border-bottom: 1px solid #f0f0f1;
                }
                
                .x8-evs-select2-container .select2-results__option--highlighted {
                    background-color: #2271b1;
                    color: white;
                }
                
                .x8-evs-state-option {
                    display: flex;
                    justify-content: space-between;
                    align-items: center;
                }
                
                .x8-evs-state-name {
                    font-weight: 500;
                }
                
                .x8-evs-state-code {
                    background: #f0f0f1;
                    padding: 2px 6px;
                    border-radius: 3px;
                    font-size: 11px;
                    font-weight: bold;
                    color: #50575e;
                }
                
                .x8-evs-state-tag {
                    font-weight: 500;
                }
                
                .x8-evs-select2-controls {
                    display: flex;
                    gap: 8px;
                    flex-wrap: wrap;
                }
                
                .x8-evs-select2-controls .button {
                    display: inline-flex;
                    align-items: center;
                    font-size: 12px;
                    padding: 4px 8px;
                    height: auto;
                    line-height: 1.4;
                }
                
                .x8-evs-status-text {
                    font-weight: 500;
                    padding: 4px 8px;
                    border-radius: 3px;
                    display: inline-block;
                }
                
                .x8-evs-status-none {
                    background-color: #d1fae5;
                    color: #065f46;
                }
                
                .x8-evs-status-all {
                    background-color: #fee2e2;
                    color: #991b1b;
                }
                
                .x8-evs-status-partial {
                    background-color: #fef3c7;
                    color: #92400e;
                }
                
                .x8-evs-select2-container .select2-search__field {
                    border: none !important;
                    outline: none !important;
                    box-shadow: none !important;
                }
                
                .x8-evs-select2-container .select2-container--default .select2-selection--multiple .select2-selection__rendered {
                    padding: 0;
                }
            </style>
        `;
        
        $('head').append(customCSS);
    }
    
    // Add keyboard shortcuts for blocked states
    function addKeyboardShortcuts() {
        $(document).on('keydown', function(e) {
            // Only activate when the blocked states select is focused
            if ($('#x8_evs_blocked_states').is(':focus') || $('.select2-container--default').is(':focus')) {
                // Ctrl/Cmd + A: Select all states
                if ((e.ctrlKey || e.metaKey) && e.key === 'a') {
                    e.preventDefault();
                    $('.x8-evs-select-all-states').trigger('click');
                }
                
                // Ctrl/Cmd + D: Clear all states
                if ((e.ctrlKey || e.metaKey) && e.key === 'd') {
                    e.preventDefault();
                    $('.x8-evs-clear-states').trigger('click');
                }
                
                // Ctrl/Cmd + T: Toggle selection
                if ((e.ctrlKey || e.metaKey) && e.key === 't') {
                    e.preventDefault();
                    $('.x8-evs-toggle-states').trigger('click');
                }
            }
        });
    }
    
    // Add accessibility features
    function addAccessibilityFeatures() {
        // Add ARIA labels and descriptions
        $('#x8_evs_blocked_states').attr({
            'aria-label': 'Select states to block customers from',
            'aria-describedby': 'x8_evs_blocked_states_description'
        });
        
        // Add description for screen readers
        if (!$('#x8_evs_blocked_states_description').length) {
            $('<div id="x8_evs_blocked_states_description" class="screen-reader-text">' +
              'Use this dropdown to select US states that should be blocked from verification. ' +
              'You can search for states by typing their name or abbreviation. ' +
              'Use Ctrl+A to select all states, Ctrl+D to clear all states, or Ctrl+T to toggle selection.</div>')
              .insertAfter('#x8_evs_blocked_states');
        }
        
        // Add screen reader only class if not exists
        if (!$('style:contains("screen-reader-text")').length) {
            $('<style>.screen-reader-text { clip: rect(1px, 1px, 1px, 1px); position: absolute !important; height: 1px; width: 1px; overflow: hidden; }</style>').appendTo('head');
        }
        
        // Add tooltips to control buttons
        $('.x8-evs-select-all-states').attr('title', 'Select all states (Ctrl+A)');
        $('.x8-evs-clear-states').attr('title', 'Clear all states (Ctrl+D)');
        $('.x8-evs-toggle-states').attr('title', 'Toggle selection (Ctrl+T)');
    }
    
    // Add keyboard shortcuts for allowed countries
    function addCountryKeyboardShortcuts() {
        $(document).on('keydown', function(e) {
            // Only activate when the allowed countries select is focused
            if ($('#x8_evs_allowed_countries').is(':focus') || $('.select2-container--default').is(':focus')) {
                // Ctrl/Cmd + A: Select all countries
                if ((e.ctrlKey || e.metaKey) && e.key === 'a') {
                    e.preventDefault();
                    $('.x8-evs-select-all-countries').trigger('click');
                }
                
                // Ctrl/Cmd + D: Clear all countries
                if ((e.ctrlKey || e.metaKey) && e.key === 'd') {
                    e.preventDefault();
                    $('.x8-evs-clear-countries').trigger('click');
                }
                
                // Ctrl/Cmd + T: Toggle selection
                if ((e.ctrlKey || e.metaKey) && e.key === 't') {
                    e.preventDefault();
                    $('.x8-evs-toggle-countries').trigger('click');
                }
            }
        });
    }
    
    // Add accessibility features for allowed countries
    function addCountryAccessibilityFeatures() {
        // Add ARIA labels and descriptions
        $('#x8_evs_allowed_countries').attr({
            'aria-label': 'Select countries to allow customers from',
            'aria-describedby': 'x8_evs_allowed_countries_description'
        });
        
        // Add description for screen readers
        if (!$('#x8_evs_allowed_countries_description').length) {
            $('<div id="x8_evs_allowed_countries_description" class="screen-reader-text">' +
              'Use this dropdown to select countries that should be allowed for verification. ' +
              'You can search for countries by typing their name or code. ' +
              'Use Ctrl+A to select all countries, Ctrl+D to clear all countries, or Ctrl+T to toggle selection.</div>')
              .insertAfter('#x8_evs_allowed_countries');
        }
        
        // Add tooltips to control buttons
        $('.x8-evs-select-all-countries').attr('title', 'Select all countries (Ctrl+A)');
        $('.x8-evs-clear-countries').attr('title', 'Clear all countries (Ctrl+D)');
        $('.x8-evs-toggle-countries').attr('title', 'Toggle selection (Ctrl+T)');
    }
    
    // Age Requirements Controls
    function initAgeRequirements() {
        // Show/hide custom age input based on selection
        $('#x8_evs_minimum_age').on('change', function() {
            var selectedValue = $(this).val();
            var $customWrapper = $('#x8_evs_custom_age_wrapper');
            
            if (selectedValue === 'other') {
                $customWrapper.slideDown(300);
                $('#x8_evs_custom_age').focus();
            } else {
                $customWrapper.slideUp(300);
            }
        });
        
        // Validate custom age input
        $('#x8_evs_custom_age').on('input', function() {
            var value = parseInt($(this).val());
            var min = parseInt($(this).attr('min'));
            var max = parseInt($(this).attr('max'));
            
            if (value < min) {
                $(this).val(min);
            } else if (value > max) {
                $(this).val(max);
            }
        });
        
        // Initialize state on page load
        $('#x8_evs_minimum_age').trigger('change');
    }
    
    // Verification Page Select Controls
    function initVerificationPageSelect() {
        // Add page preview functionality
        $('#x8_evs_verification_page').on('change', function() {
            var selectedPageId = $(this).val();
            var $description = $(this).closest('td').find('.description');
            
            // Remove any existing preview link
            $description.find('.x8-evs-page-preview').remove();
            
            if (selectedPageId && selectedPageId !== '0') {
                // Get the selected option text
                var selectedPageTitle = $(this).find('option:selected').text();
                
                // Create preview link (we'll construct the URL based on WordPress permalink structure)
                var previewHtml = '<div class="x8-evs-page-preview" style="margin-top: 8px;">' +
                    '<strong style="color: #10b981;">Selected:</strong> ' + selectedPageTitle + ' ' +
                    '<a href="#" class="x8-evs-view-page" data-page-id="' + selectedPageId + '" style="margin-left: 8px;">' +
                    '<span class="dashicons dashicons-external" style="font-size: 14px; vertical-align: middle;"></span> View Page' +
                    '</a>' +
                    '</div>';
                
                $description.append(previewHtml);
            }
        });
        
        // Handle view page link clicks
        $(document).on('click', '.x8-evs-view-page', function(e) {
            e.preventDefault();
            var pageId = $(this).data('page-id');
            
            // Open page in new tab (construct URL based on WordPress structure)
            // This is a basic URL construction - in a real implementation you'd get the actual permalink
            var pageUrl = window.location.origin + '/?page_id=' + pageId;
            window.open(pageUrl, '_blank');
        });
        
        // Initialize on page load
        $('#x8_evs_verification_page').trigger('change');
    }
    
    // Checkout Verification Flow
    function initCheckoutVerification() {
        // Check if we're on a checkout page and verification is required
        if (window.location.href.indexOf('/checkout') !== -1 || 
            window.location.href.indexOf('/cart') !== -1) {
            
            // Add a notice about verification requirement if needed
            if (typeof x8_evs_checkout !== 'undefined' && x8_evs_checkout.verification_required) {
                showCheckoutVerificationNotice();
            }
        }
    }
    
    function showCheckoutVerificationNotice() {
        // Create notice element
        var notice = $('<div class="x8-evs-checkout-notice" style="background: #fff3cd; border: 1px solid #ffeaa7; padding: 15px; margin: 15px 0; border-radius: 4px;">' +
            '<p style="margin: 0; color: #856404;"><strong>Identity Verification Required</strong><br>' +
            'To complete your purchase, you will need to verify your identity. This is a quick and secure process.</p>' +
            '</div>');
        
        // Insert notice before checkout form
        $('.woocommerce-checkout, .checkout, form[name="checkout"]').prepend(notice);
    }
    
    // Initialize checkout verification
    initCheckoutVerification();
    
    /**
     * Initialize cache management functionality
     */
    function initCacheManagement() {
        // Clear geolocation cache button
        $('#x8_evs_clear_geo_cache').on('click', function(e) {
            e.preventDefault();
            
            var $button = $(this);
            var originalText = $button.html();
            
            // Show loading state
            $button.prop('disabled', true).html('<span class="dashicons dashicons-update" style="margin-right: 5px; animation: spin 1s linear infinite;"></span>Clearing...');
            
            // Make AJAX request
            $.ajax({
                url: x8_evs_ajax.ajax_url,
                type: 'POST',
                data: {
                    action: 'x8_evs_clear_geo_cache',
                    nonce: x8_evs_ajax.nonce
                },
                dataType: 'json',
                success: function(response) {
                    if (response.success) {
                        showCacheMessage('success', response.data.message);
                        updateGeoCacheStatistics(response.data.cache_stats);
                    } else {
                        showCacheMessage('error', response.data || 'Failed to clear cache');
                    }
                },
                error: function() {
                    showCacheMessage('error', 'Network error. Please try again.');
                },
                complete: function() {
                    $button.prop('disabled', false).html(originalText);
                }
            });
        });

        // Clear blocking cache button
        $('#x8_evs_clear_blocking_cache').on('click', function(e) {
            e.preventDefault();
            
            var $button = $(this);
            var originalText = $button.html();
            
            // Show loading state
            $button.prop('disabled', true).html('<span class="dashicons dashicons-update" style="margin-right: 5px; animation: spin 1s linear infinite;"></span>Clearing...');
            
            // Make AJAX request
            $.ajax({
                url: x8_evs_ajax.ajax_url,
                type: 'POST',
                data: {
                    action: 'x8_evs_clear_blocking_cache',
                    nonce: x8_evs_ajax.nonce
                },
                dataType: 'json',
                success: function(response) {
                    if (response.success) {
                        showCacheMessage('success', response.data.message);
                        updateBlockingCacheStatistics(response.data.cache_stats);
                    } else {
                        showCacheMessage('error', response.data || 'Failed to clear cache');
                    }
                },
                error: function() {
                    showCacheMessage('error', 'Network error. Please try again.');
                },
                complete: function() {
                    $button.prop('disabled', false).html(originalText);
                }
            });
        });

        // Clear VPN cache button
        $('#x8_evs_clear_vpn_cache').on('click', function(e) {
            e.preventDefault();
            
            var $button = $(this);
            var originalText = $button.html();
            
            // Show loading state
            $button.prop('disabled', true).html('<span class="dashicons dashicons-update" style="margin-right: 5px; animation: spin 1s linear infinite;"></span>Clearing...');
            
            // Make AJAX request
            $.ajax({
                url: x8_evs_ajax.ajax_url,
                type: 'POST',
                data: {
                    action: 'x8_evs_clear_vpn_cache',
                    nonce: x8_evs_ajax.nonce
                },
                dataType: 'json',
                success: function(response) {
                    if (response.success) {
                        showCacheMessage('success', response.data.message);
                        updateVpnCacheStatistics(response.data.cache_stats);
                    } else {
                        showCacheMessage('error', response.data || 'Failed to clear VPN cache');
                    }
                },
                error: function() {
                    showCacheMessage('error', 'Network error. Please try again.');
                },
                complete: function() {
                    $button.prop('disabled', false).html(originalText);
                }
            });
        });
        
        // Refresh cache statistics button
        $('#x8_evs_refresh_cache_stats').on('click', function(e) {
            e.preventDefault();
            
            var $button = $(this);
            var originalText = $button.html();
            
            // Show loading state
            $button.prop('disabled', true).html('<span class="dashicons dashicons-update" style="margin-right: 5px; animation: spin 1s linear infinite;"></span>Refreshing...');
            
            // Make AJAX request to get updated stats
            $.ajax({
                url: x8_evs_ajax.ajax_url,
                type: 'POST',
                data: {
                    action: 'x8_evs_get_cache_stats',
                    nonce: x8_evs_ajax.nonce
                },
                dataType: 'json',
                success: function(response) {
                    if (response.success) {
                        updateAllCacheStatistics(response.data);
                        showCacheMessage('success', 'Statistics updated successfully');
                    } else {
                        showCacheMessage('error', response.data || 'Failed to refresh statistics');
                    }
                },
                error: function() {
                    showCacheMessage('error', 'Network error. Please try again.');
                },
                complete: function() {
                    $button.prop('disabled', false).html(originalText);
                }
            });
        });

        // Clear verification links button
        $('#x8_evs_clear_verification_links').on('click', function(e) {
            e.preventDefault();
            
            var $button = $(this);
            var originalText = $button.html();
            
            // Show confirmation dialog
            if (!confirm('Are you sure you want to clear all verification links? This will force all customers to generate new verification links. This action cannot be undone.')) {
                return;
            }
            
            // Show loading state
            $button.prop('disabled', true).html('<span class="dashicons dashicons-update" style="margin-right: 5px; animation: spin 1s linear infinite;"></span>Clearing...');
            
            // Make AJAX request
            $.ajax({
                url: x8_evs_ajax.ajax_url,
                type: 'POST',
                data: {
                    action: 'x8_evs_clear_verification_links',
                    nonce: x8_evs_ajax.nonce
                },
                dataType: 'json',
                success: function(response) {
                    if (response.success) {
                        showCacheMessage('success', response.data.message);
                        // Update verification link statistics
                        updateVerificationLinkStatistics(response.data);
                    } else {
                        showCacheMessage('error', response.data || 'Failed to clear verification links');
                    }
                },
                error: function() {
                    showCacheMessage('error', 'Network error. Please try again.');
                },
                complete: function() {
                    $button.prop('disabled', false).html(originalText);
                }
            });
        });
    }
    
    /**
     * Show cache management message
     */
    function showCacheMessage(type, message) {
        var $messageDiv = $('#x8_evs_cache_message');
        var messageClass = type === 'success' ? 'notice-success' : 'notice-error';
        var iconClass = type === 'success' ? 'dashicons-yes' : 'dashicons-no';
        
        var messageHtml = '<div class="notice ' + messageClass + ' is-dismissible" style="margin: 10px 0;">' +
            '<p><span class="dashicons ' + iconClass + '" style="margin-right: 5px;"></span>' + message + '</p>' +
            '</div>';
        
        $messageDiv.html(messageHtml);
        
        // Auto-hide after 5 seconds
        setTimeout(function() {
            $messageDiv.fadeOut();
        }, 5000);
    }
    
    /**
     * Update geolocation cache statistics display
     */
    function updateGeoCacheStatistics(stats) {
        var $geoCacheInfo = $('.x8-evs-cache-section:first .x8-evs-cache-info');
        
        if ($geoCacheInfo.length && stats) {
            // Update cached IPs count
            $geoCacheInfo.find('span').first().text(stats.total_cached_ips || 0);
            
            // Update cache size
            $geoCacheInfo.find('span').last().text((stats.cache_size_mb || 0) + ' MB');
        }
    }

    /**
     * Update blocking cache statistics display
     */
    function updateBlockingCacheStatistics(stats) {
        var $blockingCacheInfo = $('.x8-evs-cache-section:nth-child(2) .x8-evs-cache-info');
        
        if ($blockingCacheInfo.length && stats) {
            // Update cached users count
            $blockingCacheInfo.find('span').eq(0).text(stats.total_cached_users || 0);
            
            // Update blocked users count
            $blockingCacheInfo.find('span').eq(1).text(stats.blocked_users || 0);
            
            // Update allowed users count
            $blockingCacheInfo.find('span').eq(2).text(stats.allowed_users || 0);
            
            // Update cache size
            $blockingCacheInfo.find('span').last().text((stats.cache_size_mb || 0) + ' MB');
        }
    }

    /**
     * Update VPN cache statistics display
     */
    function updateVpnCacheStatistics(stats) {
        var $vpnCacheInfo = $('.x8-evs-cache-section:last .x8-evs-cache-info');
        
        if ($vpnCacheInfo.length && stats) {
            // Update cached IPs count
            $vpnCacheInfo.find('span').first().text(stats.total_cached_ips || 0);
            
            // Update cache size
            $vpnCacheInfo.find('span').last().text((stats.cache_size_mb || 0) + ' MB');
        }
    }

    /**
     * Update all cache statistics display
     */
    function updateAllCacheStatistics(data) {
        if (data.geo_cache_stats) {
            updateGeoCacheStatistics(data.geo_cache_stats);
        }
        if (data.vpn_cache_stats) {
            updateVpnCacheStatistics(data.vpn_cache_stats);
        }
    }

    /**
     * Update verification link statistics display
     */
    function updateVerificationLinkStatistics(data) {
        var $verificationLinkInfo = $('.x8-evs-cache-section:last .x8-evs-cache-info');
        
        if ($verificationLinkInfo.length) {
            // Update active links count to 0 since all links were cleared
            $verificationLinkInfo.find('span').first().text('0');
            
            // Update expired links count to 0 since all links were cleared
            $verificationLinkInfo.find('span').last().text('0');
        }
    }
    
    /**
     * Document types: toggle panel + sync Default radio with Allow checkboxes
     */
    function initDocumentTypesTable() {
        var $panel = $('.x8-evs-document-types-panel');
        var $wrap = $('.x8-evs-document-types-table-wrap');
        var $toggleBtn = $('.x8-evs-toggle-document-types');
        if (!$toggleBtn.length || !$panel.length || !$wrap.length) return;
        var $btnText = $toggleBtn.find('.x8-evs-doc-toggle-btn-text');
        var $previewText = $('.x8-evs-document-types-preview-text');
        var docLabels = {};
        $wrap.find('tbody tr').each(function() {
            var $row = $(this);
            var val = $row.find('.x8-evs-doc-allow-cb').val();
            var label = $row.find('.x8-evs-doc-col-type').text().trim();
            if (val) docLabels[val] = label;
        });

        function updatePreview() {
            if (!$previewText.length) return;
            var allowed = [];
            var defaultVal = $wrap.find('.x8-evs-doc-default-radio:checked').val();
            var defaultLabel = (typeof x8_evs_ajax !== 'undefined' && x8_evs_ajax.strings && x8_evs_ajax.strings.default_label) ? x8_evs_ajax.strings.default_label : 'default';
            $wrap.find('.x8-evs-doc-allow-cb:checked').each(function() {
                var v = $(this).val();
                if (docLabels[v]) {
                    allowed.push(docLabels[v] + (v === defaultVal ? ' (' + defaultLabel + ')' : ''));
                }
            });
            $previewText.text(allowed.length ? allowed.join(', ') : '—');
        }

        $toggleBtn.on('click', function() {
            if ($panel.is(':visible')) {
                $panel.slideUp(200);
                $btnText.text('Configure Document Types');
                $toggleBtn.find('.dashicons').removeClass('dashicons-arrow-up-alt2').addClass('dashicons-admin-settings');
            } else {
                $panel.slideDown(200);
                $btnText.text('Hide Document Types');
                $toggleBtn.find('.dashicons').removeClass('dashicons-admin-settings').addClass('dashicons-arrow-up-alt2');
            }
        });

        function updateDefaultRadios() {
            $wrap.find('tbody tr').each(function() {
                var $row = $(this);
                var $allow = $row.find('.x8-evs-doc-allow-cb');
                var $default = $row.find('.x8-evs-doc-default-radio');
                if ($allow.is(':checked')) {
                    $default.prop('disabled', false);
                } else {
                    $default.prop('disabled', true);
                    if ($default.is(':checked')) {
                        var $firstAllowed = $wrap.find('.x8-evs-doc-allow-cb:checked').first().closest('tr').find('.x8-evs-doc-default-radio');
                        if ($firstAllowed.length) $firstAllowed.prop('checked', true);
                    }
                }
            });
            updatePreview();
        }

        $wrap.on('change', '.x8-evs-doc-allow-cb, .x8-evs-doc-default-radio', function() {
            updateDefaultRadios();
        });
    }

    /**
     * Initialize threshold sliders functionality
     */
    function initThresholdSliders() {
        // Handle toggle button
        $('.x8-evs-toggle-thresholds').on('click', function() {
            var $button = $(this);
            var $sliders = $('.x8-evs-threshold-sliders');
            var $preview = $('.x8-evs-current-thresholds');
            
            if ($sliders.is(':visible')) {
                $sliders.slideUp(300);
                $button.html('<span class="dashicons dashicons-admin-settings"></span>Configure Thresholds');
                $preview.show();
            } else {
                $sliders.slideDown(300);
                $button.html('<span class="dashicons dashicons-no-alt"></span>Hide Configuration');
                $preview.hide();
            }
        });

        // Handle selfie threshold toggle button
        $('.x8-evs-toggle-selfie-thresholds').on('click', function() {
            var $button = $(this);
            var $sliders = $('.x8-evs-selfie-threshold-sliders');
            var $preview = $('.x8-evs-current-selfie-thresholds');
            
            if ($sliders.is(':visible')) {
                $sliders.slideUp(300);
                $button.html('<span class="dashicons dashicons-admin-settings"></span>Configure Selfie Thresholds');
                $preview.show();
            } else {
                $sliders.slideDown(300);
                $button.html('<span class="dashicons dashicons-no-alt"></span>Hide Selfie Configuration');
                $preview.hide();
            }
        });
        
        // Handle number input updates (regular thresholds only)
        $('.x8-evs-threshold-input:not([data-threshold-type^="selfie-"])').on('input change', function() {
            var $input = $(this);
            var value = $input.val();
            
            // Enforce constraints before updating labels
            enforceThresholdConstraints();
            
            // Update label text based on threshold type
            updateSliderLabel($input, value);
            
            // Update threshold values in labels
            updateThresholdValues();
            
            // Update summary ranges
            updateThresholdSummary();
            
            // Update preview text
            updateThresholdPreview();
        });
        
        // Handle selfie checkbox toggle
        $('input[name="x8_evs_require_selfie"]').on('change', function() {
            var $checkbox = $(this);
            var $wrapper = $('#x8_evs_selfie_thresholds_wrapper');
            
            if ($checkbox.is(':checked')) {
                $wrapper.slideDown(300);
            } else {
                $wrapper.slideUp(300);
            }
        });

        // Handle selfie threshold number input updates
        $('.x8-evs-threshold-input[data-threshold-type^="selfie-"]').on('input change', function() {
            var $input = $(this);
            var value = $input.val();
            
            // Enforce constraints before updating labels
            enforceSelfieThresholdConstraints();
            
            // Update label text based on threshold type
            updateSelfieSliderLabel($input, value);
            
            // Update selfie threshold values in labels
            updateSelfieThresholdValues();
            
            // Update selfie summary ranges
            updateSelfieThresholdSummary();
            
            // Update selfie preview text
            updateSelfieThresholdPreview();
        });

        // Initialize on page load
        enforceThresholdConstraints();
        enforceSelfieThresholdConstraints();
        updateThresholdValues();
        updateThresholdSummary();
        updateThresholdPreview();
        updateSelfieThresholdValues();
        updateSelfieThresholdSummary();
        updateSelfieThresholdPreview();
    }
    
    /**
     * Update slider label text
     */
    function updateSliderLabel($slider, value) {
        var thresholdType = $slider.data('threshold-type');
        var $label = $slider.closest('.x8-evs-slider-container').find('.x8-evs-slider-label');
        
        switch(thresholdType) {
            case 'auto-block':
                $label.html('Score 0-<span class="x8-evs-threshold-value">' + value + '</span> = Automatic Block');
                break;
            case 'manual-review':
                var autoBlockValue = $('#x8_evs_auto_block_threshold').val();
                $label.html('Score <span class="x8-evs-threshold-value">' + (parseInt(autoBlockValue) + 1) + '</span>-<span class="x8-evs-threshold-value">' + value + '</span> = Manual Review');
                break;
            case 'auto-approve':
                $label.html('Score <span class="x8-evs-threshold-value">' + value + '</span>-100 = Automatic Approval');
                break;
        }
    }
    
    /**
     * Update threshold values in all labels
     */
    function updateThresholdValues() {
        var autoBlockValue = $('#x8_evs_auto_block_threshold').val();
        var manualReviewValue = $('#x8_evs_manual_review_threshold').val();
        var autoApproveValue = $('#x8_evs_auto_approve_threshold').val();
        
        // Update manual review label to show correct range
        var $manualReviewSlider = $('#x8_evs_manual_review_threshold');
        var $manualReviewLabel = $manualReviewSlider.closest('.x8-evs-slider-container').find('.x8-evs-slider-label');
        $manualReviewLabel.html('Score <span class="x8-evs-threshold-value">' + (parseInt(autoBlockValue) + 1) + '</span>-<span class="x8-evs-threshold-value">' + manualReviewValue + '</span> = Manual Review');
    }
    
    /**
     * Update threshold summary ranges
     */
    function updateThresholdSummary() {
        var autoBlockValue = $('#x8_evs_auto_block_threshold').val();
        var manualReviewValue = $('#x8_evs_manual_review_threshold').val();
        var autoApproveValue = $('#x8_evs_auto_approve_threshold').val();
        
        // Update summary ranges
        $('.x8-evs-range-block .x8-evs-range-value').text('0 - ' + autoBlockValue);
        $('.x8-evs-range-manual .x8-evs-range-value').text((parseInt(autoBlockValue) + 1) + ' - ' + manualReviewValue);
        $('.x8-evs-range-approve .x8-evs-range-value').text(autoApproveValue + ' - 100');
        
        // Validate threshold logic
        validateThresholdLogic(autoBlockValue, manualReviewValue, autoApproveValue);
    }
    
    /**
     * Update threshold preview text
     */
    function updateThresholdPreview() {
        var autoBlockValue = $('#x8_evs_auto_block_threshold').val();
        var manualReviewValue = $('#x8_evs_manual_review_threshold').val();
        var autoApproveValue = $('#x8_evs_auto_approve_threshold').val();
        
        var previewText = '<strong>Current:</strong> ' +
            'Block: 0-' + autoBlockValue + ' | ' +
            'Review: ' + (parseInt(autoBlockValue) + 1) + '-' + manualReviewValue + ' | ' +
            'Approve: ' + autoApproveValue + '-100';
        
        $('.x8-evs-threshold-preview').html(previewText);
    }
    
    /**
     * Validate threshold logic and show warnings if needed
     */
    function validateThresholdLogic(autoBlock, manualReview, autoApprove) {
        var warnings = [];
        
        // Check if auto block is higher than manual review
        if (parseInt(autoBlock) >= parseInt(manualReview)) {
            warnings.push('Auto block threshold should be lower than manual review threshold');
        }
        
        // Check if manual review is higher than auto approve
        if (parseInt(manualReview) >= parseInt(autoApprove)) {
            warnings.push('Manual review threshold should be lower than auto approve threshold');
        }
        
        // Check if auto block is higher than auto approve
        if (parseInt(autoBlock) >= parseInt(autoApprove)) {
            warnings.push('Auto block threshold should be lower than auto approve threshold');
        }
        
        // Show or hide warning
        var $warning = $('.x8-evs-threshold-warning');
        if (warnings.length > 0) {
            if ($warning.length === 0) {
                $warning = $('<div class="x8-evs-threshold-warning" style="background: #fef2f2; border: 1px solid #fecaca; border-radius: 6px; padding: 12px; margin-top: 15px; color: #991b1b; font-size: 13px;"><strong>Warning:</strong> ' + warnings.join(', ') + '</div>');
                $('.x8-evs-threshold-sliders').append($warning);
            } else {
                $warning.html('<strong>Warning:</strong> ' + warnings.join(', '));
            }
        } else {
            $warning.remove();
        }
    }

    /**
     * Enforce threshold constraints by limiting slider ranges
     */
    function enforceThresholdConstraints() {
        var autoBlockValue = parseInt($('#x8_evs_auto_block_threshold').val());
        var manualReviewValue = parseInt($('#x8_evs_manual_review_threshold').val());
        var autoApproveValue = parseInt($('#x8_evs_auto_approve_threshold').val());
        
        // Set max for auto block (must be less than manual review)
        $('#x8_evs_auto_block_threshold').attr('max', Math.min(manualReviewValue - 1, 98));
        
        // Set min for manual review (must be greater than auto block)
        $('#x8_evs_manual_review_threshold').attr('min', autoBlockValue + 1);
        // Set max for manual review (must be less than auto approve)
        $('#x8_evs_manual_review_threshold').attr('max', Math.min(autoApproveValue - 1, 99));
        
        // Set min for auto approve (must be greater than manual review)
        $('#x8_evs_auto_approve_threshold').attr('min', Math.max(manualReviewValue + 1, autoBlockValue + 2));
    }

    /**
     * Enforce selfie threshold constraints by limiting slider ranges
     */
    function enforceSelfieThresholdConstraints() {
        var autoBlockValue = parseInt($('#x8_evs_selfie_auto_block_threshold').val());
        var manualReviewValue = parseInt($('#x8_evs_selfie_manual_review_threshold').val());
        var autoApproveValue = parseInt($('#x8_evs_selfie_auto_approve_threshold').val());
        
        // Set max for auto block (must be less than manual review)
        $('#x8_evs_selfie_auto_block_threshold').attr('max', Math.min(manualReviewValue - 1, 98));
        
        // Set min for manual review (must be greater than auto block)
        $('#x8_evs_selfie_manual_review_threshold').attr('min', autoBlockValue + 1);
        // Set max for manual review (must be less than auto approve)
        $('#x8_evs_selfie_manual_review_threshold').attr('max', Math.min(autoApproveValue - 1, 99));
        
        // Set min for auto approve (must be greater than manual review)
        $('#x8_evs_selfie_auto_approve_threshold').attr('min', Math.max(manualReviewValue + 1, autoBlockValue + 2));
    }

    /**
     * Update selfie slider label text
     */
    function updateSelfieSliderLabel($slider, value) {
        var thresholdType = $slider.data('threshold-type');
        var $label = $slider.closest('.x8-evs-slider-container').find('.x8-evs-slider-label');
        
        switch(thresholdType) {
            case 'selfie-auto-block':
                $label.html('Score 0-<span class="x8-evs-threshold-value">' + value + '</span> = Automatic Block');
                break;
            case 'selfie-manual-review':
                var autoBlockValue = $('#x8_evs_selfie_auto_block_threshold').val();
                $label.html('Score <span class="x8-evs-threshold-value">' + (parseInt(autoBlockValue) + 1) + '</span>-<span class="x8-evs-threshold-value">' + value + '</span> = Manual Review');
                break;
            case 'selfie-auto-approve':
                $label.html('Score <span class="x8-evs-threshold-value">' + value + '</span>-100 = Automatic Approval');
                break;
        }
    }

    /**
     * Update selfie threshold values in all labels
     */
    function updateSelfieThresholdValues() {
        var autoBlockValue = $('#x8_evs_selfie_auto_block_threshold').val();
        var manualReviewValue = $('#x8_evs_selfie_manual_review_threshold').val();
        var autoApproveValue = $('#x8_evs_selfie_auto_approve_threshold').val();
        
        // Update manual review label to show correct range
        var $manualReviewSlider = $('#x8_evs_selfie_manual_review_threshold');
        var $manualReviewLabel = $manualReviewSlider.closest('.x8-evs-slider-container').find('.x8-evs-slider-label');
        $manualReviewLabel.html('Score <span class="x8-evs-threshold-value">' + (parseInt(autoBlockValue) + 1) + '</span>-<span class="x8-evs-threshold-value">' + manualReviewValue + '</span> = Manual Review');
    }

    /**
     * Update selfie threshold summary ranges
     */
    function updateSelfieThresholdSummary() {
        var autoBlockValue = $('#x8_evs_selfie_auto_block_threshold').val();
        var manualReviewValue = $('#x8_evs_selfie_manual_review_threshold').val();
        var autoApproveValue = $('#x8_evs_selfie_auto_approve_threshold').val();
        
        // Update summary ranges in selfie threshold section
        $('.x8-evs-selfie-threshold-sliders .x8-evs-range-block .x8-evs-range-value').text('0 - ' + autoBlockValue);
        $('.x8-evs-selfie-threshold-sliders .x8-evs-range-manual .x8-evs-range-value').text((parseInt(autoBlockValue) + 1) + ' - ' + manualReviewValue);
        $('.x8-evs-selfie-threshold-sliders .x8-evs-range-approve .x8-evs-range-value').text(autoApproveValue + ' - 100');
        
        // Validate selfie threshold logic
        validateSelfieThresholdLogic(autoBlockValue, manualReviewValue, autoApproveValue);
    }

    /**
     * Update selfie threshold preview text
     */
    function updateSelfieThresholdPreview() {
        var autoBlockValue = $('#x8_evs_selfie_auto_block_threshold').val();
        var manualReviewValue = $('#x8_evs_selfie_manual_review_threshold').val();
        var autoApproveValue = $('#x8_evs_selfie_auto_approve_threshold').val();
        
        var previewText = '<strong>Current:</strong> ' +
            'Block: 0-' + autoBlockValue + ' | ' +
            'Review: ' + (parseInt(autoBlockValue) + 1) + '-' + manualReviewValue + ' | ' +
            'Approve: ' + autoApproveValue + '-100';
        
        $('.x8-evs-selfie-threshold-preview').html(previewText);
    }

    /**
     * Validate selfie threshold logic and show warnings if needed
     */
    function validateSelfieThresholdLogic(autoBlock, manualReview, autoApprove) {
        var warnings = [];
        
        // Check if auto block is higher than manual review
        if (parseInt(autoBlock) >= parseInt(manualReview)) {
            warnings.push('Selfie auto block threshold should be lower than manual review threshold');
        }
        
        // Check if manual review is higher than auto approve
        if (parseInt(manualReview) >= parseInt(autoApprove)) {
            warnings.push('Selfie manual review threshold should be lower than auto approve threshold');
        }
        
        // Check if auto block is higher than auto approve
        if (parseInt(autoBlock) >= parseInt(autoApprove)) {
            warnings.push('Selfie auto block threshold should be lower than auto approve threshold');
        }
        
        // Show or hide warning
        var $warning = $('.x8-evs-selfie-threshold-warning');
        if (warnings.length > 0) {
            if ($warning.length === 0) {
                $warning = $('<div class="x8-evs-selfie-threshold-warning" style="background: #fef2f2; border: 1px solid #fecaca; border-radius: 6px; padding: 12px; margin-top: 15px; color: #991b1b; font-size: 13px;"><strong>Warning:</strong> ' + warnings.join(', ') + '</div>');
                $('.x8-evs-selfie-threshold-sliders').append($warning);
            } else {
                $warning.html('<strong>Warning:</strong> ' + warnings.join(', '));
            }
        } else {
            $warning.remove();
        }
    }
}); 