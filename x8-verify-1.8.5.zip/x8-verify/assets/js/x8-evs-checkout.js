jQuery(document).ready(function($) {
    'use strict';
    
    // Check if we're on checkout page and have blocked states data
    if (typeof x8_evs_checkout === 'undefined' || !x8_evs_checkout.blocked_states) {
        return;
    }
    
    var blockedStates = x8_evs_checkout.blocked_states;
    var errorMessage = x8_evs_checkout.error_message;
    
    // Initialize checkout validation
    function initCheckoutValidation() {
        // Validate state selection on change
        $(document).on('change', '#billing_state, #shipping_state', function() {
            validateStateSelection($(this));
        });
        
        // Validate on form submission with higher priority
        $(document).on('submit', 'form.checkout', function(e) {
            if (!validateAllStates()) {
                e.preventDefault();
                e.stopImmediatePropagation();
                return false;
            }
        });
        
        // Add visual indicators for blocked states
        addBlockedStateIndicators();
        
        // Show notice about blocked states
        showBlockedStatesNotice();
        
        // Validate on page load
        setTimeout(function() {
            validateAllStates();
        }, 500);
    }
    
    /**
     * Validate a single state selection
     */
    function validateStateSelection($select) {
        var selectedState = $select.val();
        var fieldName = $select.attr('id');
        var $errorContainer = $select.closest('.form-row').find('.x8-evs-state-error');
        
        // Remove existing error
        $errorContainer.remove();
        
        // Check if state is blocked
        if (selectedState && blockedStates.indexOf(selectedState.toUpperCase()) !== -1) {
            // Add error message
            var $errorDiv = $('<div class="x8-evs-state-error woocommerce-error" style="color: #dc3232; font-size: 0.875em; margin-top: 5px;">' + errorMessage + '</div>');
            $select.closest('.form-row').append($errorDiv);
            
            // Add error class to select
            $select.addClass('x8-evs-blocked-state');
            
            // Prevent form submission
            return false;
        } else {
            // Remove error class
            $select.removeClass('x8-evs-blocked-state');
        }
        
        return true;
    }
    
    /**
     * Validate all state selections
     */
    function validateAllStates() {
        var isValid = true;
        
        // Check billing state
        var $billingState = $('#billing_state');
        if ($billingState.length && $billingState.val()) {
            if (!validateStateSelection($billingState)) {
                isValid = false;
            }
        }
        
        // Check shipping state (if different from billing)
        var $shippingState = $('#shipping_state');
        if ($shippingState.length && $shippingState.val() && !$('#ship-to-different-address-checkbox').is(':checked')) {
            if (!validateStateSelection($shippingState)) {
                isValid = false;
            }
        }
        
        return isValid;
    }
    
    /**
     * Add visual indicators for blocked states in dropdown
     */
    function addBlockedStateIndicators() {
        $('#billing_state, #shipping_state').each(function() {
            var $select = $(this);
            
            $select.find('option').each(function() {
                var $option = $(this);
                var stateCode = $option.val();
                
                if (stateCode && blockedStates.indexOf(stateCode.toUpperCase()) !== -1) {
                    // Add disabled attribute and modify text
                    $option.prop('disabled', true);
                    $option.text($option.text() + ' (Not Available)');
                }
            });
        });
    }
    
    /**
     * Show notice about blocked states
     */
    function showBlockedStatesNotice() {
        // Check if notice already exists
        if ($('.x8-evs-blocked-states-notice').length) {
            return;
        }
        
        // Create notice
        var noticeHtml = '<div class="x8-evs-blocked-states-notice woocommerce-info" style="background-color: #fff3cd; border-color: #ffeaa7; color: #856404; margin-bottom: 20px;">' +
            '<p><strong>Shipping Restrictions:</strong> Some states are not available for age-restricted products. ' +
            'Please select a different state if your current selection is not available.</p>' +
            '</div>';
        
        // Insert notice before checkout form
        $('.woocommerce-checkout, form.checkout').prepend(noticeHtml);
    }
    
    /**
     * Real-time validation as user types
     */
    function initRealTimeValidation() {
        // Debounce function to prevent too many validations
        function debounce(func, wait) {
            var timeout;
            return function executedFunction() {
                var later = function() {
                    clearTimeout(timeout);
                    func();
                };
                clearTimeout(timeout);
                timeout = setTimeout(later, wait);
            };
        }
        
        // Validate on state change with debounce
        var debouncedValidation = debounce(function() {
            validateAllStates();
        }, 300);
        
        $(document).on('change', '#billing_state, #shipping_state', debouncedValidation);
    }
    
    /**
     * Add AJAX validation for better UX
     */
    function initAjaxValidation() {
        // Validate states via AJAX when user selects
        $(document).on('change', '#billing_state, #shipping_state', function() {
            var $billingState = $('#billing_state');
            var $shippingState = $('#shipping_state');
            var billingState = $billingState.val();
            var shippingState = $shippingState.val();
            
            if (!billingState && !shippingState) {
                return;
            }
            
            // Show loading indicator
            $billingState.addClass('validating');
            $shippingState.addClass('validating');
            
            // Make AJAX request to validate states
            $.ajax({
                url: x8_evs_checkout.ajax_url,
                type: 'POST',
                data: {
                    action: 'x8_evs_validate_state',
                    nonce: x8_evs_checkout.nonce,
                    billing_state: billingState,
                    shipping_state: shippingState
                },
                success: function(response) {
                    $billingState.removeClass('validating');
                    $shippingState.removeClass('validating');
                    
                    if (response.success) {
                        // States are valid
                        $billingState.removeClass('x8-evs-blocked-state');
                        $shippingState.removeClass('x8-evs-blocked-state');
                        $('.x8-evs-state-error').remove();
                    } else {
                        // States are blocked - validate individually
                        validateStateSelection($billingState);
                        validateStateSelection($shippingState);
                    }
                },
                error: function() {
                    $billingState.removeClass('validating');
                    $shippingState.removeClass('validating');
                    // Fall back to client-side validation
                    validateStateSelection($billingState);
                    validateStateSelection($shippingState);
                }
            });
        });
    }
    
    /**
     * Add CSS styles for better visual feedback
     */
    function addStyles() {
        var styles = `
            <style>
                .x8-evs-blocked-state {
                    border-color: #dc3232 !important;
                    background-color: #fff5f5 !important;
                }
                
                .x8-evs-state-error {
                    color: #dc3232;
                    font-size: 0.875em;
                    margin-top: 5px;
                    font-weight: 500;
                }
                
                .validating {
                    opacity: 0.7;
                    pointer-events: none;
                }
                
                .x8-evs-blocked-states-notice {
                    background-color: #fff3cd !important;
                    border-color: #ffeaa7 !important;
                    color: #856404 !important;
                }
                
                .x8-evs-blocked-states-notice p {
                    margin: 0;
                }
                
                /* Disable blocked state options */
                select option:disabled {
                    color: #999;
                    font-style: italic;
                }
                
                /* Prevent checkout button when blocked state is selected */
                .woocommerce-checkout .checkout-button:disabled {
                    opacity: 0.5;
                    cursor: not-allowed;
                }
            </style>
        `;
        
        $('head').append(styles);
    }
    
    /**
     * Disable checkout button if blocked state is selected
     */
    function handleCheckoutButton() {
        var $checkoutButton = $('.woocommerce-checkout .checkout-button, .woocommerce-checkout .place-order .button');
        
        function updateCheckoutButton() {
            var hasBlockedState = false;
            
            $('#billing_state, #shipping_state').each(function() {
                var $select = $(this);
                var selectedState = $select.val();
                
                if (selectedState && blockedStates.indexOf(selectedState.toUpperCase()) !== -1) {
                    hasBlockedState = true;
                    return false; // break the loop
                }
            });
            
            if (hasBlockedState) {
                $checkoutButton.prop('disabled', true).addClass('disabled');
            } else {
                $checkoutButton.prop('disabled', false).removeClass('disabled');
            }
        }
        
        // Update button state on state change
        $(document).on('change', '#billing_state, #shipping_state', updateCheckoutButton);
        
        // Initial check
        updateCheckoutButton();
    }
    
    /**
     * Initialize everything
     */
    function init() {
        addStyles();
        initCheckoutValidation();
        initRealTimeValidation();
        handleCheckoutButton();
        
        // Only enable AJAX validation if AJAX URL is available
        if (x8_evs_checkout.ajax_url) {
            initAjaxValidation();
        }
    }
    
    // Initialize when document is ready
    init();
    
    // Re-initialize on WooCommerce checkout update
    $(document.body).on('updated_checkout', function() {
        // Re-add blocked state indicators
        addBlockedStateIndicators();
        
        // Re-bind validation events
        $(document).off('change', '#billing_state, #shipping_state').on('change', '#billing_state, #shipping_state', function() {
            validateStateSelection($(this));
        });
        
        // Re-handle checkout button
        handleCheckoutButton();
        
        // Re-validate all states
        setTimeout(function() {
            validateAllStates();
        }, 100);
    });
    
    // Handle dynamic form updates
    $(document.body).on('checkout_error', function() {
        // Re-validate all states after checkout error
        setTimeout(function() {
            validateAllStates();
        }, 100);
    });
    
    // Handle form field changes
    $(document.body).on('change', 'form.checkout', function() {
        setTimeout(function() {
            validateAllStates();
        }, 100);
    });
}); 