/**
 * X8 Verify Blocks Checkout Validation
 * 
 * Handles state validation for WooCommerce Blocks checkout
 */

(function($) {
    'use strict';

    // Wait for WooCommerce Blocks to be ready
    $(document).ready(function() {
        console.log('X8 Verify: Document ready');
        
        // Check if we're on the checkout page
        if (typeof wc_checkout_params === 'undefined') {
            console.log('X8 Verify: Not on checkout page');
            return;
        }
        
        console.log('X8 Verify: On checkout page, initializing validation');
        
        // Initialize validation
        initBlocksCheckoutValidation();
    });

    /**
     * Initialize blocks checkout validation
     */
    function initBlocksCheckoutValidation() {
        console.log('X8 Verify: Initializing blocks checkout validation');
        
        // Listen for state changes
        $(document).on('change', 'select[name="billing_state"], select[name="shipping_state"]', function() {
            console.log('X8 Verify: State field changed');
            validateStates();
        });
        
        // Listen for form submission
        $(document).on('submit', 'form.woocommerce-checkout', function(e) {
            console.log('X8 Verify: Checkout form submitted');
            
            // Validate states before submission
            if (!validateStates()) {
                console.log('X8 Verify: Validation failed, preventing submission');
                e.preventDefault();
                return false;
            }
        });
        
        // Listen for blocks checkout submission
        $(document).on('click', 'button[name="woocommerce_checkout_place_order"]', function(e) {
            console.log('X8 Verify: Place order button clicked');
            
            // Validate states before submission
            if (!validateStates()) {
                console.log('X8 Verify: Validation failed, preventing order placement');
                e.preventDefault();
                return false;
            }
        });
        
        // Initial validation
        setTimeout(function() {
            console.log('X8 Verify: Running initial validation');
            validateStates();
        }, 1000);
    }

    /**
     * Validate states using REST API
     */
    function validateStates() {
        console.log('X8 Verify: Validating states');
        
        // Get state values
        var billingState = $('select[name="billing_state"]').val() || '';
        var shippingState = $('select[name="shipping_state"]').val() || '';
        
        console.log('X8 Verify: Billing state:', billingState, 'Shipping state:', shippingState);
        
        // If no states selected, skip validation
        if (!billingState && !shippingState) {
            console.log('X8 Verify: No states to validate');
            return true;
        }
        
        // Make REST API call
        $.ajax({
            url: x8_evs_blocks.rest_url,
            method: 'POST',
            data: {
                billing_state: billingState,
                shipping_state: shippingState
            },
            headers: {
                'X-WP-Nonce': x8_evs_blocks.nonce
            },
            success: function(response) {
                console.log('X8 Verify: Validation response:', response);
                
                if (response.valid) {
                    console.log('X8 Verify: States are valid');
                    clearValidationErrors();
                } else {
                    console.log('X8 Verify: States are invalid:', response.message);
                    showValidationError(response.message);
                }
            },
            error: function(xhr, status, error) {
                console.error('X8 Verify: Validation error:', error);
            }
        });
        
        return true; // Allow form submission for now
    }

    /**
     * Show validation error
     */
    function showValidationError(message) {
        // Remove existing error
        clearValidationErrors();
        
        // Create error message
        var errorHtml = '<div class="x8-evs-validation-error" style="color: #dc3232; background: #fff; border: 1px solid #dc3232; padding: 10px; margin: 10px 0; border-radius: 3px;">' + message + '</div>';
        
        // Insert error message
        $('.wp-block-woocommerce-checkout').prepend(errorHtml);
    }

    /**
     * Clear validation errors
     */
    function clearValidationErrors() {
        $('.x8-evs-validation-error').remove();
    }

    /**
     * Check if state is blocked
     */
    function isStateBlocked(stateCode) {
        if (!x8_evs_blocks.blocked_states) {
            return false;
        }
        
        return x8_evs_blocks.blocked_states.indexOf(stateCode) !== -1;
    }

})(jQuery); 