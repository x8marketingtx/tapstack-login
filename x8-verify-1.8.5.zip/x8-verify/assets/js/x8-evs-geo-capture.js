/**
 * X8 Verify Geo Information Capture
 * 
 * Handles IP address capture and geo information submission
 */

(function($) {
    'use strict';

    // Global variables
    var capturedIP = null;
    var orderID = null;

    /**
     * Get IP address using ipify.org API
     */
    function getIPAddress() {
        return new Promise((resolve, reject) => {
            $.getJSON('https://api.ipify.org?format=json', function(data) {
                console.log('X8 Verify: IP address captured:', data.ip);
                resolve(data.ip);
            }).fail(function(xhr, status, error) {
                console.error('X8 Verify: Failed to get IP address:', error);
                reject(error);
            });
        });
    }

    /**
     * Send IP address to server for geo information capture
     */
    function captureGeoInfo(ipAddress, orderId) {
        return new Promise((resolve, reject) => {
            $.ajax({
                url: x8_evs_geo.ajax_url,
                type: 'POST',
                data: {
                    action: 'x8_evs_capture_geo_info',
                    nonce: x8_evs_geo.nonce,
                    ip_address: ipAddress,
                    order_id: orderId
                },
                success: function(response) {
                    console.log('X8 Verify: Geo info capture response:', response);
                    if (response.success) {
                        resolve(response.data);
                    } else {
                        reject(response.data);
                    }
                },
                error: function(xhr, status, error) {
                    console.error('X8 Verify: Geo info capture error:', error);
                    reject(error);
                }
            });
        });
    }

    /**
     * Initialize geo capture on checkout completion
     */
    function initGeoCapture() {
        // Check if we're on the thank you page
        if (window.location.href.indexOf('order-received') !== -1) {
            console.log('X8 Verify: On thank you page, initializing geo capture');
            
            // Try multiple methods to get order ID
            orderID = getOrderId();
            
            if (!orderID) {
                console.log('X8 Verify: Could not extract order ID');
                return;
            }
            
            console.log('X8 Verify: Order ID extracted:', orderID);
            
            // Capture IP and geo info
            captureIPAndGeoInfo();
        }
    }

    /**
     * Get order ID using multiple methods
     */
    function getOrderId() {
        // Method 1: Try to get from global variable set by PHP
        if (window.x8_evs_order_id) {
            return window.x8_evs_order_id;
        }
        
        // Method 2: Try to get from URL parameters
        var urlParams = new URLSearchParams(window.location.search);
        var orderKey = urlParams.get('key');
        
        if (orderKey) {
            var extractedId = extractOrderIdFromKey(orderKey);
            if (extractedId) {
                return extractedId;
            }
        }
        
        // Method 3: Try to get from order number in page content
        var orderNumberElement = $('.woocommerce-order-number');
        if (orderNumberElement.length) {
            var orderText = orderNumberElement.text();
            var match = orderText.match(/#(\d+)/);
            if (match && match[1]) {
                return match[1];
            }
        }
        
        // Method 4: Try to get from order details data attribute
        var orderDetails = $('[data-order-id]');
        if (orderDetails.length) {
            return orderDetails.attr('data-order-id');
        }
        
        // Method 5: Try to extract from page URL patterns
        var urlMatch = window.location.href.match(/order-received\/(\d+)/);
        if (urlMatch && urlMatch[1]) {
            return urlMatch[1];
        }
        
        return null;
    }

    /**
     * Extract order ID from WooCommerce order key
     */
    function extractOrderIdFromKey(orderKey) {
        // WooCommerce order keys are typically in format: wc_order_xxxxx
        // We'll try to extract the order ID from the key
        if (orderKey && orderKey.startsWith('wc_order_')) {
            var parts = orderKey.split('_');
            if (parts.length >= 3) {
                return parts[2]; // Return the order ID part
            }
        }
        return null;
    }

    /**
     * Main function to capture IP and geo info
     */
    function captureIPAndGeoInfo() {
        console.log('X8 Verify: Starting IP and geo info capture');
        
        getIPAddress()
            .then(function(ipAddress) {
                capturedIP = ipAddress;
                console.log('X8 Verify: IP address captured:', ipAddress);
                
                // Don't show loading indicator on frontend - capture silently
                
                return captureGeoInfo(ipAddress, orderID);
            })
            .then(function(geoData) {
                console.log('X8 Verify: Geo info captured successfully:', geoData);
                // Don't show anything on frontend - just capture silently
            })
            .catch(function(error) {
                console.error('X8 Verify: Failed to capture geo info:', error);
                // Don't show error on frontend - just log it
            });
    }





    /**
     * Initialize when document is ready
     */
    $(document).ready(function() {
        console.log('X8 Verify: Geo capture script loaded');
        
        initGeoCapture();
    });

    /**
     * Expose functions globally for manual triggering
     */
    window.X8EVSGeoCapture = {
        getIPAddress: getIPAddress,
        captureGeoInfo: captureGeoInfo,
        captureIPAndGeoInfo: captureIPAndGeoInfo,
        initGeoCapture: initGeoCapture
    };

})(jQuery); 