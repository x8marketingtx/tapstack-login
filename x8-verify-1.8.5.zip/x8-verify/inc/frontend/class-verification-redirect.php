<?php
/**
 * Verification Redirect Handler
 *
 * @package X8_EVS
 * @since 1.0.0
 */

// If this file is called directly, abort.
if (!defined('WPINC')) {
    die;
}

/**
 * X8 Verify Verification Redirect Class
 * 
 * Handles redirecting users to verification page when KYC is required
 */
class X8_EVS_Verification_Redirect {

    /**
     * Initialize the redirect handler
     */
    public function __construct() {
        // Hook into WordPress actions
        add_action('wp', array($this, 'check_verification_redirect'), 10, 1);
        add_action('user_register', array($this, 'handle_after_registration'), 10, 1);
        add_action('wp_login', array($this, 'handle_after_login'), 10, 2);
    }

    /**
     * Check if user should be redirected to verification page
     */
    public function check_verification_redirect() {
        // Only check on frontend
        if (is_admin() || wp_doing_ajax() || wp_doing_cron()) {
            return;
        }

        // Check if user is logged in
        if (!is_user_logged_in()) {
            return;
        }

        $current_user = wp_get_current_user();
        
        // Skip for administrators
        if (user_can($current_user, 'manage_options')) {
            return;
        }

        if (class_exists('\\TapStack\\Verify') && method_exists('\\TapStack\\Verify', 'is_required_for_user')) {
            if (!\TapStack\Verify::is_required_for_user((int) $current_user->ID)) {
                return;
            }
        }

        // Don't redirect if already on verification page
        if ($this->is_on_verification_page()) {
            return;
        }

        // Don't redirect if on login/logout pages
        if ($this->is_on_auth_page()) {
            return;
        }

        // Don't redirect if user is on blocked page to prevent redirect loops
        if ($this->is_on_blocked_page()) {
            return;
        }


        // Check if verification trigger is set to after_registration
        if (!$this->should_force_verification()) {
            return;
        }

        // Check if user has completed KYC
        if ($this->has_completed_kyc($current_user->ID)) {
            return;
        }

        // Get verification page URL
        $verification_url = $this->get_verification_page_url();
        if (!$verification_url) {
            return;
        }

        // Perform the redirect
        $this->redirect_to_verification($verification_url);
    }

    /**
     * Handle redirect after user registration
     */
    public function handle_after_registration($user_id) {
        // Check if verification trigger is set to after_registration
        if (!$this->should_force_verification()) {
            return;
        }

        // Set a transient to trigger redirect on next page load
        set_transient('x8_evs_redirect_after_registration_' . $user_id, true, 300); // 5 minutes
    }

    /**
     * Handle redirect after user login
     */
    public function handle_after_login($user_login, $user) {
        // Check if there's a pending redirect from registration
        $redirect_transient = get_transient('x8_evs_redirect_after_registration_' . $user->ID);
        
        if ($redirect_transient) {
            // Delete the transient
            delete_transient('x8_evs_redirect_after_registration_' . $user->ID);
            
            // Check if user needs verification
            if (!$this->has_completed_kyc($user->ID) && $this->should_force_verification()) {
                $verification_url = $this->get_verification_page_url();
                if ($verification_url) {
                    // Set a transient for immediate redirect
                    set_transient('x8_evs_immediate_redirect_' . $user->ID, $verification_url, 60); // 1 minute
                }
            }
        }
    }

    /**
     * Check if verification should be forced based on settings
     */
    private function should_force_verification() {
        $trigger = get_option('x8_evs_verification_trigger', 'disabled');
        // Always redirect unverified users to verification page whenever verification is enabled (any trigger except disabled)
        return $trigger !== 'disabled';
    }

    /**
     * Check if user has completed KYC verification.
     * Grandfathers existing clients: users registered before verification_start_date
     * are not forced to verify. Everyone else (no status or not verified) must complete KYC.
     */
    private function has_completed_kyc($user_id) {
        $account_status = get_user_meta($user_id, 'account_status', true);
        
        if ($account_status === 'verified') {
            return true;
        }
        
        // No status = user not yet in verification system; only grandfather if registered before start_date
        if ($account_status === '' || $account_status === false) {
            $start_date = get_option('x8_evs_verification_start_date', '');
            if ($start_date === '' || $start_date === false) {
                return false; // No start date: require verification (force KYC for all)
            }
            $user = get_userdata($user_id);
            if (!$user || !isset($user->user_registered)) {
                return false;
            }
            return strtotime($user->user_registered) < strtotime($start_date);
        }
        
        return false;
    }

    /**
     * Get verification page URL
     */
    private function get_verification_page_url() {
        $page_id = get_option('x8_evs_verification_page', 0);
        
        if ($page_id && get_post_status($page_id) === 'publish') {
            return get_permalink($page_id);
        }
        
        return null;
    }

    /**
     * Check if user is currently on the verification page
     */
    private function is_on_verification_page() {
        global $post;
        
        $verification_page_id = get_option('x8_evs_verification_page', 0);
        
        if (!$verification_page_id) {
            return false;
        }
        
        // Check if current page is the verification page
        if (is_page($verification_page_id)) {
            return true;
        }
        
        // Also check by post ID if available
        if ($post && $post->ID == $verification_page_id) {
            return true;
        }
        
        return false;
    }

    /**
     * Check if user is on authentication-related pages
     */
    private function is_on_auth_page() {
        global $pagenow;
        
        // WordPress login/logout pages
        if (in_array($pagenow, array('wp-login.php', 'wp-register.php'))) {
            return true;
        }
        
        // Check for common login/logout URLs
        $request_uri = $_SERVER['REQUEST_URI'] ?? '';
        $auth_patterns = array(
            '/wp-login',
            '/login',
            '/logout',
            '/register',
            '/wp-admin',
            '/my-account/lost-password'
        );
        
        foreach ($auth_patterns as $pattern) {
            if (strpos($request_uri, $pattern) !== false) {
                return true;
            }
        }
        
        return false;
    }

    /**
     * Perform the redirect to verification page
     */
    private function redirect_to_verification($verification_url) {
        $current_user = wp_get_current_user();
        
        // Check for immediate redirect transient first
        $immediate_redirect = get_transient('x8_evs_immediate_redirect_' . $current_user->ID);
        if ($immediate_redirect) {
            delete_transient('x8_evs_immediate_redirect_' . $current_user->ID);
            wp_redirect($immediate_redirect);
            exit;
        }
        
        // Track redirect to prevent loops
        $this->track_redirect($current_user->ID);
        
        // Add current URL as return parameter (for after verification completion)
        $current_url = home_url($_SERVER['REQUEST_URI'] ?? '');
        $redirect_url = add_query_arg('return_to', urlencode($current_url), $verification_url);
        
        // Add a verification required notice parameter
        $redirect_url = add_query_arg('verification_required', '1', $redirect_url);
        
        // Log the redirect for debugging
        $this->log_redirect($current_user->ID, $current_url, $redirect_url);
        
        wp_redirect($redirect_url);
        exit;
    }

    /**
     * Log redirect for debugging purposes
     */
    private function log_redirect($user_id, $from_url, $to_url) {
        // Only log if WP_DEBUG is enabled
        if (defined('WP_DEBUG') && WP_DEBUG) {
            error_log(sprintf(
                'X8 Verify: Redirecting user %d from %s to %s for KYC verification',
                $user_id,
                $from_url,
                $to_url
            ));
        }
    }

    /**
     * Get redirect message for display on verification page
     */
    public static function get_redirect_message() {
        if (isset($_GET['verification_required']) && $_GET['verification_required'] === '1') {
            return __('Identity verification is required to continue. Please complete the verification process below.', 'x8-evs');
        }
        return null;
    }

    /**
     * Get return URL after verification completion
     */
    public static function get_return_url() {
        if (isset($_GET['return_to']) && !empty($_GET['return_to'])) {
            $return_url = urldecode($_GET['return_to']);
            
            // Validate that it's a local URL for security
            if (self::is_local_url($return_url)) {
                return $return_url;
            }
        }
        
        // Default return URL
        return home_url();
    }

    /**
     * Check if URL is local (security measure)
     */
    private static function is_local_url($url) {
        $parsed_url = parse_url($url);
        $site_url = parse_url(home_url());
        
        // Check if hosts match
        return isset($parsed_url['host']) && $parsed_url['host'] === $site_url['host'];
    }

    /**
     * Check if user should be allowed to access a specific page without verification
     */
    public static function is_verification_exempt_page($page_id = null) {
        if (!$page_id) {
            global $post;
            $page_id = $post ? $post->ID : 0;
        }
        
        $verification_page_id = get_option('x8_evs_verification_page', 0);
        
        // Allow access to verification page itself
        if ($page_id == $verification_page_id) {
            return true;
        }
        
        // Allow access to privacy policy, terms of service, etc.
        $exempt_pages = array(
            get_option('wp_page_for_privacy_policy'),
            // Add other page IDs that should be exempt
        );
        
        // Remove empty values
        $exempt_pages = array_filter($exempt_pages);
        
        return in_array($page_id, $exempt_pages);
    }

    /**
     * Check if user is currently on the blocked state page
     */
    private function is_on_blocked_page() {
        $request_uri = $_SERVER['REQUEST_URI'] ?? '';
        $current_url = home_url($request_uri);
        $blocked_url = home_url('/blocked-state');
        
        // Check if we're on the blocked page or if the URL contains blocked-state
        return strpos($request_uri, '/blocked-state') !== false || 
               strpos($current_url, '/blocked-state') !== false ||
               (isset($_GET['reason']) && in_array($_GET['reason'], ['geolocation_country', 'geolocation_state', 'id_address', 'vpn']));
    }

    /**
     * Get cached blocking result for user (reuse blocking handler logic)
     */
    private function get_cached_blocking_result($user_id) {
        $cache_key = 'x8_evs_blocking_result_' . $user_id;
        $cached_result = get_transient($cache_key);
        
        if ($cached_result !== false) {
            return $cached_result;
        }
        
        // If no cached result, check if blocking is enabled
        if (!class_exists('X8_EVS_Admin_Settings') || !X8_EVS_Admin_Settings::has_blocking_options_enabled()) {
            return false;
        }
        
        // Return false to indicate no blocking (let blocking handler deal with it)
        return false;
    }

    /**
     * Check if redirect loop is detected
     */
    private function is_redirect_loop_detected() {
        $current_user = wp_get_current_user();
        if (!$current_user || !$current_user->ID) {
            return false;
        }

        $redirect_count = get_transient('x8_evs_redirect_count_' . $current_user->ID);
        
        // If redirect count is 3 or more, consider it a loop
        return $redirect_count >= 3;
    }

    /**
     * Track redirect to prevent loops
     */
    private function track_redirect($user_id) {
        $redirect_count = get_transient('x8_evs_redirect_count_' . $user_id);
        $redirect_count = $redirect_count ? $redirect_count + 1 : 1;
        
        // Set transient for 5 minutes
        set_transient('x8_evs_redirect_count_' . $user_id, $redirect_count, 300);
        
        if (defined('WP_DEBUG') && WP_DEBUG) {
            error_log("X8 Verify: Redirect count for user {$user_id}: {$redirect_count}");
        }
    }

    /**
     * Clear redirect tracking for user
     */
    public static function clear_redirect_tracking($user_id) {
        delete_transient('x8_evs_redirect_count_' . $user_id);
        
        if (defined('WP_DEBUG') && WP_DEBUG) {
            error_log("X8 Verify: Cleared redirect tracking for user {$user_id}");
        }
    }
}

// Initialize the verification redirect handler
new X8_EVS_Verification_Redirect(); 