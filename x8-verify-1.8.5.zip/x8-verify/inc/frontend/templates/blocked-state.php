<?php
/**
 * Blocked State Template
 *
 * @package X8_EVS
 * @since 1.0.0
 */

// If this file is called directly, abort.
if (!defined('WPINC')) {
    die;
}

// Get block reason from URL parameters
$block_reason = X8_EVS_Blocking_Handler::get_block_reason();

if (!$block_reason) {
    // If no block reason, redirect to home
    wp_redirect(home_url());
    exit;
}

// Get the current user
$current_user = wp_get_current_user();

$blocked_page_debug_payload = class_exists('X8_EVS_Blocking_Handler')
    ? X8_EVS_Blocking_Handler::get_blocked_page_debug_payload()
    : array();
$blocked_page_debug_text = !empty($blocked_page_debug_payload)
    ? wp_json_encode($blocked_page_debug_payload, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES)
    : '{}';

// Set page title
$page_title = __('Access Restricted', 'x8-evs');
?>
<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo('charset'); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?php echo esc_html($page_title); ?> - <?php bloginfo('name'); ?></title>
    <?php wp_head(); ?>
    <style>
        .x8-evs-blocked-page {
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
        }
        
        .x8-evs-blocked-container {
            background: white;
            border-radius: 12px;
            box-shadow: 0 20px 40px rgba(0, 0, 0, 0.1);
            padding: 40px;
            max-width: 500px;
            width: 90%;
            text-align: center;
        }
        
        .x8-evs-blocked-icon {
            width: 80px;
            height: 80px;
            background: #ef4444;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto 20px;
        }
        
        .x8-evs-blocked-icon svg {
            width: 40px;
            height: 40px;
            fill: white;
        }
        
        .x8-evs-blocked-title {
            font-size: 24px;
            font-weight: 700;
            color: #1f2937;
            margin-bottom: 10px;
        }
        
        .x8-evs-blocked-subtitle {
            font-size: 16px;
            color: #6b7280;
            margin-bottom: 30px;
        }
        
        .x8-evs-blocked-message {
            background: #fef2f2;
            border: 1px solid #fecaca;
            border-radius: 8px;
            padding: 20px;
            margin-bottom: 30px;
        }
        
        .x8-evs-blocked-message h3 {
            color: #dc2626;
            font-size: 18px;
            font-weight: 600;
            margin-bottom: 10px;
        }
        
        .x8-evs-blocked-message p {
            color: #7f1d1d;
            margin: 0;
            line-height: 1.6;
        }
        
        .x8-evs-blocked-details {
            background: #f8fafc;
            border: 1px solid #e2e8f0;
            border-radius: 8px;
            padding: 20px;
            margin-bottom: 30px;
            text-align: left;
        }
        
        .x8-evs-blocked-details h4 {
            color: #374151;
            font-size: 16px;
            font-weight: 600;
            margin-bottom: 15px;
        }
        
        .x8-evs-detail-row {
            display: flex;
            justify-content: space-between;
            margin-bottom: 10px;
            padding-bottom: 10px;
            border-bottom: 1px solid #e5e7eb;
        }
        
        .x8-evs-detail-row:last-child {
            border-bottom: none;
            margin-bottom: 0;
            padding-bottom: 0;
        }
        
        .x8-evs-detail-label {
            font-weight: 500;
            color: #6b7280;
        }
        
        .x8-evs-detail-value {
            font-weight: 600;
            color: #1f2937;
        }
        
        .x8-evs-blocked-actions {
            display: flex;
            gap: 15px;
            justify-content: center;
            flex-wrap: wrap;
        }
        
        .x8-evs-btn {
            padding: 12px 24px;
            border-radius: 8px;
            font-weight: 600;
            text-decoration: none;
            display: inline-block;
            transition: all 0.2s ease;
            border: none;
            cursor: pointer;
            font-size: 14px;
        }
        
        .x8-evs-btn-primary {
            background: #3b82f6;
            color: white;
        }
        
        .x8-evs-btn-primary:hover {
            background: #2563eb;
            transform: translateY(-1px);
        }
        
        .x8-evs-btn-secondary {
            background: #f3f4f6;
            color: #374151;
            border: 1px solid #d1d5db;
        }
        
        .x8-evs-btn-secondary:hover {
            background: #e5e7eb;
        }
        
        .x8-evs-contact-info {
            margin-top: 30px;
            padding-top: 20px;
            border-top: 1px solid #e5e7eb;
            color: #6b7280;
            font-size: 14px;
        }
        
        .x8-evs-debug-details {
            margin-top: 24px;
            margin-bottom: 8px;
            text-align: left;
        }

        .x8-evs-debug-details summary {
            cursor: pointer;
            font-size: 14px;
            color: #4b5563;
            font-weight: 600;
            list-style-position: outside;
            padding: 8px 0;
            user-select: none;
        }

        .x8-evs-debug-details summary:hover {
            color: #1f2937;
        }

        .x8-evs-debug-details[open] summary {
            margin-bottom: 10px;
        }

        .x8-evs-debug-pre {
            margin: 0;
            padding: 14px 16px;
            background: #0f172a;
            color: #e2e8f0;
            border-radius: 8px;
            font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, 'Liberation Mono', 'Courier New', monospace;
            font-size: 11px;
            line-height: 1.5;
            overflow-x: auto;
            white-space: pre-wrap;
            word-break: break-word;
            max-height: 320px;
            overflow-y: auto;
            border: 1px solid #1e293b;
            text-align: left;
        }

        .x8-evs-debug-hint {
            font-size: 12px;
            color: #9ca3af;
            margin-top: 6px;
            text-align: left;
        }

        @media (max-width: 600px) {
            .x8-evs-blocked-container {
                padding: 30px 20px;
                margin: 20px;
            }
            
            .x8-evs-blocked-actions {
                flex-direction: column;
            }
            
            .x8-evs-btn {
                width: 100%;
                text-align: center;
            }
        }
    </style>
</head>
<body <?php body_class(); ?>>
    <div class="x8-evs-blocked-page">
        <div class="x8-evs-blocked-container">
            <div class="x8-evs-blocked-icon">
                <svg viewBox="0 0 24 24">
                    <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-2 15l-5-5 1.41-1.41L10 14.17l7.59-7.59L19 8l-9 9z"/>
                </svg>
            </div>
            
            <h1 class="x8-evs-blocked-title"><?php echo esc_html($page_title); ?></h1>
            <p class="x8-evs-blocked-subtitle"><?php _e('We\'re sorry, but access is not available in your area.', 'x8-evs'); ?></p>
            
            <div class="x8-evs-blocked-message">
                <h3><?php _e('Access Restricted', 'x8-evs'); ?></h3>
                <p><?php echo esc_html($block_reason['message']); ?></p>
            </div>
            
            <div class="x8-evs-blocked-details">
                <h4><?php _e('Block Details', 'x8-evs'); ?></h4>
                
                <div class="x8-evs-detail-row">
                    <span class="x8-evs-detail-label"><?php _e('Block Type:', 'x8-evs'); ?></span>
                    <span class="x8-evs-detail-value">
                        <?php 
                        if ($block_reason['type'] === 'id_address') {
                            _e('ID Document Address', 'x8-evs');
                        } elseif ($block_reason['type'] === 'geolocation_state') {
                            _e('IP Geolocation (State)', 'x8-evs');
                        } elseif ($block_reason['type'] === 'geolocation_country') {
                            _e('IP Geolocation (Country)', 'x8-evs');
                        } elseif ($block_reason['type'] === 'geolocation') {
                            _e('IP Geolocation', 'x8-evs');
                        } elseif ($block_reason['type'] === 'vpn') {
                            _e('VPN/Proxy Detection', 'x8-evs');
                        } else {
                            echo esc_html(ucfirst($block_reason['type']));
                        }
                        ?>
                    </span>
                </div>
                
                <?php if (isset($block_reason['state']) && isset($block_reason['state_name'])): ?>
                <div class="x8-evs-detail-row">
                    <span class="x8-evs-detail-label"><?php _e('State:', 'x8-evs'); ?></span>
                    <span class="x8-evs-detail-value"><?php echo esc_html($block_reason['state_name']); ?> (<?php echo esc_html($block_reason['state']); ?>)</span>
                </div>
                <?php endif; ?>
                
                <?php if (isset($block_reason['country']) && isset($block_reason['country_name'])): ?>
                <div class="x8-evs-detail-row">
                    <span class="x8-evs-detail-label"><?php _e('Country:', 'x8-evs'); ?></span>
                    <span class="x8-evs-detail-value"><?php echo esc_html($block_reason['country_name']); ?> (<?php echo esc_html($block_reason['country']); ?>)</span>
                </div>
                <?php endif; ?>
                
                <div class="x8-evs-detail-row">
                    <span class="x8-evs-detail-label"><?php _e('User:', 'x8-evs'); ?></span>
                    <span class="x8-evs-detail-value"><?php echo esc_html($current_user->user_email); ?></span>
                </div>
                
                <div class="x8-evs-detail-row">
                    <span class="x8-evs-detail-label"><?php _e('Date:', 'x8-evs'); ?></span>
                    <span class="x8-evs-detail-value"><?php echo esc_html(current_time('F j, Y g:i A')); ?></span>
                </div>
            </div>

            <details class="x8-evs-debug-details">
                <summary><?php esc_html_e('Debugging info (for support)', 'x8-evs'); ?></summary>
                <p class="x8-evs-debug-hint"><?php esc_html_e('Open this section and copy the text below if you need to report an incorrect block.', 'x8-evs'); ?></p>
                <pre class="x8-evs-debug-pre" id="x8-evs-blocked-debug-log" aria-label="<?php esc_attr_e('Technical debugging information', 'x8-evs'); ?>"><?php echo esc_html($blocked_page_debug_text); ?></pre>
            </details>
            
            <div class="x8-evs-blocked-actions">
                <a href="<?php echo esc_url(home_url()); ?>" class="x8-evs-btn x8-evs-btn-secondary">
                    <?php _e('Go to Homepage', 'x8-evs'); ?>
                </a>
                
                <?php if (is_user_logged_in()): ?>
                    <a href="<?php echo esc_url(wp_logout_url(home_url())); ?>" class="x8-evs-btn x8-evs-btn-primary">
                        <?php _e('Logout', 'x8-evs'); ?>
                    </a>
                <?php endif; ?>
            </div>
            
            <div class="x8-evs-contact-info">
                <p><?php _e('If you believe this is an error, please contact support.', 'x8-evs'); ?></p>
                <?php 
                $contact_email = class_exists('X8_EVS_Admin_Settings') ? X8_EVS_Admin_Settings::get_contact_email() : get_option('admin_email');
                if ($contact_email): ?>
                    <p><?php printf(__('Email: %s', 'x8-evs'), esc_html($contact_email)); ?></p>
                <?php endif; ?>
            </div>
        </div>
    </div>
    
    <?php wp_footer(); ?>
</body>
</html> 