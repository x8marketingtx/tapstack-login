jQuery(document).ready(function($) {
    'use strict';
    
    // Initialize verification frontend functionality
    initVerificationFrontend();
    
    function initVerificationFrontend() {
        // Start verification button
        $(document).on('click', '#x8-evs-start-verification', function(e) {
            e.preventDefault();
            generateVerificationLink('generate');
        });
        

        
        // Retry verification button (for blocked users)
        $(document).on('click', '#x8-evs-retry-btn', function(e) {
            e.preventDefault();
            generateVerificationLink('regenerate');
        });
        
        // Continue verification link tracking
        $(document).on('click', 'a[href*="blueassure.evssolutions.com"]', function(e) {
            // Track when user clicks on verification link
            var $this = $(this);
            
            // Add visual feedback
            $this.addClass('clicked');
            
            // Optional: Add analytics or tracking here
            console.log('Verification link clicked');
        });
    }
    
    // Generate verification link via AJAX
    function generateVerificationLink(actionType) {
        var $loadingDiv = $('#x8-evs-loading');
        var $resultDiv = $('#x8-evs-result');
        var $button = getActionButton(actionType);
        
        if (!$button || $button.length === 0) {
            console.error('Button not found for action type:', actionType);
            return;
        }
        
        // Prevent multiple clicks
        if ($button.data('processing')) {
            console.log('Verification already in progress...');
            return;
        }
        
        // Mark button as processing
        $button.data('processing', true);
        
        // Show loading state
        setLoadingState($button, $loadingDiv, $resultDiv, actionType, true);
        
        // Customer document type choice (when multiple types allowed)
        var documentType = null;
        var $docSelect = $('#x8-evs-document-type-select');
        if ($docSelect.length && $docSelect.val()) {
            documentType = $docSelect.val();
        } else if (x8_evs_ajax.allowed_document_types && x8_evs_ajax.allowed_document_types.length > 0) {
            documentType = x8_evs_ajax.allowed_document_types[0];
        }
        var ajaxData = {
            action: 'x8_evs_verify',
            action_type: actionType,
            nonce: x8_evs_ajax.nonce
        };
        if (documentType) {
            ajaxData.document_type = documentType;
        }
        // Make AJAX request
        $.ajax({
            url: x8_evs_ajax.ajax_url,
            type: 'POST',
            data: ajaxData,
            dataType: 'json',
            timeout: 30000, // 30 seconds timeout
            success: function(response) {
                handleSuccess(response, $resultDiv, $loadingDiv);
            },
            error: function(xhr, status, error) {
                handleError(xhr, status, error, $resultDiv, $loadingDiv);
            },
            complete: function() {
                setLoadingState($button, $loadingDiv, $resultDiv, actionType, false);
                // Reset processing flag
                $button.data('processing', false);
            }
        });
    }
    
    // Get the appropriate button based on action type
    function getActionButton(actionType) {
        switch(actionType) {
            case 'generate':
                return $('#x8-evs-start-verification');
            default:
                return $('#x8-evs-retry-btn');
        }
    }
    
    // Set loading state for UI elements
    function setButtonText($button, text) {
        var $span = $button.find('.x8-evs-btn-text');
        if ($span.length) {
            $span.text(text);
        } else {
            $button.text(text);
        }
    }
    function setLoadingState($button, $loadingDiv, $resultDiv, actionType, isLoading) {
        if (isLoading) {
            var originalText = $button.text().trim();
            $button.data('original-text', originalText);
            var loadingText = getLoadingText(actionType);
            $button.prop('disabled', true);
            setButtonText($button, loadingText);
            $loadingDiv.show();
            $resultDiv.hide();
        } else {
            var originalText = $button.data('original-text') || getDefaultButtonText(actionType);
            $button.prop('disabled', false);
            setButtonText($button, originalText);
            $loadingDiv.hide();
        }
    }
    
    // Get loading text based on action type
    function getLoadingText(actionType) {
        switch(actionType) {
            case 'generate':
                return 'Generating...';
            default:
                return 'Retrying...';
        }
    }
    
    // Get default button text based on action type
    function getDefaultButtonText(actionType) {
        switch(actionType) {
            case 'generate':
                return 'Begin Verification';
            default:
                return 'Retry Verification';
        }
    }
    
    // Handle successful response
    function handleSuccess(response, $resultDiv, $loadingDiv) {
        $loadingDiv.hide();
        
        if (response.success) {
            var data = response.data;
            
            // Show success message
            var successHtml = buildSuccessMessage(data);
            $resultDiv.html(successHtml).removeClass('error').addClass('success').show();
            
            // Open verification link in new tab
            if (data.verification_link) {
                //openVerificationLink(data.verification_link);
                // Reload page immediately to show updated status (pending verification screen)
                setTimeout(function() {
                    location.reload();
                }, 100); // 1.5 seconds delay to show success message
            }
            
        } else {
            // Show error message from server
            var errorHtml = buildErrorMessage(response.data || 'Failed to generate verification link');
            $resultDiv.html(errorHtml).removeClass('success').addClass('error').show();
        }
    }
    
    // Handle error response
    function handleError(xhr, status, error, $resultDiv, $loadingDiv) {
        $loadingDiv.hide();
        
        var errorMessage = 'Network error. Please check your connection and try again.';
        
        // Try to get more specific error information
        if (xhr.responseJSON && xhr.responseJSON.data) {
            errorMessage = xhr.responseJSON.data;
        } else if (status === 'timeout') {
            errorMessage = 'Request timed out. Please try again.';
        } else if (status === 'abort') {
            errorMessage = 'Request was cancelled. Please try again.';
        }
        
        var errorHtml = buildErrorMessage(errorMessage);
        $resultDiv.html(errorHtml).removeClass('success').addClass('error').show();
        
        // Log error for debugging
        console.error('X8 Verify Error:', {
            status: status,
            error: error,
            xhr: xhr
        });
    }
    
    // Build success message HTML
    function buildSuccessMessage(data) {
        return '<div class="x8-evs-notice x8-evs-notice-success">' +
            '<p><strong>✓ ' + escapeHtml(data.message) + '</strong></p>' +
            '<p>You will be redirected to the verification page in a new tab/window.</p>' +
            '<p><small>Transaction ID: ' + escapeHtml(data.transaction_id || 'N/A') + '</small></p>' +
            '</div>';
    }
    
    // Build error message HTML
    function buildErrorMessage(message) {
        return '<div class="x8-evs-notice x8-evs-notice-error">' +
            '<p><strong>Error:</strong> ' + escapeHtml(message) + '</p>' +
            '<p><small>If this problem persists, please contact support.</small></p>' +
            '</div>';
    }
    
    // Open verification link in new tab
    function openVerificationLink(verificationLink) {
        // Small delay to show the success message
        setTimeout(function() {
            var newWindow = window.open(verificationLink, '_blank', 'noopener,noreferrer');
            
            // Check if popup was blocked
            if (!newWindow || newWindow.closed || typeof newWindow.closed === 'undefined') {
                // Popup blocked, show manual link
                showManualLink(verificationLink);
            } else {
                // Focus the new window
                newWindow.focus();
            }
        }, 1000);
    }
    
    // Show manual verification link if popup was blocked
    function showManualLink(verificationLink) {
        var manualLinkHtml = '<div class="x8-evs-notice x8-evs-notice-info" style="margin-top: 10px;">' +
            '<p><strong>Popup blocked?</strong> Click the link below to complete verification:</p>' +
            '<p><a href="' + escapeHtml(verificationLink) + '" target="_blank" rel="noopener noreferrer" class="button button-primary">' +
            'Open Verification Page <span class="dashicons dashicons-external" style="margin-left: 5px;"></span></a></p>' +
            '</div>';
        
        $('#x8-evs-result').append(manualLinkHtml);
    }
    

    
    // Utility function to escape HTML
    function escapeHtml(text) {
        if (typeof text !== 'string') {
            return text;
        }
        
        var map = {
            '&': '&amp;',
            '<': '&lt;',
            '>': '&gt;',
            '"': '&quot;',
            "'": '&#039;'
        };
        
        return text.replace(/[&<>"']/g, function(m) { return map[m]; });
    }
    
    // Initialize verification status checking
    function initStatusChecking() {
        // Check if we're on a verification page and should poll for status updates
        var $container = $('#x8-evs-form-container');
        if ($container.length && $container.find('.x8-evs-notice-info').length) {
            // User has pending verification, could implement polling here if needed
            console.log('Verification status: Pending');
        }
    }
    
    // Initialize status checking
    initStatusChecking();
    
    // Add visual feedback for external links
    $(document).on('mouseenter', 'a[target="_blank"]', function() {
        $(this).css('opacity', '0.8');
    }).on('mouseleave', 'a[target="_blank"]', function() {
        $(this).css('opacity', '1');
    });
    
    // Handle window focus to potentially refresh status
    var windowFocused = true;
    $(window).on('focus', function() {
        if (!windowFocused) {
            windowFocused = true;
            // Optional: Check if verification was completed in another tab
            // This could trigger a status refresh
        }
    }).on('blur', function() {
        windowFocused = false;
    });
}); 