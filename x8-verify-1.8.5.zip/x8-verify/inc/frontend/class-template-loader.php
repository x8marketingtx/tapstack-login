<?php
/**
 * Template Loader
 *
 * @package X8_EVS
 * @since 1.0.0
 */

// If this file is called directly, abort.
if (!defined('WPINC')) {
    die;
}

/**
 * X8 Verify Template Loader Class
 * 
 * Handles loading custom templates for the plugin
 */
class X8_EVS_Template_Loader {

    /**
     * Initialize the template loader
     */
    public function __construct() {
        add_action('template_redirect', array($this, 'load_custom_templates'));
        add_filter('template_include', array($this, 'template_include'), 99);
    }

    /**
     * Load custom templates based on URL
     */
    public function load_custom_templates() {
        $request_uri = $_SERVER['REQUEST_URI'] ?? '';
        
        // Check for blocked state page
        if (strpos($request_uri, '/blocked-state') !== false) {
            $this->load_blocked_state_template();
        }
    }

    /**
     * Template include filter to handle custom templates
     */
    public function template_include($template) {
        $request_uri = $_SERVER['REQUEST_URI'] ?? '';
        
        // Check for blocked state page
        if (strpos($request_uri, '/blocked-state') !== false) {
            $blocked_template = plugin_dir_path(dirname(__FILE__)) . 'frontend/templates/blocked-state.php';
            if (file_exists($blocked_template)) {
                return $blocked_template;
            }
        }
        
        return $template;
    }

    /**
* Load the blocked state template
     */
    private function load_blocked_state_template() {
        // Debug logging
        if (defined('WP_DEBUG') && WP_DEBUG) {
            error_log("X8 Verify: Template loader - load_blocked_state_template called");
        }

        // Check if blocking handler class exists
        if (!class_exists('X8_EVS_Blocking_Handler')) {
            if (defined('WP_DEBUG') && WP_DEBUG) {
                error_log("X8 Verify: Template loader - Blocking handler class not found, redirecting to home");
            }
            wp_redirect(home_url());
            exit;
        }

        // Get block reason
        $block_reason = X8_EVS_Blocking_Handler::get_block_reason();
        
        if (!$block_reason) {
            if (defined('WP_DEBUG') && WP_DEBUG) {
                error_log("X8 Verify: Template loader - No block reason found, redirecting to home");
            }
            wp_redirect(home_url());
            exit;
        }

        if (defined('WP_DEBUG') && WP_DEBUG) {
            error_log("X8 Verify: Template loader - Block reason found: " . print_r($block_reason, true));
        }

        // Load the template
        $template_path = plugin_dir_path(dirname(__FILE__)) . 'frontend/templates/blocked-state.php';
        
        if (file_exists($template_path)) {
            if (defined('WP_DEBUG') && WP_DEBUG) {
                error_log("X8 Verify: Template loader - Loading blocked state template from: " . $template_path);
            }
            include $template_path;
            exit;
        } else {
            if (defined('WP_DEBUG') && WP_DEBUG) {
                error_log("X8 Verify: Template loader - Template file not found: " . $template_path);
            }
            // Fallback to home if template doesn't exist
            wp_redirect(home_url());
            exit;
        }
    }

    /**
     * Add rewrite rules for custom pages
     */
    public function add_rewrite_rules() {
        add_rewrite_rule(
            '^blocked-state/?$',
            'index.php?x8_evs_page=blocked-state',
            'top'
        );
    }

    /**
     * Add query vars for custom pages
     */
    public function add_query_vars($vars) {
        $vars[] = 'x8_evs_page';
        return $vars;
    }

    /**
     * Handle custom page requests
     */
    public function handle_custom_pages($wp_query) {
        if (!is_admin() && $wp_query->is_main_query()) {
            $x8_page = $wp_query->get('x8_evs_page');
            
            if ($x8_page === 'blocked-state') {
                $this->load_blocked_state_template();
            }
        }
    }
}

// Initialize the template loader
new X8_EVS_Template_Loader(); 