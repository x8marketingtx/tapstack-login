<?php
/**
 * Verification Form Handler
 *
 * @package X8_EVS
 * @since 1.0.0
 */

// If this file is called directly, abort.
if (!defined('WPINC')) {
    die;
}

/**
 * X8 Verify Verification Form Class
 * 
 * Handles the verification form display and API interactions
 */
class X8_EVS_Verification_Form {

    /**
     * Initialize the verification form handler
     */
    public function __construct() {
        // Add shortcodes
        add_shortcode('x8_evs_form', array($this, 'render_verification_form'));
        add_shortcode('x8_verify', array($this, 'render_verification_form'));
        
        // Enqueue scripts and styles
        add_action('wp_enqueue_scripts', array($this, 'enqueue_scripts'));
        
        // AJAX handlers
        add_action('wp_ajax_x8_evs_verify', array($this, 'handle_verification'));
    }
    
    /**
     * Render verification form shortcode
     */
    public function render_verification_form($atts) {
        $atts = shortcode_atts(array(
            'title' => __('Identity Verification', 'x8-evs'),
            'button_text' => __('Begin Verification', 'x8-evs')
        ), $atts);
        
        // Check if user is logged in
        if (!is_user_logged_in()) {
            // Add debugging information
            if (defined('WP_DEBUG') && WP_DEBUG) {
                error_log('X8 Verify: User not logged in on verification form');
            }
            
            return $this->render_status_page('login_required', array(
                'title' => __('Login Required', 'x8-evs'),
                'message' => __('You must be logged in to complete identity verification.', 'x8-evs'),
                'action_text' => __('Login', 'x8-evs'),
                'action_url' => '/my-account'
            ));
        }
        
        // Add debugging information for logged-in users
        if (defined('WP_DEBUG') && WP_DEBUG) {
            $current_user = wp_get_current_user();
            error_log('X8 Verify: User logged in on verification form - User ID: ' . $current_user->ID . ', User Login: ' . $current_user->user_login);
        }
        
        $user_id = get_current_user_id();
        
        // Check if user is being redirected from a blocked state
        $is_redirected_from_blocked = isset($_GET['return_to']) && strpos($_GET['return_to'], 'blocked-state') !== false;
        
        // If user is redirected from blocked state, show a special message
        if ($is_redirected_from_blocked) {
            return $this->render_status_page('blocked_redirect', array(
                'title' => __('Verification Required', 'x8-evs'),
                'message' => __('Your account requires identity verification to continue. Please complete the verification process below.', 'x8-evs'),
                'icon' => 'shield-exclamation',
                'color' => 'warning',
                'show_verification_form' => true
            ));
        }
        
        $verification_status = $this->get_user_verification_status($user_id);
        
        // Handle different statuses with consistent styling
        switch ($verification_status['status']) {
            case 'verified':
                return $this->render_status_page('verified', array(
                    'title' => __('Identity Verified', 'x8-evs'),
                    'message' => __('Your identity has been successfully verified.', 'x8-evs'),
                    'icon' => 'check-circle',
                    'color' => 'success',
                    'action_text' => __('Continue', 'x8-evs'),
                    'action_url' => $this->get_return_url()
                ));
                
            case 'block':
                $block_reason = get_user_meta($user_id, '_verification_block_reason', true);
                $is_duplicate_license = ($block_reason === 'duplicate_license');
                if ($is_duplicate_license) {
                    return $this->render_status_page('blocked', array(
                        'title' => __('Account already exists', 'x8-evs'),
                        'message' => __("You cannot create a new account using the same identity document (license/card). An account already exists with this person's information.", 'x8-evs'),
                        'details' => __('Please sign in to your existing account. If you believe this is a mistake, contact support.', 'x8-evs'),
                        'icon' => 'x-circle',
                        'color' => 'error',
                        'show_contact_info' => true,
                        'show_logout' => true,
                        'contact_message' => __('Contact support if you believe this is a mistake.', 'x8-evs'),
                    ));
                }
                return $this->render_status_page('blocked', array(
                    'title' => __('Account Blocked', 'x8-evs'),
                    'message' => __('Your account has been blocked due to failed identity verification. Please contact support for assistance.', 'x8-evs'),
                    'icon' => 'x-circle',
                    'color' => 'error',
                    'show_contact_info' => true,
                    'show_logout' => true
                ));
                
            case 'manual_review':
                return $this->render_status_page('manual_review', array(
                    'title' => __('Under Review', 'x8-evs'),
                    'message' => __('Your verification is currently under manual review. This process typically takes 24-48 hours.', 'x8-evs'),
                    'icon' => 'clock',
                    'color' => 'warning',
                    'details' => __('You will receive an email notification once the review is complete.', 'x8-evs')
                ));
                
            case 'error':
                // Check rate limiting for users with error status
                $rate_limit_data = array();
                if (class_exists('X8_EVS_Admin_Settings')) {
                    $rate_limit_check = X8_EVS_Admin_Settings::can_generate_verification_link($user_id);
                    $rate_limit_data = $rate_limit_check;
                }
                
                if (!empty($rate_limit_data) && !$rate_limit_data['can_generate']) {
                    // User has reached rate limit
                    return $this->render_status_page('error_rate_limited', array(
                        'title' => __('Verification Failed', 'x8-evs'),
                        'message' => __('Your identity verification was unsuccessful.', 'x8-evs'),
                        'icon' => 'x-circle',
                        'color' => 'error',
                        'details' => $rate_limit_data['reason'],
                        'show_contact_info' => true,
                        'show_logout' => true
                    ));
                } else {
                    // User can still retry
                    $retry_message = __('Your identity verification was unsuccessful. You can retry the verification process.', 'x8-evs');
                    if (!empty($rate_limit_data) && $rate_limit_data['attempts_left'] > 0) {
                        $retry_message .= ' ' . sprintf(_n('You have %d attempt remaining.', 'You have %d attempts remaining.', $rate_limit_data['attempts_left'], 'x8-evs'), $rate_limit_data['attempts_left']);
                    }
                    
                    return $this->render_status_page('error_retry', array(
                        'title' => __('Verification Failed', 'x8-evs'),
                        'message' => $retry_message,
                        'icon' => 'x-circle',
                        'color' => 'error',
                        'action_text' => __('Retry Verification', 'x8-evs'),
                        'action_type' => 'button',
                        'action_id' => 'x8-evs-retry-btn',
                        'show_contact_info' => true
                    ));
                }
                
            case 'pending':
            default:
                if ($verification_status['has_active_link']) {
                    return $this->render_pending_verification_screen($verification_status);
                } else {
                    return $this->render_verification_form_content($atts);
                }
        }
    }
    

    /**
     * Render a status page with consistent styling
     */
    private function render_status_page($status_type, $data) {
        $icon_map = array(
            'check-circle' => '<path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-2 15l-5-5 1.41-1.41L10 14.17l7.59-7.59L19 8l-9 9z"/>',
            'x-circle' => '<path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm5 11.59L15.59 17 12 13.41 8.41 17 7 15.59 10.59 12 7 8.41 8.41 7 12 10.59 15.59 7 17 8.41 13.41 12 17 15.59z"/>',
            'clock' => '<path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-2 15l-5-5 1.41-1.41L10 14.17l7.59-7.59L19 8l-9 9z"/>',
            'play-circle' => '<path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-2 14.5v-9l6 4.5-6 4.5z"/>',
            'alert-circle' => '<path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm1 15h-2v-2h2v2zm0-4h-2V7h2v6z"/>',
            'shield-exclamation' => '<path d="M12 1L3 5v6c0 5.55 3.84 10.74 9 12 5.16-1.26 9-6.45 9-12V5l-9-4zM12 11.99h.01M12 7v4l3 3-1.42 1.42L12 12.41l-1.59 1.59L9 14l3-3V7z"/>'
        );
        
        $color_map = array(
            'success' => '#10b981',
            'error' => '#ef4444',
            'warning' => '#f59e0b',
            'info' => '#3b82f6'
        );
        
        $icon = $data['icon'] ?? 'alert-circle';
        $color = $color_map[$data['color'] ?? 'info'] ?? '#3b82f6';
        
        ob_start();
        ?>
        <div class="x8-evs-status-page">
            <div class="x8-evs-status-container">
                <div class="x8-evs-status-icon" style="background: <?php echo esc_attr($color); ?>;">
                    <svg viewBox="0 0 24 24">
                        <?php echo $icon_map[$icon]; ?>
                    </svg>
                </div>
                
                <h1 class="x8-evs-status-title"><?php echo esc_html($data['title']); ?></h1>
                <p class="x8-evs-status-message"><?php echo esc_html($data['message']); ?></p>
                
                <?php if (!empty($data['details'])): ?>
                    <div class="x8-evs-status-details">
                        <p><?php echo esc_html($data['details']); ?></p>
                    </div>
                <?php endif; ?>
                
                <?php if (!empty($data['action_text'])): ?>
                    <div class="x8-evs-status-actions">
                        <?php if (isset($data['action_type']) && $data['action_type'] === 'button'): ?>
                            <button type="button" id="<?php echo esc_attr($data['action_id']); ?>" class="x8-evs-btn x8-evs-btn-primary">
                                <?php echo esc_html($data['action_text']); ?>
                            </button>
                        <?php else: ?>
                            <a href="<?php echo esc_url($data['action_url']); ?>" 
                               class="x8-evs-btn x8-evs-btn-primary"
                               <?php echo isset($data['external']) && $data['external'] ? 'target="_blank"' : ''; ?>>
                                <?php echo esc_html($data['action_text']); ?>
                                <?php if (isset($data['external']) && $data['external']): ?>
                                    <span class="dashicons dashicons-external" style="margin-left: 5px;"></span>
                                <?php endif; ?>
                            </a>
                        <?php endif; ?>
                    </div>
                <?php endif; ?>
                
                <?php if (isset($data['show_logout']) && $data['show_logout']): ?>
                    <div class="x8-evs-status-actions">
                        <a href="<?php echo esc_url(wp_logout_url(home_url())); ?>" class="x8-evs-btn x8-evs-btn-secondary">
                            <?php _e('Logout', 'x8-evs'); ?>
                        </a>
                    </div>
                <?php endif; ?>
                
                <?php if (isset($data['show_contact_info']) && $data['show_contact_info']): ?>
                    <div class="x8-evs-contact-info">
                        <p><?php echo !empty($data['contact_message']) ? esc_html($data['contact_message']) : esc_html__('If you believe this is an error, please contact support.', 'x8-evs'); ?></p>
                        <?php 
                        $contact_email = class_exists('X8_EVS_Admin_Settings') ? X8_EVS_Admin_Settings::get_contact_email() : get_option('admin_email');
                        if ($contact_email): ?>
                            <p><?php printf(__('Email: %s', 'x8-evs'), esc_html($contact_email)); ?></p>
                        <?php endif; ?>
                    </div>
                <?php elseif ($status_type === 'login_required'): ?>
                    <div class="x8-evs-contact-info">
                        <p><?php _e('If you need assistance, please contact support.', 'x8-evs'); ?></p>
                    </div>
                <?php elseif ($status_type === 'blocked_redirect' && isset($data['show_verification_form']) && $data['show_verification_form']): ?>
                    <div class="x8-evs-verification-form-container">
                        <?php echo $this->render_verification_form_content(array('title' => __('Complete Identity Verification', 'x8-evs'))); ?>
                    </div>
                <?php endif; ?>
            </div>
        </div>
        
        <style>
            .x8-evs-status-page {
                min-height: 100vh;
                display: flex;
                align-items: center;
                justify-content: center;
                background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
                padding: 20px;
            }
            
            .x8-evs-status-container {
                background: white;
                border-radius: 12px;
                box-shadow: 0 20px 40px rgba(0, 0, 0, 0.1);
                padding: 40px;
                max-width: 500px;
                width: 90%;
                text-align: center;
            }
            
            .x8-evs-status-icon {
                width: 80px;
                height: 80px;
                border-radius: 50%;
                display: flex;
                align-items: center;
                justify-content: center;
                margin: 0 auto 20px;
            }
            
            .x8-evs-status-icon svg {
                width: 40px;
                height: 40px;
                fill: white;
            }
            
            .x8-evs-status-title {
                font-size: 24px;
                font-weight: 700;
                color: #1f2937;
                margin-bottom: 10px;
            }
            
            .x8-evs-status-message {
                font-size: 16px;
                color: #6b7280;
                margin-bottom: 20px;
                line-height: 1.6;
            }
            
            .x8-evs-status-details {
                background: #f8fafc;
                border: 1px solid #e2e8f0;
                border-radius: 8px;
                padding: 20px;
                margin-bottom: 30px;
                text-align: left;
            }
            
            .x8-evs-status-details p {
                color: #374151;
                margin: 0;
                line-height: 1.6;
            }
            
            .x8-evs-status-actions {
                margin-bottom: 20px;
            }
            
            .x8-evs-btn {
                padding: 12px 24px;
                border-radius: 8px;
                font-weight: 600;
                text-decoration: none;
                display: inline-block;
                transition: all 0.2s ease;
                border: none;
                cursor: pointer;
                font-size: 14px;
            }
            
            .x8-evs-btn-primary {
                background: #3b82f6;
                color: white;
            }
            
            .x8-evs-btn-primary:hover {
                background: #2563eb;
                transform: translateY(-1px);
            }
            
            .x8-evs-btn-secondary {
                background: #f3f4f6;
                color: #374151;
                border: 1px solid #d1d5db;
            }
            
            .x8-evs-btn-secondary:hover {
                background: #e5e7eb;
            }
            
            .x8-evs-contact-info {
                margin-top: 30px;
                padding-top: 20px;
                border-top: 1px solid #e5e7eb;
                color: #6b7280;
                font-size: 14px;
            }
            
            @media (max-width: 600px) {
                .x8-evs-status-container {
                    padding: 30px 20px;
                    margin: 20px;
                }
            }
        </style>
        <?php
        return ob_get_clean();
    }
    
    /**
     * Render pending verification screen for users with active links
     */
    private function render_pending_verification_screen($verification_status) {
        $link_created = $verification_status['link_created'];
        $time_remaining = '';
        
        if ($link_created) {
            $created_time = strtotime($link_created);
            $current_time = time();
            $expires_at = $created_time + (1 * 60 * 60); // 1 hour
            $remaining_seconds = $expires_at - $current_time;
            
            if ($remaining_seconds > 0) {
                $hours = floor($remaining_seconds / 3600);
                $minutes = floor(($remaining_seconds % 3600) / 60);
                $time_remaining = sprintf(
                    _n('%d hour %d minute', '%d hours %d minutes', $hours, 'x8-evs'),
                    $hours,
                    $minutes
                );
            }
        }
        
        ob_start();
        ?>
        <div class="x8-evs-pending-verification">
            <div class="x8-evs-pending-container">
                <div class="x8-evs-pending-header">
                    <div class="x8-evs-pending-icon">
                        <span class="dashicons dashicons-clock"></span>
                    </div>
                    <h1><?php _e('Verification Pending', 'x8-evs'); ?></h1>
                    <p class="x8-evs-pending-message">
                        <?php _e('You have already started the verification process. Please complete your verification using the link below.', 'x8-evs'); ?>
                    </p>
                </div>
                
                <?php if ($time_remaining): ?>
                    <div class="x8-evs-time-remaining">
                        <div class="x8-evs-time-icon">
                            <span class="dashicons dashicons-clock"></span>
                        </div>
                        <div class="x8-evs-time-info">
                            <strong><?php _e('Verification Link Expires In:', 'x8-evs'); ?></strong>
                            <div class="x8-evs-countdown" data-expires="<?php echo esc_attr($expires_at); ?>">
                                <span class="x8-evs-countdown-time"><?php echo esc_html($time_remaining); ?></span>
                            </div>
                        </div>
                    </div>
                <?php endif; ?>
                
                <div class="x8-evs-verification-actions">
                    <div class="x8-evs-primary-action">
                        <a href="<?php echo esc_url($verification_status['verification_link']); ?>" 
                           class="x8-evs-btn x8-evs-btn-primary x8-evs-btn-large x8-evs-btn-continue"
                           target="_blank">
                            <span class="dashicons dashicons-external"></span>
                            <?php _e('Continue Verification', 'x8-evs'); ?>
                        </a>
                        <p class="x8-evs-primary-action-note">
                            <?php _e('Click to open verification page in new tab', 'x8-evs'); ?>
                        </p>
                    </div>
                    <p class="x8-evs-pending-email-note">
                        <?php _e('You will be notified via email once your verification status changes.', 'x8-evs'); ?>
                    </p>
                    <div class="x8-evs-pending-logout-wrap">
                        <a href="<?php echo esc_url(wp_logout_url(home_url())); ?>" class="x8-evs-btn x8-evs-btn-secondary x8-evs-pending-logout">
                            <?php _e('Logout', 'x8-evs'); ?>
                        </a>
                    </div>
                </div>
                
                <div class="x8-evs-pending-info">
                    <h3><?php _e('What happens next?', 'x8-evs'); ?></h3>
                    <ol>
                        <li><?php _e('Click "Continue Verification" to open the verification page', 'x8-evs'); ?></li>
                        <li><?php _e('Upload your government-issued photo ID', 'x8-evs'); ?></li>
                        <li><?php _e('Take a clear selfie photo', 'x8-evs'); ?></li>
                        <li><?php _e('Submit your verification for processing', 'x8-evs'); ?></li>
                    </ol>
                    
                    <div class="x8-evs-important-note">
                        <p><strong><?php _e('Important:', 'x8-evs'); ?></strong> 
                        <?php _e('Verification links expire after 1 hour for security. If your link expires, you can generate a new one.', 'x8-evs'); ?></p>
                    </div>
                </div>

				<!-- Pre-flight modal shown before opening the verification link -->
				<div id="x8-evs-preflight-modal" class="x8-evs-modal" style="display:none;">
					<div class="x8-evs-modal-overlay"></div>
					<div class="x8-evs-modal-content">
						<h2 class="x8-evs-modal-title"><?php _e('Before you continue', 'x8-evs'); ?></h2>
						<p class="x8-evs-modal-subtitle"><?php _e('For best results when taking your selfie:', 'x8-evs'); ?></p>
						<ul class="x8-evs-modal-guidelines">
							<li><?php _e('Remove all headwear', 'x8-evs'); ?></li>
							<li><?php _e('Ensure good lighting', 'x8-evs'); ?></li>
							<li><?php _e('Use a plain background if possible', 'x8-evs'); ?></li>
							<li><?php _e('Look straight at the camera - avoid angles', 'x8-evs'); ?></li>
							<li><?php _e('Avoid blurry photos', 'x8-evs'); ?></li>
						</ul>
						<div class="x8-evs-modal-timer">
							<?php _e('Opening verification in', 'x8-evs'); ?> <span id="x8-evs-preflight-countdown">10</span> <?php _e('seconds...', 'x8-evs'); ?>
						</div>
						<div class="x8-evs-modal-actions">
							<button type="button" id="x8-evs-open-now" class="x8-evs-btn x8-evs-btn-primary"><?php _e('Open now', 'x8-evs'); ?></button>
							<button type="button" id="x8-evs-cancel-modal" class="x8-evs-btn x8-evs-btn-secondary"><?php _e('Cancel', 'x8-evs'); ?></button>
						</div>
					</div>
				</div>
            </div>
        </div>
        
        <style>
            .x8-evs-pending-verification {
                min-height: 100vh;
                display: flex;
                align-items: center;
                justify-content: center;
                background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
                padding: 20px;
            }
            
            .x8-evs-pending-container {
                background: white;
                border-radius: 20px;
                box-shadow: 0 25px 50px rgba(0, 0, 0, 0.15);
                padding: 50px;
                max-width: 700px;
                width: 90%;
                text-align: center;
                position: relative;
                overflow: hidden;
            }
            
            .x8-evs-pending-container::before {
                content: '';
                position: absolute;
                top: 0;
                left: 0;
                right: 0;
                height: 4px;
                background: linear-gradient(90deg, #10b981, #3b82f6, #8b5cf6);
            }
            
            .x8-evs-pending-header {
                margin-bottom: 40px;
            }
            
            .x8-evs-pending-icon {
                width: 100px;
                height: 100px;
                border-radius: 50%;
                background: linear-gradient(135deg, #3b82f6 0%, #1d4ed8 100%);
                display: flex;
                align-items: center;
                justify-content: center;
                margin: 0 auto 25px;
                box-shadow: 0 8px 25px rgba(59, 130, 246, 0.3);
                border: 3px solid #dbeafe;
            }
            
            .x8-evs-pending-icon .dashicons {
                font-size: 48px;
                color: white;
            }
            
            .x8-evs-pending-header h1 {
                font-size: 32px;
                font-weight: 800;
                color: #1f2937;
                margin-bottom: 20px;
                background: linear-gradient(135deg, #1f2937 0%, #374151 100%);
                -webkit-background-clip: text;
                -webkit-text-fill-color: transparent;
                background-clip: text;
            }
            
            .x8-evs-pending-message {
                font-size: 18px;
                color: #6b7280;
                line-height: 1.7;
                margin: 0;
                max-width: 500px;
                margin-left: auto;
                margin-right: auto;
            }
            
            .x8-evs-time-remaining {
                background: linear-gradient(135deg, #fef3c7 0%, #fde68a 100%);
                border: 2px solid #f59e0b;
                border-radius: 12px;
                padding: 25px;
                margin-bottom: 30px;
                display: flex;
                align-items: center;
                justify-content: center;
                gap: 20px;
                box-shadow: 0 4px 15px rgba(245, 158, 11, 0.2);
            }
            
            .x8-evs-time-icon .dashicons {
                font-size: 28px;
                color: #d97706;
            }
            
            .x8-evs-time-info {
                text-align: center;
            }
            
            .x8-evs-time-info strong {
                display: block;
                color: #92400e;
                font-size: 16px;
                margin-bottom: 10px;
                font-weight: 600;
            }
            
            .x8-evs-countdown {
                text-align: center;
            }
            
            .x8-evs-countdown-time {
                color: #92400e;
                font-size: 24px;
                font-weight: 700;
                background: white;
                padding: 8px 16px;
                border-radius: 8px;
                border: 2px solid #f59e0b;
                display: inline-block;
                min-width: 120px;
            }
            
            .x8-evs-countdown-urgent .x8-evs-countdown-time {
                background: #fef2f2;
                border-color: #ef4444;
                color: #dc2626;
                animation: pulse 2s infinite;
            }
            
            .x8-evs-countdown-expired .x8-evs-countdown-time {
                background: #fee2e2;
                border-color: #dc2626;
                color: #dc2626;
            }
            
            @keyframes pulse {
                0% { transform: scale(1); }
                50% { transform: scale(1.05); }
                100% { transform: scale(1); }
            }
            
            .x8-evs-verification-actions {
                margin-bottom: 40px;
            }
            
            .x8-evs-primary-action {
                text-align: center;
                margin-bottom: 30px;
                padding: 30px;
                background: linear-gradient(135deg, #f8fafc 0%, #e2e8f0 100%);
                border-radius: 16px;
                border: 2px solid #e2e8f0;
                width: 100%;
                box-sizing: border-box;
            }
            
            .x8-evs-btn-continue {
                background: linear-gradient(135deg, #10b981 0%, #059669 100%);
                color: white;
                font-size: 18px;
                padding: 20px 40px;
                border-radius: 12px;
                box-shadow: 0 8px 25px rgba(16, 185, 129, 0.3);
                border: none;
                transition: all 0.3s ease;
                margin: 0 auto;
                display: block;
                min-width: 280px;
            }
            
            .x8-evs-btn-continue:hover {
                background: linear-gradient(135deg, #059669 0%, #047857 100%);
                transform: translateY(-2px);
                box-shadow: 0 12px 35px rgba(16, 185, 129, 0.4);
                color: white;
            }
            
            .x8-evs-primary-action-note {
                color: #6b7280;
                font-size: 14px;
                margin-top: 15px;
                font-style: italic;
            }
            
            .x8-evs-pending-email-note {
                text-align: center;
                color: #4b5563;
                font-size: 14px;
                line-height: 1.5;
                margin: 0 0 24px 0;
                padding: 0 20px;
            }
            
            .x8-evs-pending-logout-wrap {
                text-align: center;
                margin-top: 8px;
            }
            
            .x8-evs-pending-logout-wrap .x8-evs-pending-logout {
                margin: 0;
            }
            
            .x8-evs-btn {
                padding: 12px 24px;
                border-radius: 8px;
                font-weight: 600;
                text-decoration: none;
                display: inline-flex;
                align-items: center;
                gap: 8px;
                transition: all 0.2s ease;
                border: none;
                cursor: pointer;
                font-size: 14px;
                margin: 5px;
            }
            
            .x8-evs-btn-large {
                padding: 16px 32px;
                font-size: 16px;
            }
            
            .x8-evs-btn-primary {
                background: #3b82f6;
                color: white;
            }
            
            .x8-evs-btn-primary:hover {
                background: #2563eb;
                transform: translateY(-1px);
                box-shadow: 0 4px 12px rgba(59, 130, 246, 0.3);
            }
            
            .x8-evs-btn-secondary {
                background: #f3f4f6;
                color: #374151;
                border: 1px solid #d1d5db;
            }
            
            .x8-evs-btn-secondary:hover {
                background: #e5e7eb;
                transform: translateY(-1px);
            }
            
            .x8-evs-secondary-actions {
                margin-top: 20px;
                text-align: center;
            }
            
            .x8-evs-pending-info {
                text-align: left;
                background: #f8fafc;
                border: 1px solid #e2e8f0;
                border-radius: 8px;
                padding: 25px;
            }
            
            .x8-evs-pending-info h3 {
                color: #1f2937;
                font-size: 18px;
                margin-bottom: 15px;
                text-align: center;
            }
            
            .x8-evs-pending-info ol {
                color: #374151;
                line-height: 1.8;
                margin-bottom: 20px;
                padding-left: 20px;
            }
            
            .x8-evs-pending-info li {
                margin-bottom: 8px;
            }
				
				.x8-evs-photo-guidelines {
					background: #ecfdf5;
					border: 1px solid #a7f3d0;
					border-radius: 8px;
					padding: 16px;
					margin-top: 16px;
				}
				.x8-evs-photo-guidelines h3 {
					color: #065f46;
					font-size: 16px;
					margin: 0 0 10px 0;
					text-align: center;
				}
				.x8-evs-photo-guidelines ul {
					margin: 0;
					padding-left: 18px;
					color: #065f46;
					line-height: 1.7;
				}
            
            .x8-evs-important-note {
                background: #fff3cd;
                border: 1px solid #ffeaa7;
                border-radius: 6px;
                padding: 15px;
                margin-top: 20px;
            }
            
            .x8-evs-important-note p {
                color: #856404;
                margin: 0;
                font-size: 14px;
                line-height: 1.5;
            }
            
            /* Modal styles */
            .x8-evs-modal {
                position: fixed;
                top: 0;
                left: 0;
                right: 0;
                bottom: 0;
                display: none;
                z-index: 9999;
            }
            .x8-evs-modal-overlay {
                position: absolute;
                top: 0;
                left: 0;
                right: 0;
                bottom: 0;
                background: rgba(0, 0, 0, 0.5);
            }
            .x8-evs-modal-content {
                position: relative;
                background: #ffffff;
                max-width: 560px;
                margin: 10vh auto 0 auto;
                border-radius: 12px;
                padding: 24px;
                box-shadow: 0 20px 40px rgba(0,0,0,0.2);
                text-align: left;
            }
            .x8-evs-modal-title {
                margin: 0 0 6px 0;
                font-size: 22px;
                color: #1f2937;
                text-align: center;
            }
            .x8-evs-modal-subtitle {
                margin: 0 0 12px 0;
                text-align: center;
                color: #4b5563;
            }
            .x8-evs-modal-guidelines {
                background: #ecfdf5;
                border: 1px solid #a7f3d0;
                border-radius: 8px;
                padding: 16px 20px;
                color: #065f46;
                line-height: 1.8;
                margin: 0 0 14px 0;
            }
				.x8-evs-modal-guidelines li { margin-bottom: 6px; }
				ul.x8-evs-modal-guidelines {
					list-style: none;
					padding: 20px;
				}
            .x8-evs-modal-timer {
                text-align: center;
                margin: 10px 0 14px 0;
                color: #374151;
                font-weight: 600;
            }
            .x8-evs-modal-actions { text-align: center; }
            
            @media (max-width: 600px) {
                .x8-evs-pending-container {
                    padding: 30px 20px;
                    margin: 20px;
                }
                
                .x8-evs-btn {
                    width: 100%;
                    justify-content: center;
                    margin: 5px 0;
                }
                
                .x8-evs-time-remaining {
                    flex-direction: column;
                    text-align: center;
                }
                
                .x8-evs-time-info {
                    text-align: center;
                }
            }
        </style>
        
        <script>
        jQuery(document).ready(function($) {
            // Live countdown timer
            function updateCountdown() {
                $('.x8-evs-countdown').each(function() {
                    var $countdown = $(this);
                    var expiresAt = parseInt($countdown.data('expires'));
                    var now = Math.floor(Date.now() / 1000);
                    var remaining = expiresAt - now;
                    
                    if (remaining > 0) {
                        var hours = Math.floor(remaining / 3600);
                        var minutes = Math.floor((remaining % 3600) / 60);
                        var seconds = remaining % 60;
                        
                        var timeString = '';
                        if (hours > 0) {
                            timeString = hours + 'h ' + minutes + 'm ' + seconds + 's';
                        } else if (minutes > 0) {
                            timeString = minutes + 'm ' + seconds + 's';
                        } else {
                            timeString = seconds + 's';
                        }
                        
                        $countdown.find('.x8-evs-countdown-time').text(timeString);
                        
                        // Add urgency styling when less than 30 minutes
                        if (remaining < 1800) {
                            $countdown.addClass('x8-evs-countdown-urgent');
                        }
                    } else {
                        $countdown.find('.x8-evs-countdown-time').text('EXPIRED');
                        $countdown.addClass('x8-evs-countdown-expired');
                    }
                });
            }
            
            // Update countdown every second
            updateCountdown();
            setInterval(updateCountdown, 1000);
            
            // Handle regenerate link button
            $('#x8-evs-regenerate-link').on('click', function(e) {
                e.preventDefault();
                
                if (confirm('<?php _e('Are you sure you want to generate a new verification link? This will invalidate your current link.', 'x8-evs'); ?>')) {
                    // Show loading state
                    $(this).prop('disabled', true).html('<span class="dashicons dashicons-update" style="animation: spin 1s linear infinite;"></span> Generating...');
                    
                    // Make AJAX request to regenerate link
                    $.ajax({
                        url: '<?php echo admin_url('admin-ajax.php'); ?>',
                        type: 'POST',
                        data: {
                            action: 'x8_evs_verify',
                            action_type: 'regenerate',
                            nonce: '<?php echo wp_create_nonce('x8_evs_nonce'); ?>'
                        },
                        dataType: 'json',
                        success: function(response) {
                            if (response.success) {
                                // Reload the page to show the new link
                                location.reload();
                            } else {
                                alert(response.data || '<?php _e('Failed to generate new link. Please try again.', 'x8-evs'); ?>');
                                // Reset button
                                $('#x8-evs-regenerate-link').prop('disabled', false).html('<span class="dashicons dashicons-update"></span> <?php _e('Generate New Link', 'x8-evs'); ?>');
                            }
                        },
                        error: function() {
                            alert('<?php _e('Network error. Please try again.', 'x8-evs'); ?>');
                            // Reset button
                            $('#x8-evs-regenerate-link').prop('disabled', false).html('<span class="dashicons dashicons-update"></span> <?php _e('Generate New Link', 'x8-evs'); ?>');
                        }
                    });
                }
            });

            // Intercept Continue Verification to show a pre-flight modal with countdown
            var x8EvsPreflightTimer = null;
            var x8EvsTargetUrl = null;
            function x8HidePreflightModal() {
                if (x8EvsPreflightTimer) {
                    clearInterval(x8EvsPreflightTimer);
                    x8EvsPreflightTimer = null;
                }
                $('#x8-evs-preflight-modal').hide();
            }
            function x8OpenVerificationNow() {
                if (x8EvsTargetUrl) {
                    window.open(x8EvsTargetUrl, '_blank');
                }
                x8HidePreflightModal();
            }
            function x8ShowPreflightModal(url) {
                x8EvsTargetUrl = url;
                var seconds = 10;
                $('#x8-evs-preflight-countdown').text(seconds);
                $('#x8-evs-preflight-modal').show();
                x8EvsPreflightTimer = setInterval(function() {
                    seconds -= 1;
                    if (seconds <= 0) {
                        clearInterval(x8EvsPreflightTimer);
                        x8EvsPreflightTimer = null;
                        x8OpenVerificationNow();
                    } else {
                        $('#x8-evs-preflight-countdown').text(seconds);
                    }
                }, 1000);
            }

            $('.x8-evs-btn-continue').on('click', function(e) {
                e.preventDefault();
                var href = $(this).attr('href');
                if (!href) return;
                x8ShowPreflightModal(href);
            });

            $('#x8-evs-open-now').on('click', function() { x8OpenVerificationNow(); });
            $('#x8-evs-cancel-modal, #x8-evs-preflight-modal .x8-evs-modal-overlay').on('click', function() { x8HidePreflightModal(); });
        });
        </script>
        <?php
        return ob_get_clean();
    }
    
    /**
     * Render the actual verification form content
     */
    private function render_verification_form_content($atts) {
        $allowed_types = class_exists('X8_EVS_Admin_Settings') ? X8_EVS_Admin_Settings::get_allowed_document_types() : array('DriversLicense');
        $types_map = class_exists('X8_EVS_Admin_Settings') ? X8_EVS_Admin_Settings::get_document_types_map() : array('DriversLicense' => __('Drivers License / State ID', 'x8-evs'));
        $customer_chooses = class_exists('X8_EVS_Admin_Settings') && X8_EVS_Admin_Settings::customer_chooses_document_type();
        $default_document_type = class_exists('X8_EVS_Admin_Settings') ? X8_EVS_Admin_Settings::get_default_document_type() : 'DriversLicense';
        ob_start();
        ?>
        <div id="x8-evs-form-container" class="x8-evs-verify-card">
            <div class="x8-evs-verify-header">
                <span class="x8-evs-verify-icon" aria-hidden="true"></span>
                <h2 class="x8-evs-verify-title"><?php echo esc_html($atts['title']); ?></h2>
                <p class="x8-evs-verify-subtitle"><?php _e('To continue using our services, please complete the identity verification process.', 'x8-evs'); ?></p>
            </div>
            
            <div class="x8-evs-verification-intro">
                <p class="x8-evs-intro-heading"><?php _e('You will need:', 'x8-evs'); ?></p>
                <ul class="x8-evs-requirements">
                    <li><?php _e('A valid government-issued photo ID (Driver\'s License, Passport, etc.)', 'x8-evs'); ?></li>
                    <li><?php _e('A clear selfie photo for identity confirmation', 'x8-evs'); ?></li>
                </ul>
                <p class="x8-evs-verification-note"><?php _e('Verification links expire after 1 hour for security.', 'x8-evs'); ?></p>
            </div>
            
            <div class="x8-evs-verification-form">
                <?php if ($customer_chooses && count($allowed_types) > 1): ?>
                    <div class="x8-evs-document-type-choice">
                        <label for="x8-evs-document-type-select" class="x8-evs-doc-label"><?php _e('I will verify with', 'x8-evs'); ?></label>
                        <select id="x8-evs-document-type-select" name="x8_evs_document_type" class="x8-evs-document-type-select">
                            <?php foreach ($allowed_types as $value): ?>
                                <?php if (isset($types_map[$value])): ?>
                                    <option value="<?php echo esc_attr($value); ?>" <?php selected($default_document_type, $value); ?>><?php echo esc_html($types_map[$value]); ?></option>
                                <?php endif; ?>
                            <?php endforeach; ?>
                        </select>
                    </div>
                <?php endif; ?>
                <p class="x8-evs-cta-text" style="color: #000;"><?php _e('Click below to begin. You will be redirected to a secure verification page.', 'x8-evs'); ?></p>
                
                <div class="x8-evs-cta-wrap">
                    <button type="button" id="x8-evs-start-verification" class="x8-evs-btn x8-evs-btn-primary x8-evs-btn-large">
                        <span class="x8-evs-btn-text"><?php echo esc_html($atts['button_text']); ?></span>
                    </button>
                </div>
                
                <div id="x8-evs-loading" class="x8-evs-loading" style="display: none;">
                    <div class="x8-evs-spinner"></div>
                    <p><?php _e('Generating verification link...', 'x8-evs'); ?></p>
                </div>
            </div>
            
            <?php 
            $return_url = $this->get_return_url();
            if ($return_url): ?>
                <input type="hidden" id="x8-evs-return-url" value="<?php echo esc_url($return_url); ?>" />
            <?php endif; ?>
            
            <div id="x8-evs-result" class="x8-evs-result" style="display:none;"></div>
        </div>
        <?php
        return ob_get_clean();
    }
    
    /**
     * Get user verification status and active links
     */
    private function get_user_verification_status($user_id) {
        $account_status = get_user_meta($user_id, 'account_status', true);
        $verification_link = get_user_meta($user_id, 'verification_link', true);
        $verification_link_created = get_user_meta($user_id, 'verification_link_created', true);
        $verification_notes = get_user_meta($user_id, 'verification_notes', true);
        
        // SIMPLE CHECK: If user has ANY verification link, consider it active
        $has_active_link = !empty($verification_link);
        
        return array(
            'status' => $account_status ?: 'pending',
            'verification_link' => $verification_link,
            'has_active_link' => $has_active_link,
            'link_created' => $verification_link_created,
            'notes' => $verification_notes
        );
    }
    
    /**
     * Handle AJAX verification request
     */
    public function handle_verification() {
        // Verify nonce for security
        if (!wp_verify_nonce($_POST['nonce'], 'x8_evs_nonce')) {
            wp_send_json_error(__('Security check failed', 'x8-evs'));
        }
        
        // Check if user is logged in
        if (!is_user_logged_in()) {
            wp_send_json_error(__('You must be logged in to verify your identity.', 'x8-evs'));
        }
        
        $user_id = get_current_user_id();
        $action_type = sanitize_text_field($_POST['action_type'] ?? 'generate');
        $document_type = isset($_POST['document_type']) ? sanitize_text_field($_POST['document_type']) : null;
        
        switch ($action_type) {
            case 'generate':
            case 'regenerate':
                $this->generate_verification_link($user_id, $action_type === 'regenerate', $document_type);
                break;
            case 'debug':
                // Debug endpoint to check current state
                $debug_info = $this->debug_user_meta($user_id);
                wp_send_json_success($debug_info);
                break;
            default:
                wp_send_json_error(__('Invalid action specified.', 'x8-evs'));
        }
    }
    
    /**
     * Generate verification link using X8 Verify API
     *
     * @param int       $user_id       User ID.
     * @param bool      $is_regenerate Whether this is a regenerate request.
     * @param string|null $document_type Customer-selected document type (must be in allowed list).
     */
    private function generate_verification_link($user_id, $is_regenerate = false, $document_type = null) {
        // Debug: Log the state before generation
        error_log("X8 EVS Debug - Starting link generation for user $user_id, regenerate: " . ($is_regenerate ? 'yes' : 'no'));
        $this->debug_user_meta($user_id);
        
        // SIMPLE CHECK: If user has ANY verification link, don't allow generation
        if (!$is_regenerate) {
            $existing_link = get_user_meta($user_id, 'verification_link', true);
            if (!empty($existing_link)) {
                error_log("X8 EVS Debug - User $user_id already has link: " . substr($existing_link, 0, 50) . "...");
                wp_send_json_error(__('You already have a verification link. Please use the existing link or contact support to generate a new one.', 'x8-evs'));
            }
        }
        
        // Check rate limiting for ALL users
        if (class_exists('X8_EVS_Admin_Settings')) {
            $rate_limit_check = X8_EVS_Admin_Settings::can_generate_verification_link($user_id);
            if (!$rate_limit_check['can_generate']) {
                wp_send_json_error($rate_limit_check['reason']);
            }
        }

        if (class_exists('\\TapStack\\Verify') && method_exists('\\TapStack\\Verify', 'is_required_for_user')) {
            if (!\TapStack\Verify::is_required_for_user((int) $user_id)) {
                wp_send_json_error(__('Identity verification is not required for this account type.', 'x8-evs'));
            }
        }
        
        // Get API credentials from settings
        $username = get_option('x8_evs_username', '');
        $password = get_option('x8_evs_password', '');
        
        if (empty($username) || empty($password)) {
            wp_send_json_error(__('API credentials not configured. Please contact the administrator.', 'x8-evs'));
        }
        
        // Get document type: from customer choice (if valid) or first allowed type
        $allowed_types = class_exists('X8_EVS_Admin_Settings') ? X8_EVS_Admin_Settings::get_allowed_document_types() : array('DriversLicense');
        if (!empty($document_type) && in_array($document_type, $allowed_types, true)) {
            // use customer-selected type
        } else {
            $document_type = !empty($allowed_types) ? $allowed_types[0] : get_option('x8_evs_document_type', 'DriversLicense');
        }
        $site_url = home_url();
        
        // Prepare API request data
        $request_data = array(
            'meta' => array(
                'credentials' => array(
                    'username' => $username,
                    'password' => $password
                ),
                'customerReference' => (string)$user_id
            ),
            'data' => array(
                'scanMode' => 'DeferredRequestLink',
                'documentType' => $document_type,
                'redirectUrl' => $site_url . '/verification-success',
                'errorRedirectUrl' => $site_url . '/verification-error',
                'redirectDelay' => 30
            )
        );
        
        
        // Add RequireConsumerPortrait if selfie is required
        if (class_exists('X8_EVS_Admin_Settings') && X8_EVS_Admin_Settings::is_selfie_required()) {
            $request_data['data']['RequireConsumerPortrait'] = true;
        }
        
        // Make API request
        $response = wp_remote_post('https://blueassure.evssolutions.com/WebServices/Integrated/Main/V300/AssureCard', array(
            'headers' => array(
                'Content-Type' => 'application/json'
            ),
            'body' => json_encode($request_data),
            'timeout' => 30
        ));
        
        if (is_wp_error($response)) {
            wp_send_json_error(__('Connection error. Please try again later.', 'x8-evs'));
        }
        
        $body = wp_remote_retrieve_body($response);
        $data = json_decode($body, true);
        
        // Check for API errors
        if (!$data || !isset($data['data']['deferredRequestLink'])) {
            $error_message = __('Failed to generate verification link. Please try again.', 'x8-evs');
            
            // Try to extract error message from response
            if (isset($data['error']['message'])) {
                $error_message = $data['error']['message'];
            } elseif (isset($data['errors'][0]['detail'])) {
                $error_message = $data['errors'][0]['detail'];
            } elseif (isset($data['message'])) {
                $error_message = $data['message'];
            }
            
            if (class_exists('X8_EVS_Debug_Logger')) {
                X8_EVS_Debug_Logger::log('api_error', 'EVS link generation failed: ' . $error_message, array(
                    'error_code' => $data['error']['code'] ?? ($data['errors'][0]['code'] ?? ''),
                    'errors' => $data['errors'] ?? ($data['error'] ?? array()),
                    'http_code' => wp_remote_retrieve_response_code($response)
                ), $user_id);
            }
            
            wp_send_json_error($error_message);
        }
        
        $verification_link = $data['data']['deferredRequestLink'];
        
        // Store verification link and metadata - SIMPLE AND DIRECT
        update_user_meta($user_id, 'verification_link', $verification_link);
        update_user_meta($user_id, 'verification_link_created', current_time('mysql'));
        update_user_meta($user_id, 'verification_transaction_id', $data['meta']['transactionId'] ?? '');
        update_user_meta($user_id, 'verification_customer_reference', $data['meta']['customerReference'] ?? '');
        // Ensure user status is set to pending so the UI shows the pending screen on reload
        update_user_meta($user_id, 'account_status', 'pending');
        update_user_meta($user_id, 'x8_evs_pending_since', current_time('mysql'));
        
        // Force clear any caching
        wp_cache_delete($user_id, 'user_meta');
        
        // Verify the data was saved by reading it back
        $saved_link = get_user_meta($user_id, 'verification_link', true);
        
        if (empty($saved_link)) {
            wp_send_json_error(__('Failed to save verification link. Please try again.', 'x8-evs'));
        }
        
        // Debug: Log the current state
        $this->debug_user_meta($user_id);
        
        // Track this as a verification attempt for rate limiting
        if (class_exists('X8_EVS_Admin_Settings')) {
            X8_EVS_Admin_Settings::track_verification_attempt($user_id, 'attempt');
            
            // Log comprehensive activity
            X8_EVS_Admin_Settings::log_customer_activity($user_id, 'link_generated', array(
                'verification_link' => $verification_link,
                'transaction_id' => $data['meta']['transactionId'] ?? '',
                'document_type' => $document_type,
                'is_regenerate' => $is_regenerate,
                'api_response' => $data
            ));
        }
        
        // Clear previous verification status if regenerating
        if ($is_regenerate) {
            delete_user_meta($user_id, 'verification_notes');
        }
        
        wp_send_json_success(array(
            'message' => __('Verification link generated successfully!', 'x8-evs'),
            'verification_link' => $verification_link,
            'transaction_id' => $data['meta']['transactionId'] ?? '',
            'action' => $is_regenerate ? 'regenerated' : 'generated'
        ));
    }
    
    /**
     * Enqueue frontend scripts and styles
     */
    public function enqueue_scripts() {
        wp_enqueue_script('x8-evs-frontend-script', X8_EVS_PLUGIN_URL . 'inc/frontend/assets/js/verification-form.js', array('jquery'), X8_EVS_VERSION, true);
        wp_enqueue_style('x8-evs-frontend-style', X8_EVS_PLUGIN_URL . 'inc/frontend/assets/css/verification-form.css', array(), X8_EVS_VERSION);
        
        // Localize script for AJAX (include allowed document types for customer choice)
        $allowed_types = class_exists('X8_EVS_Admin_Settings') ? X8_EVS_Admin_Settings::get_allowed_document_types() : array('DriversLicense');
        $customer_chooses = class_exists('X8_EVS_Admin_Settings') && X8_EVS_Admin_Settings::customer_chooses_document_type();
        $default_document_type = class_exists('X8_EVS_Admin_Settings') ? X8_EVS_Admin_Settings::get_default_document_type() : 'DriversLicense';
        wp_localize_script('x8-evs-frontend-script', 'x8_evs_ajax', array(
            'ajax_url' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('x8_evs_nonce'),
            'loading_text' => __('Verifying...', 'x8-evs'),
            'allowed_document_types' => $allowed_types,
            'customer_chooses_document_type' => $customer_chooses,
            'default_document_type' => $default_document_type
        ));
    }

    /**
     * Get return URL for verification redirect
     */
    private function get_return_url() {
        if (class_exists('X8_EVS_Verification_Redirect')) {
            return X8_EVS_Verification_Redirect::get_return_url();
        }
        return '';
    }
    
    /**
     * Debug function to check user meta (remove in production)
     */
    public function debug_user_meta($user_id = null) {
        if (!$user_id) {
            $user_id = get_current_user_id();
        }
        
        $verification_link = get_user_meta($user_id, 'verification_link', true);
        $verification_link_created = get_user_meta($user_id, 'verification_link_created', true);
        
        error_log("X8 EVS Debug - User $user_id - Link: " . ($verification_link ? 'EXISTS' : 'NONE') . 
                 ", Created: " . ($verification_link_created ?: 'NONE'));
        
        return array(
            'user_id' => $user_id,
            'verification_link' => $verification_link,
            'verification_link_created' => $verification_link_created
        );
    }
}

// Initialize the verification form handler
new X8_EVS_Verification_Form(); 