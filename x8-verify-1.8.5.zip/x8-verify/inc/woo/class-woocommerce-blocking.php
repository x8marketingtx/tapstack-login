<?php
/**
 * WooCommerce Blocking Utilities
 *
 * @package X8_EVS
 * @since 1.0.0
 */

// Exit if accessed directly.
if (!defined('ABSPATH')) {
    exit;
}

if (!class_exists('X8_EVS_WooCommerce_Blocking')) {
    /**
     * Adds blocking-related helpers to WooCommerce admin.
     */
    class X8_EVS_WooCommerce_Blocking {
        /**
         * Register hooks.
         */
        public function __construct() {
            // Admin styles for status badges.
            add_action('admin_enqueue_scripts', array($this, 'enqueue_admin_assets'));

            // Order edit controls under the billing section.
            add_action('woocommerce_admin_order_data_after_billing_address', array($this, 'render_admin_billing_controls'), 30);

            // AJAX handler for updating the linked user status.
            add_action('wp_ajax_x8_evs_update_user_status', array($this, 'handle_update_user_status'));

            // Add user status column to orders list.
            add_filter('manage_woocommerce_page_wc-orders_columns', array($this, 'add_user_status_column'), 20);
            add_action('manage_woocommerce_page_wc-orders_custom_column', array($this, 'render_user_status_column'), 10, 2);
        }

        /**
         * Determine the user status label for a given order.
         *
         * @param \WC_Order|null $order Order object.
         * @return string
         */
        protected function resolve_user_status($order) {
            if (!$order instanceof \WC_Order) {
                return array(
                    'label' => __('Unknown', 'x8-evs'),
                    'slug'  => 'unknown',
                    'icon'  => 'dashicons-admin-users',
                );
            }

            $customer_id = $order->get_customer_id();

            if (empty($customer_id)) {
                return array(
                    'label' => __('Guest', 'x8-evs'),
                    'slug'  => 'guest',
                    'icon'  => 'dashicons-admin-users',
                );
            }

            // Prefer dedicated account status meta if available.
            $raw_status = get_user_meta($customer_id, 'account_status', true);

            if (empty($raw_status)) {
                $raw_status = get_user_meta($customer_id, 'x8_evs_account_status', true);
            }

            if (empty($raw_status)) {
                return array(
                    'label' => __('Not Set', 'x8-evs'),
                    'slug'  => 'not-set',
                    'icon'  => 'dashicons-minus',
                );
            }

            return $this->normalize_status($raw_status);
        }

        /**
         * Normalize a raw status value to a readable label.
         *
         * @param string $status Raw status key.
         * @return array
         */
        protected function normalize_status($status) {
            $status = sanitize_text_field($status);
            $status = strtolower(trim($status));

            if ('' === $status) {
                return array(
                    'label' => __('Not Set', 'x8-evs'),
                    'slug'  => 'not-set',
                    'icon'  => 'dashicons-minus',
                );
            }

            $map = array(
                'approved'       => array(__('Approved', 'x8-evs'), 'dashicons-yes-alt'),
                'block'          => array(__('Blocked', 'x8-evs'), 'dashicons-dismiss', 'blocked'),
                'blocked'        => array(__('Blocked', 'x8-evs'), 'dashicons-dismiss', 'blocked'),
                'pending'        => array(__('Pending', 'x8-evs'), 'dashicons-clock'),
                'manual_review'  => array(__('Manual Review', 'x8-evs'), 'dashicons-search'),
                'needs_review'   => array(__('Needs Review', 'x8-evs'), 'dashicons-visibility'),
                'rejected'       => array(__('Rejected', 'x8-evs'), 'dashicons-no'),
                'suspended'      => array(__('Suspended', 'x8-evs'), 'dashicons-shield'),
                'under_review'   => array(__('Under Review', 'x8-evs'), 'dashicons-search'),
                'verified'       => array(__('Verified', 'x8-evs'), 'dashicons-saved'),
            );

            if (isset($map[$status])) {
                return array(
                    'label' => $map[$status][0],
                    'slug'  => $map[$status][2] ?? $status,
                    'icon'  => $map[$status][1],
                );
            }

            // Fallback: prettify unknown statuses.
            $readable = str_replace(array('_', '-'), ' ', $status);
            return array(
                'label' => ucwords($readable),
                'slug'  => sanitize_title($status),
                'icon'  => 'dashicons-info',
            );
        }

        /**
         * Output status and location controls under the Billing block on order edit.
         *
         * @param \WC_Order|\WC_Abstract_Order $order Order instance.
         */
        public function render_admin_billing_controls($order) {
            if (!$order instanceof \WC_Order) {
                return;
            }

            $status_data  = $this->resolve_user_status($order);
            $customer_id  = $order->get_customer_id();
            $has_customer = !empty($customer_id);

            $show_unblock = in_array($status_data['slug'], array('block', 'blocked'), true);

            $order_id = $order->get_id();
            ?>
            <div class="x8-evs-order-admin-panel" data-order-id="<?php echo esc_attr($order_id); ?>">
                <div class="x8-evs-order-admin-panel__section">
                    <div class="x8-evs-order-card">
                        <div class="x8-evs-order-card__left">
                            <h3 class="x8-evs-order-card__title"><?php esc_html_e('Verification Status', 'x8-evs'); ?></h3>
                            <p class="x8-evs-order-card__description">
                                <?php esc_html_e('Review and manage this customer’s verification state before processing the order.', 'x8-evs'); ?>
                            </p>
                            <span class="x8-evs-user-status x8-evs-user-status--<?php echo esc_attr($status_data['slug']); ?>">
                                <span class="x8-evs-user-status__icon dashicons <?php echo esc_attr($status_data['icon']); ?>" aria-hidden="true"></span>
                                <span class="x8-evs-user-status__label"><?php echo esc_html($status_data['label']); ?></span>
                            </span>
                        </div>
                        <div class="x8-evs-order-card__right" data-has-user="<?php echo $has_customer ? '1' : '0'; ?>">
                            <?php if ($has_customer) : ?>
                                <div class="x8-evs-action-stack">
                                    <button type="button"
                                        class="button button-secondary x8-evs-status-action"
                                        data-target="block"
                                        data-order-id="<?php echo esc_attr($order_id); ?>">
                                        <?php esc_html_e('Block User', 'x8-evs'); ?>
                                    </button>
                                    <button type="button"
                                        class="button button-primary x8-evs-status-action x8-evs-status-action--unblock"
                                        data-target="pending"
                                        data-order-id="<?php echo esc_attr($order_id); ?>"
                                        <?php echo $show_unblock ? '' : 'style="display:none;"'; ?>>
                                        <?php esc_html_e('Unblock User', 'x8-evs'); ?>
                                    </button>
                                </div>
                            <?php else : ?>
                                <span class="x8-evs-order-admin-panel__notice"><?php esc_html_e('Guest checkout – status actions unavailable.', 'x8-evs'); ?></span>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="x8-evs-order-admin-panel__feedback" role="alert" aria-live="assertive"></div>
                </div>
            </div>
            <?php
        }

        /**
         * Handle AJAX updates for user status from admin order edit screen.
         */
        public function handle_update_user_status() {
            check_ajax_referer('x8_evs_update_user_status', 'nonce');

            $order_id = isset($_POST['order_id']) ? absint($_POST['order_id']) : 0;
            $target   = isset($_POST['status']) ? sanitize_key(wp_unslash($_POST['status'])) : '';

            $allowed_statuses = array(
                'block'   => 'block',
                'blocked' => 'block',
                'pending' => 'pending',
            );

            if (!$order_id || !isset($allowed_statuses[$target])) {
                wp_send_json_error(array('message' => __('Invalid request.', 'x8-evs')));
            }

            $order = wc_get_order($order_id);
            if (!$order instanceof \WC_Order) {
                wp_send_json_error(array('message' => __('Order not found.', 'x8-evs')));
            }

            $customer_id = $order->get_customer_id();
            if (empty($customer_id)) {
                wp_send_json_error(array('message' => __('Guest users cannot be updated.', 'x8-evs')));
            }

            $new_status = $allowed_statuses[$target];

            update_user_meta($customer_id, 'account_status', $new_status);
            update_user_meta($customer_id, 'x8_evs_account_status', $new_status);
            if ('pending' === $new_status) {
                update_user_meta($customer_id, 'x8_evs_pending_since', current_time('mysql'));
            }

            $status_data = $this->normalize_status($new_status);

            $current_user = wp_get_current_user();
            $admin_name   = $current_user && $current_user->exists() ? ($current_user->display_name ?: $current_user->user_login) : __('Unknown admin', 'x8-evs');
            $order_number = $order->get_order_number();
            $admin_note   = '';

            if ('block' === $new_status) {
                $admin_note = sprintf(
                    __('%1$s blocked this customer from order #%2$s', 'x8-evs'),
                    $admin_name,
                    $order_number
                );
            } elseif ('pending' === $new_status) {
                $admin_note = sprintf(
                    __('%1$s moved this customer back to pending from order #%2$s', 'x8-evs'),
                    $admin_name,
                    $order_number
                );
            }

            if (!empty($admin_note)) {
                update_user_meta($customer_id, 'verification_notes', $admin_note);

                $status_history = get_user_meta($customer_id, 'status_change_history', true);
                if (!is_array($status_history)) {
                    $status_history = array();
                }

                $status_entry = array(
                    'status' => $new_status,
                    'notes'  => $admin_note,
                    'admin_user' => $admin_name,
                    'timestamp' => current_time('mysql'),
                    'ip_address' => $_SERVER['REMOTE_ADDR'] ?? '',
                    'verification_method' => 'order_panel'
                );

                array_unshift($status_history, $status_entry);
                $status_history = array_slice($status_history, 0, 20);
                update_user_meta($customer_id, 'status_change_history', $status_history);
            }

            wp_send_json_success(array(
                'status'     => $new_status,
                'label'      => $status_data['label'],
                'slug'       => $status_data['slug'],
                'icon'       => $status_data['icon'],
                'message'    => sprintf(__('User status updated to %s.', 'x8-evs'), $status_data['label']),
                'admin_note' => $admin_note,
            ));
        }

        /**
         * Add user status column to orders list.
         *
         * @param array $columns Existing columns.
         * @return array
         */
        public function add_user_status_column($columns) {
            // Insert after order_status column if it exists, otherwise append.
            $new_columns = array();
            $inserted = false;

            foreach ($columns as $key => $value) {
                $new_columns[$key] = $value;
                if ('order_status' === $key && !$inserted) {
                    $new_columns['x8_evs_user_status'] = __('User Status', 'x8-evs');
                    $inserted = true;
                }
            }

            // If order_status column not found, append at the end.
            if (!$inserted) {
                $new_columns['x8_evs_user_status'] = __('User Status', 'x8-evs');
            }

            return $new_columns;
        }

        /**
         * Render user status in orders list column.
         *
         * @param string $column Column name.
         * @param int    $order_id Order ID.
         */
        public function render_user_status_column($column, $order_id) {
            if ('x8_evs_user_status' !== $column) {
                return;
            }

            $order = wc_get_order($order_id);
            if (!$order instanceof \WC_Order) {
                return;
            }

            $status_data = $this->resolve_user_status($order);
            ?>
            <span class="x8-evs-user-status x8-evs-user-status--<?php echo esc_attr($status_data['slug']); ?>">
                <span class="x8-evs-user-status__icon dashicons <?php echo esc_attr($status_data['icon']); ?>" aria-hidden="true"></span>
                <span class="x8-evs-user-status__label"><?php echo esc_html($status_data['label']); ?></span>
            </span>
            <?php
        }

        /**
         * Enqueue admin styles for the status badge.
         *
         * @param string $hook Current admin page hook.
         */
        public function enqueue_admin_assets($hook) {
            $is_orders_page      = false;
            $is_order_edit_page  = false;

            if ('edit.php' === $hook && isset($_GET['post_type']) && 'shop_order' === $_GET['post_type']) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
                $is_orders_page = true;
            }

            if ('woocommerce_page_wc-orders' === $hook) {
                $is_orders_page = true;

                // HPOS order edit screen (admin.php?page=wc-orders&action=edit&id=...)
                if (
                    isset($_GET['action'], $_GET['id']) // phpcs:ignore WordPress.Security.NonceVerification.Recommended
                    && 'edit' === sanitize_key(wp_unslash($_GET['action'])) // phpcs:ignore WordPress.Security.NonceVerification.Recommended
                    && absint($_GET['id']) // phpcs:ignore WordPress.Security.NonceVerification.Recommended
                ) {
                    $is_order_edit_page = true;
                }
            }

            if ('post.php' === $hook && isset($_GET['post'])) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
                $post_id = absint($_GET['post']); // phpcs:ignore WordPress.Security.NonceVerification.Recommended
                if ($post_id && 'shop_order' === get_post_type($post_id)) {
                    $is_order_edit_page = true;
                }
            }

            if (!$is_orders_page && !$is_order_edit_page) {
                return;
            }

            $handle = 'x8-evs-user-status';
            wp_register_style($handle, false);
            wp_enqueue_style($handle);

            $style = '.x8-evs-user-status{display:inline-flex;align-items:center;gap:6px;padding:6px 12px;border-radius:999px;font-size:12px;text-transform:none;letter-spacing:0.25px;line-height:1;background:linear-gradient(135deg,#f8f9fb,#e9ecf4);color:#394047;border:1px solid rgba(57,64,71,0.08);box-shadow:0 1px 2px rgba(15,23,42,0.08);transition:transform 0.18s ease,box-shadow 0.18s ease;}' .
                '.x8-evs-user-status:hover{transform:translateY(-1px);box-shadow:0 4px 10px rgba(15,23,42,0.12);}' .
                '.x8-evs-user-status__icon{font-size:14px;width:14px;height:14px;line-height:14px;display:flex;align-items:center;justify-content:center;}' .
                '.x8-evs-user-status__label{display:inline-block;white-space:nowrap;}' .
                '.x8-evs-user-status--approved,.x8-evs-user-status--verified{background:linear-gradient(135deg,#d8f5e4,#a9e8c3);border-color:rgba(30,126,52,0.28);color:#155724;}' .
                '.x8-evs-user-status--blocked,.x8-evs-user-status--rejected{background:linear-gradient(135deg,#fde2dd,#fac5bf);border-color:rgba(217,48,37,0.2);color:#9b1c12;}' .
                '.x8-evs-user-status--pending,.x8-evs-user-status--needs_review,.x8-evs-user-status--under_review{background:linear-gradient(135deg,#fff0da,#ffd9a8);border-color:rgba(178,88,0,0.2);color:#8a4500;}' .
                '.x8-evs-user-status--manual_review{background:linear-gradient(135deg,#ffe8c6,#f9c888);border-color:rgba(178,88,0,0.3);color:#7a3a00;}' .
                '.x8-evs-user-status--suspended{background:linear-gradient(135deg,#efe5ff,#d5c5f2);border-color:rgba(91,47,145,0.2);color:#4c2582;}' .
                '.x8-evs-user-status--guest,.x8-evs-user-status--unknown,.x8-evs-user-status--not-set{background:linear-gradient(135deg,#f1f5f9,#e2e8f0);border-color:rgba(69,90,100,0.18);color:#334155;}';

            if ($is_order_edit_page) {
                $style .= '.x8-evs-order-admin-panel{margin-top:16px;padding:16px;background:#f8fafc;border:1px solid rgba(71,85,105,0.25);border-radius:12px;box-shadow:0 8px 16px rgba(15,23,42,0.08);}';
                $style .= '.x8-evs-order-admin-panel__section{margin-bottom:18px;}';
                $style .= '.x8-evs-order-admin-panel__section:last-child{margin-bottom:0;}';
                $style .= '.x8-evs-order-card{display:flex;flex-wrap:wrap;align-items:center;justify-content:space-between;gap:16px;padding:16px 18px;background:#ffffff;border:1px solid rgba(148,163,184,0.35);border-radius:14px;box-shadow:0 12px 20px rgba(15,23,42,0.08);position:relative;overflow:hidden;}';
                $style .= '.x8-evs-order-card::before{content:"";position:absolute;inset:0;border-radius:14px;background:radial-gradient(120% 120% at 100% 0%,rgba(79,70,229,0.08) 0%,rgba(59,130,246,0.05) 40%,rgba(148,163,184,0.03) 100%);pointer-events:none;}';
                $style .= '.x8-evs-order-card__left{position:relative;z-index:1;display:flex;flex-direction:column;gap:6px;min-width:200px;}';
                $style .= '.x8-evs-order-card__title{margin:0;font-size:16px;font-weight:700;color:#0f172a;}';
                $style .= '.x8-evs-order-card__description{margin:0;font-size:12px;color:#475569;max-width:320px;}';
                $style .= '.x8-evs-order-card__right{position:relative;z-index:1;}';
                $style .= '.x8-evs-order-card__eyebrow{font-size:11px;font-weight:700;text-transform:uppercase;letter-spacing:0.4px;color:#6366f1;background:rgba(99,102,241,0.12);display:inline-flex;align-items:center;padding:4px 10px;border-radius:999px;}';
                $style .= '.x8-evs-order-card__headline{font-size:18px;font-weight:700;color:#0f172a;display:flex;align-items:center;gap:8px;}';
                $style .= '.x8-evs-order-card__headline::before{content:"";width:32px;height:2px;border-radius:999px;background:linear-gradient(90deg,rgba(79,70,229,0.9),rgba(59,130,246,0.45));}';
                $style .= '.x8-evs-action-stack{display:flex;flex-direction:row;gap:10px;min-width:auto;flex-wrap:wrap;justify-content:flex-end;}';
                $style .= '.x8-evs-order-admin-panel__feedback{margin-top:14px;font-size:12px;font-weight:600;color:#155724;}';
                $style .= '.x8-evs-order-admin-panel__feedback.is-error{color:#b91c1c;}';
                $style .= '.x8-evs-order-admin-panel__actions .button,.x8-evs-action-stack .button{min-width:120px;}';
                $style .= '.x8-evs-order-admin-panel__actions .button[disabled],.x8-evs-action-stack .button[disabled]{opacity:0.5;cursor:not-allowed;}';
                $style .= '.x8-evs-order-admin-panel__notice{font-size:12px;color:#64748b;}';
                $style .= '.x8-evs-order-card .button-primary{background:linear-gradient(135deg,#6366f1,#4f46e5);border-color:transparent;box-shadow:0 10px 20px rgba(79,70,229,0.25);}';
                $style .= '.x8-evs-order-card .button-primary:hover{background:linear-gradient(135deg,#4f46e5,#4338ca);}';
                $style .= '.x8-evs-order-card .button-secondary{color:#1e293b;border-color:rgba(100,116,139,0.45);box-shadow:0 6px 16px rgba(15,23,42,0.12);background:linear-gradient(135deg,#f8fafc,#e2e8f0);}';
                $style .= '.x8-evs-order-card .button-secondary:hover{border-color:rgba(71,85,105,0.5);background:linear-gradient(135deg,#e2e8f0,#f8fafc);}';

                // Secondary card variant (used for location info).
                $style .= '.x8-evs-order-card--secondary{flex-direction:column;align-items:flex-start;gap:12px;box-shadow:0 10px 18px rgba(15,23,42,0.06);}';
                $style .= '.x8-evs-order-card__list{display:grid;grid-template-columns:repeat(auto-fit,minmax(180px,1fr));gap:8px 16px;width:100%;}';
                $style .= '.x8-evs-order-card__list-item{display:flex;justify-content:space-between;gap:12px;font-size:12px;color:#475569;background:rgba(241,245,249,0.6);border-radius:10px;padding:10px 12px;}';
                $style .= '.x8-evs-order-card__list-item strong{font-weight:700;color:#0f172a;}';
                $style .= '.x8-evs-order-card__link{display:inline-flex;align-items:center;gap:6px;font-size:12px;font-weight:600;color:#4f46e5;text-decoration:none;padding:6px 10px;border-radius:999px;background:rgba(99,102,241,0.1);transition:background 0.2s ease,color 0.2s ease;}';
                $style .= '.x8-evs-order-card__link:hover{color:#312e81;background:rgba(99,102,241,0.18);}';
            }

            wp_add_inline_style($handle, $style);

            if ($is_order_edit_page) {
                $script_handle = 'x8-evs-order-status-admin';
                wp_register_script($script_handle, false, array('jquery'), false, true);
                wp_enqueue_script($script_handle);
                wp_localize_script(
                    $script_handle,
                    'x8EvsOrderStatus',
                    array(
                        'ajaxUrl' => admin_url('admin-ajax.php'),
                        'nonce'   => wp_create_nonce('x8_evs_update_user_status'),
                        'i18n'    => array(
                            'genericError' => __('Unable to update user status. Please try again.', 'x8-evs'),
                        ),
                    )
                );
                wp_add_inline_script(
                    $script_handle,
                    'jQuery(function($){' .
                        'let pendingRequest = null;' .
                        '$(document).on("click", ".x8-evs-status-action", function(e){' .
                            'e.preventDefault();' .
                            'const $btn = $(this);' .
                            'const $panel = $btn.closest(".x8-evs-order-admin-panel");' .
                            'const orderId = $btn.data("orderId");' .
                            'const targetStatus = $btn.data("target");' .
                            'const $feedback = $panel.find(".x8-evs-order-admin-panel__feedback");' .
                            'if (!orderId || !targetStatus){return;}' .
                            'if (pendingRequest){pendingRequest.abort();}' .
                            '$feedback.removeClass("is-error").text("");' .
                            '$btn.prop("disabled", true);' .
                            '$panel.addClass("is-loading");' .
                            'pendingRequest = $.post(x8EvsOrderStatus.ajaxUrl, {' .
                                'action: "x8_evs_update_user_status",' .
                                'nonce: x8EvsOrderStatus.nonce,' .
                                'order_id: orderId,' .
                                'status: targetStatus' .
                            '}).done(function(response){' .
                                'pendingRequest = null;' .
                                '$panel.removeClass("is-loading");' .
                                '$btn.prop("disabled", false);' .
                                'if (response && response.success && response.data){' .
                                    'const data = response.data;' .
                                    'const $badge = $panel.find(".x8-evs-user-status");' .
                                    '$badge.attr("class","x8-evs-user-status x8-evs-user-status--"+data.slug);' .
                                    '$badge.find(".x8-evs-user-status__icon").attr("class","x8-evs-user-status__icon dashicons "+data.icon);' .
                                    '$badge.find(".x8-evs-user-status__label").text(data.label);' .
                                    'const $unblockBtn = $panel.find(".x8-evs-status-action--unblock");' .
                                    'if (data.slug === "block"){ $unblockBtn.show(); } else { $unblockBtn.hide(); }' .
                                    '$feedback.text(data.message).removeClass("is-error");' .
                                '} else {' .
                                    '$feedback.text((response && response.data && response.data.message) ? response.data.message : x8EvsOrderStatus.i18n.genericError).addClass("is-error");' .
                                '}' .
                            '}).fail(function(){' .
                                'pendingRequest = null;' .
                                '$panel.removeClass("is-loading");' .
                                '$btn.prop("disabled", false);' .
                                '$feedback.text(x8EvsOrderStatus.i18n.genericError).addClass("is-error");' .
                            '});' .
                        '});' .
                    '});'
                );
            }
        }
    }

    new X8_EVS_WooCommerce_Blocking();
}

