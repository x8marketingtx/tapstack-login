<?php
/**
 * WooCommerce Integration Class
 *
 * @package X8_EVS
 * @since 1.0.0
 */

// If this file is called directly, abort.
if (!defined('WPINC')) {
    die;
}

require_once __DIR__ . '/class-woocommerce-blocking.php';

/**
 * X8 Verify WooCommerce Integration Class
 * 
 * Handles WooCommerce-specific functionality including blocked states
 */
class X8_EVS_WooCommerce_Integration {

    /**
     * Initialize the WooCommerce integration
     */
    public function __construct() {
        error_log('X8 Verify: WooCommerce Integration constructor called');
        
        // Only initialize if WooCommerce is active
        if (!$this->is_woocommerce_active()) {
            error_log('X8 Verify: WooCommerce not active, skipping integration');
            return;
        }

        // Add Store API validation for blocks checkout
        add_filter('woocommerce_store_api_checkout_validation', array($this, 'validate_store_api_checkout'), 10, 2);
        add_filter('rest_pre_dispatch', array($this, 'register_store_api_hooks'), 10, 3);
        
        // Add hooks for order completion and geo information
        add_action('woocommerce_checkout_order_processed', array($this, 'capture_order_geo_info_backend'), 10, 3);
        add_action('woocommerce_checkout_order_processed', array($this, 'checkout_flag_verification_checks'), 20, 3);
        add_action('woocommerce_order_details_after_order_table', array($this, 'display_order_geo_info'), 10, 1);
        add_action('woocommerce_admin_order_data_after_billing_address', array($this, 'display_admin_order_geo_info'), 10, 1);
        add_action('woocommerce_admin_order_data_after_billing_address', array($this, 'display_checkout_verification_flags'), 15, 1);
        
        // Enqueue styles for geo information display
        add_action('wp_enqueue_scripts', array($this, 'enqueue_geo_info_styles'));
        add_action('admin_enqueue_scripts', array($this, 'enqueue_admin_geo_info_styles'));
        
        // Add custom column to orders list (support both traditional and HPOS)
        // Use high priority (999) to ensure we run after other plugins add columns
        add_filter('manage_edit-shop_order_columns', array($this, 'add_chargeback_package_column'), 999);
        add_action('manage_shop_order_posts_custom_column', array($this, 'render_chargeback_package_column'), 10, 2);
        
        // HPOS (High-Performance Order Storage) hooks for WooCommerce 8.0+
        add_filter('manage_woocommerce_page_wc-orders_columns', array($this, 'add_chargeback_package_column'), 999);
        add_action('manage_woocommerce_page_wc-orders_custom_column', array($this, 'render_chargeback_package_column_hpos'), 10, 2);
        
        // Additional filter to remove unwanted columns with even higher priority
        add_filter('manage_edit-shop_order_columns', array($this, 'remove_unwanted_columns'), 9999);
        add_filter('manage_woocommerce_page_wc-orders_columns', array($this, 'remove_unwanted_columns'), 9999);
        
        // Enqueue admin scripts and styles for chargeback package modal
        add_action('admin_enqueue_scripts', array($this, 'enqueue_chargeback_package_scripts'));
        
        // Note: Geo capture now happens on backend, no frontend scripts needed
        
        // Add Store API order processed hook
        // add_action('woocommerce_store_api_checkout_order_processed', array($this, 'validate_store_api_order_processed'));
        
        // // Add traditional checkout validation
        // add_action('woocommerce_checkout_process', array($this, 'validate_checkout_process'));
        
        // // Add order creation validation
        // add_action('woocommerce_checkout_create_order', array($this, 'validate_checkout_state'));
        
        // Add AJAX handlers for state validation only
        add_action('wp_ajax_x8_evs_validate_state', array($this, 'ajax_validate_state'));
        add_action('wp_ajax_nopriv_x8_evs_validate_state', array($this, 'ajax_validate_state'));
        
        error_log('X8 Verify: AJAX handlers registered successfully');
        
        // Add test AJAX handler for debugging
        add_action('wp_ajax_x8_evs_test_ajax', array($this, 'ajax_test_handler'));
        add_action('wp_ajax_nopriv_x8_evs_test_ajax', array($this, 'ajax_test_handler'));
        
        // Add AJAX handler for chargeback package customer info
        add_action('wp_ajax_x8_evs_get_customer_info', array($this, 'ajax_get_customer_info'));
        add_action('wp_ajax_x8_evs_chargeback_pdf', array($this, 'ajax_chargeback_pdf'));
        
        // // Add validation before order creation - HIGH PRIORITY to prevent order creation
        // add_action('woocommerce_checkout_create_order', array($this, 'validate_before_order_creation'), 5, 2);
        
        // // Add validation during order creation to prevent it entirely
        // add_action('woocommerce_checkout_order_created', array($this, 'validate_order_created'), 5, 1);
        
        // // Add validation to prevent order processing
        // add_action('woocommerce_checkout_order_processed', array($this, 'validate_order_processed'), 5, 3);
        
        // // Add custom error messages
        // add_filter('woocommerce_add_error', array($this, 'customize_error_message'));
        
        // // Add notice on checkout page about blocked states
        // add_action('woocommerce_before_checkout_form', array($this, 'display_blocked_states_notice'));
        
        // // Add JavaScript for real-time validation
        // add_action('wp_enqueue_scripts', array($this, 'enqueue_checkout_scripts'));
        
        // // Add filter to prevent checkout completion for blocked states
        // add_filter('woocommerce_checkout_fields', array($this, 'modify_checkout_fields'));
        
        // // Add validation to prevent order placement
        // add_filter('woocommerce_checkout_posted_data', array($this, 'validate_posted_data'), 10, 1);
    }
    

    /**
     * Check if WooCommerce is active
     */
    public function is_woocommerce_active() {
        return class_exists('WooCommerce');
    }

    public function register_store_api_hooks($result, $server, $request) {

        if ($request->get_route() === '/wc/store/v1/checkout' && $request->get_method() === 'POST') {
            $params = $request->get_params();

            // Only check if billing address blocking is enabled
            if (!class_exists('X8_EVS_Admin_Settings') || !X8_EVS_Admin_Settings::is_block_by_billing_address_enabled()) {
                return $result;
            }

            // Get blocked states from our settings
            $blocked_states = X8_EVS_Admin_Settings::get_blocked_states();

            // Check if the billing state is in blocked states
            if (!empty($params['billing_address']['state']) && in_array($params['billing_address']['state'], $blocked_states)) {
                $state_name = $this->get_state_name($params['billing_address']['state']);
                return new WP_Error(
                    'billing_state_blocked',
                    sprintf(__('Your state %s is blocked.', 'x8-evs'), $state_name),
                    ['status' => 400]
                );
            }
        }
        return $result;
    }

    /**
     * Validate Store API checkout (for blocks checkout)
     */
    public function validate_store_api_checkout($validation_results, $request) {
        error_log('X8 Verify: validate_store_api_checkout called');
        
        // Only check if billing address blocking is enabled
        if (!class_exists('X8_EVS_Admin_Settings') || !X8_EVS_Admin_Settings::is_block_by_billing_address_enabled()) {
            return $validation_results;
        }
        
        $billing_state = $request['billing_address']['state'] ?? '';
        
        // Validate billing state only
        if (!empty($billing_state) && $this->is_state_blocked($billing_state)) {
            $state_name = $this->get_state_name($billing_state);
            $error_message = sprintf(
                __('Your state %s is blocked.', 'x8-evs'),
                $state_name
            );
            $validation_results->add_error($error_message);
        }
        
        return $validation_results;
    }
    
    /**
     * Validate Store API order processed (for blocks checkout)
     */
    public function validate_store_api_order_processed($order) {
        error_log('X8 Verify: validate_store_api_order_processed called');
        
        $billing_state = $order->get_billing_state();
        
        error_log('X8 Verify: Order processed - Billing: ' . $billing_state);
        
        $this->validate_billing_state_only($billing_state);
    }
    
    /**
     * Validate checkout state during checkout process
     */
    public function validate_checkout_state() {
        // Get billing state from multiple sources
        $billing_state = $this->get_billing_state();
        
        $this->validate_billing_state_only($billing_state);
    }
    
    /**
     * Validate checkout create order line item
     */
    public function validate_checkout_create_order_line_item($item, $cart_item_key, $values) {
        error_log('X8 Verify: validate_checkout_create_order_line_item called');
        
        // Get billing state from the order being created
        $order = $item->get_order();
        if ($order) {
            $billing_state = $order->get_billing_state();
            
            error_log('X8 Verify: Line item - Billing: ' . $billing_state);
            
            $this->validate_billing_state_only($billing_state);
        }
    }
    
    /**
     * Validate checkout create order
     */
    public function validate_checkout_create_order($order, $data) {
        error_log('X8 Verify: validate_checkout_create_order called');
        
        $billing_state = $data['billing_state'] ?? '';
        
        error_log('X8 Verify: Create order - Billing: ' . $billing_state);
        
        $this->validate_billing_state_only($billing_state);
    }
    
    /**
     * Test method to verify checkout process is firing
     */
    public function test_checkout_process() {
        error_log('X8 Verify: test_checkout_process called - checkout process is working!');
    }
    
    /**
     * Initialize WooCommerce Blocks checkout
     */
    public function init_blocks_checkout() {
        // Blocks checkout is ready, validation will be handled via JavaScript
    }
    
    /**
     * Initialize traditional WooCommerce checkout
     */
    public function init_traditional_checkout() {
        // Traditional checkout is ready, validation will be handled via PHP hooks
    }
    

    
    /**
     * Validate checkout process for traditional checkout
     */
    public function validate_checkout_process() {
        // Only check if billing address blocking is enabled
        if (!class_exists('X8_EVS_Admin_Settings') || !X8_EVS_Admin_Settings::is_block_by_billing_address_enabled()) {
            return;
        }
        
        $billing_state = $_POST['billing_state'] ?? '';
        
        $this->validate_billing_state_only($billing_state);
    }
    
    /**
     * Add custom validation to checkout fields
     */
    public function add_custom_validation($fields) {
        error_log('X8 Verify: add_custom_validation called');
        
        // Add custom validation to billing state field
        if (isset($fields['billing']['billing_state'])) {
            $fields['billing']['billing_state']['validate'][] = 'x8_evs_state_validation';
        }
        

        
        return $fields;
    }
    
    /**
     * Validate state field
     */
    public function validate_state_field($valid, $value) {
        error_log('X8 Verify: validate_state_field called with value: ' . $value);
        
        if (!$valid) {
            return $valid;
        }
        
        // Only check if billing address blocking is enabled
        if (!class_exists('X8_EVS_Admin_Settings') || !X8_EVS_Admin_Settings::is_block_by_billing_address_enabled()) {
            return $valid;
        }
        
        // Check if the state is blocked
        if ($this->is_state_blocked($value)) {
            $state_name = $this->get_state_name($value);
            $error_message = sprintf(
                __('Your state %s is blocked.', 'x8-evs'),
                $state_name
            );
            
            error_log('X8 Verify: State validation failed: ' . $error_message);
            
            wc_add_notice($error_message, 'error');
            return false;
        }
        
        return $valid;
    }
    
    /**
     * Register REST API routes for blocks checkout
     */
    public function register_rest_routes() {
        register_rest_route('x8-evs/v1', '/validate-states', array(
            'methods' => 'POST',
            'callback' => array($this, 'validate_states_rest'),
            'permission_callback' => '__return_true'
        ));
    }
    
    /**
     * REST API callback for state validation
     */
    public function validate_states_rest($request) {
        $params = $request->get_params();
        $billing_state = $params['billing_state'] ?? '';
        
        $result = $this->validate_states_rest_logic($billing_state);
        
        return rest_ensure_response($result);
    }
    
    /**
     * Logic for REST API state validation
     */
    private function validate_states_rest_logic($billing_state) {
        $has_error = false;
        $error_messages = array();

        error_log('X8 Verify: validate_states_rest_logic called with billing state: ' . $billing_state);
        
        // Only check if billing address blocking is enabled
        if (!class_exists('X8_EVS_Admin_Settings') || !X8_EVS_Admin_Settings::is_block_by_billing_address_enabled()) {
            return array('valid' => true, 'message' => 'Billing address blocking not enabled');
        }
        
        // Validate billing state only
        if (!empty($billing_state)) {
            $is_billing_blocked = $this->is_state_blocked($billing_state);
            if ($is_billing_blocked) {
                $state_name = $this->get_state_name($billing_state);
                $error_messages[] = sprintf(
                    __('Your state %s is blocked.', 'x8-evs'),
                    $state_name
                );
                $has_error = true;
            }
        }
        
        if ($has_error) {
            return array(
                'valid' => false,
                'message' => implode(' ', $error_messages)
            );
        }
        
        return array('valid' => true, 'message' => 'Billing state is valid');
    }
    

    

    
    /**
     * Core method to validate billing state only and block order if needed
     */
    private function validate_billing_state_only($billing_state) {
        $has_error = false;
        $error_messages = array();

        error_log('X8 Verify: validate_billing_state_only called with billing state: ' . $billing_state);
        
        // Only check if billing address blocking is enabled
        if (!class_exists('X8_EVS_Admin_Settings') || !X8_EVS_Admin_Settings::is_block_by_billing_address_enabled()) {
            return;
        }
        
        // Validate billing state only
        if (!empty($billing_state)) {
            $is_billing_blocked = $this->is_state_blocked($billing_state);
            
            if ($is_billing_blocked) {
                $state_name = $this->get_state_name($billing_state);
                $error_messages[] = sprintf(
                    __('Your state %s is blocked.', 'x8-evs'),
                    $state_name
                );
                $has_error = true;
            }
        }
        
        // Block order if billing state is blocked
        if ($has_error) {
            $final_error_message = __('Sorry, we cannot process your order. ', 'x8-evs') . implode(' ', $error_messages);
            wc_add_notice($final_error_message, 'error');
            
            // Throw exception to prevent order creation
            throw new Exception($final_error_message);
        }
    }

    /**
     * Validate checkout state after order creation
     */
    public function validate_checkout_state_created($order_id) {
        error_log('X8 Verify: validate_checkout_state_created called for order: ' . $order_id);
        
        $order = wc_get_order($order_id);
        if (!$order) {
            return;
        }
        
        $billing_state = $order->get_billing_state();
        
        error_log('X8 Verify: Order created - Billing: ' . $billing_state);
        
        $this->validate_billing_state_only($billing_state);
    }
    
    /**
     * Validate checkout state after order processing
     */
    public function validate_checkout_state_processed($order_id, $posted_data, $order) {
        error_log('X8 Verify: validate_checkout_state_processed called for order: ' . $order_id);
        
        $billing_state = $order->get_billing_state();
        
        error_log('X8 Verify: Order processed - Billing: ' . $billing_state);
        
        $this->validate_billing_state_only($billing_state);
    }
    
    /**
     * Validate checkout state after WooCommerce validation
     */
    public function validate_checkout_state_after($data) {
        error_log('X8 Verify: validate_checkout_state_after called');
        
        $billing_state = $data['billing_state'] ?? '';
        
        error_log('X8 Verify: After validation - Billing: ' . $billing_state);
        
        $this->validate_billing_state_only($billing_state);
    }
    
    /**
     * Validate checkout update order meta
     */
    public function validate_checkout_update_order_meta($order_id) {
        error_log('X8 Verify: validate_checkout_update_order_meta called for order: ' . $order_id);
        
        $order = wc_get_order($order_id);
        if (!$order) {
            return;
        }
        
        $billing_state = $order->get_billing_state();
        
        error_log('X8 Verify: Validate checkout update order meta - Billing: ' . $billing_state);
        
        $this->validate_billing_state_only($billing_state);
    }
    
    /**
     * Validate blocks checkout data
     */
    public function validate_blocks_checkout_data($posted_data) {
        error_log('X8 Verify: validate_blocks_checkout_data called');
        
        // Only check if billing address blocking is enabled
        if (!class_exists('X8_EVS_Admin_Settings') || !X8_EVS_Admin_Settings::is_block_by_billing_address_enabled()) {
            return $posted_data;
        }
        
        $billing_state = $posted_data['billing_state'] ?? '';
        
        error_log('X8 Verify: Blocks checkout data - Billing: ' . $billing_state);
        
        // Validate billing state and block order if needed
        try {
            $this->validate_billing_state_only($billing_state);
        } catch (Exception $e) {
            error_log('X8 Verify: Validation failed: ' . $e->getMessage());
            // Return false to prevent order creation
            return false;
        }
        
        return $posted_data;
    }

    /**
     * Validate before order creation
     */
    public function validate_before_order_creation($order, $data) {
        // Only check if billing address blocking is enabled
        if (!class_exists('X8_EVS_Admin_Settings') || !X8_EVS_Admin_Settings::is_block_by_billing_address_enabled()) {
            return;
        }
        
        $billing_state = $data['billing_state'] ?? '';
        
        error_log('X8 Verify: Validating before order creation - Billing: ' . $billing_state);
        
        $has_error = false;
        $error_messages = array();
        
        // Validate billing state only
        if (!empty($billing_state)) {
            if ($this->is_state_blocked($billing_state)) {
                $state_name = $this->get_state_name($billing_state);
                $error_messages[] = sprintf(
                    __('Your state %s is blocked.', 'x8-evs'),
                    $state_name
                );
                $has_error = true;
            }
        }
        
        // Throw exception if any states are blocked
        if ($has_error) {
            $final_error_message = __('Order cannot be created. ', 'x8-evs') . implode(' ', $error_messages);
            error_log('X8 Verify: Throwing exception: ' . $final_error_message);
            throw new Exception($final_error_message);
        }
    }

    /**
     * Validate after order creation
     */
    public function validate_order_created($order_id) {
        // Only check if billing address blocking is enabled
        if (!class_exists('X8_EVS_Admin_Settings') || !X8_EVS_Admin_Settings::is_block_by_billing_address_enabled()) {
            return;
        }
        
        $order = wc_get_order($order_id);
        if (!$order) {
            return;
        }

        error_log('X8 Verify: validate_order_created called for order: ' . $order_id);

        $billing_state = $order->get_billing_state();
        
        $has_error = false;
        $error_messages = array();
        
        // Validate billing state only
        if (!empty($billing_state)) {
            if ($this->is_state_blocked($billing_state)) {
                $state_name = $this->get_state_name($billing_state);
                $error_messages[] = sprintf(
                    __('Your state %s is blocked.', 'x8-evs'),
                    $state_name
                );
                $has_error = true;
            }
        }
        
        if ($has_error) {
            $final_error_message = __('Order cannot be processed. ', 'x8-evs') . implode(' ', $error_messages);
            $order->add_order_note($final_error_message);
            $order->update_status('failed', $final_error_message);
            throw new Exception($final_error_message);
        }
    }

    /**
     * Validate after order processing
     */
    public function validate_order_processed($order_id, $posted_data, $order) {
        // Only check if billing address blocking is enabled
        if (!class_exists('X8_EVS_Admin_Settings') || !X8_EVS_Admin_Settings::is_block_by_billing_address_enabled()) {
            return;
        }
        
        $billing_state = $order->get_billing_state();

        error_log('X8 Verify: validate_order_processed called for order: ' . $order_id);
        
        $has_error = false;
        $error_messages = array();
        
        // Validate billing state only
        if (!empty($billing_state)) {
            if ($this->is_state_blocked($billing_state)) {
                $state_name = $this->get_state_name($billing_state);
                $error_messages[] = sprintf(
                    __('Your state %s is blocked.', 'x8-evs'),
                    $state_name
                );
                $has_error = true;
            }
        }
        
        if ($has_error) {
            $final_error_message = __('Order cannot be processed. ', 'x8-evs') . implode(' ', $error_messages);
            $order->add_order_note($final_error_message);
            $order->update_status('failed', $final_error_message);
            throw new Exception($final_error_message);
        }
    }

    /**
     * Validate posted data to prevent order placement
     */
    public function validate_posted_data($posted_data) {
        // Only check if billing address blocking is enabled
        if (!class_exists('X8_EVS_Admin_Settings') || !X8_EVS_Admin_Settings::is_block_by_billing_address_enabled()) {
            return $posted_data;
        }
        
        $billing_state = $posted_data['billing_state'] ?? '';

        if (empty($billing_state)) {
            return $posted_data;
        }

        $is_billing_blocked = $this->is_state_blocked($billing_state);

        if ($is_billing_blocked) {
            $error_message = __('Your state is blocked. Please select a different state.', 'x8-evs');
            wc_add_notice($error_message, 'error');
            return false; // Prevent order placement
        }

        return $posted_data;
    }

    /**
     * Get billing state from multiple sources
     */
    private function get_billing_state() {
        // Try POST data first
        if (isset($_POST['billing_state'])) {
            $state = sanitize_text_field($_POST['billing_state']);
            error_log('X8 Verify: Got billing state from POST: ' . $state);
            return $state;
        }
        
        // Try from WooCommerce checkout data
        if (function_exists('WC') && WC()->checkout()) {
            $checkout_data = WC()->checkout()->get_posted_data();
            if (isset($checkout_data['billing_state'])) {
                $state = sanitize_text_field($checkout_data['billing_state']);
                error_log('X8 Verify: Got billing state from checkout data: ' . $state);
                return $state;
            }
        }
        
        // Try from customer data
        if (function_exists('WC') && WC()->customer) {
            $state = WC()->customer->get_billing_state();
            error_log('X8 Verify: Got billing state from customer: ' . $state);
            return $state;
        }
        
        error_log('X8 Verify: No billing state found in any source');
        return '';
    }

    /**
     * Get shipping state from multiple sources
     */
    private function get_shipping_state() {
        // Try POST data first
        if (isset($_POST['shipping_state'])) {
            $state = sanitize_text_field($_POST['shipping_state']);
            error_log('X8 Verify: Got shipping state from POST: ' . $state);
            return $state;
        }
        
        // Try from WooCommerce checkout data
        if (function_exists('WC') && WC()->checkout()) {
            $checkout_data = WC()->checkout()->get_posted_data();
            if (isset($checkout_data['shipping_state'])) {
                $state = sanitize_text_field($checkout_data['shipping_state']);
                error_log('X8 Verify: Got shipping state from checkout data: ' . $state);
                return $state;
            }
        }
        
        // Try from customer data
        if (function_exists('WC') && WC()->customer) {
            $state = WC()->customer->get_shipping_state();
            error_log('X8 Verify: Got shipping state from customer: ' . $state);
            return $state;
        }
        
        error_log('X8 Verify: No shipping state found in any source');
        return '';
    }

    /**
     * Check if a state is blocked
     */
    private function is_state_blocked($state_code) {
        if (!class_exists('X8_EVS_Admin_Settings')) {
            error_log('X8 Verify: Admin_Settings class not found');
            return false;
        }
        
        $blocked_states = X8_EVS_Admin_Settings::get_blocked_states();
        error_log('X8 Verify: Blocked states configured: ' . implode(', ', $blocked_states));
        
        $is_blocked = X8_EVS_Admin_Settings::is_state_blocked($state_code);
        error_log('X8 Verify: Checking if ' . $state_code . ' is blocked: ' . ($is_blocked ? 'YES' : 'NO'));
        
        return $is_blocked;
    }

    /**
     * Get state name from state code
     */
    private function get_state_name($state_code) {
        $states = array(
            'AL' => 'Alabama', 'AK' => 'Alaska', 'AZ' => 'Arizona', 'AR' => 'Arkansas', 'CA' => 'California',
            'CO' => 'Colorado', 'CT' => 'Connecticut', 'DE' => 'Delaware', 'FL' => 'Florida', 'GA' => 'Georgia',
            'HI' => 'Hawaii', 'ID' => 'Idaho', 'IL' => 'Illinois', 'IN' => 'Indiana', 'IA' => 'Iowa',
            'KS' => 'Kansas', 'KY' => 'Kentucky', 'LA' => 'Louisiana', 'ME' => 'Maine', 'MD' => 'Maryland',
            'MA' => 'Massachusetts', 'MI' => 'Michigan', 'MN' => 'Minnesota', 'MS' => 'Mississippi', 'MO' => 'Missouri',
            'MT' => 'Montana', 'NE' => 'Nebraska', 'NV' => 'Nevada', 'NH' => 'New Hampshire', 'NJ' => 'New Jersey',
            'NM' => 'New Mexico', 'NY' => 'New York', 'NC' => 'North Carolina', 'ND' => 'North Dakota', 'OH' => 'Ohio',
            'OK' => 'Oklahoma', 'OR' => 'Oregon', 'PA' => 'Pennsylvania', 'RI' => 'Rhode Island', 'SC' => 'South Carolina',
            'SD' => 'South Dakota', 'TN' => 'Tennessee', 'TX' => 'Texas', 'UT' => 'Utah', 'VT' => 'Vermont',
            'VA' => 'Virginia', 'WA' => 'Washington', 'WV' => 'West Virginia', 'WI' => 'Wisconsin', 'WY' => 'Wyoming',
            'DC' => 'District of Columbia'
        );
        
        $state_code = strtoupper($state_code);
        return $states[$state_code] ?? $state_code;
    }

    /**
     * Customize error message for blocked states
     */
    public function customize_error_message($message) {
        // Check if this is a blocked state error
        if (strpos($message, 'billing_state') !== false && strpos($message, 'required') !== false) {
            return __('Please select a valid state for billing address.', 'x8-evs');
        }
        
        return $message;
    }

    /**
     * Display notice about blocked states on checkout page
     */
    public function display_blocked_states_notice() {
        if (!class_exists('X8_EVS_Admin_Settings')) {
            return;
        }
        
        // Only show notice if billing address blocking is enabled
        if (!X8_EVS_Admin_Settings::is_block_by_billing_address_enabled()) {
            return;
        }
        
        $blocked_states = X8_EVS_Admin_Settings::get_blocked_states();
        
        if (empty($blocked_states)) {
            return;
        }
        
        // Get blocked state names
        $blocked_state_names = array();
        foreach ($blocked_states as $state_code) {
            $blocked_state_names[] = $this->get_state_name($state_code);
        }
        
        $notice_message = sprintf(
            __('<strong>State Restrictions:</strong> The following states are blocked: %s', 'x8-evs'),
            implode(', ', $blocked_state_names)
        );
        
        echo '<div class="woocommerce-info x8-evs-blocked-states-notice" style="background-color: #fff3cd; border-color: #ffeaa7; color: #856404;">';
        echo '<p>' . $notice_message . '</p>';
        echo '</div>';
    }

    /**
     * Modify checkout fields to add validation
     */
    public function modify_checkout_fields($fields) {
        if (!class_exists('X8_EVS_Admin_Settings')) {
            return $fields;
        }
        
        // Only modify fields if billing address blocking is enabled
        if (!X8_EVS_Admin_Settings::is_block_by_billing_address_enabled()) {
            return $fields;
        }
        
        $blocked_states = X8_EVS_Admin_Settings::get_blocked_states();
        
        if (!empty($blocked_states)) {
            // Add custom validation class to billing state field
            if (isset($fields['billing']['billing_state'])) {
                $fields['billing']['billing_state']['class'][] = 'x8-evs-state-validation';
                $fields['billing']['billing_state']['custom_attributes']['data-blocked-states'] = json_encode($blocked_states);
            }
            
        }
        
        return $fields;
    }

    /**
     * Enqueue scripts for checkout validation
     */
    public function enqueue_checkout_scripts() {
        if (!is_checkout()) {
            return;
        }
        
        // Only enqueue scripts if billing address blocking is enabled
        if (!class_exists('X8_EVS_Admin_Settings') || !X8_EVS_Admin_Settings::is_block_by_billing_address_enabled()) {
            return;
        }
        
        wp_enqueue_script(
            'x8-evs-checkout',
            plugin_dir_url(dirname(dirname(__FILE__))) . 'assets/js/x8-evs-checkout.js',
            array('jquery'),
            X8_EVS_VERSION ?? '1.0.0',
            true
        );
        
        // Localize script with blocked states data
        $blocked_states = X8_EVS_Admin_Settings::get_blocked_states();
        
        wp_localize_script('x8-evs-checkout', 'x8_evs_checkout', array(
            'blocked_states' => $blocked_states,
            'error_message' => __('Your state is blocked. Please select a different state.', 'x8-evs'),
            'ajax_url' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('x8_evs_checkout_nonce')
        ));
    }


    /**
     * Enqueue styles for geo information display
     */
    public function enqueue_geo_info_styles() {
        wp_enqueue_style(
            'x8-evs-geo-info',
            plugin_dir_url(dirname(dirname(__FILE__))) . 'assets/css/x8-evs.css',
            array(),
            X8_EVS_VERSION ?? '1.0.0'
        );
    }

    /**
     * Enqueue styles for admin geo information display
     */
    public function enqueue_admin_geo_info_styles() {
        wp_enqueue_style(
            'x8-evs-admin-geo-info',
            plugin_dir_url(dirname(dirname(__FILE__))) . 'assets/css/x8-evs.css',
            array(),
            X8_EVS_VERSION ?? '1.0.0'
        );
    }

    /**
     * Get blocked states for display
     */
    public static function get_blocked_states_display() {
        if (!class_exists('X8_EVS_Admin_Settings')) {
            return array();
        }
        
        $blocked_states = X8_EVS_Admin_Settings::get_blocked_states();
        $display_states = array();
        
        foreach ($blocked_states as $state_code) {
            $display_states[] = array(
                'code' => $state_code,
                'name' => self::get_state_name_static($state_code)
            );
        }
        
        return $display_states;
    }

    /**
     * Static method to get state name
     */
    public static function get_state_name_static($state_code) {
        $states = array(
            'AL' => 'Alabama', 'AK' => 'Alaska', 'AZ' => 'Arizona', 'AR' => 'Arkansas', 'CA' => 'California',
            'CO' => 'Colorado', 'CT' => 'Connecticut', 'DE' => 'Delaware', 'FL' => 'Florida', 'GA' => 'Georgia',
            'HI' => 'Hawaii', 'ID' => 'Idaho', 'IL' => 'Illinois', 'IN' => 'Indiana', 'IA' => 'Iowa',
            'KS' => 'Kansas', 'KY' => 'Kentucky', 'LA' => 'Louisiana', 'ME' => 'Maine', 'MD' => 'Maryland',
            'MA' => 'Massachusetts', 'MI' => 'Michigan', 'MN' => 'Minnesota', 'MS' => 'Mississippi', 'MO' => 'Missouri',
            'MT' => 'Montana', 'NE' => 'Nebraska', 'NV' => 'Nevada', 'NH' => 'New Hampshire', 'NJ' => 'New Jersey',
            'NM' => 'New Mexico', 'NY' => 'New York', 'NC' => 'North Carolina', 'ND' => 'North Dakota', 'OH' => 'Ohio',
            'OK' => 'Oklahoma', 'OR' => 'Oregon', 'PA' => 'Pennsylvania', 'RI' => 'Rhode Island', 'SC' => 'South Carolina',
            'SD' => 'South Dakota', 'TN' => 'Tennessee', 'TX' => 'Texas', 'UT' => 'Utah', 'VT' => 'Vermont',
            'VA' => 'Virginia', 'WA' => 'Washington', 'WV' => 'West Virginia', 'WI' => 'Wisconsin', 'WY' => 'Wyoming',
            'DC' => 'District of Columbia'
        );
        
        $state_code = strtoupper($state_code);
        return $states[$state_code] ?? $state_code;
    }





    /**
     * Get blocked states notice text
     */
    public static function get_blocked_states_notice_text() {
        if (!class_exists('X8_EVS_Admin_Settings')) {
            return '';
        }
        
        $blocked_states = X8_EVS_Admin_Settings::get_blocked_states();
        
        if (empty($blocked_states)) {
            return '';
        }
        
        $blocked_state_names = array();
        foreach ($blocked_states as $state_code) {
            $blocked_state_names[] = self::get_state_name_static($state_code);
        }
        
        return sprintf(
            __('Blocked states: %s', 'x8-evs'),
            implode(', ', $blocked_state_names)
        );
    }

    /**
     * AJAX handler for state validation
     */
    public function ajax_validate_state() {

        error_log('X8 Verify: ajax_validate_state called');

        // Verify nonce
        if (!wp_verify_nonce($_POST['nonce'] ?? '', 'x8_evs_checkout_nonce')) {
            wp_die(__('Security check failed', 'x8-evs'));
        }
        
        // Only check if billing address blocking is enabled
        if (!class_exists('X8_EVS_Admin_Settings') || !X8_EVS_Admin_Settings::is_block_by_billing_address_enabled()) {
            wp_send_json_success(__('Billing address blocking not enabled', 'x8-evs'));
        }
        
        // Get billing state from request
        $billing_state = sanitize_text_field($_POST['billing_state'] ?? '');
        
        if (empty($billing_state)) {
            wp_send_json_error(__('No billing state provided', 'x8-evs'));
        }
        
        $has_error = false;
        $error_messages = array();
        
        // Check billing state only
        $is_billing_blocked = $this->is_state_blocked($billing_state);
        if ($is_billing_blocked) {
            $state_name = $this->get_state_name($billing_state);
                            $error_messages[] = sprintf(
                    __('Your state %s is blocked.', 'x8-evs'),
                    $state_name
                );
            $has_error = true;
        }
        
        if ($has_error) {
            $final_error_message = __('Your state is blocked. ', 'x8-evs') . implode(' ', $error_messages);
            wp_send_json_error($final_error_message);
        } else {
            wp_send_json_success(__('Billing state is valid', 'x8-evs'));
        }
    }
    

    /**
     * Test AJAX handler for debugging
     */
    public function ajax_test_handler() {
        error_log('X8 Verify: Test AJAX handler called');
        wp_send_json_success(array(
            'message' => 'AJAX handler is working',
            'timestamp' => current_time('mysql'),
            'user_id' => get_current_user_id()
        ));
    }

    /**
     * Get chargeback package data for an order (shared by modal AJAX and PDF download).
     *
     * @param \WC_Order $order
     * @return array|null Data array or null on failure
     */
    public function get_chargeback_data($order) {
        if (!$order || !$order instanceof \WC_Order) {
            return null;
        }
        $customer_id = $order->get_customer_id();
        if (!$customer_id) {
            return null;
        }
        $user = get_userdata($customer_id);
        if (!$user) {
            return null;
        }
        $order_id = $order->get_id();

        // Get customer meta data
        $phone = get_user_meta($customer_id, 'phone', true) ?: get_user_meta($customer_id, 'billing_phone', true);
        $document_type = get_user_meta($customer_id, 'document_type', true);
        $document_number = get_user_meta($customer_id, 'document_number', true);
        
        // Get document images
        $document_front_image = get_user_meta($customer_id, 'document_front_image', true);
        $document_back_image = get_user_meta($customer_id, 'document_back_image', true);
        $document_portrait_image = get_user_meta($customer_id, 'document_portrait_image', true);
        
        // Convert file paths to URLs
        $document_front_image_url = '';
        $document_back_image_url = '';
        $document_portrait_image_url = '';
        
        if ($document_front_image && file_exists($document_front_image)) {
            $document_front_image_url = str_replace(ABSPATH, site_url('/'), $document_front_image);
        }
        
        if ($document_back_image && file_exists($document_back_image)) {
            $document_back_image_url = str_replace(ABSPATH, site_url('/'), $document_back_image);
        }
        
        if ($document_portrait_image && file_exists($document_portrait_image)) {
            $document_portrait_image_url = str_replace(ABSPATH, site_url('/'), $document_portrait_image);
        }
        
        // Get verification webhook data for additional info
        $verification_data = get_user_meta($customer_id, 'verification_webhook_data', true);
        $verification_data = $verification_data ? json_decode($verification_data, true) : null;
        
        // Extract additional info from verification data
        $gender = '';
        $date_of_birth = '';
        $full_name = '';
        $address = '';
        $city = '';
        $state = '';
        $zip = '';
        $country = '';
        $document_issue_date = '';
        $document_expiry_date = '';
        $calculated_age = '';
        $verification_status = '';
        $verification_date = '';
        $transaction_id = '';
        $transaction_date = '';
        
        // Document analysis data
        $total_confidence = 0;
        $face_verification_confidence = 0;
        $selfie_authenticity_confidence = 0;
        $validation_result_code = '';
        $validation_result_description = '';
        $decision_confidence_text = '';
        $threshold_info_text = '';
        
        // Get order information
        $order_date = $order->get_date_created() ? $order->get_date_created()->date('Y-m-d H:i:s') : '';
        $order_total = $order->get_total();
        $order_status = $order->get_status();
        $billing_address = $order->get_billing_address_1();
        $billing_city = $order->get_billing_city();
        $billing_state = $order->get_billing_state();
        $billing_postcode = $order->get_billing_postcode();
        $billing_country = $order->get_billing_country();
        
        if ($verification_data) {
            // Get transaction info
            if (isset($verification_data['meta'])) {
                $transaction_id = $verification_data['meta']['transactionId'] ?? '';
                $transaction_date = $verification_data['meta']['transactionDate'] ?? '';
            }
            
            // Try to get from assureCard
            if (isset($verification_data['data']['assureCard'])) {
                $assureCard = $verification_data['data']['assureCard'];
                
                // Extract document analysis data
                $total_confidence = $assureCard['totalConfidence'] ?? 0;
                $face_verification_confidence = $assureCard['faceVerificationConfidence'] ?? 0;
                $selfie_authenticity_confidence = $assureCard['selfieIsRealConfidence'] ?? 0;
                
                if (isset($assureCard['validationResult'])) {
                    $validation_result_code = $assureCard['validationResult']['code'] ?? '';
                    $validation_result_description = $assureCard['validationResult']['description'] ?? '';
                }
                
                if (isset($assureCard['individualCharacteristics'])) {
                    $characteristics = $assureCard['individualCharacteristics'];
                    $gender = $characteristics['gender'] ?? '';
                    $date_of_birth = $characteristics['dateOfBirth'] ?? '';
                    $calculated_age = $characteristics['calculatedAge'] ?? '';
                    $full_name = $characteristics['fullName'] ?? '';
                }
                
                if (isset($assureCard['documentInformation'])) {
                    $docInfo = $assureCard['documentInformation'];
                    $document_issue_date = $docInfo['issueDate'] ?? '';
                    $document_expiry_date = $docInfo['expirationDate'] ?? '';
                }
                
                if (isset($assureCard['documentAddress'])) {
                    $docAddress = $assureCard['documentAddress'];
                    $address = $docAddress['addressLine1'] ?? '';
                    $city = $docAddress['city'] ?? '';
                    $state = $docAddress['state'] ?? '';
                    $zip = $docAddress['zip'] ?? '';
                    $country = $docAddress['country'] ?? '';
                }
                
                if (isset($assureCard['primaryResult']['code'])) {
                    $verification_status = $assureCard['primaryResult']['code'];
                }
            }
            
            // Try to get from assureId
            if (isset($verification_data['data']['assureId'])) {
                $assureId = $verification_data['data']['assureId'];
                
                if (empty($gender) && isset($assureId['individualCharacteristics'])) {
                    $characteristics = $assureId['individualCharacteristics'];
                    $gender = $characteristics['gender'] ?? $gender;
                    $date_of_birth = $characteristics['dateOfBirth'] ?? $date_of_birth;
                    $calculated_age = $characteristics['calculatedAge'] ?? $calculated_age;
                    $full_name = $characteristics['fullName'] ?? $full_name;
                }
                
                if (isset($assureId['standardizedAddress'])) {
                    $stdAddress = $assureId['standardizedAddress'];
                    $address = $stdAddress['addressLine1'] ?? $address;
                    $city = $stdAddress['city'] ?? $city;
                    $state = $stdAddress['state'] ?? $state;
                    $zip = $stdAddress['zip'] ?? $zip;
                    $country = $stdAddress['country'] ?? $country;
                }
                
                if (empty($verification_status) && isset($assureId['primaryResult']['code'])) {
                    $verification_status = $assureId['primaryResult']['code'];
                }
            }
        }
        
        // Fallback for full name: prefer first+last, then verified document name, then display name, then username
        if (empty($full_name)) {
            $full_name = trim($user->first_name . ' ' . $user->last_name);
        }
        if (empty($full_name)) {
            $full_name = get_user_meta($customer_id, 'document_full_name', true);
        }
        if (empty($full_name)) {
            $full_name = $user->display_name ?: $user->user_login;
        }
        
        // Build decision and threshold information
        if (class_exists('X8_EVS_Admin_Settings')) {
            $use_selfie_thresholds = X8_EVS_Admin_Settings::is_selfie_required();
            
            if ($use_selfie_thresholds && $face_verification_confidence > 0) {
                $decision_confidence_text = sprintf(
                    __('Decision based on Face Verification Confidence (%d%%)', 'x8-evs'),
                    $face_verification_confidence
                );
                $block_threshold = X8_EVS_Admin_Settings::get_selfie_auto_block_threshold();
                $review_threshold = X8_EVS_Admin_Settings::get_selfie_manual_review_threshold();
                $approve_threshold = X8_EVS_Admin_Settings::get_selfie_auto_approve_threshold();
                $threshold_info_text = sprintf(
                    __('Using Selfie Thresholds: Block 0-%d | Review %d-%d | Approve %d-100', 'x8-evs'),
                    $block_threshold,
                    $block_threshold + 1,
                    $review_threshold,
                    $approve_threshold
                );
            } elseif ($total_confidence > 0) {
                $decision_confidence_text = sprintf(
                    __('Decision based on Total Confidence (%d%%)', 'x8-evs'),
                    $total_confidence
                );
                $block_threshold = X8_EVS_Admin_Settings::get_auto_block_threshold(false);
                $review_threshold = X8_EVS_Admin_Settings::get_manual_review_threshold(false);
                $approve_threshold = X8_EVS_Admin_Settings::get_auto_approve_threshold(false);
                $threshold_info_text = sprintf(
                    __('Using Standard Thresholds: Block 0-%d | Review %d-%d | Approve %d-100', 'x8-evs'),
                    $block_threshold,
                    $block_threshold + 1,
                    $review_threshold,
                    $approve_threshold
                );
            }
        }
        
        // Get verification date
        $verification_date = get_user_meta($customer_id, 'verification_date', true);
        $account_status = get_user_meta($customer_id, 'account_status', true);
        
        // Get activity log
        $activity_log = get_user_meta($customer_id, 'x8_evs_activity_log', true);
        if (!is_array($activity_log)) {
            $activity_log = array();
        }
        
        // Sort activity log by timestamp descending (newest first)
        usort($activity_log, function($a, $b) {
            $timestamp_a = isset($a['unix_timestamp']) ? $a['unix_timestamp'] : (isset($a['timestamp']) ? strtotime($a['timestamp']) : 0);
            $timestamp_b = isset($b['unix_timestamp']) ? $b['unix_timestamp'] : (isset($b['timestamp']) ? strtotime($b['timestamp']) : 0);
            return $timestamp_b - $timestamp_a;
        });
        
        // Get all orders for this customer
        $customer_orders = wc_get_orders(array(
            'customer_id' => $customer_id,
            'limit' => -1,
            'orderby' => 'date',
            'order' => 'DESC',
        ));
        
        $orders_data = array();
        foreach ($customer_orders as $customer_order) {
            $order_id = $customer_order->get_id();
            
            // Construct order edit URL - check if HPOS is enabled
            $order_url = '';
            // Try HPOS URL first (WooCommerce 8.0+)
            if (class_exists('\Automattic\WooCommerce\Internal\DataStores\Orders\CustomOrdersTableController')) {
                try {
                    $hpos_enabled = wc_get_container()->get(\Automattic\WooCommerce\Internal\DataStores\Orders\CustomOrdersTableController::class)->custom_orders_table_usage_is_enabled();
                    if ($hpos_enabled) {
                        $order_url = admin_url('admin.php?page=wc-orders&id=' . $order_id . '&action=edit');
                    }
                } catch (Exception $e) {
                    // Fallback to traditional
                }
            }
            // Fallback to traditional orders URL
            if (empty($order_url)) {
                $order_url = admin_url('post.php?post=' . $order_id . '&action=edit');
            }
            
            $orders_data[] = array(
                'order_id' => $order_id,
                'order_number' => $customer_order->get_order_number(),
                'order_date' => $customer_order->get_date_created() ? $customer_order->get_date_created()->date('Y-m-d H:i:s') : '',
                'order_status' => $customer_order->get_status(),
                'order_total' => $customer_order->get_total(),
                'order_currency' => $customer_order->get_currency(),
                'order_payment_method' => $customer_order->get_payment_method_title(),
                'order_item_count' => $customer_order->get_item_count(),
                'order_url' => $order_url,
            );
        }
        
        return array(
            'customer_id' => $customer_id,
            'full_name' => $full_name,
            'email' => $user->user_email,
            'phone' => $phone ?: '',
            'username' => $user->user_login,
            'gender' => $gender,
            'date_of_birth' => $date_of_birth,
            'calculated_age' => $calculated_age,
            'document_type' => $document_type ?: '',
            'document_number' => $document_number ?: '',
            'document_issue_date' => $document_issue_date,
            'document_expiry_date' => $document_expiry_date,
            'address' => $address,
            'city' => $city,
            'state' => $state,
            'zip' => $zip,
            'country' => $country,
            'billing_address' => $billing_address,
            'billing_city' => $billing_city,
            'billing_state' => $billing_state,
            'billing_postcode' => $billing_postcode,
            'billing_country' => $billing_country,
            'verification_status' => $verification_status,
            'account_status' => $account_status,
            'verification_date' => $verification_date,
            'transaction_id' => $transaction_id,
            'transaction_date' => $transaction_date,
            'order_id' => $order_id,
            'order_date' => $order_date,
            'order_total' => $order_total,
            'order_status' => $order_status,
            'document_front_image' => $document_front_image_url,
            'document_back_image' => $document_back_image_url,
            'document_portrait_image' => $document_portrait_image_url,
            'activity_log' => $activity_log,
            'orders' => $orders_data,
            'document_analysis' => array(
                'total_confidence' => $total_confidence,
                'face_verification_confidence' => $face_verification_confidence,
                'selfie_authenticity_confidence' => $selfie_authenticity_confidence,
                'validation_result_code' => $validation_result_code,
                'validation_result_description' => $validation_result_description,
                'decision_confidence_text' => $decision_confidence_text,
                'threshold_info_text' => $threshold_info_text,
            ),
        );
    }

    /**
     * AJAX handler to get customer information for chargeback package
     */
    public function ajax_get_customer_info() {
        if (!isset($_POST['nonce']) || !wp_verify_nonce($_POST['nonce'], 'x8_evs_chargeback_nonce')) {
            wp_send_json_error(array('message' => __('Security check failed', 'x8-evs')));
            return;
        }
        $order_id = isset($_POST['order_id']) ? intval($_POST['order_id']) : 0;
        if (!$order_id) {
            wp_send_json_error(array('message' => __('Invalid order ID', 'x8-evs')));
            return;
        }
        $order = wc_get_order($order_id);
        if (!$order) {
            wp_send_json_error(array('message' => __('Order not found', 'x8-evs')));
            return;
        }
        $customer_id = $order->get_customer_id();
        if (!$customer_id) {
            wp_send_json_error(array('message' => __('No customer associated with this order', 'x8-evs')));
            return;
        }
        $user = get_userdata($customer_id);
        if (!$user) {
            wp_send_json_error(array('message' => __('Customer not found', 'x8-evs')));
            return;
        }
        $data = $this->get_chargeback_data($order);
        if (!$data) {
            wp_send_json_error(array('message' => __('Failed to build chargeback data', 'x8-evs')));
            return;
        }
        wp_send_json_success($data);
    }

    /**
     * Build HTML for chargeback PDF (same structure as modal, with inline CSS for Dompdf).
     *
     * @param array $data From get_chargeback_data()
     * @return string Full HTML document
     */
    protected function build_chargeback_pdf_html($data) {
        $safe = function ($v) {
            if ($v === null || $v === '') {
                return '';
            }
            return htmlspecialchars((string) $v, ENT_QUOTES, 'UTF-8');
        };
        $status_badge_class = function ($status) {
            if (empty($status)) {
                return 'x8-evs-status-pending';
            }
            $s = strtolower(trim($status));
            if ($s === 'verified' || $s === 'approved' || $s === 'pass') {
                return 'x8-evs-status-verified';
            }
            if ($s === 'block' || $s === 'blocked' || $s === 'fail') {
                return 'x8-evs-status-blocked';
            }
            return 'x8-evs-status-pending';
        };
        $item = function ($label, $value) use ($safe) {
            if ($value === null || $value === '') {
                return '';
            }
            return '<div class="x8-evs-info-item"><span class="x8-evs-info-label">' . $safe($label) . '</span><span class="x8-evs-info-value">' . $safe($value) . '</span></div>';
        };
        $item_badge = function ($label, $value, $badge_class) use ($safe) {
            if ($value === null && $value !== '0') {
                return '';
            }
            $val = $value === '' ? '—' : $safe($value);
            return '<div class="x8-evs-info-item"><span class="x8-evs-info-label">' . $safe($label) . '</span><span class="x8-evs-info-value"><span class="x8-evs-status-badge ' . esc_attr($badge_class) . '">' . $val . '</span></span></div>';
        };
        $section_bg_class = array(
            'x8-evs-section-1',
            'x8-evs-section-2',
            'x8-evs-section-3',
            'x8-evs-section-4',
            'x8-evs-section-5',
            'x8-evs-section-6',
        );
        $section_bg_color = array(
            '#f0f4f8',
            '#f5f0f8',
            '#f0f8f5',
            '#f8f5f0',
            '#f0f8f8',
            '#f8f0f5',
        );
        $section_index = 0;
        $section = function ($title, $rows) use (&$section_index, $section_bg_class, $section_bg_color) {
            if (trim($rows) === '') {
                return '';
            }
            $i = $section_index % count($section_bg_class);
            $section_index++;
            $bg = $section_bg_color[$i];
            $cls = 'x8-evs-info-section ' . $section_bg_class[$i];
            return '<div class="' . $cls . '" style="background-color:' . $bg . ';"><h3 class="x8-evs-info-section-title">' . esc_html($title) . '</h3><div class="x8-evs-info-grid">' . $rows . '</div></div>';
        };

        $html = '<div class="x8-evs-customer-info">';

        // Document Analysis – always show top section (purple header, three score columns)
        $analysis = isset($data['document_analysis']) && is_array($data['document_analysis']) ? $data['document_analysis'] : array();
        $total_conf = (int) ($analysis['total_confidence'] ?? 0);
        $face_conf = (int) ($analysis['face_verification_confidence'] ?? 0);
        $selfie_conf = (int) ($analysis['selfie_authenticity_confidence'] ?? 0);
        $html .= '<div class="x8-evs-document-analysis" style="background-color:#667eea;">';
        $html .= '<h3 class="x8-evs-document-analysis-title">Document Analysis</h3>';
        $html .= '<table class="x8-evs-confidence-scores-table" width="100%" cellpadding="8" cellspacing="8"><tr>';
        $html .= '<td class="x8-evs-confidence-score" width="33%"><span class="x8-evs-confidence-label">Total Confidence</span><span class="x8-evs-confidence-value">' . $total_conf . '%</span></td>';
        $html .= '<td class="x8-evs-confidence-score" width="33%"><span class="x8-evs-confidence-label">Face Verification Confidence</span><span class="x8-evs-confidence-value">' . $face_conf . '%</span></td>';
        $html .= '<td class="x8-evs-confidence-score" width="33%"><span class="x8-evs-confidence-label">Selfie Authenticity Confidence</span><span class="x8-evs-confidence-value">' . $selfie_conf . '%</span></td>';
        $html .= '</tr></table>';
        if (!empty($analysis['validation_result_description'])) {
            $html .= '<div class="x8-evs-validation-result"><p class="x8-evs-validation-result-text">' . $safe($analysis['validation_result_description']) . '</p></div>';
        }
        if (!empty($analysis['decision_confidence_text']) || !empty($analysis['threshold_info_text'])) {
            $html .= '<div class="x8-evs-decision-info">';
            if (!empty($analysis['decision_confidence_text'])) {
                $html .= '<p>' . $safe($analysis['decision_confidence_text']) . '</p>';
            }
            if (!empty($analysis['threshold_info_text'])) {
                $html .= '<p>' . $safe($analysis['threshold_info_text']) . '</p>';
            }
            $html .= '</div>';
        }
        $html .= '</div>';

        // Customer Information – one row, five columns
        $i = $section_index % count($section_bg_class);
        $section_index++;
        $bg = $section_bg_color[$i];
        $cls = 'x8-evs-info-section ' . $section_bg_class[$i];
        $html .= '<div class="' . $cls . '" style="background-color:' . $bg . ';"><h3 class="x8-evs-info-section-title">' . esc_html__('Customer Information', 'x8-evs') . '</h3>';
        $html .= '<table class="x8-evs-info-row-table" width="100%" cellpadding="6" cellspacing="0"><tr>';
        $html .= '<td width="20%"><span class="x8-evs-info-label">' . $safe(__('Customer ID', 'x8-evs')) . '</span><span class="x8-evs-info-value">' . $safe($data['customer_id'] ?? '') . '</span></td>';
        $html .= '<td width="20%"><span class="x8-evs-info-label">' . $safe(__('Full Name', 'x8-evs')) . '</span><span class="x8-evs-info-value">' . $safe($data['full_name'] ?? '') . '</span></td>';
        $html .= '<td width="20%"><span class="x8-evs-info-label">' . $safe(__('Email', 'x8-evs')) . '</span><span class="x8-evs-info-value">' . $safe($data['email'] ?? '') . '</span></td>';
        $html .= '<td width="20%"><span class="x8-evs-info-label">' . $safe(__('Phone', 'x8-evs')) . '</span><span class="x8-evs-info-value">' . $safe($data['phone'] ?? '') . '</span></td>';
        $html .= '<td width="20%"><span class="x8-evs-info-label">' . $safe(__('Username', 'x8-evs')) . '</span><span class="x8-evs-info-value">' . $safe($data['username'] ?? '') . '</span></td>';
        $html .= '</tr></table></div>';
        // Personal Details – one row, three columns
        $i = $section_index % count($section_bg_class);
        $section_index++;
        $bg = $section_bg_color[$i];
        $cls = 'x8-evs-info-section ' . $section_bg_class[$i];
        $age_val = !empty($data['calculated_age']) ? $data['calculated_age'] . ' years' : '';
        $html .= '<div class="' . $cls . '" style="background-color:' . $bg . ';"><h3 class="x8-evs-info-section-title">' . esc_html__('Personal Details', 'x8-evs') . '</h3><table class="x8-evs-info-row-table" width="100%" cellpadding="6" cellspacing="0"><tr>';
        $html .= '<td width="33%"><span class="x8-evs-info-label">' . $safe(__('Gender', 'x8-evs')) . '</span><span class="x8-evs-info-value">' . $safe($data['gender'] ?? '') . '</span></td>';
        $html .= '<td width="33%"><span class="x8-evs-info-label">' . $safe(__('Date of Birth', 'x8-evs')) . '</span><span class="x8-evs-info-value">' . $safe($data['date_of_birth'] ?? '') . '</span></td>';
        $html .= '<td width="34%"><span class="x8-evs-info-label">' . $safe(__('Age', 'x8-evs')) . '</span><span class="x8-evs-info-value">' . $safe($age_val) . '</span></td>';
        $html .= '</tr></table></div>';

        // Document Information – one row, four columns
        $i = $section_index % count($section_bg_class);
        $section_index++;
        $bg = $section_bg_color[$i];
        $cls = 'x8-evs-info-section ' . $section_bg_class[$i];
        $html .= '<div class="' . $cls . '" style="background-color:' . $bg . ';"><h3 class="x8-evs-info-section-title">' . esc_html__('Document Information', 'x8-evs') . '</h3><table class="x8-evs-info-row-table" width="100%" cellpadding="6" cellspacing="0"><tr>';
        $html .= '<td width="25%"><span class="x8-evs-info-label">' . $safe(__('Document Type', 'x8-evs')) . '</span><span class="x8-evs-info-value">' . $safe($data['document_type'] ?? '') . '</span></td>';
        $html .= '<td width="25%"><span class="x8-evs-info-label">' . $safe(__('Document Number', 'x8-evs')) . '</span><span class="x8-evs-info-value">' . $safe($data['document_number'] ?? '') . '</span></td>';
        $html .= '<td width="25%"><span class="x8-evs-info-label">' . $safe(__('Issue Date', 'x8-evs')) . '</span><span class="x8-evs-info-value">' . $safe($data['document_issue_date'] ?? '') . '</span></td>';
        $html .= '<td width="25%"><span class="x8-evs-info-label">' . $safe(__('Expiry Date', 'x8-evs')) . '</span><span class="x8-evs-info-value">' . $safe($data['document_expiry_date'] ?? '') . '</span></td>';
        $html .= '</tr></table></div>';

        // Address Information – one row, ten columns
        $i = $section_index % count($section_bg_class);
        $section_index++;
        $bg = $section_bg_color[$i];
        $cls = 'x8-evs-info-section ' . $section_bg_class[$i];
        $html .= '<div class="' . $cls . '" style="background-color:' . $bg . ';"><h3 class="x8-evs-info-section-title">' . esc_html__('Address Information', 'x8-evs') . '</h3><table class="x8-evs-info-row-table x8-evs-info-row-table--many" width="100%" cellpadding="4" cellspacing="0"><tr>';
        $html .= '<td width="10%"><span class="x8-evs-info-label">' . $safe(__('Address', 'x8-evs')) . '</span><span class="x8-evs-info-value">' . $safe($data['address'] ?? '') . '</span></td>';
        $html .= '<td width="10%"><span class="x8-evs-info-label">' . $safe(__('City', 'x8-evs')) . '</span><span class="x8-evs-info-value">' . $safe($data['city'] ?? '') . '</span></td>';
        $html .= '<td width="10%"><span class="x8-evs-info-label">' . $safe(__('State', 'x8-evs')) . '</span><span class="x8-evs-info-value">' . $safe($data['state'] ?? '') . '</span></td>';
        $html .= '<td width="10%"><span class="x8-evs-info-label">' . $safe(__('ZIP', 'x8-evs')) . '</span><span class="x8-evs-info-value">' . $safe($data['zip'] ?? '') . '</span></td>';
        $html .= '<td width="10%"><span class="x8-evs-info-label">' . $safe(__('Country', 'x8-evs')) . '</span><span class="x8-evs-info-value">' . $safe($data['country'] ?? '') . '</span></td>';
        $html .= '<td width="10%"><span class="x8-evs-info-label">' . $safe(__('Billing Address', 'x8-evs')) . '</span><span class="x8-evs-info-value">' . $safe($data['billing_address'] ?? '') . '</span></td>';
        $html .= '<td width="10%"><span class="x8-evs-info-label">' . $safe(__('Billing City', 'x8-evs')) . '</span><span class="x8-evs-info-value">' . $safe($data['billing_city'] ?? '') . '</span></td>';
        $html .= '<td width="10%"><span class="x8-evs-info-label">' . $safe(__('Billing State', 'x8-evs')) . '</span><span class="x8-evs-info-value">' . $safe($data['billing_state'] ?? '') . '</span></td>';
        $html .= '<td width="10%"><span class="x8-evs-info-label">' . $safe(__('Billing ZIP', 'x8-evs')) . '</span><span class="x8-evs-info-value">' . $safe($data['billing_postcode'] ?? '') . '</span></td>';
        $html .= '<td width="10%"><span class="x8-evs-info-label">' . $safe(__('Billing Country', 'x8-evs')) . '</span><span class="x8-evs-info-value">' . $safe($data['billing_country'] ?? '') . '</span></td>';
        $html .= '</tr></table></div>';

        // Verification Information – one row, five columns (Account Status with badge)
        $i = $section_index % count($section_bg_class);
        $section_index++;
        $bg = $section_bg_color[$i];
        $cls = 'x8-evs-info-section ' . $section_bg_class[$i];
        $acc_status = $data['account_status'] ?? '';
        $badge_cls = $status_badge_class($acc_status);
        $html .= '<div class="' . $cls . '" style="background-color:' . $bg . ';"><h3 class="x8-evs-info-section-title">' . esc_html__('Verification Information', 'x8-evs') . '</h3><table class="x8-evs-info-row-table" width="100%" cellpadding="6" cellspacing="0"><tr>';
        $html .= '<td width="20%"><span class="x8-evs-info-label">' . $safe(__('Account Status', 'x8-evs')) . '</span><span class="x8-evs-info-value"><span class="x8-evs-status-badge ' . esc_attr($badge_cls) . '">' . $safe($acc_status ?: '—') . '</span></span></td>';
        $html .= '<td width="20%"><span class="x8-evs-info-label">' . $safe(__('Verification Status', 'x8-evs')) . '</span><span class="x8-evs-info-value">' . $safe($data['verification_status'] ?? '') . '</span></td>';
        $html .= '<td width="20%"><span class="x8-evs-info-label">' . $safe(__('Verification Date', 'x8-evs')) . '</span><span class="x8-evs-info-value">' . $safe($data['verification_date'] ?? '') . '</span></td>';
        $html .= '<td width="20%"><span class="x8-evs-info-label">' . $safe(__('Transaction ID', 'x8-evs')) . '</span><span class="x8-evs-info-value">' . $safe($data['transaction_id'] ?? '') . '</span></td>';
        $html .= '<td width="20%"><span class="x8-evs-info-label">' . $safe(__('Transaction Date', 'x8-evs')) . '</span><span class="x8-evs-info-value">' . $safe($data['transaction_date'] ?? '') . '</span></td>';
        $html .= '</tr></table></div>';

        if (!empty($data['document_front_image']) || !empty($data['document_back_image']) || !empty($data['document_portrait_image'])) {
            $i = $section_index % count($section_bg_class);
            $section_index++;
            $bg = $section_bg_color[$i];
            $cls = 'x8-evs-info-section ' . $section_bg_class[$i];
            $html .= '<div class="' . $cls . '" style="background-color:' . $bg . ';"><h3 class="x8-evs-info-section-title">Document Images</h3><table class="x8-evs-images-row-table" width="100%" cellpadding="6" cellspacing="0"><tr>';
            $html .= '<td width="33%" class="x8-evs-image-cell"><h4 class="x8-evs-image-cell-title">ID Card Front</h4>';
            $html .= !empty($data['document_front_image']) ? '<img src="' . esc_url($data['document_front_image']) . '" alt="ID Front" class="x8-evs-pdf-image" />' : '<span class="x8-evs-info-value">—</span>';
            $html .= '</td>';
            $html .= '<td width="33%" class="x8-evs-image-cell"><h4 class="x8-evs-image-cell-title">ID Card Back</h4>';
            $html .= !empty($data['document_back_image']) ? '<img src="' . esc_url($data['document_back_image']) . '" alt="ID Back" class="x8-evs-pdf-image" />' : '<span class="x8-evs-info-value">—</span>';
            $html .= '</td>';
            $html .= '<td width="34%" class="x8-evs-image-cell"><h4 class="x8-evs-image-cell-title">Selfie</h4>';
            $html .= !empty($data['document_portrait_image']) ? '<img src="' . esc_url($data['document_portrait_image']) . '" alt="Selfie" class="x8-evs-pdf-image" />' : '<span class="x8-evs-info-value">—</span>';
            $html .= '</td>';
            $html .= '</tr></table></div>';
        }

        // Order Information – one row, four columns
        $order_total = isset($data['order_total']) && $data['order_total'] !== '' ? '$' . number_format((float) $data['order_total'], 2) : '';
        $i = $section_index % count($section_bg_class);
        $section_index++;
        $bg = $section_bg_color[$i];
        $cls = 'x8-evs-info-section ' . $section_bg_class[$i];
        $html .= '<div class="' . $cls . '" style="background-color:' . $bg . ';"><h3 class="x8-evs-info-section-title">' . esc_html__('Order Information', 'x8-evs') . '</h3><table class="x8-evs-info-row-table" width="100%" cellpadding="6" cellspacing="0"><tr>';
        $html .= '<td width="25%"><span class="x8-evs-info-label">' . $safe(__('Order ID', 'x8-evs')) . '</span><span class="x8-evs-info-value">' . $safe(!empty($data['order_id']) ? '#' . $data['order_id'] : '') . '</span></td>';
        $html .= '<td width="25%"><span class="x8-evs-info-label">' . $safe(__('Order Date', 'x8-evs')) . '</span><span class="x8-evs-info-value">' . $safe($data['order_date'] ?? '') . '</span></td>';
        $html .= '<td width="25%"><span class="x8-evs-info-label">' . $safe(__('Order Status', 'x8-evs')) . '</span><span class="x8-evs-info-value">' . $safe($data['order_status'] ?? '') . '</span></td>';
        $html .= '<td width="25%"><span class="x8-evs-info-label">' . $safe(__('Order Total', 'x8-evs')) . '</span><span class="x8-evs-info-value">' . $safe($order_total) . '</span></td>';
        $html .= '</tr></table></div>';

        $orders = isset($data['orders']) && is_array($data['orders']) ? $data['orders'] : array();
        if (!empty($orders)) {
            $i = $section_index % count($section_bg_class);
            $section_index++;
            $bg = $section_bg_color[$i];
            $cls = 'x8-evs-info-section ' . $section_bg_class[$i];
            $html .= '<div class="' . $cls . '" style="background-color:' . $bg . ';"><h3 class="x8-evs-info-section-title">Previous Orders (' . count($orders) . ')</h3><table class="x8-evs-orders-table"><thead><tr><th>Order #</th><th>Date</th><th>Status</th><th>Items</th><th>Total</th><th>Payment</th></tr></thead><tbody>';
            foreach ($orders as $o) {
                $html .= '<tr><td>#' . $safe($o['order_number'] ?? '') . '</td><td>' . $safe($o['order_date'] ?? '') . '</td><td>' . $safe($o['order_status'] ?? '') . '</td><td>' . (int) ($o['order_item_count'] ?? 0) . '</td><td>' . $safe($o['order_currency'] ?? '') . number_format((float) ($o['order_total'] ?? 0), 2) . '</td><td>' . $safe($o['order_payment_method'] ?? '') . '</td></tr>';
            }
            $html .= '</tbody></table></div>';
        }

        $activity = isset($data['activity_log']) && is_array($data['activity_log']) ? $data['activity_log'] : array();
        if (!empty($activity)) {
            $i = $section_index % count($section_bg_class);
            $section_index++;
            $bg = $section_bg_color[$i];
            $cls = 'x8-evs-info-section ' . $section_bg_class[$i];
            $html .= '<div class="' . $cls . '" style="background-color:' . $bg . ';"><h3 class="x8-evs-info-section-title">Activity Timeline</h3><div class="x8-evs-activity-timeline">';
            $icons = array('link_generated' => '&#128279;', 'verification_completed' => '&#9989;', 'verification_failed' => '&#10060;', 'access_blocked' => '&#128683;', 'login' => '&#128274;', 'logout' => '&#128682;');
            $titles = array('link_generated' => 'Verification Link Generated', 'verification_completed' => 'Verification Completed', 'verification_failed' => 'Verification Failed', 'access_blocked' => 'Access Blocked', 'login' => 'User Login', 'logout' => 'User Logout');
            foreach ($activity as $a) {
                $type = $a['activity_type'] ?? '';
                $loc = isset($a['geolocation']) && is_array($a['geolocation']) ? trim(($a['geolocation']['city'] ?? '') . ', ' . ($a['geolocation']['region'] ?? '') . ', ' . ($a['geolocation']['country'] ?? ''), ', ') : 'Unknown';
                if ($loc === ',' || $loc === '') {
                    $loc = 'Unknown Location';
                }
                $html .= '<div class="x8-evs-timeline-item"><table width="100%" cellpadding="0" cellspacing="0"><tr><td class="x8-evs-timeline-icon-cell" width="80"><span class="x8-evs-timeline-icon">' . ($icons[$type] ?? '&#128203;') . '</span></td><td class="x8-evs-timeline-content"><h4 class="x8-evs-timeline-header-h4">' . $safe($titles[$type] ?? $type) . '</h4><span class="x8-evs-timeline-date">' . $safe($a['timestamp'] ?? '') . '</span><p class="x8-evs-timeline-details-p"><strong>Location:</strong> ' . $safe($loc) . '</p><p class="x8-evs-timeline-details-p"><strong>IP Address:</strong> ' . $safe($a['ip_address'] ?? '') . '</p></td></tr></table></div>';
            }
            $html .= '</div></div>';
        }

        $html .= '</div>';

        // CSS matching modal design (Dompdf-compatible: solid backgrounds so they render in PDF)
        $css = '
            body { font-family: DejaVu Sans, sans-serif; font-size: 12px; color: #111827; margin: 0; padding: 0; background: #fff; }
            .x8-evs-customer-info { padding: 0; background: #fff; }
            .x8-evs-document-analysis { background-color: #667eea; color: #fff; padding: 28px 32px; margin-bottom: 0; }
            .x8-evs-document-analysis-title { font-size: 22px; font-weight: 700; margin: 0 0 20px 0; color: #fff; }
            .x8-evs-confidence-scores-table { width: 100%; border-collapse: collapse; margin-bottom: 18px; }
            .x8-evs-confidence-scores-table td { padding: 18px 16px; background-color: #8b9cf0; border: 1px solid #7c8de6; vertical-align: top; }
            .x8-evs-confidence-label { display: block; font-size: 10px; text-transform: uppercase; letter-spacing: 1px; margin-bottom: 8px; color: #fff; font-weight: 700; }
            .x8-evs-confidence-value { display: block; font-size: 28px; font-weight: 800; color: #fff; }
            .x8-evs-validation-result { background-color: #9fa8e8; padding: 14px 18px; border-radius: 10px; margin-bottom: 14px; border: 1px solid rgba(255,255,255,0.3); }
            .x8-evs-validation-result-text { font-size: 14px; font-weight: 700; margin: 0; color: #fff; }
            .x8-evs-decision-info { background-color: #8b9cf0; padding: 14px 18px; border-radius: 10px; font-size: 12px; border: 1px solid rgba(255,255,255,0.25); }
            .x8-evs-decision-info p { margin: 6px 0; color: #fff; }
            .x8-evs-info-section { padding: 28px 32px; border-bottom: 1px solid #e2e8f0; page-break-inside: avoid; }
            .x8-evs-info-section-title { font-size: 18px; font-weight: 700; color: #111827; margin: 0 0 18px 0; padding-bottom: 12px; border-bottom: 3px solid #667eea; }
            .x8-evs-info-row-table { width: 100%; table-layout: fixed; border-collapse: collapse; margin: 0; }
            .x8-evs-info-row-table td { padding: 14px 10px; background-color: #ffffff; border: 1px solid #c7d2fe; vertical-align: top; }
            .x8-evs-info-row-table .x8-evs-info-label { display: block; }
            .x8-evs-info-row-table .x8-evs-info-value { display: block; word-break: break-word; }
            .x8-evs-info-row-table--many td { padding: 10px 6px; }
            .x8-evs-info-row-table--many .x8-evs-info-label { font-size: 8px; }
            .x8-evs-info-row-table--many .x8-evs-info-value { font-size: 11px; }
            .x8-evs-info-grid { margin: 0 -8px; }
            .x8-evs-info-item { display: block; padding: 14px 16px; margin: 0 8px 12px 8px; background-color: #ffffff; border: 1px solid #c7d2fe; }
            .x8-evs-info-label { font-weight: 700; font-size: 9px; color: #4b5563; text-transform: uppercase; letter-spacing: 0.8px; display: block; margin-bottom: 6px; }
            .x8-evs-info-value { font-size: 13px; color: #111827; font-weight: 600; line-height: 1.5; }
            .x8-evs-status-badge { display: inline-block; padding: 4px 10px; border-radius: 6px; font-size: 9px; font-weight: 700; text-transform: uppercase; }
            .x8-evs-status-verified { background: #d4edda; color: #155724; border: 1px solid #c3e6cb; }
            .x8-evs-status-blocked { background: #f8d7da; color: #721c24; border: 1px solid #f5c2c7; }
            .x8-evs-status-pending { background: #fff3cd; color: #856404; border: 1px solid #ffecb5; }
            .x8-evs-images-row-table { width: 100%; table-layout: fixed; border-collapse: collapse; margin: 0; }
            .x8-evs-images-row-table td.x8-evs-image-cell { padding: 12px; background-color: #ffffff; border: 1px solid #c7d2fe; vertical-align: top; text-align: center; }
            .x8-evs-image-cell-title { margin: 0 0 10px 0; font-size: 11px; font-weight: 700; color: #111827; text-transform: uppercase; }
            .x8-evs-pdf-image { max-width: 100%; height: auto; max-height: 140px; border: 2px solid #e5e7eb; display: block; margin: 0 auto; }
            .x8-evs-customer-images { margin-top: 14px; }
            .x8-evs-customer-image-item { text-align: left; background-color: #ffffff; padding: 18px; margin-bottom: 14px; border: 1px solid #c7d2fe; }
            .x8-evs-customer-image-item h4 { margin: 0 0 12px 0; font-size: 12px; font-weight: 700; color: #111827; text-transform: uppercase; }
            .x8-evs-customer-image-item img { max-width: 220px; max-height: 150px; border: 2px solid #e5e7eb; }
            .x8-evs-orders-table { width: 100%; border-collapse: collapse; margin-top: 14px; background-color: #fff; border-radius: 10px; border: 1px solid #c7d2fe; }
            .x8-evs-orders-table th, .x8-evs-orders-table td { padding: 12px 14px; text-align: left; border-bottom: 1px solid #e5e7eb; font-size: 11px; }
            .x8-evs-orders-table th { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: #fff; font-weight: 700; text-transform: uppercase; letter-spacing: 0.8px; }
            .x8-evs-orders-table td { background: #fff; color: #111827; }
            .x8-evs-activity-timeline { margin-top: 14px; }
            .x8-evs-timeline-item { margin-bottom: 16px; padding: 18px; background-color: #ffffff; border-radius: 12px; border: 1px solid #c7d2fe; page-break-inside: avoid; }
            .x8-evs-timeline-item table { border: none; }
            .x8-evs-timeline-icon-cell { vertical-align: top; padding-right: 14px; }
            .x8-evs-timeline-icon { display: inline-block; width: 48px; height: 48px; line-height: 48px; text-align: center; font-size: 22px; background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); border-radius: 50%; border: 2px solid rgba(102,126,234,0.3); }
            .x8-evs-timeline-content { vertical-align: top; }
            .x8-evs-timeline-header-h4 { margin: 0 0 6px 0; font-size: 14px; font-weight: 700; color: #111827; }
            .x8-evs-timeline-date { font-size: 11px; color: #6b7280; }
            .x8-evs-timeline-details-p { margin: 6px 0; font-size: 12px; color: #6b7280; }
        ';
        return '<!DOCTYPE html><html><head><meta charset="UTF-8"><style>' . $css . '</style></head><body>' . $html . '</body></html>';
    }

    /**
     * AJAX handler: output chargeback package as PDF download (Dompdf).
     */
    public function ajax_chargeback_pdf() {
        $nonce = isset($_REQUEST['nonce']) ? $_REQUEST['nonce'] : '';
        if (!wp_verify_nonce($nonce, 'x8_evs_chargeback_nonce')) {
            wp_die(esc_html__('Security check failed', 'x8-evs'), '', array('response' => 403));
        }
        $order_id = isset($_REQUEST['order_id']) ? intval($_REQUEST['order_id']) : 0;
        if (!$order_id) {
            wp_die(esc_html__('Invalid order ID', 'x8-evs'), '', array('response' => 400));
        }
        $order = wc_get_order($order_id);
        if (!$order) {
            wp_die(esc_html__('Order not found', 'x8-evs'), '', array('response' => 404));
        }
        $data = $this->get_chargeback_data($order);
        if (!$data) {
            wp_die(esc_html__('No chargeback data for this order', 'x8-evs'), '', array('response' => 404));
        }
        $autoload = X8_EVS_PLUGIN_PATH . 'vendor/autoload.php';
        if (!file_exists($autoload)) {
            wp_die(esc_html__('PDF library not installed. Run "composer install" in the x8-verify plugin directory.', 'x8-evs'), '', array('response' => 503));
        }
        require_once $autoload;
        $html = $this->build_chargeback_pdf_html($data);
        $filename = 'Chargeback_Package';
        $parts = array();
        if (!empty($data['order_id'])) {
            $parts[] = 'Order_' . $data['order_id'];
        }
        if (!empty($data['customer_id'])) {
            $parts[] = 'Customer_' . $data['customer_id'];
        }
        if (!empty($data['full_name'])) {
            $parts[] = preg_replace('/[^a-zA-Z0-9]/', '_', substr($data['full_name'], 0, 30));
        }
        if (!empty($parts)) {
            $filename = 'Chargeback_Package_' . implode('_', $parts);
        }
        $filename = sanitize_file_name($filename) . '.pdf';
        try {
            $options = new \Dompdf\Options();
            $options->set('isRemoteEnabled', true);
            $options->set('isHtml5ParserEnabled', true);
            $dompdf = new \Dompdf\Dompdf($options);
            $dompdf->loadHtml($html);
            $dompdf->setPaper('A4', 'portrait');
            $dompdf->render();
            $dompdf->stream($filename, array('Attachment' => true));
        } catch (\Exception $e) {
            if (defined('WP_DEBUG') && WP_DEBUG) {
                error_log('X8 Verify PDF error: ' . $e->getMessage());
            }
            wp_die(esc_html__('Failed to generate PDF.', 'x8-evs'), '', array('response' => 500));
        }
        exit;
    }

    /**
     * Debug function to test blocked states
     */
    public static function debug_blocked_states() {
        if (!class_exists('X8_EVS_Admin_Settings')) {
            return 'Admin_Settings class not found';
        }
        
        $blocked_states = X8_EVS_Admin_Settings::get_blocked_states();
        $test_states = array('CA', 'NY', 'TX', 'FL', 'AL');
        
        $debug_info = array(
            'blocked_states_configured' => $blocked_states,
            'test_results' => array()
        );
        
        foreach ($test_states as $state) {
            $debug_info['test_results'][$state] = X8_EVS_Admin_Settings::is_state_blocked($state);
        }
        
        return $debug_info;
    }
    
    /**
     * Test method to verify integration is working
     */
    public static function test_integration() {
        $test_results = array(
            'woocommerce_active' => class_exists('WooCommerce'),
            'admin_settings_loaded' => class_exists('X8_EVS_Admin_Settings'),
            'integration_class_loaded' => class_exists('X8_EVS_WooCommerce_Integration'),
            'blocked_states' => array()
        );
        
        if (class_exists('X8_EVS_Admin_Settings')) {
            $test_results['blocked_states'] = X8_EVS_Admin_Settings::get_blocked_states();
        }
        
        return $test_results;
    }


    /**
     * Capture order geo information on backend during order processing
     */
    public function capture_order_geo_info_backend($order_id, $posted_data, $order) {
        if (!$order_id || !$order) {
            return;
        }

        // Check if geo info is already captured to avoid duplicate processing
        $existing_ip = $order->get_meta('_x8_evs_ip_address');
        if (!empty($existing_ip)) {
            error_log('X8 Verify: Geo info already captured for order ' . $order_id);
            return;
        }

        // Get IP address from user
        $ip_address = $this->get_user_ip();
        
        if (empty($ip_address)) {
            error_log('X8 Verify: No IP address found for order ' . $order_id);
            return;
        }
        
        // Get geo information from IP
        $geo_info = $this->get_geo_info_from_ip($ip_address);
        
        if ($geo_info) {
            // Save geo information to order meta using the new field names
            $order->update_meta_data('_x8_evs_ip_address', $ip_address);
            $order->update_meta_data('customer_location_country', $geo_info['country'] ?? '');
            $order->update_meta_data('customer_location_region', $geo_info['region'] ?? '');
            $order->update_meta_data('customer_location_city', $geo_info['city'] ?? '');
            $order->update_meta_data('customer_location_lat', $geo_info['lat'] ?? '');
            $order->update_meta_data('customer_location_lon', $geo_info['lon'] ?? '');
            $order->update_meta_data('customer_location_timezone', $geo_info['timezone'] ?? '');
            $order->update_meta_data('customer_location_isp', $geo_info['isp'] ?? '');
            $order->update_meta_data('_x8_evs_geo_captured_at', current_time('mysql'));
            $order->save();
            
            error_log('X8 Verify: Geo info captured on backend for order ' . $order_id . ': ' . print_r($geo_info, true));
        } else {
            error_log('X8 Verify: Failed to get geo info for order ' . $order_id . ' with IP: ' . $ip_address);
        }
    }

    /**
     * After checkout: flag order if billing state differs from verified ID, or if customer used >2 addresses.
     */
    public function checkout_flag_verification_checks($order_id, $posted_data, $order) {
        if (!$order_id || !$order) {
            return;
        }
        $customer_id = $order->get_customer_id();
        if (!$customer_id) {
            return;
        }

        $billing_state = $order->get_billing_state();
        $verified_state = $this->get_verified_state_for_user($customer_id);

        // Flag 1: Billing state different from verified ID state
        if (!empty($verified_state) && !empty($billing_state)) {
            $norm_billing = $this->normalize_state_code($billing_state);
            $norm_verified = $this->normalize_state_code($verified_state);
            if ($norm_billing && $norm_verified && $norm_billing !== $norm_verified) {
                $order->update_meta_data('_x8_evs_billing_state_mismatch', 'yes');
                $order->add_order_note(
                    sprintf(
                        __('X8 Verify: Billing state (%s) differs from verified ID state (%s). Please check.', 'x8-evs'),
                        $billing_state,
                        $verified_state
                    )
                );
            }
        }

        // Flag 2: Customer has used more than 2 different billing addresses
        $address_hash = $this->get_billing_address_hash($order);
        if ($address_hash) {
            $hashes = get_user_meta($customer_id, '_x8_evs_checkout_billing_address_hashes', true);
            if (!is_array($hashes)) {
                $hashes = array();
            }
            if (!in_array($address_hash, $hashes, true)) {
                $hashes[] = $address_hash;
                update_user_meta($customer_id, '_x8_evs_checkout_billing_address_hashes', $hashes);
            }
            if (count($hashes) > 2) {
                $order->update_meta_data('_x8_evs_multiple_addresses_flag', 'yes');
                $order->add_order_note(
                    __('X8 Verify: Customer has used more than 2 different billing addresses at checkout. Flagged for manual review.', 'x8-evs')
                );
            }
        }

        $order->save();
    }

    /**
     * Get verified address state from user's verification data (ID document).
     */
    private function get_verified_state_for_user($user_id) {
        $raw = get_user_meta($user_id, 'verification_webhook_data', true);
        if (empty($raw)) {
            return '';
        }
        if (is_string($raw)) {
            $data = json_decode($raw, true);
        } else {
            $data = $raw;
        }
        if (empty($data['data'])) {
            return '';
        }
        $state = '';
        if (!empty($data['data']['assureCard']['documentAddress']['state'])) {
            $state = $data['data']['assureCard']['documentAddress']['state'];
        }
        if (empty($state) && !empty($data['data']['assureId']['standardizedAddress']['state'])) {
            $state = $data['data']['assureId']['standardizedAddress']['state'];
        }
        return is_string($state) ? trim($state) : '';
    }

    /**
     * Normalize state to 2-letter code for comparison.
     */
    private function normalize_state_code($state) {
        if (empty($state)) {
            return '';
        }
        $state = trim($state);
        if (strlen($state) === 2) {
            return strtoupper($state);
        }
        $name_to_code = array(
            'Alabama' => 'AL', 'Alaska' => 'AK', 'Arizona' => 'AZ', 'Arkansas' => 'AR', 'California' => 'CA',
            'Colorado' => 'CO', 'Connecticut' => 'CT', 'Delaware' => 'DE', 'Florida' => 'FL', 'Georgia' => 'GA',
            'Hawaii' => 'HI', 'Idaho' => 'ID', 'Illinois' => 'IL', 'Indiana' => 'IN', 'Iowa' => 'IA',
            'Kansas' => 'KS', 'Kentucky' => 'KY', 'Louisiana' => 'LA', 'Maine' => 'ME', 'Maryland' => 'MD',
            'Massachusetts' => 'MA', 'Michigan' => 'MI', 'Minnesota' => 'MN', 'Mississippi' => 'MS', 'Missouri' => 'MO',
            'Montana' => 'MT', 'Nebraska' => 'NE', 'Nevada' => 'NV', 'New Hampshire' => 'NH', 'New Jersey' => 'NJ',
            'New Mexico' => 'NM', 'New York' => 'NY', 'North Carolina' => 'NC', 'North Dakota' => 'ND', 'Ohio' => 'OH',
            'Oklahoma' => 'OK', 'Oregon' => 'OR', 'Pennsylvania' => 'PA', 'Rhode Island' => 'RI', 'South Carolina' => 'SC',
            'South Dakota' => 'SD', 'Tennessee' => 'TN', 'Texas' => 'TX', 'Utah' => 'UT', 'Vermont' => 'VT',
            'Virginia' => 'VA', 'Washington' => 'WA', 'West Virginia' => 'WV', 'Wisconsin' => 'WI', 'Wyoming' => 'WY',
            'District of Columbia' => 'DC', 'DC' => 'DC'
        );
        return isset($name_to_code[$state]) ? $name_to_code[$state] : strtoupper(substr($state, 0, 2));
    }

    /**
     * Build a stable hash for the order's billing address (to count unique addresses).
     */
    private function get_billing_address_hash($order) {
        $parts = array(
            $order->get_billing_address_1(),
            $order->get_billing_city(),
            $this->normalize_state_code($order->get_billing_state()),
            $order->get_billing_postcode(),
            $order->get_billing_country()
        );
        $str = implode('|', array_map('trim', $parts));
        return $str !== '||||' ? md5($str) : '';
    }

    /**
     * Display X8 Verify checkout flags in admin (state mismatch, multiple addresses).
     */
    public function display_checkout_verification_flags($order) {
        if (!$order) {
            return;
        }
        $state_mismatch = $order->get_meta('_x8_evs_billing_state_mismatch');
        $multi_address = $order->get_meta('_x8_evs_multiple_addresses_flag');
        if ($state_mismatch !== 'yes' && $multi_address !== 'yes') {
            return;
        }
        echo '<div class="x8-evs-checkout-flags" style="margin-top: 12px; padding: 12px; background: #fff8e5; border: 1px solid #e6b800; border-radius: 4px;">';
        echo '<h4 style="margin: 0 0 8px 0; color: #1d2327;">' . esc_html__('X8 Verify – Please check', 'x8-evs') . '</h4>';
        if ($state_mismatch === 'yes') {
            echo '<p style="margin: 0 0 6px 0; color: #646970;"><strong>' . esc_html__('Billing state mismatch:', 'x8-evs') . '</strong> ' . esc_html__('Billing state differs from the state on the customer’s verified ID.', 'x8-evs') . '</p>';
        }
        if ($multi_address === 'yes') {
            echo '<p style="margin: 0; color: #646970;"><strong>' . esc_html__('Multiple addresses:', 'x8-evs') . '</strong> ' . esc_html__('Customer has used more than 2 different billing addresses at checkout. Flagged for manual review.', 'x8-evs') . '</p>';
        }
        echo '</div>';
    }

    /**
     * Display order geo information on frontend order details
     */
    public function display_order_geo_info($order) {
        if (!$order) {
            return;
        }

        $customer_ip = $order->get_meta('_x8_evs_ip_address');
        
        if (empty($customer_ip)) {
            return;
        }
        
        $location_fields = array(
            'customer_location_country' => 'Country',
            'customer_location_region' => 'Region', 
            'customer_location_city' => 'City',
            'customer_location_lat' => 'Latitude',
            'customer_location_lon' => 'Longitude',
            'customer_location_timezone' => 'Timezone',
            'customer_location_isp' => 'ISP'
        );
        
        echo '<div class="x8-evs-order-card x8-evs-order-card--secondary" style="margin-top: 16px;">';
        echo '<div class="x8-evs-order-card__left">';
        echo '<h3 class="x8-evs-order-card__title" style="margin:0;">' . esc_html__('Customer Location', 'x8-evs') . '</h3>';
        echo '<p class="x8-evs-order-card__description" style="margin:4px 0 12px 0;">' . esc_html__('Latest geo signals captured during verification.', 'x8-evs') . '</p>';
        echo '<div class="x8-evs-order-card__list">';
        echo '<div class="x8-evs-order-card__list-item"><span>' . esc_html__('IP Address', 'x8-evs') . '</span><strong>' . esc_html($customer_ip) . '</strong></div>';
        
        foreach ($location_fields as $meta_key => $label) {
            $value = $order->get_meta($meta_key);
            if (!empty($value)) {
                echo '<div class="x8-evs-order-card__list-item"><span>' . esc_html($label) . '</span><strong>' . esc_html($value) . '</strong></div>';
            }
        }
        
        // Add map link if coordinates are available
        $lat = $order->get_meta('customer_location_lat');
        $lon = $order->get_meta('customer_location_lon');
        if (!empty($lat) && !empty($lon)) {
            $map_url = "https://www.google.com/maps?q={$lat},{$lon}";
            echo '<a class="x8-evs-order-card__link" href="' . esc_url($map_url) . '" target="_blank">📍 ' . esc_html__('View on Google Maps', 'x8-evs') . '</a>';
        }
        
        echo '</div>'; // list wrapper
        echo '</div>'; // left
        echo '</div>'; // card
    }

    /**
     * Display order geo information in admin order details
     */
    public function display_admin_order_geo_info($order) {
        if (!$order) {
            return;
        }

        $customer_ip = $order->get_meta('_x8_evs_ip_address');
        
        if (empty($customer_ip)) {
            return;
        }
        
        $location_fields = array(
            'customer_location_country' => 'Country',
            'customer_location_region' => 'Region', 
            'customer_location_city' => 'City',
            'customer_location_lat' => 'Latitude',
            'customer_location_lon' => 'Longitude',
            'customer_location_timezone' => 'Timezone',
            'customer_location_isp' => 'ISP'
        );
        
        echo '<div class="gidx-location-info" style="margin-top: 15px; padding: 10px; background: #f8f9fa; border: 1px solid #ddd; border-radius: 4px;">';
        echo '<h4 style="margin: 0 0 10px 0; color: #23282d;">Customer Location Information</h4>';
        echo '<p style="margin: 0 0 8px 0;"><strong>IP Address:</strong> ' . esc_html($customer_ip) . '</p>';
        
        foreach ($location_fields as $meta_key => $label) {
            $value = $order->get_meta($meta_key);
            if (!empty($value)) {
                echo '<p style="margin: 0 0 5px 0;"><strong>' . esc_html($label) . ':</strong> ' . esc_html($value) . '</p>';
            }
        }
        
        // Add map link if coordinates are available
        $lat = $order->get_meta('customer_location_lat');
        $lon = $order->get_meta('customer_location_lon');
        if (!empty($lat) && !empty($lon)) {
            $map_url = "https://www.google.com/maps?q={$lat},{$lon}";
            echo '<p style="margin: 10px 0 0 0;"><a href="' . esc_url($map_url) . '" target="_blank" style="color: #0073aa; text-decoration: none;">📍 View on Google Maps</a></p>';
        }
        
        echo '</div>';
    }

    /**
     * Get user IP address
     */
    public function get_user_ip() {
        $ip_keys = array('HTTP_CLIENT_IP', 'HTTP_X_FORWARDED_FOR', 'REMOTE_ADDR');
        
        foreach ($ip_keys as $key) {
            if (array_key_exists($key, $_SERVER) === true) {
                foreach (explode(',', $_SERVER[$key]) as $ip) {
                    $ip = trim($ip);
                    if (filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE) !== false) {
                        return $ip;
                    }
                }
            }
        }
        
        // Fallback to REMOTE_ADDR
        return $_SERVER['REMOTE_ADDR'] ?? '';
    }

    /**
     * Get geo information from IP using ipinfo.io
     */
    public function get_geo_info_from_ip($ip_address) {
         // Use ipapi.co service (free tier available)
        $api_url = "http://ip-api.com/json/{$ip_address}";
        
        $response = wp_remote_get($api_url, array(
            'timeout' => 10,
            'user-agent' => 'WordPress/X8-All-In-One'
        ));
        
        if (is_wp_error($response)) {
            return false;
        }
        
        $body = wp_remote_retrieve_body($response);
        $data = json_decode($body, true);
        
        // Check if the API call was successful
        if ($data && isset($data['status']) && $data['status'] === 'success') {
            return array(
                'country' => $data['country'] ?? '',
                'region' => $data['regionName'] ?? '',
                'city' => $data['city'] ?? '',
                'lat' => $data['lat'] ?? '',
                'lon' => $data['lon'] ?? '',
                'timezone' => $data['timezone'] ?? '',
                'isp' => $data['isp'] ?? ''
            );
        }
        
        return false;
    }


    /**
     * Get geo information for display (public method)
     */
    public static function get_order_geo_info($order_id) {
        $order = wc_get_order($order_id);
        if (!$order) {
            return false;
        }

        return array(
            'geo_info' => $order->get_meta('_x8_evs_geo_info'),
            'ip_address' => $order->get_meta('_x8_evs_ip_address'),
            'captured_at' => $order->get_meta('_x8_evs_geo_captured_at')
        );
    }

    /**
     * Remove unwanted columns from orders list
     * This runs at very high priority (9999) to ensure it runs after all other plugins
     */
    public function remove_unwanted_columns($columns) {
        if (!is_array($columns)) {
            return $columns;
        }
        
        // Columns to remove
        $columns_to_remove = array(
            'origin',
            'Origin', 
            'order_origin',
            'psifi_payment_status',
            'loginasuser_col'
        );
        
        // Remove by exact key match
        foreach ($columns_to_remove as $col_key) {
            if (isset($columns[$col_key])) {
                unset($columns[$col_key]);
                error_log('X8 Verify: remove_unwanted_columns - Removed column: ' . $col_key);
            }
        }
        
        // Also check by case-insensitive key match
        foreach ($columns as $key => $column) {
            $key_lower = strtolower($key);
            foreach ($columns_to_remove as $col_key) {
                if (strtolower($col_key) === $key_lower) {
                    unset($columns[$key]);
                    error_log('X8 Verify: remove_unwanted_columns - Removed column by case-insensitive match: ' . $key);
                    break;
                }
            }
        }
        
        // Check column labels for "Origin" or "Login as User"
        foreach ($columns as $key => $column) {
            if (is_string($column)) {
                $column_lower = strtolower($column);
                if (stripos($column_lower, 'origin') !== false || 
                    stripos($column_lower, 'login as user') !== false ||
                    stripos($column_lower, 'loginasuser') !== false) {
                    unset($columns[$key]);
                    error_log('X8 Verify: remove_unwanted_columns - Removed column by label match: ' . $key . ' = ' . $column);
                }
            }
        }
        
        return $columns;
    }

    /**
     * Add custom column to orders list
     */
    public function add_chargeback_package_column($columns) {
        // Check if column already exists to avoid duplicates
        if (isset($columns['chargeback_package'])) {
            // Still remove unwanted columns if they exist
            $columns_to_remove = array('origin', 'Origin', 'order_origin', 'psifi_payment_status', 'loginasuser_col');
            foreach ($columns_to_remove as $col_key) {
                if (isset($columns[$col_key])) {
                    unset($columns[$col_key]);
                    error_log('X8 Verify: Removed column in early return: ' . $col_key);
                }
            }
            // Also check by label
            foreach ($columns as $key => $column) {
                if (is_string($column) && stripos($column, 'origin') !== false) {
                    unset($columns[$key]);
                    error_log('X8 Verify: Removed column by label in early return: ' . $key);
                }
            }
            return $columns;
        }

        error_log('X8 Verify: Adding chargeback package column. Existing columns: ' . print_r(array_keys($columns), true));
        
        $new_columns = array();
        $column_added = false;
        
        // Columns to remove (check both key and label)
        $columns_to_remove = array('origin', 'Origin', 'order_origin', 'psifi_payment_status', 'loginasuser_col');
        
        foreach ($columns as $key => $column) {
            // Skip unwanted columns by key
            $key_lower = strtolower($key);
            if (in_array($key_lower, array_map('strtolower', $columns_to_remove)) || $key === 'psifi_payment_status' || $key === 'loginasuser_col') {
                error_log('X8 Verify: Removing column: ' . $key);
                continue;
            }
            
            // Also check column label/value for "Origin" (case-insensitive)
            if (is_string($column) && stripos($column, 'origin') !== false) {
                error_log('X8 Verify: Removing column by label match: ' . $key . ' = ' . $column);
                continue;
            }
            
            // Add our column before the "order_actions" column
            if ($key === 'order_actions' && !$column_added) {
                $new_columns['chargeback_package'] = __('Chargeback Package', 'x8-evs');
                $column_added = true;
            }
            $new_columns[$key] = $column;
        }
        
        // If order_actions column doesn't exist, add at the end
        if (!$column_added) {
            $new_columns['chargeback_package'] = __('Chargeback Package', 'x8-evs');
        }
        
        error_log('X8 Verify: Column added. New columns: ' . print_r(array_keys($new_columns), true));
        
        return $new_columns;
    }

    /**
     * Render content for chargeback package column (traditional orders)
     */
    public function render_chargeback_package_column($column, $post_id) {
        if ($column === 'chargeback_package') {
            $order = wc_get_order($post_id);
            if ($order) {
                $order_id = is_numeric($post_id) ? $post_id : $order->get_id();
                echo '<button type="button" class="button x8-evs-create-chargeback-btn" data-order-id="' . esc_attr($order_id) . '">';
                echo esc_html__('Chargeback', 'x8-evs');
                echo '</button>';
            }
        }
    }

    /**
     * Render content for chargeback package column (HPOS)
     */
    public function render_chargeback_package_column_hpos($column, $order) {
        if ($column === 'chargeback_package') {
            if ($order instanceof \WC_Order) {
                $order_id = $order->get_id();
                echo '<button type="button" class="button x8-evs-create-chargeback-btn" data-order-id="' . esc_attr($order_id) . '">';
                echo esc_html__('Chargeback', 'x8-evs');
                echo '</button>';
            }
        }
    }

    /**
     * Enqueue scripts and styles for chargeback package modal
     */
    public function enqueue_chargeback_package_scripts($hook) {
        // Check if we're on the orders list page (traditional or HPOS)
        $is_orders_page = false;
        
        // Traditional orders page
        if ($hook === 'edit.php' && isset($_GET['post_type']) && $_GET['post_type'] === 'shop_order') {
            $is_orders_page = true;
        }
        
        // HPOS orders page (WooCommerce 8.0+)
        if ($hook === 'woocommerce_page_wc-orders') {
            $is_orders_page = true;
        }
        
        if (!$is_orders_page) {
            return;
        }

        // Enqueue jQuery if not already loaded
        wp_enqueue_script('jquery');

        // Register and enqueue a style handle for our inline styles
        wp_register_style('x8-evs-chargeback-modal', false);
        wp_enqueue_style('x8-evs-chargeback-modal');
        
        // Localize script with AJAX data
        wp_localize_script('jquery', 'x8_evs_chargeback', array(
            'ajax_url' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('x8_evs_chargeback_nonce')
        ));
        
        // Add inline styles
        wp_add_inline_style('x8-evs-chargeback-modal', '
            .x8-evs-chargeback-modal {
                display: none;
                position: fixed;
                z-index: 100000;
                left: 0;
                top: 0;
                width: 100%;
                height: 100%;
                overflow: auto;
                background-color: rgba(0,0,0,0.5);
            }
            .x8-evs-chargeback-modal-content {
                background-color: #fefefe;
                margin: 5% auto;
                padding: 0;
                border: 1px solid #ddd;
                width: 90%;
                max-width: 900px;
                border-radius: 8px;
                box-shadow: 0 8px 16px rgba(0,0,0,0.2);
                max-height: 90vh;
                overflow-y: auto;
            }
            .x8-evs-chargeback-modal-body {
                padding: 0;
                max-height: calc(90vh - 60px);
                overflow-y: auto;
            }
            .x8-evs-customer-info {
                padding: 0;
                background: #ffffff;
            }
            .x8-evs-document-analysis {
                background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                color: #fff;
                padding: 35px 40px;
                margin-bottom: 0;
            }
            .x8-evs-document-analysis-title {
                font-size: 24px;
                font-weight: 700;
                margin: 0 0 28px 0;
                color: #fff;
                letter-spacing: -0.5px;
            }
            .x8-evs-confidence-scores {
                display: grid;
                grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
                gap: 24px;
                margin-bottom: 24px;
            }
            .x8-evs-confidence-score {
                background: rgba(255, 255, 255, 0.18);
                padding: 24px;
                border-radius: 14px;
                backdrop-filter: blur(12px);
                transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
                border: 1px solid rgba(255, 255, 255, 0.2);
            }
            .x8-evs-confidence-score:hover {
                transform: translateY(-4px);
                box-shadow: 0 8px 20px rgba(0, 0, 0, 0.2);
                background: rgba(255, 255, 255, 0.22);
            }
            .x8-evs-confidence-label {
                display: block;
                font-size: 11px;
                text-transform: uppercase;
                letter-spacing: 1.2px;
                margin-bottom: 12px;
                opacity: 0.95;
                font-weight: 700;
            }
            .x8-evs-confidence-value {
                display: block;
                font-size: 42px;
                font-weight: 800;
                color: #fff;
                line-height: 1.1;
            }
            .x8-evs-validation-result {
                background: rgba(255, 255, 255, 0.22);
                padding: 20px;
                border-radius: 12px;
                margin-bottom: 20px;
                text-align: center;
                backdrop-filter: blur(12px);
                border: 1px solid rgba(255, 255, 255, 0.25);
            }
            .x8-evs-validation-result-text {
                font-size: 17px;
                font-weight: 700;
                margin: 0;
                color: #fff;
            }
            .x8-evs-decision-info {
                background: rgba(255, 255, 255, 0.12);
                padding: 18px 22px;
                border-radius: 10px;
                font-size: 13px;
                line-height: 1.8;
                backdrop-filter: blur(12px);
                border: 1px solid rgba(255, 255, 255, 0.15);
            }
            .x8-evs-decision-info p {
                margin: 8px 0;
                color: rgba(255, 255, 255, 0.98);
            }
            .x8-evs-info-section {
                margin-bottom: 0;
                padding: 35px 40px;
                background: linear-gradient(135deg, #f0f4f8 0%, #e8f0f7 100%);
                border-bottom: 1px solid rgba(102, 126, 234, 0.1);
                position: relative;
            }
            .x8-evs-info-section:nth-child(1) {
                background: linear-gradient(135deg, #f0f4f8 0%, #e8f0f7 100%);
            }
            .x8-evs-info-section:nth-child(2) {
                background: linear-gradient(135deg, #f5f0f8 0%, #ede8f5 100%);
            }
            .x8-evs-info-section:nth-child(3) {
                background: linear-gradient(135deg, #f0f8f5 0%, #e8f5f0 100%);
            }
            .x8-evs-info-section:nth-child(4) {
                background: linear-gradient(135deg, #f8f5f0 0%, #f5f0e8 100%);
            }
            .x8-evs-info-section:nth-child(5) {
                background: linear-gradient(135deg, #f0f8f8 0%, #e8f5f5 100%);
            }
            .x8-evs-info-section:nth-child(6) {
                background: linear-gradient(135deg, #f8f0f5 0%, #f5e8f0 100%);
            }
            .x8-evs-info-section:last-child {
                border-bottom: none;
            }
            .x8-evs-info-section-title {
                font-size: 22px;
                font-weight: 700;
                color: #111827;
                margin: 0 0 24px 0;
                padding-bottom: 14px;
                border-bottom: 3px solid #667eea;
                letter-spacing: -0.4px;
            }
            .x8-evs-info-grid {
                display: grid;
                grid-template-columns: repeat(auto-fit, minmax(260px, 1fr));
                gap: 18px;
            }
            .x8-evs-info-item {
                display: flex;
                flex-direction: column;
                padding: 18px 20px;
                background: rgba(255, 255, 255, 0.9);
                border-radius: 10px;
                border: 1px solid rgba(102, 126, 234, 0.2);
                transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
                box-shadow: 0 2px 8px rgba(0, 0, 0, 0.08);
                backdrop-filter: blur(10px);
            }
            .x8-evs-info-item:hover {
                border-color: #667eea;
                box-shadow: 0 4px 16px rgba(102, 126, 234, 0.25);
                transform: translateY(-2px);
                background: rgba(255, 255, 255, 1);
            }
            .x8-evs-info-label {
                font-weight: 700;
                font-size: 10px;
                color: #4b5563;
                text-transform: uppercase;
                letter-spacing: 1px;
                margin-bottom: 10px;
            }
            .x8-evs-info-value {
                font-size: 16px;
                color: #111827;
                word-break: break-word;
                font-weight: 600;
                line-height: 1.6;
            }
            .x8-evs-info-value:empty::before {
                content: "—";
                color: #9ca3af;
                font-style: italic;
                font-weight: 400;
            }
            .x8-evs-customer-images {
                display: grid;
                grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
                gap: 28px;
                margin-top: 24px;
            }
            .x8-evs-customer-image-item {
                text-align: center;
                background: rgba(255, 255, 255, 0.95);
                padding: 24px;
                border-radius: 14px;
                border: 1px solid rgba(102, 126, 234, 0.2);
                box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
                transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
                backdrop-filter: blur(10px);
            }
            .x8-evs-customer-image-item:hover {
                box-shadow: 0 8px 24px rgba(102, 126, 234, 0.3);
                transform: translateY(-4px);
                border-color: #667eea;
                background: rgba(255, 255, 255, 1);
            }
            .x8-evs-customer-image-item h4 {
                margin: 0 0 18px 0;
                font-size: 14px;
                font-weight: 700;
                color: #111827;
                text-transform: uppercase;
                letter-spacing: 1px;
            }
            .x8-evs-customer-image-item img {
                max-width: 100%;
                height: auto;
                border: 2px solid #e5e7eb;
                border-radius: 10px;
                box-shadow: 0 4px 12px rgba(0, 0, 0, 0.08);
                transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
            }
            .x8-evs-customer-image-item:hover img {
                border-color: #667eea;
                box-shadow: 0 8px 24px rgba(102, 126, 234, 0.25);
            }
            .x8-evs-loading {
                text-align: center;
                padding: 80px 20px;
                color: #646970;
                font-size: 16px;
                font-weight: 500;
                position: relative;
            }
            .x8-evs-loading:before {
                content: "";
                display: block;
                width: 40px;
                height: 40px;
                border: 4px solid #f3f3f3;
                border-top: 4px solid #2271b1;
                border-radius: 50%;
                animation: spin 1s linear infinite;
                margin: 0 auto 20px;
            }
            @keyframes spin {
                0% { transform: rotate(0deg); }
                100% { transform: rotate(360deg); }
            }
            .x8-evs-error {
                color: #d63638;
                padding: 25px 30px;
                text-align: center;
                background: #fcf0f1;
                border-radius: 8px;
                margin: 20px;
                border: 1px solid #f5c2c7;
                font-weight: 500;
            }
            .x8-evs-status-badge {
                display: inline-block;
                padding: 6px 14px;
                border-radius: 8px;
                font-size: 10px;
                font-weight: 700;
                text-transform: uppercase;
                letter-spacing: 0.8px;
                box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
            }
            .x8-evs-status-verified {
                background: #d4edda;
                color: #155724;
                border: 1px solid #c3e6cb;
            }
            .x8-evs-status-blocked {
                background: #f8d7da;
                color: #721c24;
                border: 1px solid #f5c2c7;
            }
            .x8-evs-status-pending {
                background: #fff3cd;
                color: #856404;
                border: 1px solid #ffecb5;
            }
            .x8-evs-chargeback-modal-actions {
                display: flex;
                justify-content: flex-end;
                gap: 14px;
                margin-top: 0;
                padding: 24px 40px;
                border-top: 1px solid #e5e7eb;
                background: linear-gradient(135deg, #f8f9fa 0%, #ffffff 100%);
            }
            .x8-evs-chargeback-modal-close-btn,
            .x8-evs-chargeback-modal-download-btn {
                padding: 12px 24px;
                border: 1px solid #e5e7eb;
                background: #ffffff;
                cursor: pointer;
                border-radius: 8px;
                font-size: 14px;
                font-weight: 700;
                transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
                box-shadow: 0 1px 3px rgba(0, 0, 0, 0.05);
            }
            .x8-evs-chargeback-modal-close-btn:hover {
                background: #f8f9fa;
                border-color: #d1d5db;
                transform: translateY(-1px);
                box-shadow: 0 2px 6px rgba(0, 0, 0, 0.1);
            }
            .x8-evs-chargeback-modal-download-btn {
                background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                color: #fff;
                border-color: transparent;
            }
            .x8-evs-chargeback-modal-download-btn:hover {
                transform: translateY(-2px);
                box-shadow: 0 4px 12px rgba(102, 126, 234, 0.4);
            }
            .x8-evs-activity-timeline {
                margin-top: 24px;
            }
            .x8-evs-timeline-item {
                display: flex;
                margin-bottom: 20px;
                padding: 24px;
                background: rgba(255, 255, 255, 0.95);
                border-radius: 12px;
                border: 1px solid rgba(102, 126, 234, 0.2);
                box-shadow: 0 2px 8px rgba(0, 0, 0, 0.08);
                transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
                backdrop-filter: blur(10px);
            }
            .x8-evs-timeline-item:hover {
                box-shadow: 0 6px 20px rgba(102, 126, 234, 0.25);
                border-color: #667eea;
                transform: translateX(4px);
                background: rgba(255, 255, 255, 1);
            }
            .x8-evs-timeline-item:last-child {
                margin-bottom: 0;
            }
            .x8-evs-timeline-icon {
                font-size: 32px;
                margin-right: 20px;
                flex-shrink: 0;
                width: 56px;
                height: 56px;
                display: flex;
                align-items: center;
                justify-content: center;
                background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                border-radius: 50%;
                border: 2px solid rgba(102, 126, 234, 0.2);
                box-shadow: 0 2px 8px rgba(102, 126, 234, 0.15);
            }
            .x8-evs-timeline-content {
                flex: 1;
            }
            .x8-evs-timeline-header {
                display: flex;
                justify-content: space-between;
                align-items: flex-start;
                margin-bottom: 14px;
            }
            .x8-evs-timeline-header h4 {
                margin: 0;
                font-size: 17px;
                font-weight: 700;
                color: #111827;
            }
            .x8-evs-timeline-date {
                font-size: 12px;
                color: #6b7280;
                white-space: nowrap;
                font-weight: 600;
                background: rgba(255, 255, 255, 0.9);
                padding: 6px 12px;
                border-radius: 6px;
                border: 1px solid rgba(102, 126, 234, 0.2);
                backdrop-filter: blur(5px);
            }
            .x8-evs-timeline-details {
                font-size: 14px;
                color: #6b7280;
                line-height: 1.7;
            }
            .x8-evs-timeline-details p {
                margin: 10px 0;
            }
            .x8-evs-timeline-details strong {
                color: #111827;
                font-weight: 700;
            }
            .x8-evs-activity-data {
                margin-top: 14px;
                padding: 14px 16px;
                border-top: 1px solid rgba(102, 126, 234, 0.15);
                background: rgba(255, 255, 255, 0.8);
                border-radius: 8px;
                border: 1px solid rgba(102, 126, 234, 0.15);
                backdrop-filter: blur(5px);
            }
            .x8-evs-activity-data p {
                margin: 8px 0;
            }
            .x8-evs-orders-table {
                width: 100%;
                border-collapse: separate;
                border-spacing: 0;
                margin-top: 24px;
                background: rgba(255, 255, 255, 0.95);
                border-radius: 12px;
                overflow: hidden;
                box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
                border: 1px solid rgba(102, 126, 234, 0.2);
                backdrop-filter: blur(10px);
            }
            .x8-evs-orders-table th,
            .x8-evs-orders-table td {
                padding: 16px 20px;
                text-align: left;
                border-bottom: 1px solid #e5e7eb;
            }
            .x8-evs-orders-table th {
                background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                font-weight: 700;
                font-size: 10px;
                text-transform: uppercase;
                color: #fff;
                letter-spacing: 1.2px;
                border-bottom: none;
            }
            .x8-evs-orders-table th:first-child {
                border-top-left-radius: 12px;
            }
            .x8-evs-orders-table th:last-child {
                border-top-right-radius: 12px;
            }
            .x8-evs-orders-table td {
                font-size: 14px;
                color: #111827;
                background: rgba(255, 255, 255, 0.95);
                font-weight: 500;
            }
            .x8-evs-orders-table tbody tr {
                transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
            }
            .x8-evs-orders-table tbody tr:hover {
                background: rgba(255, 255, 255, 1);
                box-shadow: 0 2px 8px rgba(102, 126, 234, 0.15);
            }
            .x8-evs-orders-table tbody tr:last-child td:first-child {
                border-bottom-left-radius: 12px;
            }
            .x8-evs-orders-table tbody tr:last-child td:last-child {
                border-bottom-right-radius: 12px;
            }
            .x8-evs-orders-table tbody tr:last-child td {
                border-bottom: none;
            }
            .x8-evs-order-status {
                display: inline-block;
                padding: 6px 14px;
                border-radius: 8px;
                font-size: 10px;
                font-weight: 700;
                text-transform: uppercase;
                letter-spacing: 0.8px;
                box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
            }
            .x8-evs-order-status-completed {
                background: #d4edda;
                color: #155724;
                border: 1px solid #c3e6cb;
            }
            .x8-evs-order-status-processing {
                background: #cce5ff;
                color: #004085;
                border: 1px solid #b3d7ff;
            }
            .x8-evs-order-status-pending {
                background: #fff3cd;
                color: #856404;
                border: 1px solid #ffecb5;
            }
            .x8-evs-order-status-cancelled,
            .x8-evs-order-status-failed {
                background: #f8d7da;
                color: #721c24;
                border: 1px solid #f5c2c7;
            }
            .x8-evs-order-status-refunded {
                background: #e2e3e5;
                color: #383d41;
                border: 1px solid #d6d8db;
            }
            .x8-evs-order-link {
                color: #667eea;
                text-decoration: none;
                font-weight: 700;
                transition: all 0.2s ease;
            }
            .x8-evs-order-link:hover {
                color: #764ba2;
                text-decoration: underline;
            }
            @media print {
                @page {
                    margin: 1cm;
                    size: A4;
                }
                * {
                    -webkit-print-color-adjust: exact !important;
                    print-color-adjust: exact !important;
                    color-adjust: exact !important;
                }
                body.x8-evs-printing * {
                    visibility: hidden;
                }
                body.x8-evs-printing .x8-evs-chargeback-modal,
                body.x8-evs-printing .x8-evs-chargeback-modal * {
                    visibility: visible !important;
                }
                .x8-evs-chargeback-modal {
                    display: block !important;
                    position: absolute !important;
                    left: 0 !important;
                    top: 0 !important;
                    width: 100% !important;
                    height: auto !important;
                    background: white !important;
                    z-index: 999999 !important;
                    overflow: visible !important;
                    margin: 0 !important;
                    padding: 0 !important;
                }
                .x8-evs-chargeback-modal-content {
                    margin: 0 !important;
                    padding: 0 !important;
                    box-shadow: none !important;
                    border: none !important;
                    width: 100% !important;
                    max-width: 100% !important;
                    height: auto !important;
                    overflow: visible !important;
                }
                .x8-evs-chargeback-modal-body {
                    max-height: none !important;
                    overflow: visible !important;
                    height: auto !important;
                    padding: 0 !important;
                }
                .x8-evs-chargeback-modal-actions {
                    display: none !important;
                }
                .x8-evs-customer-info {
                    padding: 20px !important;
                }
                .x8-evs-document-analysis {
                    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%) !important;
                    -webkit-print-color-adjust: exact !important;
                    print-color-adjust: exact !important;
                    page-break-inside: avoid;
                    break-inside: avoid;
                    padding: 20px !important;
                }
                .x8-evs-info-section {
                    page-break-inside: avoid;
                    break-inside: avoid;
                    margin-bottom: 20px !important;
                    padding-bottom: 15px !important;
                }
                .x8-evs-info-section-title {
                    page-break-after: avoid;
                }
                .x8-evs-customer-images {
                    page-break-inside: avoid;
                    break-inside: avoid;
                }
                .x8-evs-customer-image-item {
                    page-break-inside: avoid;
                    break-inside: avoid;
                }
                .x8-evs-orders-table {
                    page-break-inside: auto;
                    width: 100% !important;
                }
                .x8-evs-orders-table thead {
                    display: table-header-group;
                }
                .x8-evs-orders-table tbody {
                    display: table-row-group;
                }
                .x8-evs-orders-table tr {
                    page-break-inside: avoid;
                    break-inside: avoid;
                }
                .x8-evs-activity-timeline {
                    page-break-inside: auto;
                }
                .x8-evs-timeline-item {
                    page-break-inside: avoid;
                    break-inside: avoid;
                    margin-bottom: 15px !important;
                }
                .x8-evs-confidence-score {
                    background: rgba(255, 255, 255, 0.15) !important;
                    -webkit-print-color-adjust: exact !important;
                    print-color-adjust: exact !important;
                }
                .x8-evs-status-badge,
                .x8-evs-order-status {
                    -webkit-print-color-adjust: exact !important;
                    print-color-adjust: exact !important;
                }
                a[href]:after {
                    content: "" !important;
                }
                .x8-evs-order-link {
                    color: #2271b1 !important;
                    text-decoration: underline !important;
                }
                img {
                    max-width: 100% !important;
                    height: auto !important;
                    page-break-inside: avoid;
                    break-inside: avoid;
                }
                .x8-evs-loading,
                .x8-evs-error {
                    page-break-inside: avoid;
                }
                .x8-evs-info-grid {
                    page-break-inside: auto;
                }
                .x8-evs-info-item {
                    page-break-inside: avoid;
                    break-inside: avoid;
                }
            }
        ');

        // Add inline script
        wp_add_inline_script('jquery', '
            jQuery(document).ready(function($) {
                // Add modal HTML to page (without header)
                $("body").append(\'<div id="x8-evs-chargeback-modal" class="x8-evs-chargeback-modal"><div class="x8-evs-chargeback-modal-content"><div class="x8-evs-chargeback-modal-body"><div class="x8-evs-loading">Loading customer information...</div></div><div class="x8-evs-chargeback-modal-actions"><button type="button" class="x8-evs-chargeback-modal-download-btn">Download</button><button type="button" class="x8-evs-chargeback-modal-close-btn">Close</button></div></div></div>\');

                // Helper function to format value
                function formatValue(value) {
                    return value && value !== \'\' ? value : \'—\';
                }
                
                // Helper function to check if value has actual data
                function hasValue(value) {
                    if (value === null || value === undefined || value === \'\') return false;
                    if (value === \'—\' || value === \'-\' || value === \'—\') return false;
                    // Allow 0 and false as valid values
                    if (value === 0 || value === false) return true;
                    // Check if it\'s a string that\'s just whitespace or dashes
                    if (typeof value === \'string\') {
                        var trimmed = value.trim();
                        if (trimmed === \'\' || trimmed === \'—\' || trimmed === \'-\') return false;
                    }
                    return true;
                }
                
                // Helper function to render info item only if value exists
                function renderInfoItem(label, value) {
                    if (!hasValue(value)) return \'\';
                    return \'<div class="x8-evs-info-item"><span class="x8-evs-info-label">\' + label + \'</span><span class="x8-evs-info-value">\' + formatValue(value) + \'</span></div>\';
                }
                
                // Helper function to render info item with badge (for status fields)
                function renderInfoItemWithBadge(label, value, badgeClass) {
                    if (!hasValue(value)) return \'\';
                    var badgeHtml = \'<span class="x8-evs-status-badge \' + badgeClass + \'">\' + formatValue(value) + \'</span>\';
                    return \'<div class="x8-evs-info-item"><span class="x8-evs-info-label">\' + label + \'</span><span class="x8-evs-info-value">\' + badgeHtml + \'</span></div>\';
                }
                
                // Helper function to get status badge class
                function getStatusClass(status) {
                    if (!status) return \'x8-evs-status-pending\';
                    status = status.toLowerCase();
                    if (status === \'verified\' || status === \'pass\') return \'x8-evs-status-verified\';
                    if (status === \'block\' || status === \'blocked\' || status === \'fail\') return \'x8-evs-status-blocked\';
                    return \'x8-evs-status-pending\';
                }
                
                // Helper function to get order status class
                function getOrderStatusClass(status) {
                    if (!status) return \'x8-evs-order-status-pending\';
                    status = status.toLowerCase();
                    if (status === \'completed\') return \'x8-evs-order-status-completed\';
                    if (status === \'processing\' || status === \'on-hold\') return \'x8-evs-order-status-processing\';
                    if (status === \'pending\' || status === \'pending-payment\') return \'x8-evs-order-status-pending\';
                    if (status === \'cancelled\' || status === \'failed\') return \'x8-evs-order-status-cancelled\';
                    if (status === \'refunded\') return \'x8-evs-order-status-refunded\';
                    return \'x8-evs-order-status-pending\';
                }
                
                // Helper function to format order status
                function formatOrderStatus(status) {
                    if (!status) return \'—\';
                    return status.replace(/-/g, \' \').replace(/\\b\\w/g, function(l) { return l.toUpperCase(); });
                }
                
                // Helper function to get activity icon
                function getActivityIcon(activityType) {
                    var icons = {
                        \'link_generated\': \'🔗\',
                        \'verification_completed\': \'✅\',
                        \'verification_failed\': \'❌\',
                        \'access_blocked\': \'🚫\',
                        \'login\': \'🔑\',
                        \'logout\': \'🚪\'
                    };
                    return icons[activityType] || \'📝\';
                }
                
                // Helper function to get activity title
                function getActivityTitle(activityType) {
                    var titles = {
                        \'link_generated\': \'Verification Link Generated\',
                        \'verification_completed\': \'Verification Completed\',
                        \'verification_failed\': \'Verification Failed\',
                        \'access_blocked\': \'Access Blocked\',
                        \'login\': \'User Login\',
                        \'logout\': \'User Logout\'
                    };
                    return titles[activityType] || activityType.replace(/_/g, \' \').replace(/\\b\\w/g, function(l) { return l.toUpperCase(); });
                }
                
                // Helper function to render activity data
                function renderActivityData(activityType, data) {
                    if (!data || Object.keys(data).length === 0) return \'\';
                    var html = \'<div class="x8-evs-activity-data">\';
                    switch(activityType) {
                        case \'link_generated\':
                            if (data.transaction_id) html += \'<p><strong>Transaction ID:</strong> \' + data.transaction_id + \'</p>\';
                            if (data.document_type) html += \'<p><strong>Document Type:</strong> \' + data.document_type + \'</p>\';
                            if (data.is_regenerate) html += \'<p><strong>Type:</strong> Regenerated Link</p>\';
                            break;
                        case \'verification_completed\':
                            if (data.status) html += \'<p><strong>Result:</strong> <span class="x8-evs-status-badge \' + getStatusClass(data.status) + \'">\' + (data.status.charAt(0).toUpperCase() + data.status.slice(1)) + \'</span></p>\';
                            if (data.confidence_score) html += \'<p><strong>Confidence Score:</strong> \' + data.confidence_score + \'%</p>\';
                            break;
                        case \'verification_failed\':
                            if (data.error_code) html += \'<p><strong>Error Code:</strong> \' + data.error_code + \'</p>\';
                            if (data.error_detail) html += \'<p><strong>Error Detail:</strong> \' + data.error_detail + \'</p>\';
                            break;
                        case \'access_blocked\':
                            if (data.blocking_info && data.blocking_info.reason) html += \'<p><strong>Reason:</strong> \' + data.blocking_info.reason + \'</p>\';
                            break;
                    }
                    html += \'</div>\';
                    return html;
                }
                
                // Function to render customer info
                function renderCustomerInfo(data) {
                    var html = \'\';
                    
                    // Document Analysis Section (at the top)
                    if (data.document_analysis) {
                        var analysis = data.document_analysis;
                        html += \'<div class="x8-evs-document-analysis">\';
                        html += \'<h3 class="x8-evs-document-analysis-title">Document Analysis</h3>\';
                        
                        // Confidence Scores
                        html += \'<div class="x8-evs-confidence-scores">\';
                        if (analysis.total_confidence > 0) {
                            html += \'<div class="x8-evs-confidence-score"><span class="x8-evs-confidence-label">Total Confidence</span><span class="x8-evs-confidence-value">\' + analysis.total_confidence + \'%</span></div>\';
                        }
                        if (analysis.face_verification_confidence > 0) {
                            html += \'<div class="x8-evs-confidence-score"><span class="x8-evs-confidence-label">Face Verification Confidence</span><span class="x8-evs-confidence-value">\' + analysis.face_verification_confidence + \'%</span></div>\';
                        }
                        if (analysis.selfie_authenticity_confidence > 0) {
                            html += \'<div class="x8-evs-confidence-score"><span class="x8-evs-confidence-label">Selfie Authenticity Confidence</span><span class="x8-evs-confidence-value">\' + analysis.selfie_authenticity_confidence + \'%</span></div>\';
                        }
                        html += \'</div>\';
                        
                        // Validation Result
                        if (analysis.validation_result_description) {
                            html += \'<div class="x8-evs-validation-result"><p class="x8-evs-validation-result-text">\' + analysis.validation_result_description + \'</p></div>\';
                        }
                        
                        // Decision Info
                        if (analysis.decision_confidence_text || analysis.threshold_info_text) {
                            html += \'<div class="x8-evs-decision-info">\';
                            if (analysis.decision_confidence_text) {
                                html += \'<p>\' + analysis.decision_confidence_text + \'</p>\';
                            }
                            if (analysis.threshold_info_text) {
                                html += \'<p>\' + analysis.threshold_info_text + \'</p>\';
                            }
                            html += \'</div>\';
                        }
                        
                        html += \'</div>\';
                    }
                    
                    html += \'<div class="x8-evs-customer-info">\';
                    
                    // Customer Information Section
                    var customerInfoItems = renderInfoItem(\'Customer ID\', data.customer_id) +
                        renderInfoItem(\'Full Name\', data.full_name) +
                        renderInfoItem(\'Email\', data.email) +
                        renderInfoItem(\'Phone\', data.phone) +
                        renderInfoItem(\'Username\', data.username);
                    if (customerInfoItems) {
                        html += \'<div class="x8-evs-info-section">\';
                        html += \'<h3 class="x8-evs-info-section-title">Customer Information</h3>\';
                        html += \'<div class="x8-evs-info-grid">\' + customerInfoItems + \'</div></div>\';
                    }
                    
                    // Personal Details Section
                    var personalDetailsItems = renderInfoItem(\'Gender\', data.gender) +
                        renderInfoItem(\'Date of Birth\', data.date_of_birth) +
                        renderInfoItem(\'Age\', data.calculated_age ? data.calculated_age + \' years\' : null);
                    if (personalDetailsItems) {
                        html += \'<div class="x8-evs-info-section">\';
                        html += \'<h3 class="x8-evs-info-section-title">Personal Details</h3>\';
                        html += \'<div class="x8-evs-info-grid">\' + personalDetailsItems + \'</div></div>\';
                    }
                    
                    // Document Information Section
                    var documentInfoItems = renderInfoItem(\'Document Type\', data.document_type) +
                        renderInfoItem(\'Document Number\', data.document_number) +
                        renderInfoItem(\'Issue Date\', data.document_issue_date) +
                        renderInfoItem(\'Expiry Date\', data.document_expiry_date);
                    if (documentInfoItems) {
                        html += \'<div class="x8-evs-info-section">\';
                        html += \'<h3 class="x8-evs-info-section-title">Document Information</h3>\';
                        html += \'<div class="x8-evs-info-grid">\' + documentInfoItems + \'</div></div>\';
                    }
                    
                    // Address Information Section
                    var addressItems = renderInfoItem(\'Address (Document)\', data.address) +
                        renderInfoItem(\'City\', data.city) +
                        renderInfoItem(\'State\', data.state) +
                        renderInfoItem(\'ZIP Code\', data.zip) +
                        renderInfoItem(\'Country\', data.country) +
                        renderInfoItem(\'Billing Address\', data.billing_address) +
                        renderInfoItem(\'Billing City\', data.billing_city) +
                        renderInfoItem(\'Billing State\', data.billing_state) +
                        renderInfoItem(\'Billing ZIP\', data.billing_postcode) +
                        renderInfoItem(\'Billing Country\', data.billing_country);
                    if (addressItems) {
                        html += \'<div class="x8-evs-info-section">\';
                        html += \'<h3 class="x8-evs-info-section-title">Address Information</h3>\';
                        html += \'<div class="x8-evs-info-grid">\' + addressItems + \'</div></div>\';
                    }
                    
                    // Verification Information Section
                    var verificationItems = renderInfoItemWithBadge(\'Account Status\', data.account_status, getStatusClass(data.account_status)) +
                        renderInfoItem(\'Verification Status\', data.verification_status) +
                        renderInfoItem(\'Verification Date\', data.verification_date) +
                        renderInfoItem(\'Transaction ID\', data.transaction_id) +
                        renderInfoItem(\'Transaction Date\', data.transaction_date);
                    if (verificationItems) {
                        html += \'<div class="x8-evs-info-section">\';
                        html += \'<h3 class="x8-evs-info-section-title">Verification Information</h3>\';
                        html += \'<div class="x8-evs-info-grid">\' + verificationItems + \'</div></div>\';
                    }
                    
                    // Document Images Section (right below Verification Information)
                    var hasImages = data.document_front_image || data.document_back_image || data.document_portrait_image;
                    if (hasImages) {
                        html += \'<div class="x8-evs-info-section">\';
                        html += \'<h3 class="x8-evs-info-section-title">Document Images</h3>\';
                        html += \'<div class="x8-evs-customer-images">\';
                        if (data.document_front_image) {
                            html += \'<div class="x8-evs-customer-image-item"><h4>ID Card Front</h4><img src="\' + data.document_front_image + \'" alt="ID Card Front" /></div>\';
                        }
                        if (data.document_back_image) {
                            html += \'<div class="x8-evs-customer-image-item"><h4>ID Card Back</h4><img src="\' + data.document_back_image + \'" alt="ID Card Back" /></div>\';
                        }
                        if (data.document_portrait_image) {
                            html += \'<div class="x8-evs-customer-image-item"><h4>Selfie</h4><img src="\' + data.document_portrait_image + \'" alt="Selfie" /></div>\';
                        }
                        html += \'</div></div>\';
                    }
                    
                    // Order Information Section
                    var orderTotal = data.order_total ? \'$\' + parseFloat(data.order_total).toFixed(2) : null;
                    var orderInfoItems = renderInfoItem(\'Order ID\', data.order_id ? \'#\' + data.order_id : null) +
                        renderInfoItem(\'Order Date\', data.order_date) +
                        renderInfoItem(\'Order Status\', data.order_status) +
                        renderInfoItem(\'Order Total\', orderTotal);
                    if (orderInfoItems) {
                        html += \'<div class="x8-evs-info-section">\';
                        html += \'<h3 class="x8-evs-info-section-title">Order Information</h3>\';
                        html += \'<div class="x8-evs-info-grid">\' + orderInfoItems + \'</div></div>\';
                    }
                    
                    // Previous Orders Section
                    if (data.orders && data.orders.length > 0) {
                        html += \'<div class="x8-evs-info-section">\';
                        html += \'<h3 class="x8-evs-info-section-title">Previous Orders (\' + data.orders.length + \')</h3>\';
                        html += \'<table class="x8-evs-orders-table">\';
                        html += \'<thead><tr><th>Order #</th><th>Date</th><th>Status</th><th>Items</th><th>Total</th><th>Payment Method</th></tr></thead>\';
                        html += \'<tbody>\';
                        for (var i = 0; i < data.orders.length; i++) {
                            var order = data.orders[i];
                            html += \'<tr>\';
                            html += \'<td><a href="\' + (order.order_url || \'#\') + \'" class="x8-evs-order-link" target="_blank">#\' + formatValue(order.order_number) + \'</a></td>\';
                            html += \'<td>\' + formatValue(order.order_date) + \'</td>\';
                            html += \'<td><span class="x8-evs-order-status \' + getOrderStatusClass(order.order_status) + \'">\' + formatOrderStatus(order.order_status) + \'</span></td>\';
                            html += \'<td>\' + (order.order_item_count || 0) + \'</td>\';
                            html += \'<td>\' + (order.order_currency || \'$\') + (order.order_total ? parseFloat(order.order_total).toFixed(2) : \'0.00\') + \'</td>\';
                            html += \'<td>\' + formatValue(order.order_payment_method) + \'</td>\';
                            html += \'</tr>\';
                        }
                        html += \'</tbody></table></div>\';
                    }
                    
                    // Activity Timeline Section
                    if (data.activity_log && data.activity_log.length > 0) {
                        html += \'<div class="x8-evs-info-section">\';
                        html += \'<h3 class="x8-evs-info-section-title">Activity Timeline</h3>\';
                        html += \'<div class="x8-evs-activity-timeline">\';
                        for (var i = 0; i < data.activity_log.length; i++) {
                            var activity = data.activity_log[i];
                            var location = activity.geolocation || {};
                            var locationString = \'Unknown Location\';
                            if (location.city && location.region && location.country) {
                                locationString = location.city + \', \' + location.region + \', \' + location.country;
                            }
                            var ipAddress = activity.ip_address || \'Unknown\';
                            var timestamp = activity.timestamp || \'Unknown\';
                            
                            html += \'<div class="x8-evs-timeline-item">\';
                            html += \'<div class="x8-evs-timeline-icon">\' + getActivityIcon(activity.activity_type) + \'</div>\';
                            html += \'<div class="x8-evs-timeline-content">\';
                            html += \'<div class="x8-evs-timeline-header">\';
                            html += \'<h4>\' + getActivityTitle(activity.activity_type) + \'</h4>\';
                            html += \'<span class="x8-evs-timeline-date">\' + timestamp + \'</span>\';
                            html += \'</div>\';
                            html += \'<div class="x8-evs-timeline-details">\';
                            html += \'<p><strong>Location:</strong> \' + locationString + \'</p>\';
                            html += \'<p><strong>IP Address:</strong> \' + ipAddress + \'</p>\';
                            if (activity.data) {
                                html += renderActivityData(activity.activity_type, activity.data);
                            }
                            html += \'</div>\';
                            html += \'</div>\';
                            html += \'</div>\';
                        }
                        html += \'</div></div>\';
                    }
                    
                    html += \'</div>\';
                    return html;
                }

                // Store customer data globally for print filename
                var currentCustomerData = null;
                
                // Open modal when button is clicked
                $(document).on("click", ".x8-evs-create-chargeback-btn", function(e) {
                    e.preventDefault();
                    var orderId = $(this).data("order-id");
                    var $modal = $("#x8-evs-chargeback-modal");
                    var $body = $modal.find(".x8-evs-chargeback-modal-body");
                    
                    // Show loading
                    $body.html(\'<div class="x8-evs-loading">Loading customer information...</div>\');
                    $modal.fadeIn();
                    
                    // Fetch customer info
                    $.ajax({
                        url: x8_evs_chargeback.ajax_url,
                        type: "POST",
                        data: {
                            action: "x8_evs_get_customer_info",
                            order_id: orderId,
                            nonce: x8_evs_chargeback.nonce
                        },
                        success: function(response) {
                            if (response.success && response.data) {
                                // Store customer data for print filename
                                currentCustomerData = response.data;
                                $body.html(renderCustomerInfo(response.data));
                            } else {
                                currentCustomerData = null;
                                $body.html(\'<div class="x8-evs-error">\' + (response.data && response.data.message ? response.data.message : \'Failed to load customer information\') + \'</div>\');
                            }
                        },
                        error: function() {
                            currentCustomerData = null;
                            $body.html(\'<div class="x8-evs-error">Error loading customer information. Please try again.</div>\');
                        }
                    });
                });

                // Close modal when close button is clicked
                $(document).on("click", ".x8-evs-chargeback-modal-close-btn", function() {
                    $("#x8-evs-chargeback-modal").fadeOut();
                });

                // Download functionality – request PDF from server (Dompdf)
                $(document).on("click", ".x8-evs-chargeback-modal-download-btn", function() {
                    if (!currentCustomerData || !currentCustomerData.order_id) {
                        return;
                    }
                    var pdfUrl = x8_evs_chargeback.ajax_url + "?action=x8_evs_chargeback_pdf&order_id=" + encodeURIComponent(currentCustomerData.order_id) + "&nonce=" + encodeURIComponent(x8_evs_chargeback.nonce);
                    window.location.href = pdfUrl;
                });

                // Close modal when clicking outside of it
                $(window).on("click", function(event) {
                    if ($(event.target).hasClass("x8-evs-chargeback-modal")) {
                        $("#x8-evs-chargeback-modal").fadeOut();
                    }
                });
            });
        ', 'after');
    }
} 