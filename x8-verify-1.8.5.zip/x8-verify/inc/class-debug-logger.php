<?php
/**
 * Verification Debug Logger
 *
 * Always-on logging for the verification pipeline (API submissions, webhooks,
 * status decisions) so admins can see exactly what happened for a customer
 * without needing WP_DEBUG or server log access.
 *
 * @package X8_EVS
 * @since 1.7
 */

// If this file is called directly, abort.
if (!defined('WPINC')) {
    die;
}

class X8_EVS_Debug_Logger {

    const USER_META_KEY = 'x8_evs_debug_trail';
    const MAX_TRAIL_ENTRIES = 50;

    /**
     * Log a verification pipeline event.
     *
     * Writes to wp-content/uploads/x8-evs-logs/verification-debug.log and,
     * when a user id is provided, appends to that user's debug trail
     * (shown on the admin customer detail page).
     *
     * @param string $event   Short event key, e.g. 'webhook_received', 'api_request'.
     * @param string $message Human-readable description.
     * @param array  $context Extra data (will be sanitized; images/credentials stripped).
     * @param int    $user_id Related customer/user id (0 = not user specific).
     */
    public static function log($event, $message, $context = array(), $user_id = 0) {
        $context = self::sanitize_context($context);

        $entry = array(
            'timestamp' => current_time('mysql'),
            'event'     => $event,
            'message'   => $message,
            'user_id'   => (int) $user_id,
            'context'   => $context,
        );

        self::write_to_file($entry);

        if ($user_id) {
            self::append_to_user_trail((int) $user_id, $entry);
        }
    }

    /**
     * Get the debug trail for a user (newest first).
     *
     * @param int $user_id
     * @return array
     */
    public static function get_trail($user_id) {
        $trail = get_user_meta($user_id, self::USER_META_KEY, true);
        if (!is_array($trail)) {
            return array();
        }
        return array_reverse($trail);
    }

    /**
     * Path to the shared debug log file.
     *
     * @return string
     */
    public static function get_log_file_path() {
        $upload_dir = wp_upload_dir();
        return trailingslashit($upload_dir['basedir']) . 'x8-evs-logs/verification-debug.log';
    }

    /**
     * Append entry to the log file, creating a protected directory if needed.
     */
    private static function write_to_file($entry) {
        $log_file = self::get_log_file_path();
        $log_dir = dirname($log_file);

        if (!file_exists($log_dir)) {
            wp_mkdir_p($log_dir);
            // Block direct web access to the logs directory.
            @file_put_contents($log_dir . '/.htaccess', "Deny from all\n");
            @file_put_contents($log_dir . '/index.php', "<?php // Silence is golden.\n");
        }

        $line = sprintf(
            "[%s] [%s] [user:%d] %s %s\n",
            $entry['timestamp'],
            $entry['event'],
            $entry['user_id'],
            $entry['message'],
            !empty($entry['context']) ? wp_json_encode($entry['context']) : ''
        );

        @file_put_contents($log_file, $line, FILE_APPEND | LOCK_EX);
    }

    /**
     * Append entry to the per-user trail, keeping only the most recent entries.
     */
    private static function append_to_user_trail($user_id, $entry) {
        $trail = get_user_meta($user_id, self::USER_META_KEY, true);
        if (!is_array($trail)) {
            $trail = array();
        }

        $trail[] = $entry;

        if (count($trail) > self::MAX_TRAIL_ENTRIES) {
            $trail = array_slice($trail, -self::MAX_TRAIL_ENTRIES);
        }

        update_user_meta($user_id, self::USER_META_KEY, $trail);
    }

    /**
     * Strip sensitive/huge values (base64 images, credentials) from context
     * so the log stays readable and safe.
     */
    private static function sanitize_context($context) {
        if (!is_array($context)) {
            return array();
        }

        $sensitive_keys = array('password', 'username', 'credentials');
        $image_keys = array('frontimage', 'backimage', 'portraitimage');

        $sanitized = array();
        foreach ($context as $key => $value) {
            $lower_key = strtolower((string) $key);

            if (in_array($lower_key, $sensitive_keys, true)) {
                $sanitized[$key] = '[redacted]';
                continue;
            }

            if (in_array($lower_key, $image_keys, true)) {
                $sanitized[$key] = is_string($value) ? '[image, ' . strlen($value) . ' bytes base64]' : '[image]';
                continue;
            }

            if (is_array($value)) {
                $sanitized[$key] = self::sanitize_context($value);
                continue;
            }

            // Truncate very long strings (e.g. unexpected raw payloads).
            if (is_string($value) && strlen($value) > 2000) {
                $sanitized[$key] = substr($value, 0, 2000) . '... [truncated, ' . strlen($value) . ' chars total]';
                continue;
            }

            $sanitized[$key] = $value;
        }

        return $sanitized;
    }
}
