<?php
/**
 * Admin Settings Class
 *
 * @package X8_EVS
 * @since 1.0.0
 */

// If this file is called directly, abort.
if (!defined('WPINC')) {
    die;
}

/**
 * X8 Verify Admin Settings Class
 */
class X8_EVS_Admin_Settings {

    /**
     * Initialize the settings
     */
    public function __construct() {
        add_action('admin_menu', array($this, 'add_admin_menu'));
        add_action('admin_init', array($this, 'register_settings'));
        add_action('admin_enqueue_scripts', array($this, 'enqueue_admin_scripts'));
        
        // AJAX handlers
        add_action('wp_ajax_x8_evs_update_customer_status', array($this, 'handle_update_customer_status'));
        add_action('wp_ajax_x8_evs_fetch_blacklist_entries', array($this, 'handle_fetch_blacklist_entries'));
        add_action('wp_ajax_x8_evs_sync_blacklist_status', array($this, 'handle_sync_blacklist_status'));
        add_action('wp_ajax_x8_evs_sync_all_blacklist_status', array($this, 'handle_sync_all_blacklist_status'));
        add_action('wp_ajax_x8_evs_request_new_documents', array($this, 'handle_request_new_documents'));
        add_action('wp_ajax_x8_evs_clear_geo_cache', array($this, 'handle_clear_geo_cache'));
        add_action('wp_ajax_x8_evs_clear_blocking_cache', array($this, 'handle_clear_blocking_cache'));
        add_action('wp_ajax_x8_evs_clear_vpn_cache', array($this, 'handle_clear_vpn_cache'));
        add_action('wp_ajax_x8_evs_get_cache_stats', array($this, 'handle_get_cache_stats'));
        add_action('wp_ajax_x8_evs_filter_customers', array($this, 'handle_filter_customers'));
        add_action('wp_ajax_x8_evs_clear_verification_links', array($this, 'handle_clear_verification_links'));
        add_action('admin_init', array($this, 'maybe_export_customers'));
        
        // Clear cached blocking/geolocation decisions when the location provider changes
        add_action('update_option_x8_evs_location_provider', array($this, 'clear_caches_on_location_provider_change'), 10, 2);
    }

    /**
     * Clear all blocking, geolocation, and VPN caches when the location
     * detection service is switched, so old decisions don't linger.
     */
    public function clear_caches_on_location_provider_change($old_value, $new_value) {
        if ($old_value === $new_value) {
            return;
        }
        
        if (!class_exists('X8_EVS_Blocking_Handler')) {
            require_once X8_EVS_PLUGIN_PATH . 'inc/frontend/class-blocking-handler.php';
        }
        
        X8_EVS_Blocking_Handler::clear_all_blocking_cache();
        X8_EVS_Blocking_Handler::clear_geolocation_cache();
        X8_EVS_Blocking_Handler::clear_vpn_cache();
    }

    /**
     * Roles listed on the Customers tab.
     * TapStack players are the source of truth; WooCommerce "customer" is kept as fallback.
     *
     * @return list<string>
     */
    public static function customer_list_roles() {
        return array('tapstack_player', 'customer');
    }

    /**
     * SQL EXISTS clause matching customer_list_roles().
     *
     * @param string $alias Users table alias.
     */
    public static function customer_role_sql($alias = 'u') {
        global $wpdb;
        $likes = array();
        foreach (self::customer_list_roles() as $role) {
            $likes[] = $wpdb->prepare(
                'um_role.meta_value LIKE %s',
                '%' . $wpdb->esc_like('"' . $role . '"') . '%'
            );
        }
        return "EXISTS (SELECT 1 FROM {$wpdb->usermeta} um_role WHERE {$alias}.ID = um_role.user_id AND um_role.meta_key = '{$wpdb->prefix}capabilities' AND (" . implode(' OR ', $likes) . '))';
    }

    
    /**
     * Add admin menu
     */
    public function add_admin_menu() {
        add_menu_page(
            __('X8 Verify Settings', 'x8-evs'),
            __('X8 Verify', 'x8-evs'),
            'x8_verify_access',
            'x8-evs',
            array($this, 'admin_page'),
            'dashicons-shield-alt',
            30
        );
        
        // Add Track Traffic submenu
        add_submenu_page(
            'x8-evs',
            __('Track Traffic', 'x8-evs'),
            __('Track Traffic', 'x8-evs'),
            'x8_verify_access',
            'x8-evs-track-traffic',
            array($this, 'track_traffic_page')
        );
    }

    /**
     * Register settings
     */
    public function register_settings() {
        register_setting('x8_evs_settings', 'x8_evs_username', array(
            'type' => 'string',
            'sanitize_callback' => 'sanitize_text_field',
            'default' => ''
        ));
        
        register_setting('x8_evs_settings', 'x8_evs_password', array(
            'type' => 'string',
            'sanitize_callback' => 'sanitize_text_field',
            'default' => ''
        ));

        register_setting('x8_evs_verification_settings', 'x8_evs_verification_page', array(
            'type' => 'integer',
            'sanitize_callback' => 'absint',
            'default' => 0
        ));

        register_setting('x8_evs_verification_settings', 'x8_evs_verification_trigger', array(
            'type' => 'string',
            'sanitize_callback' => 'sanitize_text_field',
            'default' => 'disabled'
        ));

        register_setting('x8_evs_verification_settings', 'x8_evs_document_type', array(
            'type' => 'string',
            'sanitize_callback' => array($this, 'sanitize_document_type_default'),
            'default' => 'DriversLicense'
        ));

        register_setting('x8_evs_verification_settings', 'x8_evs_document_types', array(
            'type' => 'array',
            'sanitize_callback' => array($this, 'sanitize_document_types'),
            'default' => array()
        ));

        register_setting('x8_evs_verification_settings', 'x8_evs_require_selfie', array(
            'type' => 'boolean',
            'sanitize_callback' => 'rest_sanitize_boolean',
            'default' => true
        ));

        register_setting('x8_evs_verification_settings', 'x8_evs_blocked_states', array(
            'type' => 'array',
            'sanitize_callback' => array($this, 'sanitize_blocked_states'),
            'default' => array()
        ));

        register_setting('x8_evs_verification_settings', 'x8_evs_allowed_countries', array(
            'type' => 'array',
            'sanitize_callback' => array($this, 'sanitize_allowed_countries'),
            'default' => array()
        ));

        register_setting('x8_evs_verification_settings', 'x8_evs_block_by_geolocation', array(
            'type' => 'boolean',
            'sanitize_callback' => 'rest_sanitize_boolean',
            'default' => false
        ));

        register_setting('x8_evs_verification_settings', 'x8_evs_block_by_id_address', array(
            'type' => 'boolean',
            'sanitize_callback' => 'rest_sanitize_boolean',
            'default' => false
        ));

        register_setting('x8_evs_verification_settings', 'x8_evs_block_by_billing_address', array(
            'type' => 'boolean',
            'sanitize_callback' => 'rest_sanitize_boolean',
            'default' => false
        ));

        register_setting('x8_evs_verification_settings', 'x8_evs_block_vpns', array(
            'type' => 'boolean',
            'sanitize_callback' => 'rest_sanitize_boolean',
            'default' => false
        ));

        register_setting('x8_evs_verification_settings', 'x8_evs_minimum_age', array(
            'type' => 'string',
            'sanitize_callback' => 'sanitize_text_field',
            'default' => '21'
        ));

        register_setting('x8_evs_verification_settings', 'x8_evs_custom_age', array(
            'type' => 'integer',
            'sanitize_callback' => 'absint',
            'default' => 25
        ));

        // Approval threshold settings
        register_setting('x8_evs_verification_settings', 'x8_evs_auto_block_threshold', array(
            'type' => 'integer',
            'sanitize_callback' => array($this, 'sanitize_auto_block_threshold'),
            'default' => 70
        ));

        register_setting('x8_evs_verification_settings', 'x8_evs_manual_review_threshold', array(
            'type' => 'integer',
            'sanitize_callback' => array($this, 'sanitize_manual_review_threshold'),
            'default' => 85
        ));

        register_setting('x8_evs_verification_settings', 'x8_evs_auto_approve_threshold', array(
            'type' => 'integer',
            'sanitize_callback' => array($this, 'sanitize_auto_approve_threshold'),
            'default' => 86
        ));

        // Selfie-specific threshold settings
        register_setting('x8_evs_verification_settings', 'x8_evs_selfie_auto_block_threshold', array(
            'type' => 'integer',
            'sanitize_callback' => array($this, 'sanitize_selfie_auto_block_threshold'),
            'default' => 75
        ));

        register_setting('x8_evs_verification_settings', 'x8_evs_selfie_manual_review_threshold', array(
            'type' => 'integer',
            'sanitize_callback' => array($this, 'sanitize_selfie_manual_review_threshold'),
            'default' => 90
        ));

        register_setting('x8_evs_verification_settings', 'x8_evs_selfie_auto_approve_threshold', array(
            'type' => 'integer',
            'sanitize_callback' => array($this, 'sanitize_selfie_auto_approve_threshold'),
            'default' => 91
        ));

        // Contact email setting
        register_setting('x8_evs_verification_settings', 'x8_evs_contact_email', array(
            'type' => 'string',
            'sanitize_callback' => 'sanitize_email',
            'default' => ''
        ));

        register_setting('x8_evs_verification_settings', 'x8_evs_manual_review_emails', array(
            'type' => 'string',
            'sanitize_callback' => array($this, 'sanitize_manual_review_emails'),
            'default' => ''
        ));

        register_setting('x8_evs_verification_settings', 'x8_evs_auto_request_reverification', array(
            'type' => 'boolean',
            'sanitize_callback' => array($this, 'sanitize_auto_request_reverification'),
            'default' => false
        ));

        register_setting('x8_evs_verification_settings', 'x8_evs_block_duplicate_license', array(
            'type' => 'boolean',
            'sanitize_callback' => array($this, 'sanitize_block_duplicate_license'),
            'default' => false
        ));

        register_setting('x8_evs_verification_settings', 'x8_evs_allow_google_bots', array(
            'type' => 'boolean',
            'sanitize_callback' => array($this, 'sanitize_allow_google_bots'),
            'default' => false
        ));

        register_setting('x8_evs_verification_settings', 'x8_evs_pending_auto_delete_days', array(
            'type' => 'integer',
            'sanitize_callback' => array($this, 'sanitize_pending_auto_delete_days'),
            'default' => 0
        ));

        register_setting('x8_evs_verification_settings', 'x8_evs_whitelist_ip_addresses', array(
            'type' => 'string',
            'sanitize_callback' => array($this, 'sanitize_whitelist_ip_addresses'),
            'default' => ''
        ));

        register_setting('x8_evs_verification_settings', 'x8_evs_location_provider', array(
            'type' => 'string',
            'sanitize_callback' => array($this, 'sanitize_location_provider'),
            'default' => 'ipapi_co'
        ));

        register_setting('x8_evs_verification_settings', 'x8_evs_assurelocate_trigger', array(
            'type' => 'string',
            'sanitize_callback' => array($this, 'sanitize_assurelocate_trigger'),
            'default' => 'after_login'
        ));

        register_setting('x8_evs_verification_settings', 'x8_evs_ipapi_co_api', array(
            'type' => 'string',
            'sanitize_callback' => 'sanitize_text_field',
            'default' => ''
        ));

        register_setting('x8_evs_verification_settings', 'x8_evs_ipgeolocation_api', array(
            'type' => 'string',
            'sanitize_callback' => 'sanitize_text_field',
            'default' => ''
        ));

        // Add settings sections and fields
        add_settings_section(
            'x8_evs_general_settings',
            __('Authentication Settings', 'x8-evs'),
            array($this, 'general_settings_section_callback'),
            'x8_evs_settings'
        );

        add_settings_field(
            'x8_evs_username',
            __('Username', 'x8-evs'),
            array($this, 'username_field_callback'),
            'x8_evs_settings',
            'x8_evs_general_settings'
        );

        add_settings_field(
            'x8_evs_password',
            __('Password', 'x8-evs'),
            array($this, 'password_field_callback'),
            'x8_evs_settings',
            'x8_evs_general_settings'
        );
    }

    /**
     * General settings section callback
     */
    public function general_settings_section_callback() {
        echo '<p>' . __('Configure your X8 Verify authentication credentials below.', 'x8-evs') . '</p>';
    }

    /**
     * Username field callback
     */
    public function username_field_callback() {
        $username = get_option('x8_evs_username', '');
        echo '<input type="text" id="x8_evs_username" name="x8_evs_username" value="' . esc_attr($username) . '" class="regular-text" />';
        echo '<p class="description">' . __('Enter your X8 Verify username.', 'x8-evs') . '</p>';
    }

    /**
     * Password field callback
     */
    public function password_field_callback() {
        $password = get_option('x8_evs_password', '');
        echo '<input type="password" id="x8_evs_password" name="x8_evs_password" value="' . esc_attr($password) . '" class="regular-text" />';
        echo '<p class="description">' . __('Enter your X8 Verify password.', 'x8-evs') . '</p>';
    }

    /**
     * Get the contact email to display to users
     * 
     * @return string The contact email address
     */
    public static function get_contact_email() {
        $contact_email = get_option('x8_evs_contact_email', '');
        
        // If custom contact email is set, use it
        if (!empty($contact_email) && is_email($contact_email)) {
            return $contact_email;
        }
        
        // Fallback to site admin email
        return get_option('admin_email', '');
    }

    /**
     * Get notification emails for manual review alerts
     *
     * @return array
     */
    public static function get_manual_review_notification_emails() {
        $raw_emails = get_option('x8_evs_manual_review_emails', '');

        if (empty($raw_emails)) {
            return array();
        }

        $emails = array_filter(array_map('trim', explode(',', $raw_emails)));
        $valid_emails = array();

        foreach ($emails as $email) {
            $sanitized_email = sanitize_email($email);
            if (!empty($sanitized_email) && is_email($sanitized_email)) {
                $valid_emails[] = $sanitized_email;
            }
        }

        return array_unique($valid_emails);
    }

    /**
     * Check if another user (excluding $exclude_user_id) has the same document license number.
     * Used when "block duplicate license" is enabled to prevent multiple accounts per license.
     *
     * @param string $license_number   License number from document (e.g. assureCard documentInformation licenseNumber).
     * @param int    $exclude_user_id User ID to exclude (the current applicant).
     * @return int|null User ID of existing account with this license, or null if none.
     */
    public static function find_existing_user_by_license_number($license_number, $exclude_user_id = 0) {
        $license_number = is_string($license_number) ? trim($license_number) : '';
        if ($license_number === '') {
            return null;
        }
        $exclude_user_id = absint($exclude_user_id);
        $users = get_users(array(
            'exclude'   => array($exclude_user_id),
            'meta_key'  => 'document_number',
            'meta_value' => $license_number,
            'number'    => 1,
            'fields'    => 'ID',
        ));
        return !empty($users) ? (int) $users[0] : null;
    }

    /**
     * Notify staff when a customer is moved to manual review
     *
     * @param int    $customer_id Customer ID.
     * @param string $context     Trigger context (manual|auto).
     * @param array  $details     Additional details to include in the email.
     */
    protected static function notify_manual_review_staff($customer_id, $context = 'auto', $details = array()) {
        $recipients = self::get_manual_review_notification_emails();
        if (empty($recipients)) {
            return;
        }

        $user = get_userdata($customer_id);
        if (!$user) {
            return;
        }

        $user_name = trim($user->first_name . ' ' . $user->last_name);
        if (empty($user_name)) {
            $user_name = $user->display_name ?: $user->user_login ?: $user->user_email;
        }

        $user_email = $user->user_email;
        $site_name  = wp_specialchars_decode(get_bloginfo('name'), ENT_QUOTES);

        $subject = sprintf(
            __('[%s] Manual review required for %s', 'x8-evs'),
            $site_name,
            $user_name
        );

        $trigger_message = ($context === 'manual')
            ? __('An administrator routed this customer to manual review.', 'x8-evs')
            : __('Automatic verification flagged this customer for manual review.', 'x8-evs');

        $customer_link = admin_url('admin.php?page=x8-evs&view_customer=' . $customer_id);

        $message  = '<p>' . esc_html($trigger_message) . '</p>';
        $message .= '<p><strong>' . esc_html__('Customer', 'x8-evs') . ':</strong> ' . esc_html($user_name) . ' (' . esc_html($user_email) . ')</p>';

        if (!empty($details['admin'])) {
            $message .= '<p><strong>' . esc_html__('Updated by', 'x8-evs') . ':</strong> ' . esc_html($details['admin']) . '</p>';
        }

        if (!empty($details['notes'])) {
            $message .= '<p><strong>' . esc_html__('Notes', 'x8-evs') . ':</strong> ' . nl2br(esc_html($details['notes'])) . '</p>';
        }

        if (!empty($details['confidence']) || !empty($details['face_confidence'])) {
            $message .= '<p><strong>' . esc_html__('Confidence Scores', 'x8-evs') . ':</strong><br />';
            if (!empty($details['confidence'])) {
                $message .= esc_html__('Total', 'x8-evs') . ': ' . esc_html($details['confidence']) . '%<br />';
            }
            if (!empty($details['face_confidence'])) {
                $message .= esc_html__('Face Verification', 'x8-evs') . ': ' . esc_html($details['face_confidence']) . '%';
            }
            $message .= '</p>';
        }

        if (!empty($details['reason'])) {
            $message .= '<p><strong>' . esc_html__('Reason', 'x8-evs') . ':</strong> ' . esc_html($details['reason']) . '</p>';
        }

        $message .= '<p><a href="' . esc_url($customer_link) . '">' . esc_html__('Review customer in X8 Verify', 'x8-evs') . '</a></p>';
        $message .= '<p style="font-size:12px;color:#6b7280;">' . esc_html__('You are receiving this email because you are listed as a manual review contact in the X8 Verify settings.', 'x8-evs') . '</p>';

        $headers = array('Content-Type: text/html; charset=UTF-8');
        wp_mail($recipients, $subject, $message, $headers);
    }

    /**
     * Admin page
     */
    public function admin_page() {
        // Check user capabilities
        if (!current_user_can('x8_verify_access')) {
            wp_die(__('You do not have sufficient permissions to access this page.', 'x8-evs'));
        }

        // Check if viewing single customer
        if (isset($_GET['view_customer']) && !empty($_GET['view_customer'])) {
            $customer_id = intval($_GET['view_customer']);
            $this->render_single_customer_page($customer_id);
            return;
        }

        // Handle form submission
        if (isset($_GET['settings-updated'])) {
            add_settings_error('x8_evs_messages', 'x8_evs_message', __('Settings saved successfully!', 'x8-evs'), 'updated');
        }

        // Show error/update messages
        settings_errors('x8_evs_messages');

        // Check if credentials are configured
        $username = get_option('x8_evs_username', '');
        $password = get_option('x8_evs_password', '');
        $credentials_configured = !empty($username) && !empty($password);

        $current_tab = $_GET['tab'] ?? 'dashboard';
        
        ?>
        <div class="wrap x8-evs-admin-container">
            <h1><?php echo esc_html(get_admin_page_title()); ?></h1>
            
            <?php if (!$credentials_configured): ?>
                <!-- Initial setup form -->
                <div class="x8-evs-welcome-section">
                    <div class="x8-evs-welcome-header">
                        <h2><?php _e('Welcome to X8 Verify Integration', 'x8-evs'); ?></h2>
                        <p><?php _e('Please enter your authentication credentials to get started.', 'x8-evs'); ?></p>
                    </div>
                    
                    <div class="x8-evs-credentials-form">
                        <form method="post" action="options.php">
                            <?php
                            settings_fields('x8_evs_settings');
                            do_settings_sections('x8_evs_settings');
                            submit_button(__('Save Credentials & Continue', 'x8-evs'), 'primary large');
                            ?>
                        </form>
                    </div>
                </div>
            <?php else: ?>
                <!-- Main dashboard with tabs -->
                <div class="x8-evs-dashboard">
                    <div class="x8-evs-header-actions">
                        <button class="button button-secondary" onclick="this.nextElementSibling.style.display='block'"><?php _e('Update Credentials', 'x8-evs'); ?></button>
                        <div class="x8-evs-credentials-update" style="display:none;">
                            <div class="x8-evs-credentials-update-header">
                                <h4><?php _e('Update Authentication Credentials', 'x8-evs'); ?></h4>
                                <button type="button" class="x8-evs-close-btn" onclick="this.closest('.x8-evs-credentials-update').style.display='none'">
                                    <span class="dashicons dashicons-no-alt"></span>
                                </button>
                            </div>
                            <form method="post" action="options.php" class="x8-evs-credentials-form-inline">
                                <?php settings_fields('x8_evs_settings'); ?>
                                <div class="x8-evs-form-row">
                                    <div class="x8-evs-form-group">
                                        <label for="x8_evs_username_update"><?php _e('Username', 'x8-evs'); ?></label>
                                        <input type="text" id="x8_evs_username_update" name="x8_evs_username" value="<?php echo esc_attr($username); ?>" class="regular-text" required />
                                    </div>
                                    <div class="x8-evs-form-group">
                                        <label for="x8_evs_password_update"><?php _e('Password', 'x8-evs'); ?></label>
                                        <input type="password" id="x8_evs_password_update" name="x8_evs_password" value="<?php echo esc_attr($password); ?>" class="regular-text" required />
                                    </div>
                                </div>
                                <div class="x8-evs-form-actions">
                                    <input type="submit" class="button button-primary" value="<?php _e('Update Credentials', 'x8-evs'); ?>" />
                                    <button type="button" class="button button-secondary" onclick="this.closest('.x8-evs-credentials-update').style.display='none'"><?php _e('Cancel', 'x8-evs'); ?></button>
                                </div>
                            </form>
                        </div>
                    </div>

                    <!-- Tab Navigation -->
                    <nav class="x8-evs-tab-nav">
                        <a href="#dashboard" class="x8-evs-tab active" data-tab="dashboard">
                            <span class="dashicons dashicons-dashboard"></span>
                            <?php _e('Dashboard', 'x8-evs'); ?>
                        </a>
                        <a href="#customers" class="x8-evs-tab" data-tab="customers">
                            <span class="dashicons dashicons-groups"></span>
                            <?php _e('Customers', 'x8-evs'); ?>
                        </a>
                        <a href="#settings" class="x8-evs-tab" data-tab="settings">
                            <span class="dashicons dashicons-admin-settings"></span>
                            <?php _e('Settings', 'x8-evs'); ?>
                        </a>
                        <a href="#cache" class="x8-evs-tab" data-tab="cache">
                            <span class="dashicons dashicons-database"></span>
                            <?php _e('Cache', 'x8-evs'); ?>
                        </a>
                        <a href="#integration" class="x8-evs-tab" data-tab="integration">
                            <span class="dashicons dashicons-admin-links"></span>
                            <?php _e('Integration', 'x8-evs'); ?>
                        </a>
                        <a href="#help" class="x8-evs-tab" data-tab="help">
                            <span class="dashicons dashicons-sos"></span>
                            <?php _e('Help', 'x8-evs'); ?>
                        </a>
                    </nav>
                  

                    <!-- Tab Content -->
                    <div class="x8-evs-tab-content">
                        <!-- Dashboard Tab -->
                        <div id="dashboard" class="x8-evs-tab-panel active">
                            <?php $this->render_dashboard_tab(); ?>
                        </div>

                        <!-- Customers Tab -->
                        <div id="customers" class="x8-evs-tab-panel">
                            <?php $this->render_customers_tab(); ?>
                        </div>

                        <!-- Settings Tab -->
                        <div id="settings" class="x8-evs-tab-panel">
                            <?php $this->render_settings_tab(); ?>
                        </div>

                        <!-- Cache Tab -->
                        <div id="cache" class="x8-evs-tab-panel">
                            <?php $this->render_cache_tab(); ?>
                        </div>

                        <!-- Integration Tab -->
                        <div id="integration" class="x8-evs-tab-panel">
                            <?php $this->render_integration_tab(); ?>
                        </div>

                        <!-- Help Tab -->
                        <div id="help" class="x8-evs-tab-panel">
                            <?php $this->render_help_tab(); ?>
                        </div>
                    </div>
                </div>
            <?php endif; ?>
        </div>
        
        <script type="text/javascript">
        jQuery(document).ready(function($) {
            console.log('X8 Verify: Inline script loaded');
            console.log('X8 Verify: Tabs found:', $('.x8-evs-tab').length);
            console.log('X8 Verify: Panels found:', $('.x8-evs-tab-panel').length);
            
            // Log specific tab information
            $('.x8-evs-tab').each(function() {
                var tabText = $(this).text().trim();
                var tabData = $(this).data('tab');
                console.log('X8 Verify: Tab - Text:', tabText, 'Data:', tabData);
            });
            
            // Check if customers panel exists
            var customersPanel = $('#customers');
            console.log('X8 Verify: Customers panel exists:', customersPanel.length);
            if (customersPanel.length > 0) {
                console.log('X8 Verify: Customers panel classes:', customersPanel.attr('class'));
                console.log('X8 Verify: Customers panel content length:', customersPanel.html().length);
            }
            
            // Fallback tab functionality
            $('.x8-evs-tab').on('click', function(e) {
                e.preventDefault();
                console.log('X8 Verify: Tab clicked (inline):', $(this).data('tab'));
                
                var $tab = $(this);
                var targetTab = $tab.data('tab');
                
                // Remove active class from all tabs and panels
                $('.x8-evs-tab').removeClass('active');
                $('.x8-evs-tab-panel').removeClass('active');
                
                // Add active class to clicked tab and corresponding panel
                $tab.addClass('active');
                var $targetPanel = $('#' + targetTab);
                console.log('X8 Verify: Target panel for', targetTab, ':', $targetPanel.length);
                
                if ($targetPanel.length > 0) {
                    $targetPanel.addClass('active');
                    console.log('X8 Verify: Tab switched to:', targetTab);
                } else {
                    console.error('X8 Verify: Panel not found for tab:', targetTab);
                }
            });
            
            // Stat card click functionality
            $('.x8-evs-stat-card').on('click', function(e) {
                e.preventDefault();
                var filter = $(this).data('filter');
                console.log('X8 Verify: Stat card clicked with filter:', filter);
                
                // Switch to customers tab
                $('.x8-evs-tab[data-tab="customers"]').click();
                
                // Set the filter after a short delay to ensure tab is loaded
                setTimeout(function() {
                    var statusFilter = $('.x8-evs-status-filter');
                    if (statusFilter.length > 0) {
                        // Handle "all" filter by setting empty value
                        var filterValue = filter === 'all' ? '' : filter;
                        statusFilter.val(filterValue);
                        console.log('X8 Verify: Filter set to:', filterValue);
                        
                        // Trigger change event to apply filter
                        statusFilter.trigger('change');
                    } else {
                        console.error('X8 Verify: Status filter not found');
                    }
                }, 100);
            });
            
            // Test customers tab specifically
            setTimeout(function() {
                console.log('X8 Verify: Testing customers tab...');
                var customersTab = $('.x8-evs-tab[data-tab="customers"]');
                var customersPanel = $('#customers');
                console.log('X8 Verify: Customers tab found:', customersTab.length);
                console.log('X8 Verify: Customers panel found:', customersPanel.length);
                
                if (customersTab.length > 0 && customersPanel.length > 0) {
                    console.log('X8 Verify: Both customers tab and panel exist');
                } else {
                    console.error('X8 Verify: Missing customers tab or panel');
                }
            }, 1000);
        });
        </script>
        <?php
    }

    /**
     * Render Dashboard Tab
     */
    private function render_dashboard_tab() {
        // Get verification statistics
        $stats = $this->get_verification_stats();
        
        ?>
        <div class="x8-evs-dashboard-content">
            <div class="x8-evs-status-overview">
                <h2><?php _e('System Status', 'x8-evs'); ?></h2>
                <div class="x8-evs-status-cards">
                    <div class="x8-evs-status-card">
                        <div class="x8-evs-status-icon success">
                            <span class="dashicons dashicons-yes-alt"></span>
                        </div>
                        <div class="x8-evs-status-content">
                            <h3><?php _e('Connection Status', 'x8-evs'); ?></h3>
                            <p><?php _e('Connected to X8 Verify API', 'x8-evs'); ?></p>
                        </div>
                    </div>
                    <div class="x8-evs-status-card">
                        <div class="x8-evs-status-icon info">
                            <span class="dashicons dashicons-admin-users"></span>
                        </div>
                        <div class="x8-evs-status-content">
                            <h3><?php _e('Active User', 'x8-evs'); ?></h3>
                            <p><?php echo esc_html(get_option('x8_evs_username', '')); ?></p>
                        </div>
                    </div>
                </div>
            </div>

            <div class="x8-evs-stats-section">
                <h2><?php _e('Quick Stats', 'x8-evs'); ?></h2>
                <div class="x8-evs-stats">
                    <div class="x8-evs-stat-card" data-filter="all">
                        <span class="x8-evs-stat-number"><?php echo esc_html($stats['total']); ?></span>
                        <span class="x8-evs-stat-label"><?php _e('Total Customers', 'x8-evs'); ?></span>
                    </div>
                    <div class="x8-evs-stat-card" data-filter="active">
                        <span class="x8-evs-stat-number"><?php echo esc_html($stats['passed']); ?></span>
                        <span class="x8-evs-stat-label"><?php _e('Total Verified', 'x8-evs'); ?></span>
                    </div>
                    <div class="x8-evs-stat-card" data-filter="blocked">
                        <span class="x8-evs-stat-number"><?php echo esc_html($stats['failed']); ?></span>
                        <span class="x8-evs-stat-label"><?php _e('Total Blocked', 'x8-evs'); ?></span>
                    </div>
                    <div class="x8-evs-stat-card" data-filter="pending">
                        <span class="x8-evs-stat-number"><?php echo esc_html($stats['pending']); ?></span>
                        <span class="x8-evs-stat-label"><?php _e('Total Pending', 'x8-evs'); ?></span>
                    </div>
                    <div class="x8-evs-stat-card" data-filter="manual_review">
                        <span class="x8-evs-stat-number"><?php echo esc_html($stats['manual_review']); ?></span>
                        <span class="x8-evs-stat-label"><?php _e('Manual Review', 'x8-evs'); ?></span>
                    </div>
                </div>
            </div>
        </div>
        <?php
    }

    /**
     * Get verification statistics
     */
    private function get_verification_stats() {
        // Get all TapStack players (and WooCommerce customers, if any)
        $all_users = get_users(array(
            'role__in' => self::customer_list_roles(),
            'fields' => array('ID'),
        ));
        
        // Initialize stats
        $stats = array(
            'total' => count($all_users),
            'passed' => 0,
            'failed' => 0,
            'pending' => 0,
            'manual_review' => 0
        );

        // Count statuses
        foreach ($all_users as $user) {
            $account_status = get_user_meta($user->ID, 'account_status', true);
            
            // Count by status
            if (empty($account_status)) {
                $stats['pending']++;
            } elseif ($account_status === 'verified') {
                $stats['passed']++;
            } elseif ($account_status === 'block') {
                $stats['failed']++;
            } elseif ($account_status === 'manual_review') {
                $stats['manual_review']++;
            } else {
                $stats['pending']++;
            }
        }

        return $stats;
    }

    /**
     * Render Single Customer Page
     */
    private function render_single_customer_page($customer_id) {
        $user = get_userdata($customer_id);
        
        if (!$user) {
            echo '<div class="wrap"><h1>' . __('Customer Not Found', 'x8-evs') . '</h1>';
            echo '<p>' . __('The requested customer could not be found.', 'x8-evs') . '</p>';
            echo '<a href="' . admin_url('admin.php?page=x8-evs&tab=customers') . '" class="button">' . __('Back to Customers', 'x8-evs') . '</a></div>';
            return;
        }

        // Get customer meta data
        $phone = get_user_meta($customer_id, 'phone', true) ?: get_user_meta($customer_id, 'billing_phone', true);
        $account_status = get_user_meta($customer_id, 'account_status', true);
        $kyc_id_front = get_user_meta($customer_id, 'kyc_id_front', true);
        $kyc_id_back = get_user_meta($customer_id, 'kyc_id_back', true);
        $kyc_selfie = get_user_meta($customer_id, 'kyc_selfie', true);
        $verification_date = get_user_meta($customer_id, 'verification_date', true);
        $verification_notes = get_user_meta($customer_id, 'verification_notes', true);
        $document_type = get_user_meta($customer_id, 'document_type', true);
        $document_number = get_user_meta($customer_id, 'document_number', true);
        
        // Get document images from webhook
        $document_front_image = get_user_meta($customer_id, 'document_front_image', true);
        $document_back_image = get_user_meta($customer_id, 'document_back_image', true);
        $document_portrait_image = get_user_meta($customer_id, 'document_portrait_image', true);
        $document_transaction_id = get_user_meta($customer_id, 'document_transaction_id', true);
        $document_transaction_date = get_user_meta($customer_id, 'document_transaction_date', true);
        
        // Convert file paths to URLs for display
        if ($document_front_image && file_exists($document_front_image)) {
            $document_front_image_url = str_replace(ABSPATH, site_url('/'), $document_front_image);
        } else {
            $document_front_image_url = '';
        }
        
        if ($document_back_image && file_exists($document_back_image)) {
            $document_back_image_url = str_replace(ABSPATH, site_url('/'), $document_back_image);
        } else {
            $document_back_image_url = '';
        }
        
        if ($document_portrait_image && file_exists($document_portrait_image)) {
            $document_portrait_image_url = str_replace(ABSPATH, site_url('/'), $document_portrait_image);
        } else {
            $document_portrait_image_url = '';
        }
        
        // Get verification webhook data
        $verification_data = get_user_meta($customer_id, 'verification_webhook_data', true);
        $verification_data = $verification_data ? json_decode($verification_data, true) : null;
        
        // Get error information
        $verification_errors = get_user_meta($customer_id, 'verification_errors', true);
        $verification_error_code = get_user_meta($customer_id, 'verification_error_code', true);
        $verification_error_detail = get_user_meta($customer_id, 'verification_error_detail', true);
        $verification_errors = $verification_errors ? json_decode($verification_errors, true) : null;
        
        // Determine status details
        $status_class = '';
        $status_text = '';
        switch($account_status) {
            case 'verified':
                $status_class = 'verified';
                $status_text = __('Verified', 'x8-evs');
                break;
            case 'block':
                $status_class = 'blocked';
                $status_text = __('Blocked', 'x8-evs');
                break;
            case 'manual_review':
                $status_class = 'manual_review';
                $status_text = __('Manual Review', 'x8-evs');
                break;
            case 'error':
                $status_class = 'error';
                $status_text = __('Verification Error', 'x8-evs');
                break;
            case 'waiting':
                $status_class = 'pending';
                $status_text = __('Waiting for API Result', 'x8-evs');
                break;
            default:
                $status_class = 'pending';
                $status_text = __('Pending', 'x8-evs');
        }
        
        ?>
        <div class="wrap x8-evs-single-customer">
            <h1 class="wp-heading-inline"><?php echo esc_html(get_admin_page_title()); ?></h1>
            
            <!-- WordPress admin notices will appear here automatically -->
            
            <div class="x8-evs-customer-header">
                <h2 class="x8-evs-customer-title">
                    <span class="dashicons dashicons-admin-users"></span>
                    <?php echo esc_html($user->display_name ?: ($user->first_name . ' ' . $user->last_name)); ?>
                    <span class="x8-evs-badge <?php echo esc_attr($status_class); ?>">
                        <?php echo esc_html($status_text); ?>
                    </span>
                </h2>
                <div class="x8-evs-customer-actions">
                    <button type="button" class="button" id="x8-evs-update-status-btn">
                        <span class="dashicons dashicons-update"></span>
                        <?php _e('Update Status', 'x8-evs'); ?>
                    </button>
                    <button type="button" class="button" id="x8-evs-request-documents-btn">
                        <span class="dashicons dashicons-format-image"></span>
                        <?php _e('Request New Documents', 'x8-evs'); ?>
                    </button>
                    <a href="<?php echo admin_url('admin.php?page=x8-evs&tab=customers'); ?>" class="button">
                        <span class="dashicons dashicons-arrow-left-alt"></span>
                        <?php _e('Back to Customers', 'x8-evs'); ?>
                    </a>
                </div>
            </div>

            <div class="x8-evs-customer-content">
                <div class="x8-evs-customer-main">
                    <!-- Customer Information -->
                    <div class="x8-evs-info-section">
                        <h2><?php _e('Customer Information', 'x8-evs'); ?></h2>
                        <div class="x8-evs-info-grid">
                            <div class="x8-evs-info-item">
                                <label><?php _e('Customer ID', 'x8-evs'); ?>:</label>
                                <span><?php echo esc_html($customer_id); ?></span>
                            </div>
                            <div class="x8-evs-info-item">
                                <label><?php _e('Full Name', 'x8-evs'); ?>:</label>
                                <?php
                                $display_full_name = trim($user->first_name . ' ' . $user->last_name);
                                if (empty($display_full_name)) {
                                    $display_full_name = get_user_meta($customer_id, 'document_full_name', true);
                                }
                                if (empty($display_full_name)) {
                                    $display_full_name = $user->display_name;
                                }
                                if (empty($display_full_name)) {
                                    $display_full_name = $user->user_login;
                                }
                                ?>
                                <span><?php echo esc_html($display_full_name); ?></span>
                            </div>
                            <div class="x8-evs-info-item">
                                <label><?php _e('Email Address', 'x8-evs'); ?>:</label>
                                <span><?php echo esc_html($user->user_email); ?></span>
                            </div>
                            <div class="x8-evs-info-item">
                                <label><?php _e('Phone Number', 'x8-evs'); ?>:</label>
                                <span><?php echo esc_html($phone ?: '—'); ?></span>
                            </div>
                            <div class="x8-evs-info-item">
                                <label><?php _e('Registration Date', 'x8-evs'); ?>:</label>
                                <span><?php echo esc_html(date('F j, Y g:i A', strtotime($user->user_registered))); ?></span>
                            </div>
                            <div class="x8-evs-info-item">
                                <label><?php _e('Username', 'x8-evs'); ?>:</label>
                                <span><?php echo esc_html($user->user_login); ?></span>
                            </div>
                        </div>
                    </div>

                    <!-- Verification Information -->
                    <div class="x8-evs-info-section">
                        <h2><?php _e('Verification Details', 'x8-evs'); ?></h2>
                        <div class="x8-evs-info-grid">
                            <div class="x8-evs-info-item">
                                <label><?php _e('Verification Status', 'x8-evs'); ?>:</label>
                                <span class="x8-evs-badge <?php echo esc_attr($status_class); ?>">
                                    <?php echo esc_html($status_text); ?>
                                </span>
                            </div>
                            <div class="x8-evs-info-item">
                                <label><?php _e('Document Type', 'x8-evs'); ?>:</label>
                                <span><?php echo esc_html($document_type ?: '—'); ?></span>
                            </div>
                            <div class="x8-evs-info-item">
                                <label><?php _e('Document Number', 'x8-evs'); ?>:</label>
                                <span><?php echo esc_html($document_number ?: '—'); ?></span>
                            </div>
                            <div class="x8-evs-info-item">
                                <label><?php _e('Verification Date', 'x8-evs'); ?>:</label>
                                <span><?php echo $verification_date ? esc_html(date('F j, Y g:i A', strtotime($verification_date))) : '—'; ?></span>
                            </div>
                            <div class="x8-evs-info-item">
                                <label><?php _e('Age Requirement', 'x8-evs'); ?>:</label>
                                <span><?php echo esc_html(self::get_age_requirement_text()); ?></span>
                            </div>
                            <?php if ($verification_data && isset($verification_data['data']['assureCard']['individualCharacteristics']['calculatedAge'])): 
                                $calculated_age = $verification_data['data']['assureCard']['individualCharacteristics']['calculatedAge'];
                                $meets_age = self::meets_age_requirement($calculated_age);
                                ?>
                                <div class="x8-evs-info-item">
                                    <label><?php _e('Age Check', 'x8-evs'); ?>:</label>
                                    <span class="x8-evs-badge <?php echo $meets_age ? 'verified' : 'blocked'; ?>">
                                        <?php 
                                        if ($meets_age) {
                                            printf(__('Passed (%d years old)', 'x8-evs'), $calculated_age);
                                        } else {
                                            printf(__('Failed (%d years old)', 'x8-evs'), $calculated_age);
                                        }
                                        ?>
                                    </span>
                                </div>
                            <?php endif; ?>
                            <div class="x8-evs-info-item full-width">
                                <label><?php _e('Verification Notes', 'x8-evs'); ?>:</label>
                                <span><?php echo esc_html($verification_notes ?: __('No notes available', 'x8-evs')); ?></span>
                            </div>
                        </div>
                    </div>

                    <!-- Verification Error Information -->
                    <?php if ($account_status === 'error' && $verification_errors): ?>
                        <div class="x8-evs-info-section x8-evs-error-section">
                            <h2><?php _e('Verification Error Details', 'x8-evs'); ?></h2>
                            <div class="x8-evs-error-summary">
                                <div class="x8-evs-error-badge">
                                    <span class="dashicons dashicons-warning"></span>
                                    <?php printf(__('Verification failed with %d error(s)', 'x8-evs'), count($verification_errors)); ?>
                                </div>
                            </div>
                            
                            <?php if ($verification_error_code || $verification_error_detail): ?>
                                <div class="x8-evs-error-details">
                                    <h3><?php _e('Primary Error', 'x8-evs'); ?></h3>
                                    <div class="x8-evs-info-grid">
                                        <?php if ($verification_error_code): ?>
                                            <div class="x8-evs-info-item">
                                                <label><?php _e('Error Code', 'x8-evs'); ?>:</label>
                                                <span class="x8-evs-error-code"><?php echo esc_html($verification_error_code); ?></span>
                                            </div>
                                            <div class="x8-evs-info-item">
                                                <label><?php _e('Error Type', 'x8-evs'); ?>:</label>
                                                <span class="x8-evs-error-type"><?php echo esc_html(self::get_error_message($verification_error_code)); ?></span>
                                            </div>
                                        <?php endif; ?>
                                        <?php if ($verification_error_detail): ?>
                                            <div class="x8-evs-info-item full-width">
                                                <label><?php _e('Error Description', 'x8-evs'); ?>:</label>
                                                <span class="x8-evs-error-description"><?php echo esc_html($verification_error_detail); ?></span>
                                            </div>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            <?php endif; ?>
                            
                            <?php if (count($verification_errors) > 1): ?>
                                <div class="x8-evs-error-list">
                                    <h3><?php _e('All Errors', 'x8-evs'); ?></h3>
                                    <div class="x8-evs-error-items">
                                        <?php foreach ($verification_errors as $index => $error): ?>
                                            <div class="x8-evs-error-item">
                                                <div class="x8-evs-error-header">
                                                    <span class="x8-evs-error-number"><?php echo esc_html($index + 1); ?></span>
                                                    <?php if (isset($error['code'])): ?>
                                                        <span class="x8-evs-error-code"><?php echo esc_html($error['code']); ?></span>
                                                    <?php endif; ?>
                                                </div>
                                                <?php if (isset($error['code'])): ?>
                                                    <div class="x8-evs-error-type">
                                                        <strong><?php _e('Error Type:', 'x8-evs'); ?></strong> <?php echo esc_html(self::get_error_message($error['code'])); ?>
                                                    </div>
                                                <?php endif; ?>
                                                <?php if (isset($error['detail'])): ?>
                                                    <div class="x8-evs-error-message">
                                                        <strong><?php _e('Details:', 'x8-evs'); ?></strong> <?php echo esc_html($error['detail']); ?>
                                                    </div>
                                                <?php endif; ?>
                                            </div>
                                        <?php endforeach; ?>
                                    </div>
                                </div>
                            <?php endif; ?>
                            
                            <!-- Transaction Information for Error -->
                            <?php if ($verification_data && isset($verification_data['meta'])): ?>
                                <div class="x8-evs-error-transaction">
                                    <h3><?php _e('Transaction Information', 'x8-evs'); ?></h3>
                                    <div class="x8-evs-info-grid">
                                        <div class="x8-evs-info-item">
                                            <label><?php _e('Transaction ID', 'x8-evs'); ?>:</label>
                                            <span><?php echo esc_html($verification_data['meta']['transactionId'] ?? '—'); ?></span>
                                        </div>
                                        <div class="x8-evs-info-item">
                                            <label><?php _e('Transaction Date', 'x8-evs'); ?>:</label>
                                            <span><?php echo esc_html($verification_data['meta']['transactionDate'] ?? '—'); ?></span>
                                        </div>
                                        <div class="x8-evs-info-item">
                                            <label><?php _e('Product Name', 'x8-evs'); ?>:</label>
                                            <span><?php echo esc_html($verification_data['meta']['productName'] ?? '—'); ?></span>
                                        </div>
                                        <div class="x8-evs-info-item">
                                            <label><?php _e('Processing Duration', 'x8-evs'); ?>:</label>
                                            <span><?php echo esc_html(($verification_data['meta']['totalDuration'] ?? '0') . 's'); ?></span>
                                        </div>
                                    </div>
                                </div>
                            <?php endif; ?>
                        </div>
                    <?php endif; ?>

                    <!-- Document Images from Webhook -->
                    <?php if ($document_front_image || $document_back_image || $document_portrait_image): ?>
                        <div class="x8-evs-info-section">
                            <h2><?php _e('Document Images from Verification', 'x8-evs'); ?></h2>
                            <?php if ($document_transaction_id): ?>
                                <div class="x8-evs-document-meta">
                                    <p><strong><?php _e('Transaction ID:', 'x8-evs'); ?></strong> <?php echo esc_html($document_transaction_id); ?></p>
                                    <?php if ($document_transaction_date): ?>
                                        <p><strong><?php _e('Transaction Date:', 'x8-evs'); ?></strong> <?php echo esc_html($document_transaction_date); ?></p>
                                    <?php endif; ?>
                                </div>
                            <?php endif; ?>
                            <div class="x8-evs-kyc-images">
                                <div class="x8-evs-kyc-item">
                                    <h3><?php _e('Document Front', 'x8-evs'); ?></h3>
                                    <div class="x8-evs-image-container">
                                        <?php if ($document_front_image_url): ?>
                                            <img src="<?php echo esc_url($document_front_image_url); ?>" alt="<?php _e('Document Front', 'x8-evs'); ?>" class="x8-evs-kyc-image" />
                                            <div class="x8-evs-image-actions">
                                                <a href="<?php echo esc_url($document_front_image_url); ?>" target="_blank" class="button button-small">
                                                    <span class="dashicons dashicons-visibility"></span>
                                                    <?php _e('View Full Size', 'x8-evs'); ?>
                                                </a>
                                            </div>
                                        <?php else: ?>
                                            <div class="x8-evs-no-image">
                                                <span class="dashicons dashicons-format-image"></span>
                                                <p><?php _e('No front document image available', 'x8-evs'); ?></p>
                                            </div>
                                        <?php endif; ?>
                                    </div>
                                </div>

                                <div class="x8-evs-kyc-item">
                                    <h3><?php _e('Document Back', 'x8-evs'); ?></h3>
                                    <div class="x8-evs-image-container">
                                        <?php if ($document_back_image_url): ?>
                                            <img src="<?php echo esc_url($document_back_image_url); ?>" alt="<?php _e('Document Back', 'x8-evs'); ?>" class="x8-evs-kyc-image" />
                                            <div class="x8-evs-image-actions">
                                                <a href="<?php echo esc_url($document_back_image_url); ?>" target="_blank" class="button button-small">
                                                    <span class="dashicons dashicons-visibility"></span>
                                                    <?php _e('View Full Size', 'x8-evs'); ?>
                                                </a>
                                            </div>
                                        <?php else: ?>
                                            <div class="x8-evs-no-image">
                                                <span class="dashicons dashicons-format-image"></span>
                                                <p><?php _e('No back document image available', 'x8-evs'); ?></p>
                                            </div>
                                        <?php endif; ?>
                                    </div>
                                </div>

                                <div class="x8-evs-kyc-item">
                                    <h3><?php _e('Portrait Image', 'x8-evs'); ?></h3>
                                    <div class="x8-evs-image-container">
                                        <?php if ($document_portrait_image_url): ?>
                                            <img src="<?php echo esc_url($document_portrait_image_url); ?>" alt="<?php _e('Portrait Image', 'x8-evs'); ?>" class="x8-evs-kyc-image" />
                                            <div class="x8-evs-image-actions">
                                                <a href="<?php echo esc_url($document_portrait_image_url); ?>" target="_blank" class="button button-small">
                                                    <span class="dashicons dashicons-visibility"></span>
                                                    <?php _e('View Full Size', 'x8-evs'); ?>
                                                </a>
                                            </div>
                                        <?php else: ?>
                                            <div class="x8-evs-no-image">
                                                <span class="dashicons dashicons-format-image"></span>
                                                <p><?php _e('No portrait image available', 'x8-evs'); ?></p>
                                            </div>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php endif; ?>

                    <!-- Verification Data -->
                    <?php if ($verification_data): ?>
                        <div class="x8-evs-info-section">
                            <h2><?php _e('Identity Verification Results', 'x8-evs'); ?></h2>
                            
                            <!-- Debug Information -->
                            <div class="x8-evs-verification-section">
                                <h3><?php _e('Debug Information', 'x8-evs'); ?></h3>
                                <div class="x8-evs-debug-info">
                                    <p><strong><?php _e('Raw Verification Data Available:', 'x8-evs'); ?></strong> <?php echo $verification_data ? 'Yes' : 'No'; ?></p>
                                    <p><strong><?php _e('Data Structure:', 'x8-evs'); ?></strong> <?php echo is_array($verification_data) ? 'Array' : gettype($verification_data); ?></p>
                                    <?php if (is_array($verification_data)): ?>
                                        <p><strong><?php _e('Top Level Keys:', 'x8-evs'); ?></strong> <?php echo esc_html(implode(', ', array_keys($verification_data))); ?></p>
                                        <?php if (isset($verification_data['data'])): ?>
                                            <p><strong><?php _e('Data Keys:', 'x8-evs'); ?></strong> <?php echo esc_html(implode(', ', array_keys($verification_data['data']))); ?></p>
                                        <?php endif; ?>
                                        <?php if (isset($verification_data['meta'])): ?>
                                            <p><strong><?php _e('Meta Keys:', 'x8-evs'); ?></strong> <?php echo esc_html(implode(', ', array_keys($verification_data['meta']))); ?></p>
                                        <?php endif; ?>
                                    <?php endif; ?>
                                </div>
                            </div>
                            
                            <!-- Transaction Meta -->
                            <?php if (isset($verification_data['meta'])): ?>
                                <div class="x8-evs-verification-section">
                                    <h3><?php _e('Transaction Information', 'x8-evs'); ?></h3>
                                    <div class="x8-evs-info-grid">
                                        <div class="x8-evs-info-item">
                                            <label><?php _e('Transaction ID', 'x8-evs'); ?>:</label>
                                            <span><?php echo esc_html($verification_data['meta']['transactionId'] ?? '—'); ?></span>
                                        </div>
                                        <div class="x8-evs-info-item">
                                            <label><?php _e('Transaction Date', 'x8-evs'); ?>:</label>
                                            <span><?php echo esc_html($verification_data['meta']['transactionDate'] ?? '—'); ?></span>
                                        </div>
                                        <div class="x8-evs-info-item">
                                            <label><?php _e('Product Name', 'x8-evs'); ?>:</label>
                                            <span><?php echo esc_html($verification_data['meta']['productName'] ?? '—'); ?></span>
                                        </div>
                                        <div class="x8-evs-info-item">
                                            <label><?php _e('Processing Duration', 'x8-evs'); ?>:</label>
                                            <span><?php echo esc_html(($verification_data['meta']['totalDuration'] ?? '0') . 's'); ?></span>
                                        </div>
                                    </div>
                                </div>
                            <?php endif; ?>

                            <!-- Document Verification Results -->
                            <?php if (isset($verification_data['data']['assureCard'])): 
                                $assureCard = $verification_data['data']['assureCard']; ?>
                                <div class="x8-evs-verification-section">
                                    <h3><?php _e('Document Analysis', 'x8-evs'); ?></h3>
                                    <div class="x8-evs-verification-summary">
                                        <div class="x8-evs-confidence-score">
                                            <span class="x8-evs-confidence-label"><?php _e('Total Confidence', 'x8-evs'); ?></span>
                                            <span class="x8-evs-confidence-value <?php echo ($assureCard['totalConfidence'] ?? 0) >= 80 ? 'high' : (($assureCard['totalConfidence'] ?? 0) >= 60 ? 'medium' : 'low'); ?>">
                                                <?php echo esc_html($assureCard['totalConfidence'] ?? 0); ?>%
                                            </span>
                                        </div>
                                        <?php if (isset($assureCard['faceVerificationConfidence'])): ?>
                                        <div class="x8-evs-confidence-score">
                                            <span class="x8-evs-confidence-label"><?php _e('Face Verification Confidence', 'x8-evs'); ?></span>
                                            <span class="x8-evs-confidence-value <?php echo ($assureCard['faceVerificationConfidence'] ?? 0) >= 80 ? 'high' : (($assureCard['faceVerificationConfidence'] ?? 0) >= 60 ? 'medium' : 'low'); ?>">
                                                <?php echo esc_html($assureCard['faceVerificationConfidence'] ?? 0); ?>%
                                            </span>
                                        </div>
                                        <?php endif; ?>
                                        <?php if (isset($assureCard['selfieIsRealConfidence'])): ?>
                                        <div class="x8-evs-confidence-score">
                                            <span class="x8-evs-confidence-label"><?php _e('Selfie Authenticity Confidence', 'x8-evs'); ?></span>
                                            <span class="x8-evs-confidence-value <?php echo ($assureCard['selfieIsRealConfidence'] ?? 0) >= 80 ? 'high' : (($assureCard['selfieIsRealConfidence'] ?? 0) >= 60 ? 'medium' : 'low'); ?>">
                                                <?php echo esc_html($assureCard['selfieIsRealConfidence'] ?? 0); ?>%
                                            </span>
                                        </div>
                                        <?php endif; ?>
                                        <div class="x8-evs-validation-result">
                                            <span class="x8-evs-result-badge <?php echo isset($assureCard['validationResult']['code']) && $assureCard['validationResult']['code'] === '0' ? 'success' : 'error'; ?>">
                                                <?php echo esc_html($assureCard['validationResult']['description'] ?? 'Unknown'); ?>
                                            </span>
                                        </div>
                                        
                                        <?php 
                                        // Show which confidence score was used for decision making
                                        $use_selfie_thresholds = self::is_selfie_required();
                                        $decision_confidence = '';
                                        $threshold_info = '';
                                        
                                        if ($use_selfie_thresholds && isset($assureCard['faceVerificationConfidence'])) {
                                            $decision_confidence = sprintf(__('Decision based on Face Verification Confidence (%d%%)', 'x8-evs'), $assureCard['faceVerificationConfidence']);
                                            $threshold_info = sprintf(__('Using Selfie Thresholds: Block 0-%d | Review %d-%d | Approve %d-100', 'x8-evs'), 
                                                self::get_selfie_auto_block_threshold(),
                                                self::get_selfie_auto_block_threshold() + 1,
                                                self::get_selfie_manual_review_threshold(),
                                                self::get_selfie_auto_approve_threshold()
                                            );
                                        } else {
                                            $decision_confidence = sprintf(__('Decision based on Total Confidence (%d%%)', 'x8-evs'), $assureCard['totalConfidence'] ?? 0);
                                            $threshold_info = sprintf(__('Using Standard Thresholds: Block 0-%d | Review %d-%d | Approve %d-100', 'x8-evs'), 
                                                self::get_auto_block_threshold(false),
                                                self::get_auto_block_threshold(false) + 1,
                                                self::get_manual_review_threshold(false),
                                                self::get_auto_approve_threshold(false)
                                            );
                                        }
                                        ?>
                                        <div class="x8-evs-decision-info">
                                            <small class="x8-evs-decision-note"><?php echo esc_html($decision_confidence); ?></small>
                                            <small class="x8-evs-threshold-info"><?php echo esc_html($threshold_info); ?></small>
                                        </div>
                                    </div>
                                    
                                    <div class="x8-evs-info-grid">
                                        <?php if (isset($assureCard['documentInformation'])): ?>
                                            <div class="x8-evs-info-item">
                                                <label><?php _e('License Number', 'x8-evs'); ?>:</label>
                                                <span><?php echo esc_html($assureCard['documentInformation']['licenseNumber'] ?? '—'); ?></span>
                                            </div>
                                            <div class="x8-evs-info-item">
                                                <label><?php _e('Document Type', 'x8-evs'); ?>:</label>
                                                <span><?php echo esc_html($assureCard['documentInformation']['documentType'] ?? '—'); ?></span>
                                            </div>
                                            <div class="x8-evs-info-item">
                                                <label><?php _e('Issue Date', 'x8-evs'); ?>:</label>
                                                <span><?php echo esc_html($assureCard['documentInformation']['issueDate'] ?? '—'); ?></span>
                                            </div>
                                            <div class="x8-evs-info-item">
                                                <label><?php _e('Expiration Date', 'x8-evs'); ?>:</label>
                                                <span><?php echo esc_html($assureCard['documentInformation']['expirationDate'] ?? '—'); ?></span>
                                            </div>
                                        <?php endif; ?>
                                        
                                        <?php if (isset($assureCard['documentName'])): ?>
                                            <div class="x8-evs-info-item">
                                                <label><?php _e('Full Name', 'x8-evs'); ?>:</label>
                                                <span><?php echo esc_html($assureCard['documentName']['fullName'] ?? '—'); ?></span>
                                            </div>
                                            <div class="x8-evs-info-item">
                                                <label><?php _e('Name Confidence', 'x8-evs'); ?>:</label>
                                                <span><?php echo esc_html(($assureCard['documentName']['nameConfidence'] ?? 0) . '%'); ?></span>
                                            </div>
                                        <?php endif; ?>
                                        
                                        <?php if (isset($assureCard['documentAddress'])): ?>
                                            <div class="x8-evs-info-item">
                                                <label><?php _e('Document Address', 'x8-evs'); ?>:</label>
                                                <span><?php echo esc_html($assureCard['documentAddress']['address'] ?? '—'); ?></span>
                                            </div>
                                            <div class="x8-evs-info-item">
                                                <label><?php _e('Address Confidence', 'x8-evs'); ?>:</label>
                                                <span><?php echo esc_html(($assureCard['documentAddress']['addressConfidence'] ?? 0) . '%'); ?></span>
                                            </div>
                                        <?php endif; ?>
                                        
                                    </div>
                                </div>
                            <?php endif; ?>

                            <!-- Detailed Personal Characteristics -->
                            <?php if (isset($verification_data['data']['assureCard']['individualCharacteristics'])): 
                                $characteristics = $verification_data['data']['assureCard']['individualCharacteristics']; ?>
                                <div class="x8-evs-verification-section">
                                    <h3><?php _e('Personal Characteristics', 'x8-evs'); ?></h3>
                                    <div class="x8-evs-info-grid">
                                        <div class="x8-evs-info-item">
                                            <label><?php _e('Calculated Age', 'x8-evs'); ?>:</label>
                                            <span><?php echo esc_html($characteristics['calculatedAge'] ?? '—'); ?> <?php _e('years', 'x8-evs'); ?></span>
                                        </div>
                                        <div class="x8-evs-info-item">
                                            <label><?php _e('Gender', 'x8-evs'); ?>:</label>
                                            <span><?php echo esc_html($characteristics['gender'] ?? '—'); ?></span>
                                        </div>
                                        <div class="x8-evs-info-item">
                                            <label><?php _e('Height', 'x8-evs'); ?>:</label>
                                            <span><?php echo esc_html($characteristics['height'] ?? '—'); ?> <?php _e('inches', 'x8-evs'); ?></span>
                                        </div>
                                        <div class="x8-evs-info-item">
                                            <label><?php _e('Weight', 'x8-evs'); ?>:</label>
                                            <span><?php echo esc_html($characteristics['weight'] ?: '—'); ?> <?php echo $characteristics['weight'] ? __('lbs', 'x8-evs') : ''; ?></span>
                                        </div>
                                        <div class="x8-evs-info-item">
                                            <label><?php _e('Eye Color', 'x8-evs'); ?>:</label>
                                            <span><?php echo esc_html($characteristics['eyeColor'] ?? '—'); ?></span>
                                        </div>
                                        <div class="x8-evs-info-item">
                                            <label><?php _e('Hair Color', 'x8-evs'); ?>:</label>
                                            <span><?php echo esc_html($characteristics['hairColor'] ?? '—'); ?></span>
                                        </div>
                                    </div>
                                </div>
                            <?php endif; ?>

                            <!-- Detailed Document Information -->
                            <?php if (isset($verification_data['data']['assureCard']['documentInformation'])): 
                                $docInfo = $verification_data['data']['assureCard']['documentInformation']; ?>
                                <div class="x8-evs-verification-section">
                                    <h3><?php _e('Detailed Document Information', 'x8-evs'); ?></h3>
                                    <div class="x8-evs-info-grid">
                                        <div class="x8-evs-info-item">
                                            <label><?php _e('License Number', 'x8-evs'); ?>:</label>
                                            <span><?php echo esc_html($docInfo['licenseNumber'] ?? '—'); ?></span>
                                        </div>
                                        <div class="x8-evs-info-item">
                                            <label><?php _e('License Number Confidence', 'x8-evs'); ?>:</label>
                                            <span><?php echo esc_html(($docInfo['licenseNumberConfidence'] ?? 0) . '%'); ?></span>
                                        </div>
                                        <div class="x8-evs-info-item">
                                            <label><?php _e('Document Type', 'x8-evs'); ?>:</label>
                                            <span><?php echo esc_html($docInfo['documentType'] ?? '—'); ?></span>
                                        </div>
                                        <div class="x8-evs-info-item">
                                            <label><?php _e('Document Class', 'x8-evs'); ?>:</label>
                                            <span><?php echo esc_html($docInfo['documentClass'] ?? '—'); ?></span>
                                        </div>
                                        <div class="x8-evs-info-item">
                                            <label><?php _e('Template', 'x8-evs'); ?>:</label>
                                            <span><?php echo esc_html($docInfo['template'] ?? '—'); ?></span>
                                        </div>
                                        <div class="x8-evs-info-item">
                                            <label><?php _e('Issue Date', 'x8-evs'); ?>:</label>
                                            <span><?php echo esc_html($docInfo['issueDate'] ?? '—'); ?></span>
                                        </div>
                                        <div class="x8-evs-info-item">
                                            <label><?php _e('Expiration Date', 'x8-evs'); ?>:</label>
                                            <span><?php echo esc_html($docInfo['expirationDate'] ?? '—'); ?></span>
                                        </div>
                                    </div>
                                </div>
                            <?php endif; ?>

                            <!-- Detailed Personal Information -->
                            <?php if (isset($verification_data['data']['assureCard']['documentName'])): 
                                $docName = $verification_data['data']['assureCard']['documentName']; ?>
                                <div class="x8-evs-verification-section">
                                    <h3><?php _e('Personal Information from Document', 'x8-evs'); ?></h3>
                                    <div class="x8-evs-info-grid">
                                        <div class="x8-evs-info-item">
                                            <label><?php _e('Full Name', 'x8-evs'); ?>:</label>
                                            <span><?php echo esc_html($docName['fullName'] ?? '—'); ?></span>
                                        </div>
                                        <div class="x8-evs-info-item">
                                            <label><?php _e('First Name', 'x8-evs'); ?>:</label>
                                            <span><?php echo esc_html($docName['firstName'] ?? '—'); ?></span>
                                        </div>
                                        <div class="x8-evs-info-item">
                                            <label><?php _e('Middle Name', 'x8-evs'); ?>:</label>
                                            <span><?php echo esc_html($docName['middleName'] ?? '—'); ?></span>
                                        </div>
                                        <div class="x8-evs-info-item">
                                            <label><?php _e('Family Name', 'x8-evs'); ?>:</label>
                                            <span><?php echo esc_html($docName['familyName'] ?? '—'); ?></span>
                                        </div>
                                        <div class="x8-evs-info-item">
                                            <label><?php _e('Private Name', 'x8-evs'); ?>:</label>
                                            <span><?php echo esc_html($docName['privateName'] ?? '—'); ?></span>
                                        </div>
                                        <div class="x8-evs-info-item">
                                            <label><?php _e('Name Confidence', 'x8-evs'); ?>:</label>
                                            <span><?php echo esc_html(($docName['nameConfidence'] ?? 0) . '%'); ?></span>
                                        </div>
                                    </div>
                                </div>
                            <?php endif; ?>

                            <!-- Document Address Information -->
                            <?php if (isset($verification_data['data']['assureCard']['documentAddress'])): 
                                $docAddress = $verification_data['data']['assureCard']['documentAddress']; ?>
                                <div class="x8-evs-verification-section">
                                    <h3><?php _e('Address Information from Document', 'x8-evs'); ?></h3>
                                    <div class="x8-evs-info-grid">
                                        <div class="x8-evs-info-item">
                                            <label><?php _e('Street Address', 'x8-evs'); ?>:</label>
                                            <span><?php echo esc_html($docAddress['address'] ?? '—'); ?></span>
                                        </div>
                                        <div class="x8-evs-info-item">
                                            <label><?php _e('City', 'x8-evs'); ?>:</label>
                                            <span><?php echo esc_html($docAddress['city'] ?? '—'); ?></span>
                                        </div>
                                        <div class="x8-evs-info-item">
                                            <label><?php _e('State', 'x8-evs'); ?>:</label>
                                            <span><?php echo esc_html($docAddress['state'] ?? '—'); ?></span>
                                        </div>
                                        <div class="x8-evs-info-item">
                                            <label><?php _e('ZIP Code', 'x8-evs'); ?>:</label>
                                            <span><?php echo esc_html($docAddress['zipCode'] ?? '—'); ?></span>
                                        </div>
                                        <div class="x8-evs-info-item">
                                            <label><?php _e('Country', 'x8-evs'); ?>:</label>
                                            <span><?php echo esc_html($docAddress['country'] ?? '—'); ?></span>
                                        </div>
                                        <div class="x8-evs-info-item">
                                            <label><?php _e('Address Confidence', 'x8-evs'); ?>:</label>
                                            <span><?php echo esc_html(($docAddress['addressConfidence'] ?? 0) . '%'); ?></span>
                                        </div>
                                    </div>
                                </div>
                            <?php endif; ?>

                            <!-- Identity Verification Results -->
                            <?php if (isset($verification_data['data']['assureId'])): 
                                $assureId = $verification_data['data']['assureId']; ?>
                                <div class="x8-evs-verification-section">
                                    <h3><?php _e('Identity Verification', 'x8-evs'); ?></h3>
                                    <div class="x8-evs-info-grid">
                                        <div class="x8-evs-info-item">
                                            <label><?php _e('Primary Result', 'x8-evs'); ?>:</label>
                                            <span class="x8-evs-result-badge <?php echo isset($assureId['primaryResult']['code']) && $assureId['primaryResult']['code'] === '00' ? 'success' : 'warning'; ?>">
                                                <?php echo esc_html($assureId['primaryResult']['code'] ?? 'Unknown'); ?>
                                            </span>
                                        </div>
                                        <div class="x8-evs-info-item">
                                            <label><?php _e('Address Verification', 'x8-evs'); ?>:</label>
                                            <span><?php echo esc_html($assureId['addressVerificationResult']['description'] ?? '—'); ?></span>
                                        </div>
                                        <div class="x8-evs-info-item">
                                            <label><?php _e('Address Type', 'x8-evs'); ?>:</label>
                                            <span><?php echo esc_html($assureId['addressTypeResult']['description'] ?? '—'); ?></span>
                                        </div>
                                        <div class="x8-evs-info-item">
                                            <label><?php _e('Phone Verification', 'x8-evs'); ?>:</label>
                                            <span><?php echo esc_html($assureId['phoneVerificationResult']['description'] ?? '—'); ?></span>
                                        </div>
                                        <div class="x8-evs-info-item">
                                            <label><?php _e('Date of Birth Check', 'x8-evs'); ?>:</label>
                                            <span><?php echo esc_html($assureId['dateOfBirthResult']['description'] ?? '—'); ?></span>
                                        </div>
                                        <div class="x8-evs-info-item">
                                            <label><?php _e('Reported Fraud', 'x8-evs'); ?>:</label>
                                            <span class="x8-evs-result-badge <?php echo isset($assureId['reportedFraudResult']['code']) && $assureId['reportedFraudResult']['code'] === 'N' ? 'success' : 'error'; ?>">
                                                <?php echo esc_html($assureId['reportedFraudResult']['description'] ?? '—'); ?>
                                            </span>
                                        </div>
                                    </div>
                                </div>
                            <?php endif; ?>

                            <!-- Risk Assessment -->
                            <?php if (isset($verification_data['data']['assureId']['fraudShieldResults'])): 
                                $fraudShield = $verification_data['data']['assureId']['fraudShieldResults'];
                                $activeFlags = array_filter($fraudShield, function($result) { 
                                    return isset($result['code']) && $result['code'] === 'Y'; 
                                }); ?>
                                <div class="x8-evs-verification-section">
                                    <h3><?php _e('Risk Assessment', 'x8-evs'); ?></h3>
                                    <?php if (!empty($activeFlags)): ?>
                                        <div class="x8-evs-risk-flags">
                                            <?php foreach ($activeFlags as $flag => $result): ?>
                                                <div class="x8-evs-risk-flag warning">
                                                    <span class="dashicons dashicons-warning"></span>
                                                    <span><?php echo esc_html($result['description'] ?? $flag); ?></span>
                                                </div>
                                            <?php endforeach; ?>
                                        </div>
                                    <?php else: ?>
                                        <div class="x8-evs-risk-flag success">
                                            <span class="dashicons dashicons-yes-alt"></span>
                                            <span><?php _e('No risk flags detected', 'x8-evs'); ?></span>
                                        </div>
                                    <?php endif; ?>
                                </div>
                            <?php endif; ?>

                            <!-- Address History -->
                            <?php if (isset($verification_data['data']['assureId']['additionalAddresses']) && !empty($verification_data['data']['assureId']['additionalAddresses'])): ?>
                                <div class="x8-evs-verification-section">
                                    <h3><?php _e('Address History', 'x8-evs'); ?></h3>
                                    <div class="x8-evs-address-history">
                                        <?php foreach (array_slice($verification_data['data']['assureId']['additionalAddresses'], 0, 5) as $address): ?>
                                            <div class="x8-evs-address-item">
                                                <div class="x8-evs-address-main">
                                                    <strong><?php echo esc_html($address['street'] . ', ' . $address['city'] . ', ' . $address['state'] . ' ' . $address['zipCode']); ?></strong>
                                                </div>
                                                <div class="x8-evs-address-meta">
                                                    <span><?php _e('Reported:', 'x8-evs'); ?> <?php echo esc_html($address['reportDate']['month'] . '/' . $address['reportDate']['year']); ?></span>
                                                    <span><?php _e('Updated:', 'x8-evs'); ?> <?php echo esc_html($address['updateDate']['month'] . '/' . $address['updateDate']['year']); ?></span>
                                                </div>
                                            </div>
                                        <?php endforeach; ?>
                                    </div>
                                </div>
                            <?php endif; ?>

                            <!-- KBA Questions -->
                            <?php if (isset($verification_data['data']['kbaQuestions']['questions']) && !empty($verification_data['data']['kbaQuestions']['questions'])): ?>
                                <div class="x8-evs-verification-section">
                                    <h3><?php _e('Knowledge-Based Authentication', 'x8-evs'); ?></h3>
                                    <div class="x8-evs-kba-summary">
                                        <span><?php printf(__('%d KBA questions generated', 'x8-evs'), count($verification_data['data']['kbaQuestions']['questions'])); ?></span>
                                    </div>
                                    <details class="x8-evs-kba-details">
                                        <summary><?php _e('View KBA Questions', 'x8-evs'); ?></summary>
                                        <div class="x8-evs-kba-questions">
                                            <?php foreach ($verification_data['data']['kbaQuestions']['questions'] as $index => $question): ?>
                                                <div class="x8-evs-kba-question">
                                                    <h4><?php echo esc_html(($index + 1) . '. ' . $question['text']); ?></h4>
                                                    <div class="x8-evs-kba-answers">
                                                        <?php foreach ($question['answers'] as $answer): ?>
                                                            <div class="x8-evs-kba-answer <?php echo $answer['isCorrect'] ? 'correct' : ''; ?>">
                                                                <?php echo esc_html($answer['text']); ?>
                                                                <?php if ($answer['isCorrect']): ?>
                                                                    <span class="dashicons dashicons-yes-alt"></span>
                                                                <?php endif; ?>
                                                            </div>
                                                        <?php endforeach; ?>
                                                    </div>
                                                </div>
                                            <?php endforeach; ?>
                                        </div>
                                    </details>
                                </div>
                            <?php endif; ?>
                            
                            <!-- Raw Data Display for Debugging -->
                            <div class="x8-evs-verification-section">
                                <h3><?php _e('Raw Verification Data (Debug)', 'x8-evs'); ?></h3>
                                <details class="x8-evs-raw-data-details">
                                    <summary><?php _e('View Raw JSON Data', 'x8-evs'); ?></summary>
                                    <div class="x8-evs-raw-data">
                                        <pre><?php echo esc_html(json_encode($verification_data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE)); ?></pre>
                                    </div>
                                </details>
                            </div>
                        </div>
                    <?php endif; ?>
                </div>

                <!-- Status Update Modal -->
                <div id="x8-evs-status-modal" class="x8-evs-modal">
                    <div class="x8-evs-modal-content">
                        <div class="x8-evs-modal-header">
                            <h3>
                                <span class="dashicons dashicons-update"></span>
                                <?php _e('Update Customer Status', 'x8-evs'); ?>
                            </h3>
                            <button type="button" class="x8-evs-modal-close" id="x8-evs-close-status-modal">
                                <span class="dashicons dashicons-no-alt"></span>
                            </button>
                        </div>
                        <div class="x8-evs-modal-body">
                            <div class="x8-evs-status-change-form">
                                <form id="x8-evs-status-change-form" method="post" enctype="multipart/form-data">
                                    <?php wp_nonce_field('x8_evs_nonce', 'x8_evs_nonce'); ?>
                                    <input type="hidden" name="customer_id" value="<?php echo esc_attr($customer_id); ?>" />
                                    <input type="hidden" name="x8_evs_require_selfie" value="<?php echo esc_attr(get_option('x8_evs_require_selfie', 1)); ?>" />
                                    
                                    <div class="x8-evs-form-row">
                                        <div class="x8-evs-form-group">
                                            <label for="new_status"><?php _e('Change Status To:', 'x8-evs'); ?></label>
                                            <select name="new_status" id="new_status" required>
                                                <option value=""><?php _e('Select Status', 'x8-evs'); ?></option>
                                                <option value="verified"><?php _e('Verified', 'x8-evs'); ?></option>
                                                <option value="block"><?php _e('Blocked', 'x8-evs'); ?></option>
                                                <option value="manual_review"><?php _e('Manual Review', 'x8-evs'); ?></option>
                                                <option value="pending"><?php _e('Pending', 'x8-evs'); ?></option>
                                            </select>
                                        </div>
                                    </div>
                                    
                                    <!-- Verification Method Selection (initially hidden) -->
                                    <div class="x8-evs-form-row" id="x8-evs-verification-method-row" style="display: none;">
                                        <div class="x8-evs-form-group">
                                            <label for="verification_method"><?php _e('Verification Method:', 'x8-evs'); ?> <span style="color: #dc2626;">*</span></label>
                                            <select name="verification_method" id="verification_method">
                                                <option value=""><?php _e('Select Verification Method', 'x8-evs'); ?></option>
                                                <option value="manual"><?php _e('Manual Verification', 'x8-evs'); ?></option>
                                                <option value="api"><?php _e('API System Verification', 'x8-evs'); ?></option>
                                                <option value="approve"><?php _e('Approve Verification', 'x8-evs'); ?></option>
                                            </select>
                                            <p class="description"><?php _e('Choose how this customer was verified. "Approve Verification" allows you to verify a customer without requiring additional document images or address information.', 'x8-evs'); ?></p>
                                                                           </div>
                                   
                                   
                               </div>
                                    
                                    <div class="x8-evs-form-row">
                                        <div class="x8-evs-form-group">
                                            <label for="status_notes"><?php _e('Notes (Required):', 'x8-evs'); ?> <span style="color: #dc2626;">*</span></label>
                                            <textarea name="status_notes" id="status_notes" rows="3" placeholder="<?php _e('Add notes about this status change...', 'x8-evs'); ?>" required><?php echo esc_textarea($verification_notes); ?></textarea>
                                        </div>
                                    </div>
                                    
                                                                   <!-- Additional Verification Data Fields (initially hidden) -->
                               <div id="x8-evs-additional-data" style="display: none;">
                                   <div class="x8-evs-form-row">
                                       <div class="x8-evs-upload-columns">
                                           <div class="x8-evs-form-group">
                                               <label for="document_front_image"><?php _e('Document Front Image:', 'x8-evs'); ?></label>
                                               <div class="x8-evs-file-upload-container">
                                                   <input type="file" name="document_front_image" id="document_front_image" accept="image/*" class="x8-evs-file-input" />
                                                   <div class="x8-evs-file-upload-area" id="front-upload-area">
                                                       <div class="x8-evs-upload-icon">
                                                           <span class="dashicons dashicons-upload"></span>
                                                       </div>
                                                       <div class="x8-evs-upload-text">
                                                           <span class="x8-evs-upload-title"><?php _e('Click to upload or drag and drop', 'x8-evs'); ?></span>
                                                           <span class="x8-evs-upload-subtitle"><?php _e('PNG, JPG, JPEG up to 5MB', 'x8-evs'); ?></span>
                                                       </div>
                                                   </div>
                                                   <div class="x8-evs-file-preview" id="front-preview" style="display: none;">
                                                       <img src="" alt="Document Front Preview" class="x8-evs-preview-image" />
                                                       <button type="button" class="x8-evs-remove-file" data-target="front">
                                                           <span class="dashicons dashicons-no-alt"></span>
                                                       </button>
                                                   </div>
                                               </div>
                                               <p class="description"><?php _e('Upload the front image of the document if not available from verification.', 'x8-evs'); ?></p>
                                           </div>
                                           
                                           <div class="x8-evs-form-group">
                                               <label for="document_back_image"><?php _e('Document Back Image:', 'x8-evs'); ?></label>
                                               <div class="x8-evs-file-upload-container">
                                                   <input type="file" name="document_back_image" id="document_back_image" accept="image/*" class="x8-evs-file-input" />
                                                   <div class="x8-evs-file-upload-area" id="back-upload-area">
                                                       <div class="x8-evs-upload-icon">
                                                           <span class="dashicons dashicons-upload"></span>
                                                       </div>
                                                       <div class="x8-evs-upload-text">
                                                           <span class="x8-evs-upload-title"><?php _e('Click to upload or drag and drop', 'x8-evs'); ?></span>
                                                           <span class="x8-evs-upload-subtitle"><?php _e('PNG, JPG, JPEG up to 5MB', 'x8-evs'); ?></span>
                                                       </div>
                                                   </div>
                                                   <div class="x8-evs-file-preview" id="back-preview" style="display: none;">
                                                       <img src="" alt="Document Back Preview" class="x8-evs-preview-image" />
                                                       <button type="button" class="x8-evs-remove-file" data-target="back">
                                                           <span class="dashicons dashicons-no-alt"></span>
                                                       </button>
                                                   </div>
                                               </div>
                                               <p class="description"><?php _e('Upload the back image of the document if not available from verification.', 'x8-evs'); ?></p>
                                           </div>
                                           
                                           <?php 
                                           // Check if selfie is required based on settings
                                           $require_selfie = get_option('x8_evs_require_selfie', 1);
                                           if ($require_selfie): ?>
                                           <div class="x8-evs-form-group" id="portrait-image-group">
                                               <label for="document_portrait_image"><?php _e('Portrait Image:', 'x8-evs'); ?></label>
                                               <div class="x8-evs-file-upload-container">
                                                   <input type="file" name="document_portrait_image" id="document_portrait_image" accept="image/*" class="x8-evs-file-input" />
                                                   <div class="x8-evs-file-upload-area" id="portrait-upload-area">
                                                       <div class="x8-evs-upload-icon">
                                                           <span class="dashicons dashicons-upload"></span>
                                                       </div>
                                                       <div class="x8-evs-upload-text">
                                                           <span class="x8-evs-upload-title"><?php _e('Click to upload or drag and drop', 'x8-evs'); ?></span>
                                                           <span class="x8-evs-upload-subtitle"><?php _e('PNG, JPG, JPEG up to 5MB', 'x8-evs'); ?></span>
                                                       </div>
                                                   </div>
                                                   <div class="x8-evs-file-preview" id="portrait-preview" style="display: none;">
                                                       <img src="" alt="Portrait Image Preview" class="x8-evs-preview-image" />
                                                       <button type="button" class="x8-evs-remove-file" data-target="portrait">
                                                           <span class="dashicons dashicons-no-alt"></span>
                                                       </button>
                                                   </div>
                                               </div>
                                               <p class="description"><?php _e('Upload the portrait image if not available from verification.', 'x8-evs'); ?></p>
                                           </div>
                                           <?php endif; ?>
                                       </div>
                                   </div>


                                   <div class="x8-evs-form-row">
                                       <div class="x8-evs-address-section">
                                           <h4 class="x8-evs-section-title">
                                               <span class="dashicons dashicons-location"></span>
                                               <?php _e('Document Address Information', 'x8-evs'); ?>
                                           </h4>
                                           <p class="x8-evs-section-description"><?php _e('Enter the address information from the document if not available from verification.', 'x8-evs'); ?></p>
                                           
                                           <div class="x8-evs-address-fields">
                                               <div class="x8-evs-form-group x8-evs-full-width">
                                                   <label for="document_address_street"><?php _e('Street Address:', 'x8-evs'); ?></label>
                                                   <input type="text" name="document_address_street" id="document_address_street" placeholder="<?php _e('Enter street address...', 'x8-evs'); ?>" value="<?php echo esc_attr(get_user_meta($customer_id, 'document_address_street', true)); ?>" />
                                               </div>
                                               
                                               <div class="x8-evs-address-row">
                                                   <div class="x8-evs-form-group">
                                                       <label for="document_address_city"><?php _e('City:', 'x8-evs'); ?></label>
                                                       <input type="text" name="document_address_city" id="document_address_city" placeholder="<?php _e('Enter city...', 'x8-evs'); ?>" value="<?php echo esc_attr(get_user_meta($customer_id, 'document_address_city', true)); ?>" />
                                                   </div>
                                                   
                                                   <div class="x8-evs-form-group">
                                                       <label for="document_address_state"><?php _e('State:', 'x8-evs'); ?></label>
                                                       <select name="document_address_state" id="document_address_state">
                                                           <option value=""><?php _e('Select State', 'x8-evs'); ?></option>
                                                           <option value="AL" <?php selected(get_user_meta($customer_id, 'document_address_state', true), 'AL'); ?>>Alabama</option>
                                                           <option value="AK" <?php selected(get_user_meta($customer_id, 'document_address_state', true), 'AK'); ?>>Alaska</option>
                                                           <option value="AZ" <?php selected(get_user_meta($customer_id, 'document_address_state', true), 'AZ'); ?>>Arizona</option>
                                                           <option value="AR" <?php selected(get_user_meta($customer_id, 'document_address_state', true), 'AR'); ?>>Arkansas</option>
                                                           <option value="CA" <?php selected(get_user_meta($customer_id, 'document_address_state', true), 'CA'); ?>>California</option>
                                                           <option value="CO" <?php selected(get_user_meta($customer_id, 'document_address_state', true), 'CO'); ?>>Colorado</option>
                                                           <option value="CT" <?php selected(get_user_meta($customer_id, 'document_address_state', true), 'CT'); ?>>Connecticut</option>
                                                           <option value="DE" <?php selected(get_user_meta($customer_id, 'document_address_state', true), 'DE'); ?>>Delaware</option>
                                                           <option value="FL" <?php selected(get_user_meta($customer_id, 'document_address_state', true), 'FL'); ?>>Florida</option>
                                                           <option value="GA" <?php selected(get_user_meta($customer_id, 'document_address_state', true), 'GA'); ?>>Georgia</option>
                                                           <option value="HI" <?php selected(get_user_meta($customer_id, 'document_address_state', true), 'HI'); ?>>Hawaii</option>
                                                           <option value="ID" <?php selected(get_user_meta($customer_id, 'document_address_state', true), 'ID'); ?>>Idaho</option>
                                                           <option value="IL" <?php selected(get_user_meta($customer_id, 'document_address_state', true), 'IL'); ?>>Illinois</option>
                                                           <option value="IN" <?php selected(get_user_meta($customer_id, 'document_address_state', true), 'IN'); ?>>Indiana</option>
                                                           <option value="IA" <?php selected(get_user_meta($customer_id, 'document_address_state', true), 'IA'); ?>>Iowa</option>
                                                           <option value="KS" <?php selected(get_user_meta($customer_id, 'document_address_state', true), 'KS'); ?>>Kansas</option>
                                                           <option value="KY" <?php selected(get_user_meta($customer_id, 'document_address_state', true), 'KY'); ?>>Kentucky</option>
                                                           <option value="LA" <?php selected(get_user_meta($customer_id, 'document_address_state', true), 'LA'); ?>>Louisiana</option>
                                                           <option value="ME" <?php selected(get_user_meta($customer_id, 'document_address_state', true), 'ME'); ?>>Maine</option>
                                                           <option value="MD" <?php selected(get_user_meta($customer_id, 'document_address_state', true), 'MD'); ?>>Maryland</option>
                                                           <option value="MA" <?php selected(get_user_meta($customer_id, 'document_address_state', true), 'MA'); ?>>Massachusetts</option>
                                                           <option value="MI" <?php selected(get_user_meta($customer_id, 'document_address_state', true), 'MI'); ?>>Michigan</option>
                                                           <option value="MN" <?php selected(get_user_meta($customer_id, 'document_address_state', true), 'MN'); ?>>Minnesota</option>
                                                           <option value="MS" <?php selected(get_user_meta($customer_id, 'document_address_state', true), 'MS'); ?>>Mississippi</option>
                                                           <option value="MO" <?php selected(get_user_meta($customer_id, 'document_address_state', true), 'MO'); ?>>Missouri</option>
                                                           <option value="MT" <?php selected(get_user_meta($customer_id, 'document_address_state', true), 'MT'); ?>>Montana</option>
                                                           <option value="NE" <?php selected(get_user_meta($customer_id, 'document_address_state', true), 'NE'); ?>>Nebraska</option>
                                                           <option value="NV" <?php selected(get_user_meta($customer_id, 'document_address_state', true), 'NV'); ?>>Nevada</option>
                                                           <option value="NH" <?php selected(get_user_meta($customer_id, 'document_address_state', true), 'NH'); ?>>New Hampshire</option>
                                                           <option value="NJ" <?php selected(get_user_meta($customer_id, 'document_address_state', true), 'NJ'); ?>>New Jersey</option>
                                                           <option value="NM" <?php selected(get_user_meta($customer_id, 'document_address_state', true), 'NM'); ?>>New Mexico</option>
                                                           <option value="NY" <?php selected(get_user_meta($customer_id, 'document_address_state', true), 'NY'); ?>>New York</option>
                                                           <option value="NC" <?php selected(get_user_meta($customer_id, 'document_address_state', true), 'NC'); ?>>North Carolina</option>
                                                           <option value="ND" <?php selected(get_user_meta($customer_id, 'document_address_state', true), 'ND'); ?>>North Dakota</option>
                                                           <option value="OH" <?php selected(get_user_meta($customer_id, 'document_address_state', true), 'OH'); ?>>Ohio</option>
                                                           <option value="OK" <?php selected(get_user_meta($customer_id, 'document_address_state', true), 'OK'); ?>>Oklahoma</option>
                                                           <option value="OR" <?php selected(get_user_meta($customer_id, 'document_address_state', true), 'OR'); ?>>Oregon</option>
                                                           <option value="PA" <?php selected(get_user_meta($customer_id, 'document_address_state', true), 'PA'); ?>>Pennsylvania</option>
                                                           <option value="RI" <?php selected(get_user_meta($customer_id, 'document_address_state', true), 'RI'); ?>>Rhode Island</option>
                                                           <option value="SC" <?php selected(get_user_meta($customer_id, 'document_address_state', true), 'SC'); ?>>South Carolina</option>
                                                           <option value="SD" <?php selected(get_user_meta($customer_id, 'document_address_state', true), 'SD'); ?>>South Dakota</option>
                                                           <option value="TN" <?php selected(get_user_meta($customer_id, 'document_address_state', true), 'TN'); ?>>Tennessee</option>
                                                           <option value="TX" <?php selected(get_user_meta($customer_id, 'document_address_state', true), 'TX'); ?>>Texas</option>
                                                           <option value="UT" <?php selected(get_user_meta($customer_id, 'document_address_state', true), 'UT'); ?>>Utah</option>
                                                           <option value="VT" <?php selected(get_user_meta($customer_id, 'document_address_state', true), 'VT'); ?>>Vermont</option>
                                                           <option value="VA" <?php selected(get_user_meta($customer_id, 'document_address_state', true), 'VA'); ?>>Virginia</option>
                                                           <option value="WA" <?php selected(get_user_meta($customer_id, 'document_address_state', true), 'WA'); ?>>Washington</option>
                                                           <option value="WV" <?php selected(get_user_meta($customer_id, 'document_address_state', true), 'WV'); ?>>West Virginia</option>
                                                           <option value="WI" <?php selected(get_user_meta($customer_id, 'document_address_state', true), 'WI'); ?>>Wisconsin</option>
                                                           <option value="WY" <?php selected(get_user_meta($customer_id, 'document_address_state', true), 'WY'); ?>>Wyoming</option>
                                                       </select>
                                                   </div>
                                                   
                                                   <div class="x8-evs-form-group">
                                                       <label for="document_address_postcode"><?php _e('Post Code:', 'x8-evs'); ?></label>
                                                       <input type="text" name="document_address_postcode" id="document_address_postcode" placeholder="<?php _e('Enter post code...', 'x8-evs'); ?>" value="<?php echo esc_attr(get_user_meta($customer_id, 'document_address_postcode', true)); ?>" />
                                                   </div>
                                                   
                                                   <div class="x8-evs-form-group">
                                                       <label for="document_address_country"><?php _e('Country:', 'x8-evs'); ?></label>
                                                       <input type="text" name="document_address_country" id="document_address_country" value="United States" readonly />
                                                   </div>
                                               </div>
                                           </div>
                                       </div>
                                   </div>
                                   

                               </div>
                                    
                                    <div class="x8-evs-form-row">
                                        <div class="x8-evs-form-actions">
                                            <button type="submit" class="button button-primary" id="x8-evs-update-status">
                                                <span class="dashicons dashicons-update"></span>
                                                <?php _e('Update Status', 'x8-evs'); ?>
                                            </button>
                                            <button type="button" class="button button-secondary" id="x8-evs-cancel-status">
                                                <?php _e('Cancel', 'x8-evs'); ?>
                                            </button>
                                            <span class="x8-evs-status-message" id="x8-evs-status-message"></span>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- Status Change History -->
                <div class="x8-evs-info-section">
                    <h2><?php _e('Status Change History', 'x8-evs'); ?></h2>
                    <div class="x8-evs-status-history">
                        <?php
                        $status_history = get_user_meta($customer_id, 'status_change_history', true);
                        if (is_array($status_history) && !empty($status_history)) {
                            echo '<div class="x8-evs-status-timeline">';
                            foreach ($status_history as $entry) {
                                $status_class = '';
                                $status_text = '';
                                switch($entry['status']) {
                                    case 'verified':
                                        $status_class = 'verified';
                                        $status_text = __('Verified', 'x8-evs');
                                        break;
                                    case 'block':
                                        $status_class = 'blocked';
                                        $status_text = __('Blocked', 'x8-evs');
                                        break;
                                    case 'manual_review':
                                        $status_class = 'manual_review';
                                        $status_text = __('Manual Review', 'x8-evs');
                                        break;
                                    default:
                                        $status_class = 'pending';
                                        $status_text = __('Pending', 'x8-evs');
                                }
                                
                                $timestamp = isset($entry['timestamp']) ? $entry['timestamp'] : '';
                                $admin_user = isset($entry['admin_user']) ? $entry['admin_user'] : __('Unknown', 'x8-evs');
                                $notes = isset($entry['notes']) ? $entry['notes'] : '';
                                $ip_address = isset($entry['ip_address']) ? $entry['ip_address'] : '';
                                $verification_method = isset($entry['verification_method']) ? $entry['verification_method'] : '';
                                
                                ?>
                                <div class="x8-evs-status-entry">
                                    <div class="x8-evs-status-entry-header">
                                        <div class="x8-evs-status-entry-status">
                                            <span class="x8-evs-badge <?php echo esc_attr($status_class); ?>">
                                                <?php echo esc_html($status_text); ?>
                                            </span>
                                            <?php if ($verification_method && $entry['status'] === 'verified'): ?>
                                                <span class="x8-evs-verification-method-badge">
                                                    <?php 
                                                    if ($verification_method === 'manual') {
                                                        echo __('Manual', 'x8-evs');
                                                    } elseif ($verification_method === 'api') {
                                                        echo __('API', 'x8-evs');
                                                    } elseif ($verification_method === 'approve') {
                                                        echo __('Approve', 'x8-evs');
                                                    }
                                                    ?>
                                                </span>
                                            <?php endif; ?>
                                        </div>
                                        <div class="x8-evs-status-entry-meta">
                                            <span class="x8-evs-status-entry-date">
                                                <?php echo $timestamp ? esc_html(date('F j, Y g:i A', strtotime($timestamp))) : ''; ?>
                                            </span>
                                            <span class="x8-evs-status-entry-admin">
                                                <?php printf(__('by %s', 'x8-evs'), esc_html($admin_user)); ?>
                                            </span>
                                            <?php if ($ip_address): ?>
                                                <span class="x8-evs-status-entry-ip">
                                                    <?php printf(__('from %s', 'x8-evs'), esc_html($ip_address)); ?>
                                                </span>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                    <?php if ($notes): ?>
                                        <div class="x8-evs-status-entry-notes">
                                            <strong><?php _e('Notes:', 'x8-evs'); ?></strong>
                                            <?php echo esc_html($notes); ?>
                                        </div>
                                    <?php endif; ?>
                                    <?php if ($verification_method && $entry['status'] === 'verified'): ?>
                                        <div class="x8-evs-status-entry-verification-method">
                                            <strong><?php _e('Verification Method:', 'x8-evs'); ?></strong>
                                            <?php 
                                            if ($verification_method === 'manual') {
                                                echo __('Manual Verification', 'x8-evs');
                                            } elseif ($verification_method === 'api') {
                                                echo __('API System Verification', 'x8-evs');
                                            } elseif ($verification_method === 'approve') {
                                                echo __('Approve Verification', 'x8-evs');
                                            }
                                            ?>
                                        </div>
                                    <?php endif; ?>
                                </div>
                                <?php
                            }
                            echo '</div>';
                        } else {
                            echo '<p class="x8-evs-no-history">' . __('No status change history available.', 'x8-evs') . '</p>';
                        }
                        ?>
                    </div>
                </div>
                
                <!-- Verification Debug Log -->
                <div class="x8-evs-info-section">
                    <h2><?php _e('Verification Debug Log', 'x8-evs'); ?></h2>
                    <p class="description" style="margin-bottom: 12px;">
                        <?php _e('Technical trail of API submissions and incoming EVS webhooks for this customer. Use this to check whether a verification result webhook was received.', 'x8-evs'); ?><br>
                        <?php printf(
                            __('Webhook endpoint: %s', 'x8-evs'),
                            '<code>' . esc_html(rest_url('x8-evs/v1/webhook')) . '</code>'
                        ); ?>
                    </p>
                    <?php
                    $debug_trail = class_exists('X8_EVS_Debug_Logger') ? X8_EVS_Debug_Logger::get_trail($customer_id) : array();
                    if (!empty($debug_trail)) {
                        $event_colors = array(
                            'webhook_received' => '#3b82f6',
                            'webhook_processed' => '#10b981',
                            'webhook_rejected' => '#ef4444',
                            'webhook_failed' => '#ef4444',
                            'api_request' => '#3b82f6',
                            'api_result' => '#10b981',
                            'api_waiting' => '#f59e0b',
                            'api_error' => '#ef4444',
                            'status_decision' => '#8b5cf6'
                        );
                        echo '<div class="x8-evs-debug-trail" style="max-height: 480px; overflow-y: auto; border: 1px solid #e2e8f0; border-radius: 6px; background: #fff;">';
                        foreach ($debug_trail as $trail_entry) {
                            $event = isset($trail_entry['event']) ? $trail_entry['event'] : '';
                            $color = isset($event_colors[$event]) ? $event_colors[$event] : '#6b7280';
                            ?>
                            <div style="padding: 10px 14px; border-bottom: 1px solid #f1f5f9; font-size: 13px;">
                                <div style="display: flex; align-items: center; gap: 10px; flex-wrap: wrap;">
                                    <span style="background: <?php echo esc_attr($color); ?>; color: #fff; padding: 2px 8px; border-radius: 10px; font-size: 11px; font-weight: 600;">
                                        <?php echo esc_html($event); ?>
                                    </span>
                                    <span style="color: #6b7280;">
                                        <?php echo isset($trail_entry['timestamp']) ? esc_html(date('F j, Y g:i:s A', strtotime($trail_entry['timestamp']))) : ''; ?>
                                    </span>
                                </div>
                                <div style="margin-top: 6px; color: #1f2937;">
                                    <?php echo esc_html(isset($trail_entry['message']) ? $trail_entry['message'] : ''); ?>
                                </div>
                                <?php if (!empty($trail_entry['context'])): ?>
                                    <details style="margin-top: 6px;">
                                        <summary style="cursor: pointer; color: #6b7280;"><?php _e('Details', 'x8-evs'); ?></summary>
                                        <pre style="margin: 6px 0 0; padding: 8px; background: #f8fafc; border-radius: 4px; overflow-x: auto; font-size: 12px; white-space: pre-wrap; word-break: break-word;"><?php echo esc_html(wp_json_encode($trail_entry['context'], JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES)); ?></pre>
                                    </details>
                                <?php endif; ?>
                            </div>
                            <?php
                        }
                        echo '</div>';
                    } else {
                        echo '<p class="x8-evs-no-history">' . __('No debug events recorded yet for this customer. Events are recorded from now on for every API verification attempt and incoming webhook.', 'x8-evs') . '</p>';
                    }
                    ?>
                </div>
                
                <!-- Location Verification Log (EVS AssureLocate) -->
                <div class="x8-evs-info-section">
                    <h2><?php _e('Location Verification Log (EVS AssureLocate)', 'x8-evs'); ?></h2>
                    <p class="description" style="margin-bottom: 12px;">
                        <?php _e('Every AssureLocate location verification for this customer, including the full webhook response received from EVS.', 'x8-evs'); ?>
                    </p>
                    <?php $this->render_assurelocate_log($customer_id); ?>
                </div>
            </div>
        </div>
        <?php
    }

    /**
     * Render the AssureLocate location verification log table for a customer
     */
    private function render_assurelocate_log($customer_id) {
        global $wpdb;

        if (!class_exists('X8_EVS_AssureLocate_Handler')) {
            require_once X8_EVS_PLUGIN_PATH . 'inc/frontend/class-assurelocate-handler.php';
        }

        $table_name = X8_EVS_AssureLocate_Handler::get_table_name();
        $table_exists = $wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $table_name));

        if ($table_exists !== $table_name) {
            echo '<p class="x8-evs-no-history">' . __('No location verifications recorded yet.', 'x8-evs') . '</p>';
            return;
        }

        $records = $wpdb->get_results($wpdb->prepare(
            "SELECT * FROM $table_name WHERE user_id = %d ORDER BY id DESC LIMIT 25",
            $customer_id
        ));

        if (empty($records)) {
            echo '<p class="x8-evs-no-history">' . __('No location verifications recorded yet.', 'x8-evs') . '</p>';
            return;
        }

        $status_colors = array(
            'passed' => '#10b981',
            'failed' => '#ef4444',
            'error' => '#ef4444',
            'pending' => '#f59e0b',
            'submitted' => '#3b82f6'
        );
        ?>
        <table class="widefat striped" style="border: 1px solid #e2e8f0; border-radius: 6px;">
            <thead>
                <tr>
                    <th><?php _e('Date', 'x8-evs'); ?></th>
                    <th><?php _e('Status', 'x8-evs'); ?></th>
                    <th><?php _e('IP Address', 'x8-evs'); ?></th>
                    <th><?php _e('Location', 'x8-evs'); ?></th>
                    <th><?php _e('VPN', 'x8-evs'); ?></th>
                    <th><?php _e('Transaction', 'x8-evs'); ?></th>
                    <th><?php _e('Webhook Response', 'x8-evs'); ?></th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($records as $rec):
                    $color = isset($status_colors[$rec->status]) ? $status_colors[$rec->status] : '#6b7280';
                    $webhook = !empty($rec->webhook_response) ? json_decode($rec->webhook_response, true) : null;

                    $device_location = '';
                    $ip_location = '';
                    if ($webhook && isset($webhook['data']['assureLocate'])) {
                        $device = $webhook['data']['assureLocate']['deviceLocation'] ?? array();
                        $ip_loc = $webhook['data']['assureLocate']['ipLocation'] ?? array();
                        $device_location = trim(implode(', ', array_filter(array(
                            $device['city'] ?? '',
                            $device['province'] ?? '',
                            $device['country'] ?? ''
                        ))), ', ');
                        $ip_location = trim(implode(', ', array_filter(array(
                            $ip_loc['city'] ?? '',
                            $ip_loc['isoCountry'] ?? ''
                        ))), ', ');
                    }
                    ?>
                    <tr>
                        <td style="white-space: nowrap;">
                            <?php echo esc_html(date('M j, Y g:i A', strtotime($rec->created_at))); ?>
                            <?php if (!empty($rec->verified_at)): ?>
                                <br><small style="color: #6b7280;"><?php printf(__('Result: %s', 'x8-evs'), esc_html(date('M j, Y g:i A', strtotime($rec->verified_at)))); ?></small>
                            <?php endif; ?>
                        </td>
                        <td>
                            <span style="background: <?php echo esc_attr($color); ?>; color: #fff; padding: 2px 10px; border-radius: 10px; font-size: 11px; font-weight: 600; text-transform: uppercase;">
                                <?php echo esc_html($rec->status); ?>
                            </span>
                        </td>
                        <td>
                            <code><?php echo esc_html($rec->ip_address); ?></code>
                            <?php if (!empty($rec->verified_ip) && $rec->verified_ip !== $rec->ip_address): ?>
                                <br><small style="color: #6b7280;"><?php _e('Verified:', 'x8-evs'); ?> <code><?php echo esc_html($rec->verified_ip); ?></code></small>
                            <?php endif; ?>
                        </td>
                        <td>
                            <?php if ($device_location): ?>
                                <strong><?php _e('Device:', 'x8-evs'); ?></strong> <?php echo esc_html($device_location); ?><br>
                            <?php endif; ?>
                            <?php if ($ip_location): ?>
                                <small style="color: #6b7280;"><?php _e('IP:', 'x8-evs'); ?> <?php echo esc_html($ip_location); ?></small>
                            <?php endif; ?>
                            <?php if (!$device_location && !$ip_location) echo '&mdash;'; ?>
                        </td>
                        <td>
                            <?php if (!empty($rec->vpn_probability)): ?>
                                <strong><?php echo esc_html($rec->vpn_probability); ?></strong>
                                <?php if (!empty($rec->vpn_description)): ?>
                                    <br><small style="color: #6b7280;"><?php echo esc_html($rec->vpn_description); ?></small>
                                <?php endif; ?>
                            <?php else: ?>
                                &mdash;
                            <?php endif; ?>
                        </td>
                        <td><?php echo !empty($rec->transaction_id) ? esc_html($rec->transaction_id) : '&mdash;'; ?></td>
                        <td>
                            <?php if ($webhook): ?>
                                <details>
                                    <summary style="cursor: pointer; color: #2271b1;"><?php _e('View full response', 'x8-evs'); ?></summary>
                                    <pre style="margin: 6px 0 0; padding: 8px; background: #f8fafc; border-radius: 4px; max-width: 420px; max-height: 320px; overflow: auto; font-size: 11px; white-space: pre-wrap; word-break: break-word;"><?php echo esc_html(wp_json_encode($webhook, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES)); ?></pre>
                                </details>
                            <?php else: ?>
                                <span style="color: #6b7280;"><?php _e('Not received yet', 'x8-evs'); ?></span>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
        <?php
    }

    /**
     * Render Customers Tab
     */
    private function render_customers_tab() {
        // Get current page for pagination
        $current_page = isset($_GET['customer_page']) ? max(1, intval($_GET['customer_page'])) : 1;
        $per_page = 20;
        
        // Get customers data
        $customers_data = $this->get_customers_paginated($current_page, $per_page);
        
        ?>
        <div class="x8-evs-customers-content">
            <div class="x8-evs-customers-header">
                <h2><?php _e('Manage Customers', 'x8-evs'); ?></h2>
            </div>
            
            <!-- Customer Search and Filters -->
            <div class="x8-evs-customer-filters">
                <div class="x8-evs-filter-row">
                    <div class="x8-evs-search-box">
                        <input type="text" class="x8-evs-customer-search" placeholder="<?php _e('Search customers...', 'x8-evs'); ?>" />
                        <span class="dashicons dashicons-search"></span>
                    </div>
                    <div class="x8-evs-filter-select">
                        <select class="x8-evs-status-filter">
                            <option value=""><?php _e('All Statuses', 'x8-evs'); ?></option>
                            <option value="active"><?php _e('Active', 'x8-evs'); ?></option>
                            <option value="blocked"><?php _e('Blocked', 'x8-evs'); ?></option>
                            <option value="pending"><?php _e('Pending', 'x8-evs'); ?></option>
                            <option value="manual_review"><?php _e('Manual Review', 'x8-evs'); ?></option>
                        </select>
                    </div>
                    <div class="x8-evs-export-wrap">
                        <select class="x8-evs-export-status" id="x8-evs-export-status">
                            <option value=""><?php _e('All Statuses', 'x8-evs'); ?></option>
                            <option value="pending"><?php _e('Pending', 'x8-evs'); ?></option>
                            <option value="active"><?php _e('Active', 'x8-evs'); ?></option>
                            <option value="blocked"><?php _e('Blocked', 'x8-evs'); ?></option>
                            <option value="manual_review"><?php _e('Manual Review', 'x8-evs'); ?></option>
                        </select>
                        <a href="#" class="button button-secondary x8-evs-export-excel" id="x8-evs-export-excel-btn">
                            <span class="dashicons dashicons-download" style="margin-right: 4px;"></span>
                            <?php _e('Export to Excel', 'x8-evs'); ?>
                        </a>
                    </div>
                </div>
            </div>

            <!-- Customer Table -->
            <div class="x8-evs-customers-table">
                <div class="x8-evs-table-container">
                    <table class="wp-list-table widefat fixed striped">
                        <thead>
                            <tr>
                                <th class="manage-column column-cb check-column">
                                    <input type="checkbox" class="x8-evs-select-all" />
                                </th>
                                <th class="manage-column sortable">
                                    <a href="#"><span><?php _e('ID', 'x8-evs'); ?></span></a>
                                </th>
                                <th class="manage-column sortable">
                                    <a href="#"><span><?php _e('Name', 'x8-evs'); ?></span></a>
                                </th>
                                <th class="manage-column sortable">
                                    <a href="#"><span><?php _e('Email', 'x8-evs'); ?></span></a>
                                </th>
                                <th class="manage-column">
                                    <?php _e('Phone', 'x8-evs'); ?>
                                </th>
                                <th class="manage-column">
                                    <?php _e('Status', 'x8-evs'); ?>
                                </th>
                                <th class="manage-column">
                                    <?php _e('Registered', 'x8-evs'); ?>
                                </th>
                                <th class="manage-column">
                                    <?php _e('Actions', 'x8-evs'); ?>
                                </th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (empty($customers_data['customers'])): ?>
                                <tr>
                                    <td colspan="8" style="text-align: center; padding: 40px; color: #646970;">
                                        <span class="dashicons dashicons-groups" style="font-size: 48px; opacity: 0.3; display: block; margin-bottom: 10px;"></span>
                                        <?php _e('No customers found. Add your first customer to get started.', 'x8-evs'); ?>
                                    </td>
                                </tr>
                            <?php else: ?>
                                <?php foreach ($customers_data['customers'] as $customer): ?>
                                    <tr>
                                        <td class="check-column">
                                            <input type="checkbox" name="customer[]" value="<?php echo esc_attr($customer['id']); ?>" />
                                        </td>
                                        <td><strong><?php echo esc_html($customer['id']); ?></strong></td>
                                        <td>
                                            <strong>
                                                <a href="<?php echo admin_url('admin.php?page=x8-evs&view_customer=' . $customer['id']); ?>" class="row-title">
                                                    <?php echo esc_html($customer['name']); ?>
                                                </a>
                                            </strong>
                                            <div class="row-actions">
                                                <span class="view">
                                                    <a href="<?php echo admin_url('admin.php?page=x8-evs&view_customer=' . $customer['id']); ?>"><?php _e('View', 'x8-evs'); ?></a> |
                                                </span>
                                                <span class="trash">
                                                    <a href="#" class="x8-evs-delete-customer" data-id="<?php echo esc_attr($customer['id']); ?>"><?php _e('Delete', 'x8-evs'); ?></a>
                                                </span>
                                            </div>
                                        </td>
                                        <td><?php echo esc_html($customer['email']); ?></td>
                                        <td><?php echo esc_html($customer['phone'] ?: '—'); ?></td>
                                        <td>
                                            <span class="x8-evs-badge <?php echo esc_attr($customer['status']); ?>">
                                                <?php echo esc_html(ucfirst($customer['status'])); ?>
                                            </span>
                                        </td>
                                        <td><?php echo esc_html(date('M j, Y', strtotime($customer['created_at']))); ?></td>
                                        <td>
                                            <div class="x8-evs-action-buttons">
                                                <a href="<?php echo admin_url('admin.php?page=x8-evs&view_customer=' . $customer['id']); ?>" class="button button-small" title="<?php _e('View Customer', 'x8-evs'); ?>">
                                                    <span class="dashicons dashicons-visibility"></span>
                                                </a>
                                                <button class="button button-small x8-evs-delete-customer" data-id="<?php echo esc_attr($customer['id']); ?>" title="<?php _e('Delete Customer', 'x8-evs'); ?>">
                                                    <span class="dashicons dashicons-trash"></span>
                                                </button>
                                            </div>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>

                <!-- Pagination -->
                <!-- Pagination will be populated by AJAX -->
                <div class="x8-evs-pagination"></div>
            </div>
        </div>
        <?php
    }

    /**
     * Get customers with pagination
     */
    private function get_customers_paginated($page = 1, $per_page = 20) {
        $offset = ($page - 1) * $per_page;
        
        // Get total user count
        $counts = count_users();
        $total = 0;
        foreach (self::customer_list_roles() as $role) {
            $total += isset($counts['avail_roles'][$role]) ? (int) $counts['avail_roles'][$role] : 0;
        }
        
        // Get users for current page
        $users = get_users(array(
            'number' => $per_page,
            'offset' => $offset,
            'orderby' => 'registered',
            'order' => 'DESC',
            'role__in' => self::customer_list_roles(),
            'fields' => 'all'
        ));

        // Format users data to match expected structure
        $customers = array();
        foreach ($users as $user) {
            // Get user meta for additional fields
            $phone = get_user_meta($user->ID, 'phone', true) ?: get_user_meta($user->ID, 'billing_phone', true);
            
            // Determine status based on account_status user meta
            $account_status = get_user_meta($user->ID, 'account_status', true);
            
            if (empty($account_status)) {
                $status = 'pending'; // Empty means pending
            } elseif ($account_status === 'verified') {
                $status = 'active'; // Verified means active/verified
            } elseif ($account_status === 'block') {
                $status = 'blocked'; // Block means blocked
            } elseif ($account_status === 'manual_review') {
                $status = 'manual_review'; // Manual review status
            } elseif ($account_status === '') {
                $status = 'pending'; // Default fallback to pending
            }
            else {
                $status = $account_status; // Default fallback to pending
            }
            
            $customers[] = array(
                'id' => $user->ID,
                'name' => $user->display_name ?: ($user->first_name . ' ' . $user->last_name),
                'email' => $user->user_email,
                'phone' => $phone ?: '—',
                'status' => $status,
                'created_at' => $user->user_registered
            );
        }

        // Calculate total pages
        $total_pages = ceil($total / $per_page);

        return array(
            'customers' => $customers,
            'total' => $total,
            'total_pages' => $total_pages
        );
    }

    /**
     * Render Verifications Tab
     */
    private function render_verifications_tab() {
        ?>
        <div class="x8-evs-verifications-content">
            <h2><?php _e('Email Verifications', 'x8-evs'); ?></h2>
            
            <div class="x8-evs-verification-tools">
                <div class="x8-evs-single-verify">
                    <h3><?php _e('Verify Single Email', 'x8-evs'); ?></h3>
                    <div class="x8-evs-verify-form">
                        <input type="email" placeholder="<?php _e('Enter email address', 'x8-evs'); ?>" class="regular-text" />
                        <button class="button button-primary"><?php _e('Verify Email', 'x8-evs'); ?></button>
                    </div>
                </div>
            </div>

            <div class="x8-evs-recent-verifications">
                <h3><?php _e('Recent Verifications', 'x8-evs'); ?></h3>
                <div class="x8-evs-table-container">
                    <table class="wp-list-table widefat fixed striped">
                        <thead>
                            <tr>
                                <th><?php _e('Email', 'x8-evs'); ?></th>
                                <th><?php _e('Status', 'x8-evs'); ?></th>
                                <th><?php _e('Date', 'x8-evs'); ?></th>
                                <th><?php _e('Result', 'x8-evs'); ?></th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td colspan="4" style="text-align: center; padding: 40px; color: #646970;">
                                    <?php _e('No verifications yet. Start verifying emails to see results here.', 'x8-evs'); ?>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
        <?php
    }

    /**
     * Render Settings Tab
     */
    private function render_settings_tab() {
        ?>
        <div class="x8-evs-settings-content">
            <h2><?php _e('Configuration Settings', 'x8-evs'); ?></h2>
            
            <div class="x8-evs-settings-sections">
                <div class="x8-evs-settings-section">
                    <h3><?php _e('Verification Options', 'x8-evs'); ?></h3>
                    <form method="post" action="options.php">
                        <?php settings_fields('x8_evs_verification_settings'); ?>
                        <table class="form-table">
                            <tr>
                                <th scope="row"><?php _e('Verification Page', 'x8-evs'); ?></th>
                                <td>
                                    <?php 
                                    $selected_page = get_option('x8_evs_verification_page', 0);
                                    $pages = get_pages(array(
                                        'sort_order' => 'ASC',
                                        'sort_column' => 'post_title',
                                        'post_status' => 'publish'
                                    ));
                                    ?>
                                    <select name="x8_evs_verification_page" id="x8_evs_verification_page" class="regular-text">
                                        <option value="0" <?php selected($selected_page, 0); ?>><?php _e('Select a page...', 'x8-evs'); ?></option>
                                        <?php foreach ($pages as $page): ?>
                                            <option value="<?php echo esc_attr($page->ID); ?>" <?php selected($selected_page, $page->ID); ?>>
                                                <?php echo esc_html($page->post_title); ?>
                                                <?php if ($page->post_parent): ?>
                                                    <?php 
                                                    $parent = get_post($page->post_parent);
                                                    if ($parent) {
                                                        echo ' (' . esc_html($parent->post_title) . ')';
                                                    }
                                                    ?>
                                                <?php endif; ?>
                                            </option>
                                        <?php endforeach; ?>
                                    </select>
                                    <p class="description"><?php _e('Select the page where customers will complete identity verification. If no page is selected, verification will use the default form.', 'x8-evs'); ?></p>
                                </td>
                            </tr>
                            <tr>
                                <th scope="row"><?php _e('Verification Trigger', 'x8-evs'); ?></th>
                                <td>
                                    <select name="x8_evs_verification_trigger" id="x8_evs_verification_trigger" class="regular-text">
                                        <option value="disabled" <?php selected(get_option('x8_evs_verification_trigger', 'disabled'), 'disabled'); ?>><?php _e('Disabled', 'x8-evs'); ?></option>
                                        <option value="after_registration" <?php selected(get_option('x8_evs_verification_trigger', 'disabled'), 'after_registration'); ?>><?php _e('After Registration', 'x8-evs'); ?></option>
                                        <option value="checkout_page" <?php selected(get_option('x8_evs_verification_trigger', 'disabled'), 'checkout_page'); ?>><?php _e('On Checkout Page', 'x8-evs'); ?></option>
                                        <option value="manual" <?php selected(get_option('x8_evs_verification_trigger', 'disabled'), 'manual'); ?>><?php _e('Manual Only', 'x8-evs'); ?></option>
                                    </select>
                                    <p class="description"><?php _e('Choose when identity verification should be performed for customers.', 'x8-evs'); ?></p>
                                </td>
                            </tr>
                            <tr>
                                <th scope="row"><?php _e('Auto-delete pending users', 'x8-evs'); ?></th>
                                <td>
                                    <?php
                                    $pending_days = (int) get_option('x8_evs_pending_auto_delete_days', 0);
                                    $pending_days = max(0, min(60, $pending_days));
                                    ?>
                                    <select name="x8_evs_pending_auto_delete_days" id="x8_evs_pending_auto_delete_days" class="regular-text">
                                        <option value="0" <?php selected($pending_days, 0); ?>><?php _e('Disabled', 'x8-evs'); ?></option>
                                        <?php for ($d = 1; $d <= 60; $d++) : ?>
                                            <option value="<?php echo (int) $d; ?>" <?php selected($pending_days, $d); ?>><?php echo esc_html(sprintf(_n('%d day', '%d days', $d, 'x8-evs'), $d)); ?></option>
                                        <?php endfor; ?>
                                    </select>
                                    <p class="description"><?php _e('Users who remain in Pending verification longer than this period will be automatically deleted. Only applies to users with status Pending.', 'x8-evs'); ?></p>
                                </td>
                            </tr>
                            <tr>
                                <th scope="row"><?php _e('Document Types', 'x8-evs'); ?></th>
                                <td>
                                    <?php
                                    $document_types_map = X8_EVS_Admin_Settings::get_document_types_map();
                                    $allowed_types = X8_EVS_Admin_Settings::get_allowed_document_types();
                                    $saved_multi = get_option('x8_evs_document_types', array());
                                    if (!empty($saved_multi) && is_array($saved_multi)) {
                                        $allowed_types = $saved_multi;
                                    } else {
                                        $allowed_types = array(get_option('x8_evs_document_type', 'DriversLicense'));
                                    }
                                    $default_type = X8_EVS_Admin_Settings::get_default_document_type();
                                    $preview_parts = array();
                                    foreach ($allowed_types as $v) {
                                        if (isset($document_types_map[$v])) {
                                            $preview_parts[] = $document_types_map[$v] . ($v === $default_type ? ' (' . __('default', 'x8-evs') . ')' : '');
                                        }
                                    }
                                    $preview_text = implode(', ', $preview_parts);
                                    ?>
                                    <p class="description" style="margin-bottom: 10px;"><?php _e('Choose which document types customers can use and which one is pre-selected by default.', 'x8-evs'); ?></p>
                                    <div class="x8-evs-document-types-toggle-wrap">
                                        <button type="button" class="button button-secondary x8-evs-toggle-document-types">
                                            <span class="dashicons dashicons-admin-settings" style="margin-right: 4px;"></span>
                                            <span class="x8-evs-doc-toggle-btn-text"><?php _e('Configure Document Types', 'x8-evs'); ?></span>
                                        </button>
                                        <div class="x8-evs-document-types-preview" style="margin-top: 10px;">
                                            <strong><?php _e('Current:', 'x8-evs'); ?></strong>
                                            <span class="x8-evs-document-types-preview-text"><?php echo esc_html($preview_text ?: '—'); ?></span>
                                        </div>
                                    </div>
                                    <div class="x8-evs-document-types-panel" style="display: none; margin-top: 16px;">
                                        <div class="x8-evs-document-types-table-wrap">
                                            <table class="x8-evs-document-types-table" role="presentation">
                                                <thead>
                                                    <tr>
                                                        <th class="x8-evs-doc-col-type"><?php _e('Document type', 'x8-evs'); ?></th>
                                                        <th class="x8-evs-doc-col-allow"><?php _e('Allow', 'x8-evs'); ?></th>
                                                        <th class="x8-evs-doc-col-default"><?php _e('Default', 'x8-evs'); ?></th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <?php foreach ($document_types_map as $value => $label): ?>
                                                        <?php
                                                        $is_allowed = in_array($value, $allowed_types, true);
                                                        $is_default = ($default_type === $value);
                                                        ?>
                                                        <tr>
                                                            <td class="x8-evs-doc-col-type"><?php echo esc_html($label); ?></td>
                                                            <td class="x8-evs-doc-col-allow">
                                                                <label class="x8-evs-doc-allow-label">
                                                                    <input type="checkbox" name="x8_evs_document_types[]" value="<?php echo esc_attr($value); ?>" <?php checked($is_allowed); ?> class="x8-evs-doc-allow-cb" data-doc-value="<?php echo esc_attr($value); ?>" />
                                                                    <span class="screen-reader-text"><?php printf(__('Allow %s', 'x8-evs'), esc_html($label)); ?></span>
                                                                </label>
                                                            </td>
                                                            <td class="x8-evs-doc-col-default">
                                                                <label class="x8-evs-doc-default-label">
                                                                    <input type="radio" name="x8_evs_document_type" value="<?php echo esc_attr($value); ?>" <?php checked($is_default); ?> <?php echo $is_allowed ? '' : 'disabled'; ?> class="x8-evs-doc-default-radio" />
                                                                    <span class="screen-reader-text"><?php printf(__('Set %s as default', 'x8-evs'), esc_html($label)); ?></span>
                                                                </label>
                                                            </td>
                                                        </tr>
                                                    <?php endforeach; ?>
                                                </tbody>
                                            </table>
                                        </div>
                                        <p class="description" style="margin-top: 10px;"><?php _e('If multiple types are allowed, the customer will choose their preferred type on the verification page. Default is the pre-selected option.', 'x8-evs'); ?></p>
                                    </div>
                                </td>
                            </tr>
                            <tr>
                                <th scope="row"><?php _e('Require Selfie', 'x8-evs'); ?></th>
                                <td>
                                    <label>
                                        <input type="checkbox" name="x8_evs_require_selfie" value="1" <?php checked(get_option('x8_evs_require_selfie', 1), 1); ?> />
                                        <?php _e('Force live-capture of selfie for verification', 'x8-evs'); ?>
                                    </label>
                                    <p class="description"><?php _e('When enabled, customers must provide a selfie photo along with their ID document for verification.', 'x8-evs'); ?></p>
                                    
                                    <div id="x8_evs_selfie_thresholds_wrapper" style="margin-top: 15px; padding: 15px; background: #f9f9f9; border: 1px solid #ddd; border-radius: 4px; <?php echo (get_option('x8_evs_require_selfie', 1) ? '' : 'display: none;'); ?>">
                                        <h4 style="margin-top: 0; color: #23282d;"><?php _e('Selfie-Specific Thresholds', 'x8-evs'); ?></h4>
                                        <p style="margin-bottom: 15px; color: #666;"><?php _e('Configure separate approval thresholds when selfie verification is required. These thresholds are typically higher since selfie verification provides additional security.', 'x8-evs'); ?></p>
                                        
                                        <div class="x8-evs-selfie-threshold-toggle">
                                            <button type="button" class="x8-evs-toggle-selfie-thresholds button-secondary">
                                                <span class="dashicons dashicons-admin-settings"></span>
                                                <?php _e('Configure Selfie Thresholds', 'x8-evs'); ?>
                                            </button>
                                            <div class="x8-evs-current-selfie-thresholds">
                                                <span class="x8-evs-selfie-threshold-preview">
                                                    <strong><?php _e('Current:', 'x8-evs'); ?></strong>
                                                    Block: 0-<?php echo esc_html(get_option('x8_evs_selfie_auto_block_threshold', 75)); ?> | 
                                                    Review: <?php echo esc_html(get_option('x8_evs_selfie_auto_block_threshold', 75) + 1); ?>-<?php echo esc_html(get_option('x8_evs_selfie_manual_review_threshold', 90)); ?> | 
                                                    Approve: <?php echo esc_html(get_option('x8_evs_selfie_auto_approve_threshold', 91)); ?>-100
                                                </span>
                                            </div>
                                        </div>
                                        
                                        <div class="x8-evs-selfie-threshold-sliders" style="display: none;">
                                            <div class="x8-evs-threshold-section">
                                                <h4><?php _e('Selfie Auto Block Threshold', 'x8-evs'); ?></h4>
                                                <div class="x8-evs-slider-container">
                                                    <input type="number" 
                                                           id="x8_evs_selfie_auto_block_threshold" 
                                                           name="x8_evs_selfie_auto_block_threshold" 
                                                           min="0" 
                                                           max="100" 
                                                           value="<?php echo esc_attr(get_option('x8_evs_selfie_auto_block_threshold', 75)); ?>" 
                                                           class="x8-evs-threshold-input" 
                                                           data-threshold-type="selfie-auto-block" />
                                                    <div class="x8-evs-slider-value">
                                                        <span class="x8-evs-slider-label"><?php _e('Score 0-', 'x8-evs'); ?><span class="x8-evs-threshold-value"><?php echo esc_html(get_option('x8_evs_selfie_auto_block_threshold', 75)); ?></span><?php _e(' = Automatic Block', 'x8-evs'); ?></span>
                                                    </div>
                                                </div>
                                            </div>
                                            
                                            <div class="x8-evs-threshold-section">
                                                <h4><?php _e('Selfie Manual Review Threshold', 'x8-evs'); ?></h4>
                                                <div class="x8-evs-slider-container">
                                                    <input type="number" 
                                                           id="x8_evs_selfie_manual_review_threshold" 
                                                           name="x8_evs_selfie_manual_review_threshold" 
                                                           min="0" 
                                                           max="100" 
                                                           value="<?php echo esc_attr(get_option('x8_evs_selfie_manual_review_threshold', 90)); ?>" 
                                                           class="x8-evs-threshold-input" 
                                                           data-threshold-type="selfie-manual-review" />
                                                    <div class="x8-evs-slider-value">
                                                        <span class="x8-evs-slider-label"><?php _e('Score ', 'x8-evs'); ?><span class="x8-evs-threshold-value"><?php echo esc_html(get_option('x8_evs_selfie_auto_block_threshold', 75) + 1); ?></span><?php _e('-', 'x8-evs'); ?><span class="x8-evs-threshold-value"><?php echo esc_html(get_option('x8_evs_selfie_manual_review_threshold', 90)); ?></span><?php _e(' = Manual Review', 'x8-evs'); ?></span>
                                                    </div>
                                                </div>
                                            </div>
                                            
                                            <div class="x8-evs-threshold-section">
                                                <h4><?php _e('Selfie Auto Approval Threshold', 'x8-evs'); ?></h4>
                                                <div class="x8-evs-slider-container">
                                                    <input type="number" 
                                                           id="x8_evs_selfie_auto_approve_threshold" 
                                                           name="x8_evs_selfie_auto_approve_threshold" 
                                                           min="0" 
                                                           max="100" 
                                                           value="<?php echo esc_attr(get_option('x8_evs_selfie_auto_approve_threshold', 91)); ?>" 
                                                           class="x8-evs-threshold-input" 
                                                           data-threshold-type="selfie-auto-approve" />
                                                    <div class="x8-evs-slider-value">
                                                        <span class="x8-evs-slider-label"><?php _e('Score ', 'x8-evs'); ?><span class="x8-evs-threshold-value"><?php echo esc_html(get_option('x8_evs_selfie_auto_approve_threshold', 91)); ?></span><?php _e('-100 = Automatic Approval', 'x8-evs'); ?></span>
                                                    </div>
                                                </div>
                                            </div>
                                            
                                            <div class="x8-evs-threshold-summary">
                                                <h4><?php _e('Selfie Threshold Summary', 'x8-evs'); ?></h4>
                                                <div class="x8-evs-threshold-ranges">
                                                    <div class="x8-evs-range-block">
                                                        <span class="x8-evs-range-label"><?php _e('Block:', 'x8-evs'); ?></span>
                                                        <span class="x8-evs-range-value">0 - <?php echo esc_html(get_option('x8_evs_selfie_auto_block_threshold', 75)); ?></span>
                                                    </div>
                                                    <div class="x8-evs-range-manual">
                                                        <span class="x8-evs-range-label"><?php _e('Manual Review:', 'x8-evs'); ?></span>
                                                        <span class="x8-evs-range-value"><?php echo esc_html(get_option('x8_evs_selfie_auto_block_threshold', 75) + 1); ?> - <?php echo esc_html(get_option('x8_evs_selfie_manual_review_threshold', 90)); ?></span>
                                                    </div>
                                                    <div class="x8-evs-range-approve">
                                                        <span class="x8-evs-range-label"><?php _e('Auto Approve:', 'x8-evs'); ?></span>
                                                        <span class="x8-evs-range-value"><?php echo esc_html(get_option('x8_evs_selfie_auto_approve_threshold', 91)); ?> - 100</span>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </td>
                            </tr>
                            <tr>
                                <th scope="row"><?php _e('Blocked States', 'x8-evs'); ?></th>
                                <td>
                                    <?php 
                                    $blocked_states = get_option('x8_evs_blocked_states', array());
                                    $us_states = array(
                                        'AL' => 'Alabama', 'AK' => 'Alaska', 'AZ' => 'Arizona', 'AR' => 'Arkansas', 'CA' => 'California',
                                        'CO' => 'Colorado', 'CT' => 'Connecticut', 'DE' => 'Delaware', 'FL' => 'Florida', 'GA' => 'Georgia',
                                        'HI' => 'Hawaii', 'ID' => 'Idaho', 'IL' => 'Illinois', 'IN' => 'Indiana', 'IA' => 'Iowa',
                                        'KS' => 'Kansas', 'KY' => 'Kentucky', 'LA' => 'Louisiana', 'ME' => 'Maine', 'MD' => 'Maryland',
                                        'MA' => 'Massachusetts', 'MI' => 'Michigan', 'MN' => 'Minnesota', 'MS' => 'Mississippi', 'MO' => 'Missouri',
                                        'MT' => 'Montana', 'NE' => 'Nebraska', 'NV' => 'Nevada', 'NH' => 'New Hampshire', 'NJ' => 'New Jersey',
                                        'NM' => 'New Mexico', 'NY' => 'New York', 'NC' => 'North Carolina', 'ND' => 'North Dakota', 'OH' => 'Ohio',
                                        'OK' => 'Oklahoma', 'OR' => 'Oregon', 'PA' => 'Pennsylvania', 'RI' => 'Rhode Island', 'SC' => 'South Carolina',
                                        'SD' => 'South Dakota', 'TN' => 'Tennessee', 'TX' => 'Texas', 'UT' => 'Utah', 'VT' => 'Vermont',
                                        'VA' => 'Virginia', 'WA' => 'Washington', 'WV' => 'West Virginia', 'WI' => 'Wisconsin', 'WY' => 'Wyoming',
                                        'DC' => 'District of Columbia'
                                    );
                                    ?>
                                    <div class="x8-evs-select2-container">
                                        <select name="x8_evs_blocked_states[]" id="x8_evs_blocked_states" multiple="multiple" class="x8-evs-select2-states" style="width: 100%;">
                                            <?php foreach ($us_states as $code => $name): ?>
                                                <option value="<?php echo esc_attr($code); ?>" <?php selected(in_array($code, $blocked_states), true); ?>>
                                                    <?php echo esc_html($name . ' (' . $code . ')'); ?>
                                                </option>
                                            <?php endforeach; ?>
                                        </select>
                                        <div class="x8-evs-select2-controls" style="margin-top: 10px;">
                                            <button type="button" class="button button-small x8-evs-select-all-states">
                                                <span class="dashicons dashicons-yes-alt" style="margin-right: 3px;"></span><?php _e('Select All', 'x8-evs'); ?>
                                            </button>
                                            <button type="button" class="button button-small x8-evs-clear-states">
                                                <span class="dashicons dashicons-no-alt" style="margin-right: 3px;"></span><?php _e('Clear All', 'x8-evs'); ?>
                                            </button>
                                            <button type="button" class="button button-small x8-evs-toggle-states">
                                                <span class="dashicons dashicons-visibility" style="margin-right: 3px;"></span><?php _e('Toggle Selection', 'x8-evs'); ?>
                                            </button>
                                        </div>
                                        <div class="x8-evs-select2-status" style="margin-top: 8px; font-size: 12px; color: #666;">
                                            <span class="x8-evs-status-text"></span>
                                        </div>
                                    </div>
                                    <p class="description">
                                        <?php _e('Select states to block customers from. Customers from selected states will be blocked from verification. Use the search box to quickly find states.', 'x8-evs'); ?>
                                    </p>
                                </td>
                            </tr>
                            <tr>
                                <th scope="row"><?php _e('Allowed Countries', 'x8-evs'); ?></th>
                                <td>
                                    <?php 
                                    $allowed_countries = get_option('x8_evs_allowed_countries', array());
                                    $countries = array(
                                        'US' => 'United States', 'CA' => 'Canada', 'GB' => 'United Kingdom', 'AU' => 'Australia', 'DE' => 'Germany',
                                        'FR' => 'France', 'IT' => 'Italy', 'ES' => 'Spain', 'NL' => 'Netherlands', 'BE' => 'Belgium',
                                        'CH' => 'Switzerland', 'AT' => 'Austria', 'SE' => 'Sweden', 'NO' => 'Norway', 'DK' => 'Denmark',
                                        'FI' => 'Finland', 'IE' => 'Ireland', 'PT' => 'Portugal', 'LU' => 'Luxembourg', 'IS' => 'Iceland',
                                        'MT' => 'Malta', 'CY' => 'Cyprus', 'GR' => 'Greece', 'PL' => 'Poland', 'CZ' => 'Czech Republic',
                                        'HU' => 'Hungary', 'SK' => 'Slovakia', 'SI' => 'Slovenia', 'HR' => 'Croatia', 'BG' => 'Bulgaria',
                                        'RO' => 'Romania', 'LT' => 'Lithuania', 'LV' => 'Latvia', 'EE' => 'Estonia', 'JP' => 'Japan',
                                        'KR' => 'South Korea', 'SG' => 'Singapore', 'HK' => 'Hong Kong', 'TW' => 'Taiwan', 'NZ' => 'New Zealand',
                                        'BR' => 'Brazil', 'AR' => 'Argentina', 'CL' => 'Chile', 'CO' => 'Colombia', 'MX' => 'Mexico',
                                        'PE' => 'Peru', 'VE' => 'Venezuela', 'UY' => 'Uruguay', 'PY' => 'Paraguay', 'BO' => 'Bolivia',
                                        'EC' => 'Ecuador', 'GY' => 'Guyana', 'SR' => 'Suriname', 'GF' => 'French Guiana', 'FK' => 'Falkland Islands',
                                        'ZA' => 'South Africa', 'EG' => 'Egypt', 'NG' => 'Nigeria', 'KE' => 'Kenya', 'GH' => 'Ghana',
                                        'MA' => 'Morocco', 'TN' => 'Tunisia', 'DZ' => 'Algeria', 'LY' => 'Libya', 'SD' => 'Sudan',
                                        'ET' => 'Ethiopia', 'UG' => 'Uganda', 'TZ' => 'Tanzania', 'ZW' => 'Zimbabwe', 'BW' => 'Botswana',
                                        'NA' => 'Namibia', 'SZ' => 'Swaziland', 'LS' => 'Lesotho', 'MW' => 'Malawi', 'ZM' => 'Zambia',
                                        'AO' => 'Angola', 'MZ' => 'Mozambique', 'MG' => 'Madagascar', 'MU' => 'Mauritius', 'SC' => 'Seychelles',
                                        'CN' => 'China', 'IN' => 'India', 'ID' => 'Indonesia', 'TH' => 'Thailand', 'VN' => 'Vietnam',
                                        'PH' => 'Philippines', 'MY' => 'Malaysia', 'BN' => 'Brunei', 'KH' => 'Cambodia', 'LA' => 'Laos',
                                        'MM' => 'Myanmar', 'BD' => 'Bangladesh', 'LK' => 'Sri Lanka', 'MV' => 'Maldives', 'NP' => 'Nepal',
                                        'BT' => 'Bhutan', 'PK' => 'Pakistan', 'AF' => 'Afghanistan', 'IR' => 'Iran', 'IQ' => 'Iraq',
                                        'SA' => 'Saudi Arabia', 'AE' => 'United Arab Emirates', 'QA' => 'Qatar', 'KW' => 'Kuwait', 'BH' => 'Bahrain',
                                        'OM' => 'Oman', 'YE' => 'Yemen', 'JO' => 'Jordan', 'LB' => 'Lebanon', 'SY' => 'Syria',
                                        'IL' => 'Israel', 'PS' => 'Palestine', 'TR' => 'Turkey', 'RU' => 'Russia', 'UA' => 'Ukraine',
                                        'BY' => 'Belarus', 'MD' => 'Moldova', 'GE' => 'Georgia', 'AM' => 'Armenia', 'AZ' => 'Azerbaijan',
                                        'KZ' => 'Kazakhstan', 'UZ' => 'Uzbekistan', 'TM' => 'Turkmenistan', 'TJ' => 'Tajikistan', 'KG' => 'Kyrgyzstan',
                                        'MN' => 'Mongolia', 'KP' => 'North Korea', 'FJ' => 'Fiji', 'PG' => 'Papua New Guinea', 'SB' => 'Solomon Islands',
                                        'VU' => 'Vanuatu', 'NC' => 'New Caledonia', 'PF' => 'French Polynesia', 'WS' => 'Samoa', 'TO' => 'Tonga',
                                        'KI' => 'Kiribati', 'TV' => 'Tuvalu', 'NR' => 'Nauru', 'PW' => 'Palau', 'FM' => 'Micronesia',
                                        'MH' => 'Marshall Islands', 'AS' => 'American Samoa', 'GU' => 'Guam', 'MP' => 'Northern Mariana Islands',
                                        'VI' => 'U.S. Virgin Islands', 'PR' => 'Puerto Rico', 'DO' => 'Dominican Republic', 'HT' => 'Haiti',
                                        'JM' => 'Jamaica', 'CU' => 'Cuba', 'BS' => 'Bahamas', 'BB' => 'Barbados', 'TT' => 'Trinidad and Tobago',
                                        'GD' => 'Grenada', 'LC' => 'Saint Lucia', 'VC' => 'Saint Vincent and the Grenadines', 'AG' => 'Antigua and Barbuda',
                                        'KN' => 'Saint Kitts and Nevis', 'DM' => 'Dominica', 'BZ' => 'Belize', 'GT' => 'Guatemala', 'HN' => 'Honduras',
                                        'SV' => 'El Salvador', 'NI' => 'Nicaragua', 'CR' => 'Costa Rica', 'PA' => 'Panama'
                                    );
                                    ?>
                                    <div class="x8-evs-select2-container">
                                        <select name="x8_evs_allowed_countries[]" id="x8_evs_allowed_countries" multiple="multiple" class="x8-evs-select2-countries" style="width: 100%;">
                                            <?php foreach ($countries as $code => $name): ?>
                                                <option value="<?php echo esc_attr($code); ?>" <?php selected(in_array($code, $allowed_countries), true); ?>>
                                                    <?php echo esc_html($name . ' (' . $code . ')'); ?>
                                                </option>
                                            <?php endforeach; ?>
                                        </select>
                                        <div class="x8-evs-select2-controls" style="margin-top: 10px;">
                                            <button type="button" class="button button-small x8-evs-select-all-countries">
                                                <span class="dashicons dashicons-yes-alt" style="margin-right: 3px;"></span><?php _e('Select All', 'x8-evs'); ?>
                                            </button>
                                            <button type="button" class="button button-small x8-evs-clear-countries">
                                                <span class="dashicons dashicons-no-alt" style="margin-right: 3px;"></span><?php _e('Clear All', 'x8-evs'); ?>
                                            </button>
                                            <button type="button" class="button button-small x8-evs-toggle-countries">
                                                <span class="dashicons dashicons-visibility" style="margin-right: 3px;"></span><?php _e('Toggle Selection', 'x8-evs'); ?>
                                            </button>
                                        </div>
                                        <div class="x8-evs-select2-status" style="margin-top: 8px; font-size: 12px; color: #666;">
                                            <span class="x8-evs-status-text"></span>
                                        </div>
                                    </div>
                                    <p class="description">
                                        <?php _e('Select countries to allow customers from. Only customers from selected countries will be allowed to verify. Use the search box to quickly find countries.', 'x8-evs'); ?>
                                    </p>
                                </td>
                            </tr>
                            <tr>
                                <th scope="row"></th>
                                <td>
                                    <div class="x8-evs-blocking-options">
                                        <label style="display: block; margin-bottom: 10px;">
                                            <input type="checkbox" name="x8_evs_block_by_geolocation" value="1" <?php checked(get_option('x8_evs_block_by_geolocation', false), true); ?> />
                                            <strong><?php _e('Block by GeoLocation', 'x8-evs'); ?></strong>
                                            <span style="color: #666; font-weight: normal;"> - <?php _e('Block customers based on their IP geolocation', 'x8-evs'); ?></span>
                                        </label>
                                        
                                        <label style="display: block; margin-bottom: 10px;">
                                            <input type="checkbox" name="x8_evs_block_by_id_address" value="1" <?php checked(get_option('x8_evs_block_by_id_address', false), true); ?> />
                                            <strong><?php _e('Block by ID Address', 'x8-evs'); ?></strong>
                                            <span style="color: #666; font-weight: normal;"> - <?php _e('Block customers based on the address on their ID document', 'x8-evs'); ?></span>
                                        </label>
                                        
                                        <label style="display: block; margin-bottom: 10px;">
                                            <input type="checkbox" name="x8_evs_block_by_billing_address" value="1" <?php checked(get_option('x8_evs_block_by_billing_address', false), true); ?> />
                                            <strong><?php _e('Block by Billing Address', 'x8-evs'); ?></strong>
                                            <span style="color: #666; font-weight: normal;"> - <?php _e('Block customers based on their billing address', 'x8-evs'); ?></span>
                                        </label>
                                    </div>
                                    <p class="description">
                                        <?php _e('You can enable any combination of these blocking options. When enabled, customers will be blocked if their location/address matches any of the blocked states above.', 'x8-evs'); ?>
                                    </p>
                                </td>
                            </tr>
                            <tr>
                                <th scope="row"><?php _e('Age Requirements', 'x8-evs'); ?></th>
                                <td>
                                    <?php 
                                    $minimum_age = get_option('x8_evs_minimum_age', '21');
                                    $custom_age = get_option('x8_evs_custom_age', 25);
                                    ?>
                                    <select name="x8_evs_minimum_age" id="x8_evs_minimum_age" class="regular-text">
                                        <option value="none" <?php selected($minimum_age, 'none'); ?>><?php _e('No minimum age requirement', 'x8-evs'); ?></option>
                                        <option value="18" <?php selected($minimum_age, '18'); ?>><?php _e('18', 'x8-evs'); ?></option>
                                        <option value="21" <?php selected($minimum_age, '21'); ?>><?php _e('21', 'x8-evs'); ?></option>
                                        <option value="other" <?php selected($minimum_age, 'other'); ?>><?php _e('Other age', 'x8-evs'); ?></option>
                                    </select>
                                    
                                    <div id="x8_evs_custom_age_wrapper" style="margin-top: 10px; <?php echo ($minimum_age !== 'other') ? 'display: none;' : ''; ?>">
                                        <label for="x8_evs_custom_age" style="display: inline-block; width: 150px;"><?php _e('Custom minimum age:', 'x8-evs'); ?></label>
                                        <input type="number" name="x8_evs_custom_age" id="x8_evs_custom_age" value="<?php echo esc_attr($custom_age); ?>" min="13" max="99" style="width: 80px;" />
                                        <span style="color: #666; font-size: 12px; margin-left: 8px;"><?php _e('(13-99 years)', 'x8-evs'); ?></span>
                                    </div>
                                    
                                    <p class="description">
                                        <?php _e('If your products are age restricted, you can have Real ID enforce a minimum age to pass ID verification. You\'ll be alerted if a customer is underage.', 'x8-evs'); ?>
                                    </p>
                                </td>
                            </tr>
                            <tr>
                                <th scope="row"><?php _e('VPN Blocking', 'x8-evs'); ?></th>
                                <td>
                                    <label style="display: block; margin-bottom: 10px;">
                                        <input type="checkbox" name="x8_evs_block_vpns" value="1" <?php checked(get_option('x8_evs_block_vpns', false), true); ?> />
                                        <strong><?php _e('Block VPN Connections', 'x8-evs'); ?></strong>
                                        <span style="color: #666; font-weight: normal;"> - <?php _e('Block customers who are using VPN or proxy services during verification', 'x8-evs'); ?></span>
                                    </label>
                                    <p class="description">
                                        <?php _e('When enabled, customers using VPN, proxy, or other anonymizing services will be blocked from completing verification. This helps prevent fraud and ensures accurate location-based verification.', 'x8-evs'); ?>
                                    </p>
                                </td>
                            </tr>
                            <tr>
                                <th scope="row"><?php _e('Approval Thresholds', 'x8-evs'); ?></th>
                                <td>
                                    <div class="x8-evs-threshold-toggle">
                                        <button type="button" class="x8-evs-toggle-thresholds button-secondary">
                                            <span class="dashicons dashicons-admin-settings"></span>
                                            <?php _e('Configure Thresholds', 'x8-evs'); ?>
                                        </button>
                                        <div class="x8-evs-current-thresholds">
                                            <span class="x8-evs-threshold-preview">
                                                <strong><?php _e('Current:', 'x8-evs'); ?></strong>
                                                Block: 0-<?php echo esc_html(get_option('x8_evs_auto_block_threshold', 70)); ?> | 
                                                Review: <?php echo esc_html(get_option('x8_evs_auto_block_threshold', 70) + 1); ?>-<?php echo esc_html(get_option('x8_evs_manual_review_threshold', 85)); ?> | 
                                                Approve: <?php echo esc_html(get_option('x8_evs_auto_approve_threshold', 86)); ?>-100
                                            </span>
                                        </div>
                                    </div>
                                    <div class="x8-evs-threshold-sliders" style="display: none;">
                                        <div class="x8-evs-threshold-section">
                                            <h4><?php _e('Automatic Block Threshold', 'x8-evs'); ?></h4>
                                            <div class="x8-evs-slider-container">
                                                <input type="number" 
                                                       id="x8_evs_auto_block_threshold" 
                                                       name="x8_evs_auto_block_threshold" 
                                                       min="0" 
                                                       max="100" 
                                                       value="<?php echo esc_attr(get_option('x8_evs_auto_block_threshold', 70)); ?>" 
                                                       class="x8-evs-threshold-input" 
                                                       data-threshold-type="auto-block" />
                                                <div class="x8-evs-slider-value">
                                                    <span class="x8-evs-slider-label"><?php _e('Score 0-', 'x8-evs'); ?><span class="x8-evs-threshold-value"><?php echo esc_html(get_option('x8_evs_auto_block_threshold', 70)); ?></span><?php _e(' = Automatic Block', 'x8-evs'); ?></span>
                                                </div>
                                            </div>
                                        </div>
                                        
                                        <div class="x8-evs-threshold-section">
                                            <h4><?php _e('Manual Review Threshold', 'x8-evs'); ?></h4>
                                            <div class="x8-evs-slider-container">
                                                <input type="number" 
                                                       id="x8_evs_manual_review_threshold" 
                                                       name="x8_evs_manual_review_threshold" 
                                                       min="0" 
                                                       max="100" 
                                                       value="<?php echo esc_attr(get_option('x8_evs_manual_review_threshold', 85)); ?>" 
                                                       class="x8-evs-threshold-input" 
                                                       data-threshold-type="manual-review" />
                                                <div class="x8-evs-slider-value">
                                                    <span class="x8-evs-slider-label"><?php _e('Score ', 'x8-evs'); ?><span class="x8-evs-threshold-value"><?php echo esc_html(get_option('x8_evs_auto_block_threshold', 70) + 1); ?></span><?php _e('-', 'x8-evs'); ?><span class="x8-evs-threshold-value"><?php echo esc_html(get_option('x8_evs_manual_review_threshold', 85)); ?></span><?php _e(' = Manual Review', 'x8-evs'); ?></span>
                                                </div>
                                            </div>
                                        </div>
                                        
                                        <div class="x8-evs-threshold-section">
                                            <h4><?php _e('Automatic Approval Threshold', 'x8-evs'); ?></h4>
                                            <div class="x8-evs-slider-container">
                                                <input type="number" 
                                                       id="x8_evs_auto_approve_threshold" 
                                                       name="x8_evs_auto_approve_threshold" 
                                                       min="0" 
                                                       max="100" 
                                                       value="<?php echo esc_attr(get_option('x8_evs_auto_approve_threshold', 86)); ?>" 
                                                       class="x8-evs-threshold-input" 
                                                       data-threshold-type="auto-approve" />
                                                <div class="x8-evs-slider-value">
                                                    <span class="x8-evs-slider-label"><?php _e('Score ', 'x8-evs'); ?><span class="x8-evs-threshold-value"><?php echo esc_html(get_option('x8_evs_auto_approve_threshold', 86)); ?></span><?php _e('-100 = Automatic Approval', 'x8-evs'); ?></span>
                                                </div>
                                            </div>
                                        </div>
                                        
                                        <div class="x8-evs-threshold-summary">
                                            <h4><?php _e('Current Threshold Summary', 'x8-evs'); ?></h4>
                                            <div class="x8-evs-threshold-ranges">
                                                <div class="x8-evs-range-block">
                                                    <span class="x8-evs-range-label"><?php _e('Block:', 'x8-evs'); ?></span>
                                                    <span class="x8-evs-range-value">0 - <?php echo esc_html(get_option('x8_evs_auto_block_threshold', 70)); ?></span>
                                                </div>
                                                <div class="x8-evs-range-manual">
                                                    <span class="x8-evs-range-label"><?php _e('Manual Review:', 'x8-evs'); ?></span>
                                                    <span class="x8-evs-range-value"><?php echo esc_html(get_option('x8_evs_auto_block_threshold', 70) + 1); ?> - <?php echo esc_html(get_option('x8_evs_manual_review_threshold', 85)); ?></span>
                                                </div>
                                                <div class="x8-evs-range-approve">
                                                    <span class="x8-evs-range-label"><?php _e('Auto Approve:', 'x8-evs'); ?></span>
                                                    <span class="x8-evs-range-value"><?php echo esc_html(get_option('x8_evs_auto_approve_threshold', 86)); ?> - 100</span>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <p class="description">
                                        <?php _e('Configure the approval score thresholds for automatic verification decisions. Scores are based on the verification confidence level returned by the verification service.', 'x8-evs'); ?>
                                    </p>
                                </td>
                            </tr>
                            <tr>
                                <th scope="row"><?php _e('Location Detection Service', 'x8-evs'); ?></th>
                                <td>
                                    <?php $location_provider = get_option('x8_evs_location_provider', 'ipapi_co'); ?>
                                    <select name="x8_evs_location_provider" id="x8_evs_location_provider" class="regular-text">
                                        <option value="ipapi_co" <?php selected($location_provider, 'ipapi_co'); ?>><?php _e('ipapi.co', 'x8-evs'); ?></option>
                                        <option value="ipgeolocation" <?php selected($location_provider, 'ipgeolocation'); ?>><?php _e('IPGeolocation.io', 'x8-evs'); ?></option>
                                        <option value="evs_assurelocate" <?php selected($location_provider, 'evs_assurelocate'); ?>><?php _e('EVS AssureLocate', 'x8-evs'); ?></option>
                                    </select>
                                    <p class="description">
                                        <?php _e('Choose which service is used for location detection.', 'x8-evs'); ?>
                                    </p>
                                </td>
                            </tr>
                            <tr class="x8-evs-location-provider-field" data-provider="ipapi_co" <?php echo $location_provider !== 'ipapi_co' ? 'style="display:none;"' : ''; ?>>
                                <th scope="row"><?php _e('ipapi.co API key', 'x8-evs'); ?></th>
                                <td>
                                    <input type="text"
                                           name="x8_evs_ipapi_co_api"
                                           id="x8_evs_ipapi_co_api"
                                           value="<?php echo esc_attr(get_option('x8_evs_ipapi_co_api', '')); ?>"
                                           class="regular-text"
                                           placeholder="<?php esc_attr_e('Your ipapi.co API key', 'x8-evs'); ?>"
                                           autocomplete="off" />
                                    <p class="description">
                                        <?php _e('Optional. When set, ipapi.co is used first for IP geolocation and VPN-related lookups. Get a key at', 'x8-evs'); ?>
                                        <a href="https://ipapi.co/" target="_blank" rel="noopener noreferrer">ipapi.co</a>.
                                    </p>
                                </td>
                            </tr>
                            <tr class="x8-evs-location-provider-field" data-provider="ipgeolocation" <?php echo $location_provider !== 'ipgeolocation' ? 'style="display:none;"' : ''; ?>>
                                <th scope="row"><?php _e('IPGeolocation.io API key', 'x8-evs'); ?></th>
                                <td>
                                    <input type="text" 
                                           name="x8_evs_ipgeolocation_api" 
                                           id="x8_evs_ipgeolocation_api" 
                                           value="<?php echo esc_attr(get_option('x8_evs_ipgeolocation_api', '')); ?>" 
                                           class="regular-text" 
                                           placeholder="<?php esc_attr_e('Enter IPGeolocation.io API key…', 'x8-evs'); ?>" />
                                    <p class="description">
                                        <?php _e('Optional fallback provider when ipapi.co does not return data. Used after ipapi.co.', 'x8-evs'); ?>
                                    </p>
                                </td>
                            </tr>
                            <tr class="x8-evs-location-provider-field" data-provider="evs_assurelocate" <?php echo $location_provider !== 'evs_assurelocate' ? 'style="display:none;"' : ''; ?>>
                                <th scope="row"><?php _e('EVS AssureLocate', 'x8-evs'); ?></th>
                                <td>
                                    <p class="description">
                                        <?php _e('Uses the EVS Web Service credentials configured in Authentication Settings (username/password). Each customer\'s IP is stored against their account. When a customer visits with a new IP, they are redirected to the EVS AssureLocate portal to verify their location. If their IP has not changed since the last passed verification, no re-verification is required.', 'x8-evs'); ?>
                                    </p>
                                    <p class="description">
                                        <strong><?php _e('Webhook URL:', 'x8-evs'); ?></strong>
                                        <code><?php echo esc_html(rest_url('x8-evs/v1/webhook')); ?></code>
                                        <?php _e('(configure this in your EVS BlueAssure account so AssureLocate results are delivered back to the site)', 'x8-evs'); ?>
                                    </p>
                                </td>
                            </tr>
                            <tr class="x8-evs-location-provider-field" data-provider="evs_assurelocate" <?php echo $location_provider !== 'evs_assurelocate' ? 'style="display:none;"' : ''; ?>>
                                <th scope="row"><?php _e('Location Trigger', 'x8-evs'); ?></th>
                                <td>
                                    <?php $assurelocate_trigger = get_option('x8_evs_assurelocate_trigger', 'after_login'); ?>
                                    <select name="x8_evs_assurelocate_trigger" id="x8_evs_assurelocate_trigger" class="regular-text">
                                        <option value="after_login" <?php selected($assurelocate_trigger, 'after_login'); ?>><?php _e('After Login', 'x8-evs'); ?></option>
                                        <option value="global" <?php selected($assurelocate_trigger, 'global'); ?>><?php _e('Global (all visitors)', 'x8-evs'); ?></option>
                                    </select>
                                    <p class="description">
                                        <?php _e('After Login: location verification only runs for logged-in customers. Global: every visitor on the site (including guests, tracked by IP address) must verify their location.', 'x8-evs'); ?>
                                    </p>
                                </td>
                            </tr>
                            <tr>
                                <th scope="row"><?php _e('Contact Email', 'x8-evs'); ?></th>
                                <td>
                                    <input type="email" 
                                           name="x8_evs_contact_email" 
                                           id="x8_evs_contact_email" 
                                           value="<?php echo esc_attr(get_option('x8_evs_contact_email', '')); ?>" 
                                           class="regular-text" 
                                           placeholder="<?php _e('Enter contact email address...', 'x8-evs'); ?>" />
                                    <p class="description">
                                        <?php _e('This email address will be displayed to users on blocked state pages and verification status pages instead of the site admin email. Leave empty to use the default site admin email.', 'x8-evs'); ?>
                                    </p>
                                </td>
                            </tr>
                            <tr>
                                <th scope="row"><?php _e('Manual Review Notifications', 'x8-evs'); ?></th>
                                <td>
                                    <?php $manual_review_emails = get_option('x8_evs_manual_review_emails', ''); ?>
                                    <input type="text" name="x8_evs_manual_review_emails" id="x8_evs_manual_review_emails" value="<?php echo esc_attr($manual_review_emails); ?>" class="regular-text" placeholder="<?php esc_attr_e('name@example.com, staff@example.com', 'x8-evs'); ?>" />
                                    <p class="description">
                                        <?php _e('Enter one or more email addresses separated by commas. These contacts will receive an alert whenever a customer is moved into the Manual Review list.', 'x8-evs'); ?>
                                    </p>
                                </td>
                            </tr>
                            <tr>
                                <th scope="row"><?php _e('Auto Request Re-verification', 'x8-evs'); ?></th>
                                <td>
                                    <?php $auto_request_reverification = get_option('x8_evs_auto_request_reverification', false); ?>
                                    <label>
                                        <input type="checkbox" name="x8_evs_auto_request_reverification" id="x8_evs_auto_request_reverification" value="1" <?php checked($auto_request_reverification, true); ?> />
                                        <?php _e('Automatically request new verification when user lands in manual review', 'x8-evs'); ?>
                                    </label>
                                    <p class="description">
                                        <?php _e('When enabled, users who land in manual review will automatically receive an email requesting them to try verification again. Their status will be changed to pending for the next review.', 'x8-evs'); ?>
                                    </p>
                                </td>
                            </tr>
                            <tr>
                                <th scope="row"><?php _e('Do not allow multiple accounts per license number', 'x8-evs'); ?></th>
                                <td>
                                    <?php $block_duplicate_license = get_option('x8_evs_block_duplicate_license', false); ?>
                                    <label>
                                        <input type="checkbox" name="x8_evs_block_duplicate_license" id="x8_evs_block_duplicate_license" value="1" <?php checked($block_duplicate_license, true); ?> />
                                        <?php _e('Block verification when license number is already used by another account', 'x8-evs'); ?>
                                    </label>
                                    <p class="description">
                                        <?php _e('When enabled, during verification the system checks if the document license number is already associated with another customer. If so, verification is blocked and the user receives an email stating that an account already exists with this person\'s information and they cannot create a new account.', 'x8-evs'); ?>
                                    </p>
                                </td>
                            </tr>
                            <tr>
                                <th scope="row"><?php _e('Allow Google Bots', 'x8-evs'); ?></th>
                                <td>
                                    <?php $allow_google_bots = get_option('x8_evs_allow_google_bots', false); ?>
                                    <label>
                                        <input type="checkbox" name="x8_evs_allow_google_bots" id="x8_evs_allow_google_bots" value="1" <?php checked($allow_google_bots, true); ?> />
                                        <?php _e('Allow Google crawlers and bots to bypass blocking', 'x8-evs'); ?>
                                    </label>
                                    <p class="description">
                                        <?php _e('When enabled, Googlebot, Google Search Console, and other Google crawlers will be automatically whitelisted and allowed to access your site.', 'x8-evs'); ?>
                                    </p>
                                </td>
                            </tr>
                            <tr>
                                <th scope="row"><?php _e('Whitelist IP Addresses & Ranges', 'x8-evs'); ?></th>
                                <td>
                                    <?php $whitelist_ips = get_option('x8_evs_whitelist_ip_addresses', ''); ?>
                                    <textarea name="x8_evs_whitelist_ip_addresses" id="x8_evs_whitelist_ip_addresses" rows="5" class="large-text" placeholder="<?php esc_attr_e('192.168.1.1&#10;10.0.0.0/8&#10;172.16.0.0/12', 'x8-evs'); ?>"><?php echo esc_textarea($whitelist_ips); ?></textarea>
                                    <p class="description">
                                        <?php _e('Enter IP addresses or CIDR ranges (one per line) that should bypass blocking. Examples: 192.168.1.1, 10.0.0.0/8, 172.16.0.0/12', 'x8-evs'); ?>
                                    </p>
                                </td>
                            </tr>

                        </table>
                        <?php submit_button(__('Save Settings', 'x8-evs')); ?>
                    </form>
                </div>
            </div>
        </div>
        <?php
    }

    /**
     * Render Cache Tab
     */
    private function render_cache_tab() {
        ?>
        <div class="x8-evs-cache-content">
            <h2><?php _e('Cache Management', 'x8-evs'); ?></h2>
            
            <div class="x8-evs-cache-sections">
                <div class="x8-evs-cache-section">
                    <h3><?php _e('Geolocation Cache', 'x8-evs'); ?></h3>
                    <table class="form-table">
                        <tr>
                            <th scope="row"><?php _e('Cache Statistics', 'x8-evs'); ?></th>
                            <td>
                                <?php 
                                // Get cache statistics
                                $geo_cache_stats = array('total_cached_ips' => 0, 'cache_size_mb' => 0);
                                if (class_exists('X8_EVS_Blocking_Handler')) {
                                    $geo_cache_stats = X8_EVS_Blocking_Handler::get_geolocation_cache_stats();
                                }
                                ?>
                                <div class="x8-evs-cache-info" style="background: #f8f9fa; padding: 15px; border-radius: 4px; margin-bottom: 15px;">
                                    <h4 style="margin: 0 0 10px 0; color: #2271b1;"><?php _e('Geolocation Cache Statistics', 'x8-evs'); ?></h4>
                                    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 15px;">
                                        <div>
                                            <strong><?php _e('Cached IP Addresses:', 'x8-evs'); ?></strong><br>
                                            <span style="font-size: 18px; color: #2271b1;"><?php echo esc_html($geo_cache_stats['total_cached_ips']); ?></span>
                                        </div>
                                        <div>
                                            <strong><?php _e('Cache Size:', 'x8-evs'); ?></strong><br>
                                            <span style="font-size: 18px; color: #2271b1;"><?php echo esc_html($geo_cache_stats['cache_size_mb']); ?> MB</span>
                                        </div>
                                    </div>
                                    <p style="margin: 10px 0 0 0; font-size: 12px; color: #666;">
                                        <?php _e('Geolocation data is cached for 48 hours to reduce API calls and improve performance.', 'x8-evs'); ?>
                                    </p>
                                </div>
                                
                                <button type="button" id="x8_evs_clear_geo_cache" class="button button-secondary" style="margin-right: 10px;">
                                    <span class="dashicons dashicons-trash" style="margin-right: 5px;"></span>
                                    <?php _e('Clear Geolocation Cache', 'x8-evs'); ?>
                                </button>
                                
                                <p class="description">
                                    <?php _e('The geolocation cache stores IP address location data to reduce API calls. Clear the cache if you need fresh location data or are experiencing issues.', 'x8-evs'); ?>
                                </p>
                            </td>
                        </tr>
                    </table>
                </div>

                <div class="x8-evs-cache-section" style="margin-top: 30px;">
                    <h3><?php _e('Blocking Cache', 'x8-evs'); ?></h3>
                    <table class="form-table">
                        <tr>
                            <th scope="row"><?php _e('Cache Statistics', 'x8-evs'); ?></th>
                            <td>
                                <?php 
                                // Get blocking cache statistics
                                $blocking_cache_stats = array('total_cached_users' => 0, 'blocked_users' => 0, 'allowed_users' => 0, 'cache_size_mb' => 0);
                                if (class_exists('X8_EVS_Blocking_Handler')) {
                                    $blocking_cache_stats = X8_EVS_Blocking_Handler::get_blocking_cache_stats();
                                }
                                ?>
                                <div class="x8-evs-cache-info" style="background: #f8f9fa; padding: 15px; border-radius: 4px; margin-bottom: 15px;">
                                    <h4 style="margin: 0 0 10px 0; color: #2271b1;"><?php _e('Blocking Cache Statistics', 'x8-evs'); ?></h4>
                                    <div style="display: grid; grid-template-columns: 1fr 1fr 1fr; gap: 15px;">
                                        <div>
                                            <strong><?php _e('Cached Users:', 'x8-evs'); ?></strong><br>
                                            <span style="font-size: 18px; color: #2271b1;"><?php echo esc_html($blocking_cache_stats['total_cached_users']); ?></span>
                                        </div>
                                        <div>
                                            <strong><?php _e('Blocked Users:', 'x8-evs'); ?></strong><br>
                                            <span style="font-size: 18px; color: #dc3232;"><?php echo esc_html($blocking_cache_stats['blocked_users']); ?></span>
                                        </div>
                                        <div>
                                            <strong><?php _e('Allowed Users:', 'x8-evs'); ?></strong><br>
                                            <span style="font-size: 18px; color: #00a32a;"><?php echo esc_html($blocking_cache_stats['allowed_users']); ?></span>
                                        </div>
                                    </div>
                                    <div style="margin-top: 10px;">
                                        <strong><?php _e('Cache Size:', 'x8-evs'); ?></strong>
                                        <span style="font-size: 16px; color: #2271b1; margin-left: 5px;"><?php echo esc_html($blocking_cache_stats['cache_size_mb']); ?> MB</span>
                                    </div>
                                    <p style="margin: 10px 0 0 0; font-size: 12px; color: #666;">
                                        <?php _e('Blocking results are cached for 1 hour to improve performance. Cache is automatically cleared when user verification data changes.', 'x8-evs'); ?>
                                    </p>
                                </div>
                                
                                <button type="button" id="x8_evs_clear_blocking_cache" class="button button-secondary" style="margin-right: 10px;">
                                    <span class="dashicons dashicons-trash" style="margin-right: 5px;"></span>
                                    <?php _e('Clear Blocking Cache', 'x8-evs'); ?>
                                </button>
                                
                                <p class="description">
                                    <?php _e('The blocking cache stores user blocking decisions to improve performance. Clear the cache to force fresh blocking checks for all users.', 'x8-evs'); ?>
                                </p>
                            </td>
                        </tr>
                    </table>
                </div>

                <div class="x8-evs-cache-section" style="margin-top: 30px;">
                    <h3><?php _e('VPN Detection Cache', 'x8-evs'); ?></h3>
                    <table class="form-table">
                        <tr>
                            <th scope="row"><?php _e('Cache Statistics', 'x8-evs'); ?></th>
                            <td>
                                <?php 
                                // Get VPN cache statistics
                                $vpn_cache_stats = array('total_cached_ips' => 0, 'cache_size_mb' => 0);
                                if (class_exists('X8_EVS_Blocking_Handler')) {
                                    $vpn_cache_stats = X8_EVS_Blocking_Handler::get_vpn_cache_stats();
                                }
                                ?>
                                <div class="x8-evs-cache-info" style="background: #f8f9fa; padding: 15px; border-radius: 4px; margin-bottom: 15px;">
                                    <h4 style="margin: 0 0 10px 0; color: #2271b1;"><?php _e('VPN Detection Cache Statistics', 'x8-evs'); ?></h4>
                                    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 15px;">
                                        <div>
                                            <strong><?php _e('Cached IP Addresses:', 'x8-evs'); ?></strong><br>
                                            <span style="font-size: 18px; color: #2271b1;"><?php echo esc_html($vpn_cache_stats['total_cached_ips']); ?></span>
                                        </div>
                                        <div>
                                            <strong><?php _e('Cache Size:', 'x8-evs'); ?></strong><br>
                                            <span style="font-size: 18px; color: #2271b1;"><?php echo esc_html($vpn_cache_stats['cache_size_mb']); ?> MB</span>
                                        </div>
                                    </div>
                                    <p style="margin: 10px 0 0 0; font-size: 12px; color: #666;">
                                        <?php _e('VPN detection data is cached for 48 hours to reduce API calls and improve performance.', 'x8-evs'); ?>
                                    </p>
                                </div>
                                
                                <button type="button" id="x8_evs_clear_vpn_cache" class="button button-secondary" style="margin-right: 10px;">
                                    <span class="dashicons dashicons-trash" style="margin-right: 5px;"></span>
                                    <?php _e('Clear VPN Cache', 'x8-evs'); ?>
                                </button>
                                
                                <button type="button" id="x8_evs_refresh_cache_stats" class="button button-secondary">
                                    <span class="dashicons dashicons-update" style="margin-right: 5px;"></span>
                                    <?php _e('Refresh All Statistics', 'x8-evs'); ?>
                                </button>
                                
                                <div id="x8_evs_cache_message" style="margin-top: 10px;"></div>
                                
                                <p class="description">
                                    <?php _e('The VPN detection cache stores IP address VPN/proxy detection data to reduce API calls. Clear the cache if you need fresh detection data or are experiencing issues.', 'x8-evs'); ?>
                                </p>
                            </td>
                        </tr>
                    </table>
                </div>

                <div class="x8-evs-cache-section" style="margin-top: 30px;">
                    <h3><?php _e('Verification Link Management', 'x8-evs'); ?></h3>
                    <table class="form-table">
                        <tr>
                            <th scope="row"><?php _e('Verification Links', 'x8-evs'); ?></th>
                            <td>
                                <?php 
                                // Get verification link statistics
                                $verification_link_stats = $this->get_verification_link_stats();
                                ?>
                                <div class="x8-evs-cache-info" style="background: #f8f9fa; padding: 15px; border-radius: 4px; margin-bottom: 15px;">
                                    <h4 style="margin: 0 0 10px 0; color: #2271b1;"><?php _e('Verification Link Statistics', 'x8-evs'); ?></h4>
                                    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 15px;">
                                        <div>
                                            <strong><?php _e('Active Links:', 'x8-evs'); ?></strong><br>
                                            <span style="font-size: 18px; color: #2271b1;"><?php echo esc_html($verification_link_stats['active_links']); ?></span>
                                        </div>
                                        <div>
                                            <strong><?php _e('Expired Links:', 'x8-evs'); ?></strong><br>
                                            <span style="font-size: 18px; color: #2271b1;"><?php echo esc_html($verification_link_stats['expired_links']); ?></span>
                                        </div>
                                    </div>
                                    <p style="margin: 10px 0 0 0; font-size: 12px; color: #666;">
                                        <?php _e('Verification links expire after 1 hour. Expired links are automatically cleaned up but can be manually cleared.', 'x8-evs'); ?>
                                    </p>
                                </div>
                                
                                <button type="button" id="x8_evs_clear_verification_links" class="button button-secondary" style="margin-right: 10px;">
                                    <span class="dashicons dashicons-trash" style="margin-right: 5px;"></span>
                                    <?php _e('Clear All Verification Links', 'x8-evs'); ?>
                                </button>
                                
                                <p class="description">
                                    <?php _e('This will clear all verification links for all customers, forcing them to generate new links. Use this if you need to reset all verification processes.', 'x8-evs'); ?>
                                </p>
                            </td>
                        </tr>
                    </table>
                </div>
            </div>
        </div>
        <?php
    }

    /**
     * Render Integration Tab
     */
    private function render_integration_tab() {
        ?>
        <style>
            #x8-evs-integration-modal .x8-evs-modal-content {
                width: 80vw;
                max-width: 1200px;
            }
            #x8-evs-integration-modal .x8-evs-modal-body {
                padding: 20px 24px;
            }
            .x8-evs-blacklist-table-wrapper {
                margin-top: 15px;
                max-height: 60vh;
                overflow-y: auto;
                border: 1px solid #dcdcde;
                border-radius: 6px;
                background: #ffffff;
            }
            .x8-evs-blacklist-table-wrapper table {
                margin-bottom: 0;
            }
            .x8-evs-blacklist-table-wrapper td,
            .x8-evs-blacklist-table-wrapper th {
                vertical-align: top;
            }
            .x8-evs-blacklist-status {
                display: none;
                margin: 0 0 15px 0;
                padding: 12px 14px;
                border-left: 4px solid #2563eb;
                background: #eff6ff;
                color: #1d4ed8;
                border-radius: 6px;
            }
            .x8-evs-blacklist-status.success {
                border-color: #059669;
                background: #ecfdf5;
                color: #047857;
            }
            .x8-evs-blacklist-status.error {
                border-color: #dc2626;
                background: #fef2f2;
                color: #b91c1c;
            }
            .x8-evs-blacklist-status .dashicons {
                margin-right: 6px;
                vertical-align: text-bottom;
            }
            .x8-evs-blacklist-no-match {
                color: #9ca3af;
                font-style: italic;
            }
            .x8-evs-blacklist-meta {
                display: block;
                color: #6b7280;
                font-size: 12px;
                margin-top: 4px;
            }
            .x8-evs-blacklist-actions {
                display: flex;
                gap: 8px;
                align-items: center;
            }
            .x8-evs-blacklist-actions .dashicons {
                color: #059669;
            }
        </style>
        <div class="x8-evs-integration-content">
            <h2><?php _e('Integrations', 'x8-evs'); ?></h2>

            <div class="x8-evs-settings-sections">
                <div class="x8-evs-settings-section">
                    <h3><?php _e('Blacklist Integration', 'x8-evs'); ?></h3>
                    <p><?php _e('Connect to your external blacklist service and keep blocked users in sync with X8 Verify.', 'x8-evs'); ?></p>

                    <button type="button" class="button button-primary" id="x8-evs-sync-blocklist">
                        <span class="dashicons dashicons-cloud"></span>
                        <?php _e('Sync Blocklist Users', 'x8-evs'); ?>
                    </button>
                </div>
            </div>
        </div>

        <div id="x8-evs-integration-modal" class="x8-evs-modal" style="display:none;">
            <div class="x8-evs-modal-content x8-evs-modal-wide">
                <div class="x8-evs-modal-header">
                    <h3>
                        <span class="dashicons dashicons-cloud"></span>
                        <?php _e('Blacklist Sync', 'x8-evs'); ?>
                    </h3>
                    <button type="button" class="x8-evs-modal-close" id="x8-evs-close-integration-modal">
                        <span class="dashicons dashicons-no-alt"></span>
                    </button>
                </div>
                <div class="x8-evs-modal-body">
                    <p class="description">
                        <?php _e('Review blocked entries and sync their X8 status. Customers are matched by email first and phone number if no email is available.', 'x8-evs'); ?>
                    </p>
                    <div class="x8-evs-blacklist-status" id="x8-evs-blacklist-status"></div>
                    <div class="x8-evs-blacklist-table-wrapper">
                        <table class="wp-list-table widefat fixed striped">
                            <thead>
                                <tr>
                                    <th><?php _e('Blacklist Record', 'x8-evs'); ?></th>
                                    <th><?php _e('Customer ID', 'x8-evs'); ?></th>
                                    <th><?php _e('Name', 'x8-evs'); ?></th>
                                    <th><?php _e('Contact', 'x8-evs'); ?></th>
                                    <th><?php _e('Current X8 Status', 'x8-evs'); ?></th>
                                    <th><?php _e('Action', 'x8-evs'); ?></th>
                                </tr>
                            </thead>
                            <tbody id="x8-evs-blacklist-rows">
                                <tr class="x8-evs-blacklist-loading">
                                    <td colspan="6" style="text-align:center;">
                                        <span class="dashicons dashicons-update spin"></span>
                                        <?php _e('Loading blacklist entries...', 'x8-evs'); ?>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
                <div class="x8-evs-modal-footer">
                    <button type="button" class="button" id="x8-evs-refresh-blacklist">
                        <span class="dashicons dashicons-update"></span>
                        <?php _e('Refresh Data', 'x8-evs'); ?>
                    </button>
                    <button type="button" class="button button-primary" id="x8-evs-sync-all-blacklist">
                        <span class="dashicons dashicons-shield"></span>
                        <?php _e('Sync All Matches', 'x8-evs'); ?>
                    </button>
                    <button type="button" class="button button-secondary" id="x8-evs-dismiss-integration-modal">
                        <?php _e('Close', 'x8-evs'); ?>
                    </button>
                </div>
            </div>
        </div>
        <?php
    }

    /**
     * Get verification link statistics
     */
    private function get_verification_link_stats() {
        global $wpdb;
        
        $active_links = 0;
        $expired_links = 0;
        
        // Get all users with verification links and creation times
        $users_with_links = $wpdb->get_results("
            SELECT um.user_id, um.meta_value as verification_link, 
                   um_created.meta_value as created_time
            FROM {$wpdb->usermeta} um 
            LEFT JOIN {$wpdb->usermeta} um_created ON um.user_id = um_created.user_id AND um_created.meta_key = 'verification_link_created'
            WHERE um.meta_key = 'verification_link' 
            AND um.meta_value != ''
        ");
        
        if ($users_with_links) {
            $current_time = time();
            $one_hour_ago = $current_time - (1 * 60 * 60);
            
            foreach ($users_with_links as $user_data) {
                if ($user_data->created_time) {
                    $created_time = strtotime($user_data->created_time);
                    if ($created_time && $created_time > $one_hour_ago) {
                        $active_links++;
                    } else {
                        $expired_links++;
                    }
                } else {
                    // If no creation time, consider it expired
                    $expired_links++;
                }
            }
        }
        
        return array(
            'active_links' => $active_links,
            'expired_links' => $expired_links
        );
    }

    /**
     * Fetch and cache the server's external IP address.
     *
     * @return string|false
     */
    private function get_server_external_ip() {
        $cache_key = 'x8_evs_server_external_ip';
        $cached_ip = get_transient($cache_key);

        if ($cached_ip !== false) {
            return $cached_ip;
        }

        $response = wp_remote_get('https://api.ipify.org?format=json', array(
            'timeout' => 5,
            'headers' => array(
                'Accept' => 'application/json',
            ),
        ));

        if (is_wp_error($response)) {
            if (defined('WP_DEBUG') && WP_DEBUG) {
                error_log('X8 EVS: Failed to fetch server IP - ' . $response->get_error_message());
            }
            return false;
        }

        $body = wp_remote_retrieve_body($response);
        $data = json_decode($body, true);

        if (empty($data['ip']) || !filter_var($data['ip'], FILTER_VALIDATE_IP)) {
            if (defined('WP_DEBUG') && WP_DEBUG) {
                error_log('X8 EVS: Invalid server IP response - ' . $body);
            }
            return false;
        }

        $ip_address = $data['ip'];
        $cache_duration = apply_filters('x8_evs_server_ip_cache_ttl', HOUR_IN_SECONDS);
        $cache_duration = max(300, (int) $cache_duration);

        set_transient($cache_key, $ip_address, $cache_duration);

        return $ip_address;
    }

    /**
     * Render Help Tab
     */
    private function render_help_tab() {
        $server_ip_address = $this->get_server_external_ip();
        ?>
        <div class="x8-evs-help-content">
            <h2><?php _e('Documentation & Support', 'x8-evs'); ?></h2>
            
            <div class="x8-evs-help-sections">
                <div class="x8-evs-help-section">
                    <h3><?php _e('Getting Started', 'x8-evs'); ?></h3>
                    <p><?php _e('Follow these steps to set up identity verification on your WordPress site.', 'x8-evs'); ?></p>
                    
                    <h4><?php _e('Step 1: Create a Verification Page', 'x8-evs'); ?></h4>
                    <ol class="x8-evs-setup-steps">
                        <li><?php _e('Go to <strong>Pages > Add New</strong> in your WordPress admin', 'x8-evs'); ?></li>
                        <li><?php _e('Create a new page (e.g., "Identity Verification" or "KYC Verification")', 'x8-evs'); ?></li>
                        <li><?php _e('Add the verification shortcode to the page content:', 'x8-evs'); ?></li>
                    </ol>
                    <div class="shortcode-example">
[x8_verify]
                    </div>
                    <p><em><?php _e('This shortcode will display the identity verification form where customers can upload their ID documents and selfie.', 'x8-evs'); ?></em></p>
                    
                    <h4><?php _e('Step 2: Configure Settings', 'x8-evs'); ?></h4>
                    <ol class="x8-evs-setup-steps">
                        <li><?php _e('Go to the <strong>Settings</strong> tab in this plugin', 'x8-evs'); ?></li>
                        <li><?php _e('In the <strong>"Verification Page"</strong> dropdown, select the page you created in Step 1', 'x8-evs'); ?></li>
                        <li><?php _e('Configure your verification trigger, document type, age requirements, and other settings', 'x8-evs'); ?></li>
                        <li><?php _e('Click <strong>"Save Settings"</strong>', 'x8-evs'); ?></li>
                    </ol>
                    
                    <h4><?php _e('Step 3: Test the Verification Flow', 'x8-evs'); ?></h4>
                    <p><?php _e('Visit your verification page to test the identity verification process. Customers will be able to upload their documents and complete the verification process.', 'x8-evs'); ?></p>
                    
                    <div class="x8-evs-help-tip">
                        <h5><span class="dashicons dashicons-lightbulb"></span> <?php _e('Important Tip', 'x8-evs'); ?></h5>
                        <p><?php _e('Make sure to create the page with the <code>[x8_verify]</code> shortcode FIRST, then select that same page in the Settings tab under "Verification Page". This ensures customers are directed to your custom verification page instead of the default form.', 'x8-evs'); ?></p>
                    </div>
                </div>

                <div class="x8-evs-help-section">
                    <h3><?php _e('Webhook Configuration', 'x8-evs'); ?></h3>
                    <p><?php _e('Configure webhooks to receive automatic verification results from the EVS portal.', 'x8-evs'); ?></p>
                    
                    <table class="form-table">
                        <tr>
                            <th scope="row"><?php _e('Webhook URL', 'x8-evs'); ?></th>
                            <td>
                                <?php 
                                if (class_exists('X8_EVS_Webhook_Handler')) {
                                    $webhook_url = X8_EVS_Webhook_Handler::get_webhook_url();
                                } else {
                                    $webhook_url = rest_url('x8-evs/v1/webhook');
                                }
                                ?>
                                <input type="text" value="<?php echo esc_url($webhook_url); ?>" class="large-text" readonly />
                                <button type="button" class="button button-secondary" onclick="navigator.clipboard.writeText(this.previousElementSibling.value); this.innerText='Copied!'; setTimeout(() => this.innerText='Copy URL', 2000);" style="margin-left: 10px;">
                                    <?php _e('Copy URL', 'x8-evs'); ?>
                                </button>
                                <p class="description">
                                    <?php _e('Configure this URL in your EVS portal as the webhook endpoint. This URL will receive verification results automatically when a customer completes identity verification.', 'x8-evs'); ?>
                                </p>
                                <div class="x8-evs-webhook-info" style="background: #f7f7f7; padding: 15px; margin-top: 10px; border-left: 4px solid #0073aa;">
                                    <h4 style="margin: 0 0 10px 0;"><?php _e('How to Configure in EVS Portal:', 'x8-evs'); ?></h4>
                                    <ol style="margin: 0; padding-left: 20px;">
                                        <li><?php _e('Copy the webhook URL above', 'x8-evs'); ?></li>
                                        <li><?php _e('Log into your EVS portal account', 'x8-evs'); ?></li>
                                        <li><?php _e('Navigate to Webhook/Notification settings', 'x8-evs'); ?></li>
                                        <li><?php _e('Paste this URL as your webhook endpoint', 'x8-evs'); ?></li>
                                        <li><?php _e('Set the method to POST and content type to application/json', 'x8-evs'); ?></li>
                                    </ol>
                                    <p style="margin: 10px 0 0 0;"><strong><?php _e('Note:', 'x8-evs'); ?></strong> <?php _e('Webhook data will be logged when WP_DEBUG is enabled.', 'x8-evs'); ?></p>
                                </div>
                                <div class="x8-evs-webhook-test" style="background: #f0f6fc; padding: 15px; margin-top: 10px; border-left: 4px solid #2271b1;">
                                    <h4 style="margin: 0 0 10px 0;"><?php _e('Test Webhook Endpoint:', 'x8-evs'); ?></h4>
                                    <p style="margin: 0 0 10px 0;"><?php _e('You can test if the webhook is working by visiting:', 'x8-evs'); ?></p>
                                    <p style="margin: 0;"><code><a href="<?php echo esc_url(rest_url('x8-evs/v1/webhook/test')); ?>" target="_blank"><?php echo esc_url(rest_url('x8-evs/v1/webhook/test')); ?></a></code></p>
                                </div>
                            </td>
                        </tr>
                    </table>
                </div>

                <div class="x8-evs-help-section">
                    <h3><?php _e('Support', 'x8-evs'); ?></h3>
                    <p><?php _e('Need help? Contact our support team or check our documentation.', 'x8-evs'); ?></p>
                    <ul>
                        <li><a href="#" target="_blank"><?php _e('Documentation', 'x8-evs'); ?></a></li>
                        <li><a href="#" target="_blank"><?php _e('Support Forum', 'x8-evs'); ?></a></li>
                        <li><a href="#" target="_blank"><?php _e('Contact Support', 'x8-evs'); ?></a></li>
                    </ul>
                </div>

                <div class="x8-evs-help-section">
                    <h3><?php _e('Server IP Address', 'x8-evs'); ?></h3>
                    <p><?php _e('This is the external IP address that third-party services will see when your site makes outbound requests.', 'x8-evs'); ?></p>
                    <?php if ($server_ip_address) : ?>
                        <p><strong><?php _e('External IP:', 'x8-evs'); ?></strong> <code><?php echo esc_html($server_ip_address); ?></code></p>
                        <p class="description"><?php _e('Use this IP when whitelisting your server with EVS or other verification providers.', 'x8-evs'); ?></p>
                    <?php else : ?>
                        <p class="description"><?php _e('Unable to determine the server\'s external IP address at this time. Please ensure outbound requests to api.ipify.org are allowed.', 'x8-evs'); ?></p>
                    <?php endif; ?>
                </div>
            </div>
        </div>
        <?php
    }


    /**
     * Enqueue admin scripts
     */
    public function enqueue_admin_scripts($hook) {
        error_log('X8 Verify: Enqueuing scripts for hook: ' . $hook);
        
        if ('toplevel_page_x8-evs' !== $hook) {
            error_log('X8 Verify: Not the correct page, skipping script enqueue');
            return;
        }
        
        error_log('X8 Verify: Loading admin scripts and styles');
        
        // Enqueue Select2 for enhanced select dropdowns
        wp_enqueue_style('select2', 'https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css', array(), '4.1.0');
        wp_enqueue_script('select2', 'https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js', array('jquery'), '4.1.0', true);
        
        wp_enqueue_style('x8-evs-admin-style', X8_EVS_PLUGIN_URL . 'assets/css/x8-evs-admin.css', array(), X8_EVS_VERSION);
        wp_enqueue_script('x8-evs-admin-script', X8_EVS_PLUGIN_URL . 'assets/js/x8-evs.js', array('jquery', 'select2'), X8_EVS_VERSION, true);
        
        // Localize script for AJAX
        wp_localize_script('x8-evs-admin-script', 'x8_evs_ajax', array(
            'ajax_url' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('x8_evs_nonce'),
            'export_nonce' => wp_create_nonce('x8_evs_export_customers'),
            'export_url' => admin_url('admin.php?page=x8-evs&x8_evs_export_customers=1'),
            'strings' => array(
                'default_label' => __('default', 'x8-evs'),
                'verifying' => __('Verifying...', 'x8-evs'),
                'success' => __('Success', 'x8-evs'),
                'error' => __('Error', 'x8-evs'),
                'invalid_email' => __('Please enter a valid email address', 'x8-evs'),
                'select_states' => __('Select states to block...', 'x8-evs'),
                'no_states_selected' => __('No states blocked', 'x8-evs'),
                'all_states_blocked' => __('All states blocked', 'x8-evs'),
                'states_blocked' => __('states blocked', 'x8-evs'),
                'blacklist_loading' => __('Loading blacklist entries...', 'x8-evs'),
                'blacklist_loaded' => __('Loaded %d blacklist entries.', 'x8-evs'),
                'blacklist_empty' => __('No blocked entries found.', 'x8-evs'),
                'blacklist_no_match' => __('No matching customer found', 'x8-evs'),
                'blacklist_no_customer_id' => __('No customer match', 'x8-evs'),
                'blacklist_unknown' => __('Unknown', 'x8-evs'),
                'blacklist_match_email' => __('Matched by email address', 'x8-evs'),
                'blacklist_match_phone' => __('Matched by phone number', 'x8-evs'),
                'blacklist_order_prefix' => __('Order #', 'x8-evs'),
                'blacklist_sync_button' => __('Sync Customer Status', 'x8-evs'),
                'blacklist_already_synced' => __('Already synced', 'x8-evs'),
                'blacklist_synced' => __('Status synced successfully', 'x8-evs'),
                'blacklist_syncing' => __('Syncing...', 'x8-evs'),
                'blacklist_error_generic' => __('Unable to sync status. Please try again.', 'x8-evs'),
                'blacklist_sync_all' => __('Sync All Matches', 'x8-evs'),
                'blacklist_sync_all_confirm' => __('Sync all matched customers and set their status to Block?', 'x8-evs'),
                'blacklist_sync_all_running' => __('Syncing all matches...', 'x8-evs'),
                'blacklist_sync_all_success' => __('Bulk sync complete. %1$d updated, %2$d already blocked.', 'x8-evs'),
                'blacklist_sync_all_none' => __('No matched customers needed syncing.', 'x8-evs'),
                'blacklist_sync_all_error' => __('Unable to complete bulk sync. Please try again.', 'x8-evs')
            )
        ));
        
        error_log('X8 Verify: Scripts enqueued successfully');
    }
    
    /**
     * Handle AJAX request to update customer status
     */
    public function handle_update_customer_status() {
        // Verify nonce for security
        if (!wp_verify_nonce($_POST['nonce'], 'x8_evs_nonce')) {
            wp_send_json_error(__('Security check failed', 'x8-evs'));
        }
        
        // Check user capabilities
        if (!current_user_can('x8_verify_access')) {
            wp_send_json_error(__('Insufficient permissions', 'x8-evs'));
        }
        
        $customer_id = intval($_POST['customer_id']);
        $new_status = sanitize_text_field($_POST['new_status']);
        $notes = sanitize_textarea_field($_POST['notes'] ?? '');
        $verification_method = sanitize_text_field($_POST['verification_method'] ?? '');
        
        // Validate input
        if (!$customer_id || !in_array($new_status, array('pending', 'verified', 'block', 'manual_review'))) {
            wp_send_json_error(__('Invalid input provided', 'x8-evs'));
        }

        $normalized_notes = trim(preg_replace('/\s+/', ' ', $notes));
        if (mb_strlen($normalized_notes) < 10) {
            wp_send_json_error(__('Please provide at least 10 characters of detail when placing a customer into manual review.', 'x8-evs'));
        }
        
        
        // Validate verification method for verified status
        if ($new_status === 'verified' && !in_array($verification_method, array('manual', 'api', 'approve'))) {
            wp_send_json_error(__('Invalid verification method provided', 'x8-evs'));
        }
        
        // If trying to verify user, check for required verification data
        // Skip verification data check for "approve" method
        if ($new_status === 'verified' && $verification_method !== 'approve') {
            // Check for existing data in user meta
            $document_front_image = get_user_meta($customer_id, 'document_front_image', true);
            $document_back_image = get_user_meta($customer_id, 'document_back_image', true);
            $document_portrait_image = get_user_meta($customer_id, 'document_portrait_image', true);
            
            // Check for new data being provided in this request
            $has_new_document_images = false;
            
            // Debug file uploads
            error_log('X8 EVS Debug - Front image: ' . print_r($_FILES['document_front_image'] ?? 'not set', true));
            error_log('X8 EVS Debug - Back image: ' . print_r($_FILES['document_back_image'] ?? 'not set', true));
            error_log('X8 EVS Debug - Portrait image: ' . print_r($_FILES['document_portrait_image'] ?? 'not set', true));
            
            if (!empty($_FILES['document_front_image']['tmp_name']) && $_FILES['document_front_image']['error'] === UPLOAD_ERR_OK) {
                $has_new_document_images = true;
                error_log('X8 EVS Debug - Front image valid');
            }
            if (!empty($_FILES['document_back_image']['tmp_name']) && $_FILES['document_back_image']['error'] === UPLOAD_ERR_OK) {
                $has_new_document_images = true;
                error_log('X8 EVS Debug - Back image valid');
            }
            if (!empty($_FILES['document_portrait_image']['tmp_name']) && $_FILES['document_portrait_image']['error'] === UPLOAD_ERR_OK) {
                $has_new_document_images = true;
                error_log('X8 EVS Debug - Portrait image valid');
            }
            
            error_log('X8 EVS Debug - Has new document images: ' . ($has_new_document_images ? 'true' : 'false'));
            $has_new_address_data = !empty($_POST['document_address_street']) || !empty($_POST['document_address_city']) || !empty($_POST['document_address_state']) || !empty($_POST['document_address_postcode']);
            
            // Check if we have all required document images (existing or new)
            $has_front_image = !empty($document_front_image) || (!empty($_FILES['document_front_image']['tmp_name']) && $_FILES['document_front_image']['error'] === UPLOAD_ERR_OK);
            $has_back_image = !empty($document_back_image) || (!empty($_FILES['document_back_image']['tmp_name']) && $_FILES['document_back_image']['error'] === UPLOAD_ERR_OK);
            $has_portrait_image = !empty($document_portrait_image) || (!empty($_FILES['document_portrait_image']['tmp_name']) && $_FILES['document_portrait_image']['error'] === UPLOAD_ERR_OK);
            
            // Check if selfie is required based on settings
            $require_selfie = get_option('x8_evs_require_selfie', 1);
            
            // Determine required images based on selfie setting
            if ($require_selfie) {
                $has_all_document_images = $has_front_image && $has_back_image && $has_portrait_image;
            } else {
                $has_all_document_images = $has_front_image && $has_back_image;
            }
            
            // Check for address information (existing or new)
            $document_address_street = get_user_meta($customer_id, 'document_address_street', true);
            $document_address_city = get_user_meta($customer_id, 'document_address_city', true);
            $document_address_state = get_user_meta($customer_id, 'document_address_state', true);
            $document_address_postcode = get_user_meta($customer_id, 'document_address_postcode', true);
            $document_address_country = get_user_meta($customer_id, 'document_address_country', true);
            
            $has_existing_address = !empty($document_address_street) || !empty($document_address_city) || !empty($document_address_state) || !empty($document_address_postcode) || !empty($document_address_country);
            
            // Also check for address information in verification data
            $verification_data = get_user_meta($customer_id, 'verification_webhook_data', true);
            $verification_data = $verification_data ? json_decode($verification_data, true) : null;
            
            $has_verification_address = false;
            if ($verification_data) {
                if (isset($verification_data['data']['assureCard']['documentAddress'])) {
                    $has_verification_address = true;
                }
                if (isset($verification_data['data']['assureId']['standardizedAddress'])) {
                    $has_verification_address = true;
                }
            }
            
            $has_address_info = $has_existing_address || $has_new_address_data || $has_verification_address;
            
            // Only document images are required for verification (address is optional)
            // Check required document images based on selfie setting
            if (!$has_all_document_images) {
                $missing_images = array();
                if (!$has_front_image) $missing_images[] = 'front image';
                if (!$has_back_image) $missing_images[] = 'back image';
                if ($require_selfie && !$has_portrait_image) $missing_images[] = 'portrait image';
                
                wp_send_json_error(array(
                    'message' => sprintf(__('Cannot verify user. Missing required document images: %s', 'x8-evs'), implode(', ', $missing_images)),
                    'missing_data' => array(
                        'document_images' => true,
                        'address_info' => false
                    ),
                    'requires_additional_data' => true
                ));
            }
            
            // Address information is optional - no validation required
        }
        
        // Check if user exists
        $user = get_userdata($customer_id);
        if (!$user) {
            wp_send_json_error(__('Customer not found', 'x8-evs'));
        }
        
        $previous_status = get_user_meta($customer_id, 'account_status', true);

        // If verifying, check for duplicate license number when setting is enabled
        $block_duplicate_license = get_option('x8_evs_block_duplicate_license', false);
        $block_duplicate_license = ($block_duplicate_license === true || $block_duplicate_license === '1' || $block_duplicate_license === 1);
        if ($block_duplicate_license && $new_status === 'verified') {
            $license_number = trim((string) get_user_meta($customer_id, 'document_number', true));
            if ($license_number !== '' && self::find_existing_user_by_license_number($license_number, $customer_id) !== null) {
                $new_status = 'block';
                update_user_meta($customer_id, '_duplicate_license_block', '1');
                update_user_meta($customer_id, '_verification_block_reason', 'duplicate_license');
            }
        }

        // Get current admin user
        $current_user = wp_get_current_user();
        $admin_user_id = $current_user->ID;
        $admin_user_name = $current_user->display_name ?: $current_user->user_login;
        
        // If verifying and additional data is provided, save it
        // Skip data saving for "approve" method
        if ($new_status === 'verified' && $verification_method !== 'approve') {
            // Check if this is an API-based verification
            if ($verification_method === 'api') {
                // Handle API-based verification with direct image upload
                $this->handle_api_verification($customer_id, $verification_method);
            } else {
                // Handle manual verification (existing logic)
                // Handle file uploads for document images
                if (!empty($_FILES['document_front_image']['tmp_name'])) {
                    $front_image_url = $this->handle_file_upload($_FILES['document_front_image'], $customer_id, 'front');
                    if ($front_image_url) {
                        update_user_meta($customer_id, 'document_front_image', $front_image_url);
                    }
                }
                
                if (!empty($_FILES['document_back_image']['tmp_name'])) {
                    $back_image_url = $this->handle_file_upload($_FILES['document_back_image'], $customer_id, 'back');
                    if ($back_image_url) {
                        update_user_meta($customer_id, 'document_back_image', $back_image_url);
                    }
                }
                
                if (!empty($_FILES['document_portrait_image']['tmp_name'])) {
                    $portrait_image_url = $this->handle_file_upload($_FILES['document_portrait_image'], $customer_id, 'portrait');
                    if ($portrait_image_url) {
                        update_user_meta($customer_id, 'document_portrait_image', $portrait_image_url);
                    }
                }
                
                // Save address information if provided - store in webhook data format
                $document_address_street = sanitize_text_field($_POST['document_address_street'] ?? '');
                $document_address_city = sanitize_text_field($_POST['document_address_city'] ?? '');
                $document_address_state = sanitize_text_field($_POST['document_address_state'] ?? '');
                $document_address_postcode = sanitize_text_field($_POST['document_address_postcode'] ?? '');
                $document_address_country = sanitize_text_field($_POST['document_address_country'] ?? '');
                
                if (!empty($document_address_street) || !empty($document_address_city) || !empty($document_address_state)) {
                    // Get existing webhook data or create new structure
                    $existing_webhook_data = get_user_meta($customer_id, 'verification_webhook_data', true);
                    $webhook_data = $existing_webhook_data ? json_decode($existing_webhook_data, true) : array();
                    
                    // Ensure the data structure exists
                    if (!isset($webhook_data['data'])) {
                        $webhook_data['data'] = array();
                    }
                    if (!isset($webhook_data['data']['assureCard'])) {
                        $webhook_data['data']['assureCard'] = array();
                    }
                    
                    // Create or update documentAddress structure
                    $webhook_data['data']['assureCard']['documentAddress'] = array(
                        'address' => $document_address_street,
                        'city' => $document_address_city,
                        'state' => $document_address_state,
                        'zipCode' => $document_address_postcode,
                        'country' => $document_address_country,
                    );
                    
                    // Set confidence scores to 100 for manual verification
                    $webhook_data['data']['assureCard']['totalConfidence'] = 100;
                    $webhook_data['data']['assureCard']['faceVerificationConfidence'] = 100;
                    $webhook_data['data']['assureCard']['selfieIsRealConfidence'] = 100;
                    
                    // Set validation result to success for manual verification
                    $webhook_data['data']['assureCard']['validationResult'] = array(
                        'code' => '0',
                        'description' => 'Valid'
                    );
                    
                    // Save the updated webhook data
                    update_user_meta($customer_id, 'verification_webhook_data', json_encode($webhook_data));
                }
            }
        }
        
        // Update customer status (for manual verification only)
        update_user_meta($customer_id, 'account_status', $new_status);
        update_user_meta($customer_id, 'verification_date', current_time('mysql'));
        update_user_meta($customer_id, 'verification_notes', $notes);
        update_user_meta($customer_id, 'verification_admin_user', $admin_user_id);
        update_user_meta($customer_id, 'verification_admin_name', $admin_user_name);
        
        // Store verification method if status is verified
        if ($new_status === 'verified' && !in_array($verification_method, array('api', 'approve'))) {
            update_user_meta($customer_id, 'verification_method', $verification_method);
        }
        

        
        // Log the status change
        $this->log_status_change($customer_id, $new_status, $notes, $admin_user_name, $verification_method);
        
        // Allow other plugins to react when a user is approved/verified (e.g. create game accounts)
        if ($new_status === 'verified') {
            do_action('x8_evs_user_verified', $customer_id);
        }
        
        wp_send_json_success(array(
            'message' => __('Customer status updated successfully', 'x8-evs'),
            'new_status' => $new_status,
            'verification_date' => current_time('mysql')
        ));
    }

    /**
     * Handle AJAX geolocation cache clearing
     */
    public function handle_clear_geo_cache() {
        // Verify nonce for security
        if (!wp_verify_nonce($_POST['nonce'], 'x8_evs_nonce')) {
            wp_send_json_error(__('Security check failed', 'x8-evs'));
        }
        
        // Check user capabilities
        if (!current_user_can('x8_verify_access')) {
            wp_send_json_error(__('Insufficient permissions', 'x8-evs'));
        }
        
        // Clear the cache
        $cleared_count = 0;
        if (class_exists('X8_EVS_Blocking_Handler')) {
            $cleared_count = X8_EVS_Blocking_Handler::clear_geolocation_cache();
        }
        
        // Get updated cache statistics
        $cache_stats = array('total_cached_ips' => 0, 'cache_size_mb' => 0);
        if (class_exists('X8_EVS_Blocking_Handler')) {
            $cache_stats = X8_EVS_Blocking_Handler::get_geolocation_cache_stats();
        }
        
        wp_send_json_success(array(
            'message' => sprintf(__('Cache cleared successfully. %d entries removed.', 'x8-evs'), $cleared_count),
            'cleared_count' => $cleared_count,
            'cache_stats' => $cache_stats
        ));
    }

    /**
     * Handle AJAX blocking cache clearing
     */
    public function handle_clear_blocking_cache() {
        // Verify nonce for security
        if (!wp_verify_nonce($_POST['nonce'], 'x8_evs_nonce')) {
            wp_send_json_error(__('Security check failed', 'x8-evs'));
        }
        
        // Check user capabilities
        if (!current_user_can('x8_verify_access')) {
            wp_send_json_error(__('Insufficient permissions', 'x8-evs'));
        }
        
        // Clear the cache
        $cleared_count = 0;
        if (class_exists('X8_EVS_Blocking_Handler')) {
            $cleared_count = X8_EVS_Blocking_Handler::clear_all_blocking_cache();
        }
        
        // Get updated cache statistics
        $cache_stats = array('total_cached_users' => 0, 'blocked_users' => 0, 'allowed_users' => 0, 'cache_size_mb' => 0);
        if (class_exists('X8_EVS_Blocking_Handler')) {
            $cache_stats = X8_EVS_Blocking_Handler::get_blocking_cache_stats();
        }
        
        wp_send_json_success(array(
            'message' => sprintf(__('Blocking cache cleared successfully. %d user entries removed.', 'x8-evs'), $cleared_count),
            'cleared_count' => $cleared_count,
            'cache_stats' => $cache_stats
        ));
    }

    /**
     * Handle AJAX VPN cache clearing
     */
    public function handle_clear_vpn_cache() {
        // Verify nonce for security
        if (!wp_verify_nonce($_POST['nonce'], 'x8_evs_nonce')) {
            wp_send_json_error(__('Security check failed', 'x8-evs'));
        }
        
        // Check user capabilities
        if (!current_user_can('x8_verify_access')) {
            wp_send_json_error(__('Insufficient permissions', 'x8-evs'));
        }
        
        // Clear the cache
        $cleared_count = 0;
        if (class_exists('X8_EVS_Blocking_Handler')) {
            $cleared_count = X8_EVS_Blocking_Handler::clear_vpn_cache();
        }
        
        // Get updated cache statistics
        $cache_stats = array('total_cached_ips' => 0, 'cache_size_mb' => 0);
        if (class_exists('X8_EVS_Blocking_Handler')) {
            $cache_stats = X8_EVS_Blocking_Handler::get_vpn_cache_stats();
        }
        
        wp_send_json_success(array(
            'message' => sprintf(__('VPN cache cleared successfully. %d entries removed.', 'x8-evs'), $cleared_count),
            'cleared_count' => $cleared_count,
            'cache_stats' => $cache_stats
        ));
    }

    /**
     * Handle AJAX request to request new documents from user
     */
    public function handle_request_new_documents() {
        // Verify nonce for security
        if (!wp_verify_nonce($_POST['nonce'], 'x8_evs_nonce')) {
            wp_send_json_error(__('Security check failed', 'x8-evs'));
        }
        
        // Check user capabilities
        if (!current_user_can('x8_verify_access')) {
            wp_send_json_error(__('Insufficient permissions', 'x8-evs'));
        }
        
        // Get customer ID
        $customer_id = intval($_POST['customer_id'] ?? 0);
        
        if (!$customer_id) {
            wp_send_json_error(__('Invalid customer ID', 'x8-evs'));
        }
        
        // Check if user exists
        $user = get_userdata($customer_id);
        if (!$user) {
            wp_send_json_error(__('Customer not found', 'x8-evs'));
        }
        
        // Clear existing verification data to force new upload
        $fields_to_clear = array(
            'verification_link',
            'verification_link_created',
            'verification_transaction_id',
            'verification_customer_reference',
            'verification_attempts',
            'document_front_image',
            'document_back_image',
            'document_portrait_image',
            'verification_webhook_data',
            'verification_date',
            'verification_notes',
            'account_status'
        );
        
        foreach ($fields_to_clear as $field) {
            delete_user_meta($customer_id, $field);
        }
        
        // Set a temporary flag to indicate we're in document request process
        update_user_meta($customer_id, '_document_request_in_progress', '1');
        
        // Set status to fresh_data first to trigger email notification
        update_user_meta($customer_id, 'account_status', 'fresh_data');
        
        // Set status back to pending
        update_user_meta($customer_id, 'account_status', 'pending');
        update_user_meta($customer_id, 'x8_evs_pending_since', current_time('mysql'));
        
        // Remove the temporary flag
        delete_user_meta($customer_id, '_document_request_in_progress');
        
        // Add to status change history for pending
        $this->log_status_change($customer_id, 'pending', 'Status reset to pending after document request', '', 'document_request');
        
        // Log this action
        $admin_user = wp_get_current_user();
        $this->log_document_request($admin_user->ID, $admin_user->display_name, $customer_id, $user->display_name);
        
        wp_send_json_success(array(
            'message' => __('Document request sent successfully. User status reset to pending.', 'x8-evs'),
            'status_updated' => true
        ));
    }
    
    /**
     * Log when documents are requested from user
     */
    private function log_document_request($admin_user_id, $admin_user_name, $customer_id, $customer_name) {
        $log_entry = array(
            'timestamp' => current_time('mysql'),
            'action' => 'request_new_documents',
            'admin_user_id' => $admin_user_id,
            'admin_user_name' => $admin_user_name,
            'customer_id' => $customer_id,
            'customer_name' => $customer_name,
            'details' => 'Admin requested new documents from customer'
        );
        
        // Store in global activity log
        self::store_global_activity_log($log_entry);
    }

    /**
     * Handle AJAX request to clear all verification links
     * Uses delete_user_meta() per user so WordPress (and object cache) is updated; direct $wpdb->delete
     * would leave cached meta and customers would still see "You already have a verification link".
     */
    public function handle_clear_verification_links() {
        // Verify nonce for security
        if (!wp_verify_nonce($_POST['nonce'], 'x8_evs_nonce')) {
            wp_send_json_error(__('Security check failed', 'x8-evs'));
        }
        
        // Check user capabilities
        if (!current_user_can('x8_verify_access')) {
            wp_send_json_error(__('Insufficient permissions', 'x8-evs'));
        }
        
        global $wpdb;
        $meta_keys = array(
            'verification_link',
            'verification_link_created',
            'verification_transaction_id',
            'verification_customer_reference',
            'verification_attempts'
        );
        
        // Get distinct user IDs that have any of these meta keys (so we can clear cache per user)
        $placeholders = implode(',', array_fill(0, count($meta_keys), '%s'));
        $user_ids = $wpdb->get_col(
            $wpdb->prepare(
                "SELECT DISTINCT user_id FROM {$wpdb->usermeta} WHERE meta_key IN ($placeholders)",
                $meta_keys
            )
        );
        
        $deleted_links = 0;
        $deleted_created_times = 0;
        $deleted_transaction_ids = 0;
        $deleted_customer_refs = 0;
        $deleted_attempts = 0;
        
        foreach ($user_ids as $user_id) {
            $user_id = (int) $user_id;
            if ($user_id <= 0) {
                continue;
            }
            if (delete_user_meta($user_id, 'verification_link')) {
                $deleted_links++;
            }
            if (delete_user_meta($user_id, 'verification_link_created')) {
                $deleted_created_times++;
            }
            if (delete_user_meta($user_id, 'verification_transaction_id')) {
                $deleted_transaction_ids++;
            }
            if (delete_user_meta($user_id, 'verification_customer_reference')) {
                $deleted_customer_refs++;
            }
            if (delete_user_meta($user_id, 'verification_attempts')) {
                $deleted_attempts++;
            }
            // Ensure user meta cache is cleared (important for persistent object caches)
            wp_cache_delete($user_id, 'user_meta');
        }
        
        // Log this action
        $admin_user = wp_get_current_user();
        $this->log_verification_links_cleared($admin_user->ID, $admin_user->display_name);
        
        wp_send_json_success(array(
            'message' => sprintf(
                __('Successfully cleared %d verification links and related metadata. Reset limits for %d customers.', 'x8-evs'),
                (int) $deleted_links,
                (int) $deleted_attempts
            ),
            'deleted_links' => $deleted_links,
            'deleted_created_times' => $deleted_created_times,
            'deleted_transaction_ids' => $deleted_transaction_ids,
            'deleted_customer_refs' => $deleted_customer_refs,
            'deleted_attempts' => $deleted_attempts
        ));
    }
    
    /**
     * Fetch blacklist entries for the integration modal.
     */
    public function handle_fetch_blacklist_entries() {
        if (!wp_verify_nonce($_POST['nonce'] ?? '', 'x8_evs_nonce')) {
            wp_send_json_error(array('message' => __('Security check failed', 'x8-evs')));
        }

        if (!current_user_can('x8_verify_access')) {
            wp_send_json_error(array('message' => __('Insufficient permissions', 'x8-evs')));
        }

        global $wpdb;

        $table = $wpdb->prefix . 'wc_blacklist';
        $entries = $wpdb->get_results(
            "SELECT * FROM {$table} WHERE is_blocked = 1 ORDER BY date_added DESC",
            ARRAY_A
        );

        if (empty($entries)) {
            wp_send_json_success(array(
                'count' => 0,
                'entries' => array()
            ));
        }

        $prepared_entries = array();

        foreach ($entries as $entry) {
            $entry_name = trim(
                sprintf(
                    '%s %s',
                    $entry['first_name'] ?? '',
                    $entry['last_name'] ?? ''
                )
            );

            $matched_user = $this->find_matching_user_for_blacklist_entry($entry);

            $prepared_entries[] = array(
                'blacklist_id' => isset($entry['id']) ? (int) $entry['id'] : 0,
                'order_id' => isset($entry['order_id']) ? (int) $entry['order_id'] : 0,
                'name' => $entry_name ?: ($entry['email_address'] ?? $entry['phone_number'] ?? '—'),
                'email' => sanitize_email($entry['email_address'] ?? '') ?: sanitize_email($entry['normalized_email'] ?? ''),
                'phone' => $entry['phone_number'] ?? '',
                'sources' => $entry['sources'] ?? '',
                'date_added' => $entry['date_added'] ?? '',
                'customer_id' => $matched_user ? $matched_user['id'] : 0,
                'customer_name' => $matched_user ? $matched_user['display_name'] : '',
                'customer_email' => $matched_user ? $matched_user['user_email'] : '',
                'account_status' => $matched_user ? $matched_user['account_status'] : '',
                'match_type' => $matched_user ? $matched_user['match_type'] : '',
                'match_value' => $matched_user ? $matched_user['match_value'] : '',
                'normalized_match_value' => $matched_user ? $matched_user['normalized_match_value'] : '',
            );
        }

        wp_send_json_success(array(
            'count' => count($prepared_entries),
            'entries' => $prepared_entries
        ));
    }

    /**
     * Sync an individual blacklist record to the customer's X8 status.
     */
    public function handle_sync_blacklist_status() {
        if (!wp_verify_nonce($_POST['nonce'] ?? '', 'x8_evs_nonce')) {
            wp_send_json_error(array('message' => __('Security check failed', 'x8-evs')));
        }

        if (!current_user_can('x8_verify_access')) {
            wp_send_json_error(array('message' => __('Insufficient permissions', 'x8-evs')));
        }

        $customer_id = intval($_POST['customer_id'] ?? 0);
        $blacklist_id = intval($_POST['blacklist_id'] ?? 0);

        if (!$customer_id) {
            wp_send_json_error(array('message' => __('Invalid customer ID provided.', 'x8-evs')));
        }

        $user = get_userdata($customer_id);

        if (!$user) {
            wp_send_json_error(array('message' => __('Customer not found.', 'x8-evs')));
        }

        $previous_status = get_user_meta($customer_id, 'account_status', true) ?: 'pending';
        $status_changed = false;

        if ('block' !== $previous_status) {
            update_user_meta($customer_id, 'account_status', 'block');
            $status_changed = true;

            $admin_user = wp_get_current_user();
            $this->log_status_change(
                $customer_id,
                'block',
                sprintf(
                    /* translators: %d: blacklist record ID */
                    __('Status synced with blacklist record #%d', 'x8-evs'),
                    $blacklist_id
                ),
                $admin_user->display_name ?: $admin_user->user_login,
                'blacklist_sync'
            );
        }

        self::log_customer_activity($customer_id, 'blacklist_sync', array(
            'previous_status' => $previous_status,
            'new_status' => 'block',
            'blacklist_id' => $blacklist_id,
            'status_changed' => $status_changed,
        ));

        wp_send_json_success(array(
            'new_status' => 'block',
            'previous_status' => $previous_status,
            'status_changed' => $status_changed,
            'message' => __('Customer status synced successfully.', 'x8-evs')
        ));
    }

    /**
     * Sync all matched blacklist records to customer status.
     */
    public function handle_sync_all_blacklist_status() {
        if (!wp_verify_nonce($_POST['nonce'] ?? '', 'x8_evs_nonce')) {
            wp_send_json_error(array('message' => __('Security check failed', 'x8-evs')));
        }

        if (!current_user_can('x8_verify_access')) {
            wp_send_json_error(array('message' => __('Insufficient permissions', 'x8-evs')));
        }

        global $wpdb;

        $table = $wpdb->prefix . 'wc_blacklist';
        $entries = $wpdb->get_results(
            "SELECT * FROM {$table} WHERE is_blocked = 1 ORDER BY date_added DESC",
            ARRAY_A
        );

        if (empty($entries)) {
            wp_send_json_success(array(
                'updated' => 0,
                'already' => 0
            ));
        }

        $updated = 0;
        $already = 0;

        foreach ($entries as $entry) {
            $matched_user = $this->find_matching_user_for_blacklist_entry($entry);

            if (!$matched_user || empty($matched_user['id'])) {
                continue;
            }

            $customer_id = (int) $matched_user['id'];
            $previous_status = get_user_meta($customer_id, 'account_status', true) ?: 'pending';

            if ('block' === $previous_status) {
                $already++;
                continue;
            }

            update_user_meta($customer_id, 'account_status', 'block');
            $updated++;

            $admin_user = wp_get_current_user();
            $this->log_status_change(
                $customer_id,
                'block',
                sprintf(
                    /* translators: %d: blacklist record ID */
                    __('Status synced with blacklist record #%d', 'x8-evs'),
                    isset($entry['id']) ? (int) $entry['id'] : 0
                ),
                $admin_user->display_name ?: $admin_user->user_login,
                'blacklist_sync_bulk'
            );

            self::log_customer_activity($customer_id, 'blacklist_sync_bulk', array(
                'previous_status' => $previous_status,
                'new_status' => 'block',
                'blacklist_id' => isset($entry['id']) ? (int) $entry['id'] : 0,
                'match_type' => $matched_user['match_type'],
                'match_value' => $matched_user['match_value'],
            ));
        }

        wp_send_json_success(array(
            'updated' => $updated,
            'already' => $already
        ));
    }

    /**
     * Attempt to match a blacklist entry to an existing customer account.
     *
     * @param array $entry Blacklist row.
     * @return array|null Matched user array or null.
     */
    private function find_matching_user_for_blacklist_entry($entry) {
        if (!is_array($entry)) {
            $entry = (array) $entry;
        }

        $email_candidates = array_unique(array_filter(array(
            sanitize_email($entry['email_address'] ?? ''),
            sanitize_email($entry['normalized_email'] ?? ''),
        )));

        foreach ($email_candidates as $email) {
            if (!$email) {
                continue;
            }

            $user = get_user_by('email', $email);

            if ($user) {
                return $this->format_matched_user_response($user, 'email', $email);
            }
        }

        $normalized_phone = $this->normalize_phone_number($entry['phone_number'] ?? '');

        if ($normalized_phone) {
            $phone_match = $this->find_user_by_normalized_phone($normalized_phone);

            if ($phone_match) {
                return $this->format_matched_user_response(
                    $phone_match['user'],
                    'phone',
                    $phone_match['match_value'],
                    $phone_match['normalized_value']
                );
            }
        }

        return null;
    }

    /**
     * Format user data for blacklist responses.
     *
     * @param \WP_User $user                  Matched user.
     * @param string  $match_type             Match type (email|phone).
     * @param string  $match_value            Original value used to match.
     * @param string  $normalized_match_value Normalized value (for phone matches).
     * @return array
     */
    private function format_matched_user_response($user, $match_type, $match_value, $normalized_match_value = '') {
        $display_name = trim($user->first_name . ' ' . $user->last_name);

        if ('' === $display_name) {
            $display_name = $user->display_name ?: $user->user_login;
        }

        $account_status = get_user_meta($user->ID, 'account_status', true) ?: 'pending';

        return array(
            'id' => (int) $user->ID,
            'display_name' => $display_name,
            'user_email' => $user->user_email,
            'account_status' => $account_status,
            'match_type' => $match_type,
            'match_value' => $match_value,
            'normalized_match_value' => $normalized_match_value ?: $match_value,
        );
    }

    /**
     * Find a user by normalized phone number.
     *
     * @param string $normalized_phone Normalized phone digits.
     * @return array|null
     */
    private function find_user_by_normalized_phone($normalized_phone) {
        if (!$normalized_phone) {
            return null;
        }

        global $wpdb;

        $meta_keys = apply_filters('x8_evs_blacklist_phone_meta_keys', array(
            'phone',
            'billing_phone',
            '_billing_phone',
            'shipping_phone',
            '_shipping_phone',
        ));

        $placeholders = implode(', ', array_fill(0, count($meta_keys), '%s'));
        $like_fragment = '%' . substr($normalized_phone, -4) . '%';

        $query = $wpdb->prepare(
            "SELECT user_id, meta_value
             FROM {$wpdb->usermeta}
             WHERE meta_key IN ($placeholders)
             AND meta_value LIKE %s",
            array_merge($meta_keys, array($like_fragment))
        );

        $rows = $wpdb->get_results($query);

        if (empty($rows)) {
            return null;
        }

        foreach ($rows as $row) {
            $stored_normalized = $this->normalize_phone_number($row->meta_value);

            if ($stored_normalized && $stored_normalized === $normalized_phone) {
                $user = get_userdata((int) $row->user_id);

                if ($user) {
                    return array(
                        'user' => $user,
                        'match_value' => $row->meta_value,
                        'normalized_value' => $stored_normalized,
                    );
                }
            }
        }

        return null;
    }

    /**
     * Normalize phone numbers to digits for comparison.
     *
     * @param string $phone Raw phone string.
     * @return string
     */
    private function normalize_phone_number($phone) {
        if (empty($phone)) {
            return '';
        }

        $digits = preg_replace('/\D+/', '', $phone);

        if (strlen($digits) === 11 && '1' === substr($digits, 0, 1)) {
            $digits = substr($digits, 1);
        }

        return $digits;
    }

    /**
     * Log when verification links are cleared
     */
    private function log_verification_links_cleared($admin_user_id, $admin_user_name) {
        $log_entry = array(
            'timestamp' => current_time('mysql'),
            'action' => 'verification_links_cleared',
            'admin_user_id' => $admin_user_id,
            'admin_user_name' => $admin_user_name,
            'details' => 'All verification links cleared by administrator'
        );
        
        // Store in global activity log
        self::store_global_activity_log($log_entry);
    }

    /**
     * Handle AJAX request to get cache statistics
     */
    public function handle_get_cache_stats() {
        // Verify nonce for security
        if (!wp_verify_nonce($_POST['nonce'], 'x8_evs_nonce')) {
            wp_send_json_error(__('Security check failed', 'x8-evs'));
        }
        
        // Check user capabilities
        if (!current_user_can('x8_verify_access')) {
            wp_send_json_error(__('Insufficient permissions', 'x8-evs'));
        }
        
        // Get cache statistics for both geolocation and VPN
        $geo_cache_stats = array('total_cached_ips' => 0, 'cache_size_mb' => 0);
        $vpn_cache_stats = array('total_cached_ips' => 0, 'cache_size_mb' => 0);
        
        if (class_exists('X8_EVS_Blocking_Handler')) {
            $geo_cache_stats = X8_EVS_Blocking_Handler::get_geolocation_cache_stats();
            $vpn_cache_stats = X8_EVS_Blocking_Handler::get_vpn_cache_stats();
        }
        
        wp_send_json_success(array(
            'geo_cache_stats' => $geo_cache_stats,
            'vpn_cache_stats' => $vpn_cache_stats
        ));
    }
    
    /**
     * Handle AJAX customer filtering
     */
    public function handle_filter_customers() {
        // Verify nonce for security
        if (!wp_verify_nonce($_POST['nonce'], 'x8_evs_nonce')) {
            wp_send_json_error(__('Security check failed', 'x8-evs'));
        }
        
        // Check user capabilities
        if (!current_user_can('x8_verify_access')) {
            wp_send_json_error(__('Insufficient permissions', 'x8-evs'));
        }
        
        // Get filter parameters
        $search_term = sanitize_text_field($_POST['search_term'] ?? '');
        $status_filter = sanitize_text_field($_POST['status_filter'] ?? '');
        $page = max(1, intval($_POST['page'] ?? 1));
        $per_page = 20;
        
        // Get filtered customers
        $customers_data = $this->get_filtered_customers($search_term, $status_filter, $page, $per_page);
        
        // Generate HTML for the table body and pagination
        ob_start();
        $this->render_customers_table_rows($customers_data['customers']);
        $table_rows = ob_get_clean();
        
        ob_start();
        $this->render_customers_pagination($customers_data, $page);
        $pagination = ob_get_clean();
        
        wp_send_json_success(array(
            'table_rows' => $table_rows,
            'pagination' => $pagination,
            'total_customers' => $customers_data['total'],
            'current_page' => $page,
            'total_pages' => $customers_data['total_pages']
        ));
    }
    
    /**
     * Handle export to Excel (CSV) - trigger from admin_init when export requested
     */
    public function maybe_export_customers() {
        if (empty($_GET['x8_evs_export_customers']) || empty($_GET['_wpnonce'])) {
            return;
        }
        if (!wp_verify_nonce($_GET['_wpnonce'], 'x8_evs_export_customers')) {
            wp_die(__('Security check failed', 'x8-evs'));
        }
        if (!current_user_can('x8_verify_access')) {
            wp_die(__('Insufficient permissions', 'x8-evs'));
        }
        $status_filter = sanitize_text_field($_GET['status_filter'] ?? '');
        $search_term = sanitize_text_field($_GET['search_term'] ?? '');
        $per_page = 999999;
        $customers_data = $this->get_filtered_customers($search_term, $status_filter, 1, $per_page);
        $customers = $customers_data['customers'];
        $status_labels = array(
            'pending' => __('Pending', 'x8-evs'),
            'active' => __('Active', 'x8-evs'),
            'blocked' => __('Blocked', 'x8-evs'),
            'manual_review' => __('Manual Review', 'x8-evs'),
        );
        $filename = 'x8-verify-customers';
        if ($status_filter) {
            $filename .= '-' . $status_filter;
        }
        $filename .= '-' . date('Y-m-d-His') . '.csv';
        header('Content-Type: text/csv; charset=utf-8');
        header('Content-Disposition: attachment; filename="' . $filename . '"');
        header('Pragma: no-cache');
        header('Expires: 0');
        $out = fopen('php://output', 'w');
        fprintf($out, "\xEF\xBB\xBF"); // UTF-8 BOM for Excel
        fputcsv($out, array(__('ID', 'x8-evs'), __('Full Name', 'x8-evs'), __('Email', 'x8-evs'), __('Phone', 'x8-evs'), __('Status', 'x8-evs'), __('Registered', 'x8-evs')));
        foreach ($customers as $row) {
            $status_label = isset($status_labels[$row['status']]) ? $status_labels[$row['status']] : $row['status'];
            $created = $row['created_at'] ? date_i18n(get_option('date_format') . ' ' . get_option('time_format'), strtotime($row['created_at'])) : '';
            fputcsv($out, array($row['id'], $row['name'], $row['email'], $row['phone'], $status_label, $created));
        }
        fclose($out);
        exit;
    }
    
    /**
     * Get filtered customers with pagination
     */
    private function get_filtered_customers($search_term = '', $status_filter = '', $page = 1, $per_page = 20) {
        global $wpdb;
        
        $offset = ($page - 1) * $per_page;
        $where_conditions = array();
        $join_conditions = array();
        
        // Base query for TapStack players (and WooCommerce customers, if any)
        $base_where = 'WHERE ' . self::customer_role_sql('u');
        
        // Search by name, email, or ID
        if (!empty($search_term)) {
            if (is_numeric($search_term)) {
                $where_conditions[] = $wpdb->prepare("u.ID = %d", intval($search_term));
            } else {
                $where_conditions[] = $wpdb->prepare(
                    "(u.user_login LIKE %s OR u.user_email LIKE %s OR u.display_name LIKE %s)",
                    '%' . $wpdb->esc_like($search_term) . '%',
                    '%' . $wpdb->esc_like($search_term) . '%',
                    '%' . $wpdb->esc_like($search_term) . '%'
                );
            }
        }
        
        // Filter by status
        if (!empty($status_filter)) {
            $join_conditions[] = "LEFT JOIN {$wpdb->usermeta} um_status ON u.ID = um_status.user_id AND um_status.meta_key = 'account_status'";
            
            if ($status_filter === 'pending') {
                // For pending status, we need to check for empty or null account_status
                $where_conditions[] = "(um_status.meta_value IS NULL OR um_status.meta_value = '' OR um_status.meta_value = 'pending')";
            } elseif ($status_filter === 'active') {
                // For active status, check for 'verified' account_status
                $where_conditions[] = $wpdb->prepare("um_status.meta_value = %s", 'verified');
            } elseif ($status_filter === 'blocked') {
                // For blocked status, check for 'block' account_status
                $where_conditions[] = $wpdb->prepare("um_status.meta_value = %s", 'block');
            } else {
                // For other statuses, check exact match
                $where_conditions[] = $wpdb->prepare("um_status.meta_value = %s", $status_filter);
            }
        }
        
        // Build complete query for count
        $count_query = "SELECT COUNT(DISTINCT u.ID) FROM {$wpdb->users} u ";
        if (!empty($join_conditions)) {
            $count_query .= implode(' ', $join_conditions) . ' ';
        }
        $count_query .= $base_where;
        if (!empty($where_conditions)) {
            $count_query .= " AND " . implode(' AND ', $where_conditions);
        }
        
        $total = $wpdb->get_var($count_query);
        
        // Build complete query for data
        $data_query = "SELECT DISTINCT u.ID, u.user_login, u.user_email, u.display_name, u.user_registered FROM {$wpdb->users} u ";
        if (!empty($join_conditions)) {
            $data_query .= implode(' ', $join_conditions) . ' ';
        }
        $data_query .= $base_where;
        if (!empty($where_conditions)) {
            $data_query .= " AND " . implode(' AND ', $where_conditions);
        }
        $data_query .= " ORDER BY u.user_registered DESC LIMIT {$per_page} OFFSET {$offset}";
        
        $users = $wpdb->get_results($data_query);
        
        // Format users data to match expected structure
        $customers = array();
        foreach ($users as $user) {
            // Get user meta for additional fields
            $phone = get_user_meta($user->ID, 'phone', true) ?: get_user_meta($user->ID, 'billing_phone', true);
            $full_name = trim($user->first_name . ' ' . $user->last_name);
            if (empty($full_name)) {
                $full_name = get_user_meta($user->ID, 'document_full_name', true);
            }
            if (empty($full_name)) {
                $full_name = $user->display_name ?: $user->user_login;
            }
            
            // Determine status based on account_status user meta
            $account_status = get_user_meta($user->ID, 'account_status', true);
            
            if (empty($account_status)) {
                $status = 'pending'; // Empty means pending
            } elseif ($account_status === 'verified') {
                $status = 'active'; // Verified means active/verified
            } elseif ($account_status === 'block') {
                $status = 'blocked'; // Block means blocked
            } elseif ($account_status === 'manual_review') {
                $status = 'manual_review'; // Manual review status
            } else {
                $status = $account_status; // Default fallback
            }
            
            $customers[] = array(
                'id' => $user->ID,
                'name' => $full_name,
                'email' => $user->user_email,
                'phone' => $phone ?: '—',
                'status' => $status,
                'created_at' => $user->user_registered
            );
        }
        
        // Calculate total pages
        $total_pages = ceil($total / $per_page);
        
        return array(
            'customers' => $customers,
            'total' => $total,
            'total_pages' => $total_pages
        );
    }
    
    /**
     * Render customer table rows only
     */
    private function render_customers_table_rows($customers) {
        if (empty($customers)): ?>
            <tr>
                <td colspan="8" style="text-align: center; padding: 40px; color: #646970;">
                    <span class="dashicons dashicons-groups" style="font-size: 48px; opacity: 0.3; display: block; margin-bottom: 10px;"></span>
                    <?php _e('No customers found matching your criteria.', 'x8-evs'); ?>
                </td>
            </tr>
        <?php else: ?>
            <?php foreach ($customers as $customer): ?>
                <tr>
                    <td class="check-column">
                        <input type="checkbox" name="customer[]" value="<?php echo esc_attr($customer['id']); ?>" />
                    </td>
                    <td><strong><?php echo esc_html($customer['id']); ?></strong></td>
                    <td>
                        <strong>
                            <a href="<?php echo admin_url('admin.php?page=x8-evs&view_customer=' . $customer['id']); ?>" class="row-title">
                                <?php echo esc_html($customer['name']); ?>
                            </a>
                        </strong>
                        <div class="row-actions">
                            <span class="view">
                                <a href="<?php echo admin_url('admin.php?page=x8-evs&view_customer=' . $customer['id']); ?>"><?php _e('View', 'x8-evs'); ?></a> |
                            </span>
                            <span class="trash">
                                <a href="#" class="x8-evs-delete-customer" data-id="<?php echo esc_attr($customer['id']); ?>"><?php _e('Delete', 'x8-evs'); ?></a>
                            </span>
                        </div>
                    </td>
                    <td><?php echo esc_html($customer['email']); ?></td>
                    <td><?php echo esc_html($customer['phone'] ?: '—'); ?></td>
                    <td>
                        <span class="x8-evs-badge <?php echo esc_attr($customer['status']); ?>">
                            <?php echo esc_html(ucfirst($customer['status'])); ?>
                        </span>
                    </td>
                    <td><?php echo esc_html(date('M j, Y', strtotime($customer['created_at']))); ?></td>
                    <td>
                        <div class="x8-evs-customer-actions">
                            <a href="<?php echo admin_url('admin.php?page=x8-evs&view_customer=' . $customer['id']); ?>" class="button button-small">
                                <span class="dashicons dashicons-visibility"></span>
                                <?php _e('View', 'x8-evs'); ?>
                            </a>
                        </div>
                    </td>
                </tr>
            <?php endforeach; ?>
        <?php endif;
    }
    
    /**
     * Render customer pagination only
     */
    private function render_customers_pagination($customers_data, $current_page) {
        if ($customers_data['total_pages'] <= 1) {
            return;
        }
        
        $base_url = admin_url('admin.php?page=x8-evs&tab=customers');
        ?>
        <div class="x8-evs-pagination">
            <div class="x8-evs-pagination-info">
                <span><?php printf(__('Page %d of %d (%d total customers)', 'x8-evs'), $current_page, $customers_data['total_pages'], $customers_data['total']); ?></span>
            </div>
            
            <div class="x8-evs-pagination-links">
                <?php if ($current_page > 1): ?>
                    <button class="button x8-evs-page-btn" data-page="<?php echo $current_page - 1; ?>"><?php _e('Previous', 'x8-evs'); ?></button>
                <?php endif; ?>
                
                <?php
                $start_page = max(1, $current_page - 2);
                $end_page = min($customers_data['total_pages'], $current_page + 2);
                
                for ($i = $start_page; $i <= $end_page; $i++): ?>
                    <button class="button <?php echo $i === $current_page ? 'button-primary' : ''; ?> x8-evs-page-btn" data-page="<?php echo $i; ?>"><?php echo $i; ?></button>
                <?php endfor; ?>
                
                <?php if ($current_page < $customers_data['total_pages']): ?>
                    <button class="button x8-evs-page-btn" data-page="<?php echo $current_page + 1; ?>"><?php _e('Next', 'x8-evs'); ?></button>
                <?php endif; ?>
            </div>
        </div>
        <?php
    }
    
    /**
     * Log status changes for audit trail
     */
    private function log_status_change($customer_id, $new_status, $notes = '', $admin_user_name = '', $verification_method = '') {
        global $wpdb;
        
        $current_user = wp_get_current_user();
        $table_name = $wpdb->prefix . 'x8_evs_logs';
        
        // Store status change history in user meta
        $status_history = get_user_meta($customer_id, 'status_change_history', true);
        if (!is_array($status_history)) {
            $status_history = array();
        }
        
        $status_entry = array(
            'status' => $new_status,
            'notes' => $notes,
            'admin_user' => $admin_user_name ?: $current_user->display_name ?: $current_user->user_login,
            'timestamp' => current_time('mysql'),
            'ip_address' => $_SERVER['REMOTE_ADDR'],
            'verification_method' => $verification_method
        );
        
        // Add to beginning of array (most recent first)
        array_unshift($status_history, $status_entry);
        
        // Keep only last 20 entries
        $status_history = array_slice($status_history, 0, 20);
        
        update_user_meta($customer_id, 'status_change_history', $status_history);
        
        $wpdb->insert(
            $table_name,
            array(
                'verification_code' => 'STATUS_UPDATE',
                'document_number' => $customer_id,
                'status' => $new_status,
                'ip_address' => $_SERVER['REMOTE_ADDR'],
                'user_agent' => $_SERVER['HTTP_USER_AGENT'],
                'created_at' => current_time('mysql')
            ),
            array('%s', '%s', '%s', '%s', '%s', '%s')
        );
    }
    
    /**
     * Handle file upload for document images
     */
    private function handle_file_upload($file, $customer_id, $type) {
        // Check if file was uploaded without errors
        if ($file['error'] !== UPLOAD_ERR_OK) {
            return false;
        }
        
        // Validate file type
        $allowed_types = array('image/jpeg', 'image/jpg', 'image/png', 'image/gif');
        if (!in_array($file['type'], $allowed_types)) {
            return false;
        }
        
        // Validate file size (5MB max)
        if ($file['size'] > 5 * 1024 * 1024) {
            return false;
        }
        
        // Create upload directory if it doesn't exist
        $upload_dir = wp_upload_dir();
        $x8_evs_dir = $upload_dir['basedir'] . '/x8-evs-documents';
        if (!file_exists($x8_evs_dir)) {
            wp_mkdir_p($x8_evs_dir);
        }
        
        // Generate unique filename
        $file_extension = pathinfo($file['name'], PATHINFO_EXTENSION);
        $filename = 'customer_' . $customer_id . '_' . $type . '_' . time() . '.' . $file_extension;
        $filepath = $x8_evs_dir . '/' . $filename;
        
        // Move uploaded file
        if (move_uploaded_file($file['tmp_name'], $filepath)) {
            // Return the file path (not URL) to match existing code structure
            return $filepath;
        }
        
        return false;
    }
    
    /**
     * Store verification webhook data
     * Call this method when receiving webhook data
     */
    public static function store_verification_data($customer_id, $webhook_data) {
        // Location (AssureLocate) callbacks share workflowOutcome with identity
        // verification. Never let them replace stored AssureCard results/images.
        $has_identity_card = isset($webhook_data['data']['assureCard']) || isset($webhook_data['data']['assureId']);
        if (!$has_identity_card) {
            if (class_exists('X8_EVS_Debug_Logger')) {
                X8_EVS_Debug_Logger::log('webhook_ignored', 'Refusing to overwrite identity verification data: payload has no assureCard/assureId', array(
                    'product_name' => $webhook_data['meta']['productName'] ?? '',
                    'transaction_id' => $webhook_data['meta']['transactionId'] ?? '',
                    'data_keys' => isset($webhook_data['data']) && is_array($webhook_data['data']) ? array_keys($webhook_data['data']) : array()
                ), $customer_id);
            }
            return true;
        }

        // Store the complete webhook data
        update_user_meta($customer_id, 'verification_webhook_data', wp_json_encode($webhook_data));

        // Extract and store specific fields for easier access
        if (isset($webhook_data['data']['assureCard'])) {
            $assureCard = $webhook_data['data']['assureCard'];
            
            // Store document information
            if (isset($assureCard['documentInformation'])) {
                update_user_meta($customer_id, 'document_type', $assureCard['documentInformation']['documentType'] ?? '');
                update_user_meta($customer_id, 'document_number', $assureCard['documentInformation']['licenseNumber'] ?? '');
                update_user_meta($customer_id, 'document_issue_date', $assureCard['documentInformation']['issueDate'] ?? '');
                update_user_meta($customer_id, 'document_expiry_date', $assureCard['documentInformation']['expirationDate'] ?? '');
            }
            
            // Store document name information
            if (isset($assureCard['documentName'])) {
                update_user_meta($customer_id, 'document_full_name', $assureCard['documentName']['fullName'] ?? '');
                update_user_meta($customer_id, 'name_confidence', $assureCard['documentName']['nameConfidence'] ?? 0);
            }
            
            // Store individual characteristics
            if (isset($assureCard['individualCharacteristics'])) {
                update_user_meta($customer_id, 'calculated_age', $assureCard['individualCharacteristics']['calculatedAge'] ?? '');
                update_user_meta($customer_id, 'gender', $assureCard['individualCharacteristics']['gender'] ?? '');
                update_user_meta($customer_id, 'height', $assureCard['individualCharacteristics']['height'] ?? '');
                update_user_meta($customer_id, 'eye_color', $assureCard['individualCharacteristics']['eyeColor'] ?? '');
            }
            
            // Store confidence scores
            update_user_meta($customer_id, 'total_confidence', $assureCard['totalConfidence'] ?? 0);
            update_user_meta($customer_id, 'face_verification_confidence', $assureCard['faceVerificationConfidence'] ?? 0);
            update_user_meta($customer_id, 'selfie_is_real_confidence', $assureCard['selfieIsRealConfidence'] ?? 0);
        }
        
        // Store transaction metadata
        if (isset($webhook_data['meta'])) {
            update_user_meta($customer_id, 'transaction_id', $webhook_data['meta']['transactionId'] ?? '');
            update_user_meta($customer_id, 'transaction_date', $webhook_data['meta']['transactionDate'] ?? '');
            update_user_meta($customer_id, 'product_name', $webhook_data['meta']['productName'] ?? '');
        }
        
        // Store primary verification result
        if (isset($webhook_data['data']['assureId']['primaryResult'])) {
            update_user_meta($customer_id, 'primary_result_code', $webhook_data['data']['assureId']['primaryResult']['code'] ?? '');
        }
        
        $total_confidence = $webhook_data['data']['assureCard']['totalConfidence'] ?? null;
        $face_confidence  = $webhook_data['data']['assureCard']['faceVerificationConfidence'] ?? null;
        $validation_reason = $webhook_data['data']['assureCard']['validationResult']['description'] ?? '';

        // Determine overall verification status based on results
        $overall_status = self::determine_verification_status($webhook_data);

        // If would be verified, check for duplicate license number when setting is enabled
        $block_duplicate_license = get_option('x8_evs_block_duplicate_license', false);
        $block_duplicate_license = ($block_duplicate_license === true || $block_duplicate_license === '1' || $block_duplicate_license === 1);
        if ($block_duplicate_license && $overall_status === 'verified' && isset($webhook_data['data']['assureCard']['documentInformation']['licenseNumber'])) {
            $license_number = trim((string) ($webhook_data['data']['assureCard']['documentInformation']['licenseNumber'] ?? ''));
            if ($license_number !== '' && self::find_existing_user_by_license_number($license_number, $customer_id) !== null) {
                $overall_status = 'block';
                update_user_meta($customer_id, '_duplicate_license_block', '1');
                update_user_meta($customer_id, '_verification_block_reason', 'duplicate_license');
            }
        }

        $previous_status = get_user_meta($customer_id, 'account_status', true);

        update_user_meta($customer_id, 'account_status', $overall_status);
        if ($overall_status === 'pending') {
            update_user_meta($customer_id, 'x8_evs_pending_since', current_time('mysql'));
        }
        update_user_meta($customer_id, 'verification_date', current_time('mysql'));
        
        if (class_exists('X8_EVS_Debug_Logger')) {
            X8_EVS_Debug_Logger::log('status_decision', 'Verification result processed: status "' . ($previous_status ?: 'none') . '" -> "' . $overall_status . '"', array(
                'total_confidence' => $total_confidence,
                'face_confidence' => $face_confidence,
                'validation_reason' => $validation_reason,
                'thresholds' => array(
                    'total' => array(
                        'auto_block' => self::get_auto_block_threshold(false),
                        'manual_review' => self::get_manual_review_threshold(false),
                        'auto_approve' => self::get_auto_approve_threshold(false)
                    ),
                    'selfie' => array(
                        'auto_block' => self::get_auto_block_threshold(true),
                        'manual_review' => self::get_manual_review_threshold(true),
                        'auto_approve' => self::get_auto_approve_threshold(true)
                    )
                ),
                'transaction_id' => $webhook_data['meta']['transactionId'] ?? ''
            ), $customer_id);
        }
        
        // Track this as a successful verification if status is verified
        if ($overall_status === 'verified') {
            self::track_verification_attempt($customer_id, 'success');
            do_action('x8_evs_user_verified', $customer_id);
        }
        
        if ($overall_status === 'manual_review' && $previous_status !== 'manual_review') {
            self::notify_manual_review_staff($customer_id, 'auto', array(
                'confidence' => is_numeric($total_confidence) ? $total_confidence : '',
                'face_confidence' => is_numeric($face_confidence) ? $face_confidence : '',
                'reason' => $validation_reason
            ));
        }

        
        // Log comprehensive activity for verification result
        self::log_customer_activity($customer_id, 'verification_completed', array(
            'status' => $overall_status,
            'document_type' => $webhook_data['data']['assureCard']['documentInformation']['documentType'] ?? '',
            'confidence_score' => $webhook_data['data']['assureCard']['totalConfidence'] ?? 0,
            'transaction_id' => $webhook_data['meta']['transactionId'] ?? '',
            'webhook_data' => $webhook_data
        ));
        
        return true;
    }
    
    /**
     * Store verification error data from webhook
     */
    public static function store_verification_error($customer_id, $webhook_data) {
        if (!class_exists('X8_EVS_AssureLocate_Handler')) {
            require_once X8_EVS_PLUGIN_PATH . 'inc/frontend/class-assurelocate-handler.php';
        }
        if (X8_EVS_AssureLocate_Handler::is_locate_webhook($webhook_data)) {
            if (class_exists('X8_EVS_Debug_Logger')) {
                X8_EVS_Debug_Logger::log('webhook_ignored', 'Refusing to store AssureLocate error as an identity verification error', array(
                    'product_name' => $webhook_data['meta']['productName'] ?? '',
                    'transaction_id' => $webhook_data['meta']['transactionId'] ?? ''
                ), $customer_id);
            }
            return true;
        }

        // Store the complete webhook data
        update_user_meta($customer_id, 'verification_webhook_data', json_encode($webhook_data));
        
        // Store error information
        if (isset($webhook_data['errors']) && is_array($webhook_data['errors'])) {
            update_user_meta($customer_id, 'verification_errors', json_encode($webhook_data['errors']));
            
            // Store the first error code and detail for easy access
            $first_error = $webhook_data['errors'][0] ?? null;
            if ($first_error) {
                update_user_meta($customer_id, 'verification_error_code', $first_error['code'] ?? '');
                update_user_meta($customer_id, 'verification_error_detail', $first_error['detail'] ?? '');
            }
        }
        
        // Store transaction metadata
        if (isset($webhook_data['meta'])) {
            update_user_meta($customer_id, 'transaction_id', $webhook_data['meta']['transactionId'] ?? '');
            update_user_meta($customer_id, 'transaction_date', $webhook_data['meta']['transactionDate'] ?? '');
            update_user_meta($customer_id, 'product_name', $webhook_data['meta']['productName'] ?? '');
        }
        
        // Set status to error
        update_user_meta($customer_id, 'account_status', 'error');
        update_user_meta($customer_id, 'verification_date', current_time('mysql'));
        

        
        // Track this as a failed verification attempt for rate limiting
        self::track_verification_attempt($customer_id, 'failed');
        
        // Log comprehensive activity for failed verification
        self::log_customer_activity($customer_id, 'verification_failed', array(
            'errors' => $webhook_data['errors'] ?? array(),
            'error_code' => $first_error['code'] ?? '',
            'error_detail' => $first_error['detail'] ?? '',
            'transaction_id' => $webhook_data['meta']['transactionId'] ?? '',
            'webhook_data' => $webhook_data
        ));
        
        return true;
    }
    
    /**
     * Track verification attempts for rate limiting
     */
    public static function track_verification_attempt($user_id, $type = 'attempt') {
        $current_time = current_time('mysql');
        $attempts_key = 'verification_attempts';
        
        // Get existing attempts
        $attempts = get_user_meta($user_id, $attempts_key, true);
        if (!is_array($attempts)) {
            $attempts = array();
        }
        
        // Add new attempt
        $attempts[] = array(
            'type' => $type, // 'attempt', 'failed', 'success'
            'timestamp' => $current_time,
            'unix_timestamp' => time()
        );
        
        // Clean up old attempts (older than 24 hours)
        $twenty_four_hours_ago = time() - (24 * 60 * 60);
        $attempts = array_filter($attempts, function($attempt) use ($twenty_four_hours_ago) {
            return isset($attempt['unix_timestamp']) && $attempt['unix_timestamp'] > $twenty_four_hours_ago;
        });
        
        // Update user meta
        update_user_meta($user_id, $attempts_key, $attempts);
        
        return true;
    }
    
    /**
     * Check if user can generate a new verification link (rate limiting)
     */
    public static function can_generate_verification_link($user_id) {
        // Get verification attempts for ALL users (rate limiting applies to everyone)
        $attempts = get_user_meta($user_id, 'verification_attempts', true);
        if (!is_array($attempts)) {
            $attempts = array();
        }
        
        // Filter attempts from the last 24 hours
        $twenty_four_hours_ago = time() - (24 * 60 * 60);
        $recent_attempts = array_filter($attempts, function($attempt) use ($twenty_four_hours_ago) {
            return isset($attempt['unix_timestamp']) && $attempt['unix_timestamp'] > $twenty_four_hours_ago;
        });
        
        // Count link generation attempts (when user clicks generate/regenerate)
        $link_generation_attempts = array_filter($recent_attempts, function($attempt) {
            return in_array($attempt['type'], array('attempt', 'failed'));
        });
        
        $attempt_count = count($link_generation_attempts);
        $max_attempts = 3; // Maximum 3 attempts in 24 hours
        
        if ($attempt_count >= $max_attempts) {
            // Find the oldest attempt to calculate when the limit resets
            $oldest_attempt_time = min(array_column($link_generation_attempts, 'unix_timestamp'));
            $time_until_reset = ($oldest_attempt_time + (24 * 60 * 60)) - time();
            
            return array(
                'can_generate' => false,
                'reason' => sprintf(
                    __('You have reached the maximum number of verification attempts (%d) in 24 hours. Please try again in %s.', 'x8-evs'),
                    $max_attempts,
                    self::format_time_remaining($time_until_reset)
                ),
                'attempts_left' => 0,
                'time_until_reset' => $time_until_reset
            );
        }
        
        return array(
            'can_generate' => true,
            'reason' => '',
            'attempts_left' => $max_attempts - $attempt_count,
            'time_until_reset' => 0
        );
    }
    
    /**
     * Format time remaining in human readable format
     */
    private static function format_time_remaining($seconds) {
        if ($seconds <= 0) {
            return __('now', 'x8-evs');
        }
        
        $hours = floor($seconds / 3600);
        $minutes = floor(($seconds % 3600) / 60);
        
        if ($hours > 0) {
            return sprintf(_n('%d hour', '%d hours', $hours, 'x8-evs'), $hours) . 
                   ($minutes > 0 ? ' ' . sprintf(_n('%d minute', '%d minutes', $minutes, 'x8-evs'), $minutes) : '');
        } else {
            return sprintf(_n('%d minute', '%d minutes', $minutes, 'x8-evs'), max(1, $minutes));
        }
    }
    
    /**
     * Get error message by error code
     */
    public static function get_error_message($error_code) {
        $error_messages = array(
            '1000' => __('An unknown internal error occurred', 'x8-evs'),
            '1001' => __('Creation of transaction failed', 'x8-evs'),
            '1002' => __('Data provider returned an error', 'x8-evs'),
            '1003' => __('Request parse error', 'x8-evs'),
            '2000' => __('Account is locked', 'x8-evs'),
            '2001' => __('Account is disabled', 'x8-evs'),
            '2002' => __('Account not found', 'x8-evs'),
            '2003' => __('User is locked', 'x8-evs'),
            '2004' => __('User is disabled', 'x8-evs'),
            '2005' => __('User not found', 'x8-evs'),
            '2006' => __('Not enough permissions to perform the action', 'x8-evs'),
            '2007' => __('Account does not have access to the product being requested', 'x8-evs'),
            '2008' => __('User is not allowed to run web service requests', 'x8-evs'),
            '2009' => __('Account has reached its transaction limit', 'x8-evs'),
            '2010' => __('IP address is not in acceptable range', 'x8-evs'),
            '3000' => __('An input field failed validation', 'x8-evs'),
            '4000' => __('An active FinCEN list could not be found', 'x8-evs')
        );
        
        return $error_messages[$error_code] ?? __('Unknown error', 'x8-evs');
    }
    
    /**
     * Determine verification status based on webhook data
     */
    /**
     * Determine verification status based on webhook data
     *
     * Debug for: int(80) int(75) int(90) int(91) int(80) int(50) int(85) int(86) bool(false)
     * Why is this false?
     *
     * int(80)  = $face_verification_confidence
     * int(75)  = $face_auto_block_threshold
     * int(90)  = $face_manual_review_threshold
     * int(91)  = $face_auto_approve_threshold
     * int(80)  = $total_confidence
     * int(50)  = $total_auto_block_threshold
     * int(85)  = $total_manual_review_threshold
     * int(86)  = $total_auto_approve_threshold
     * bool(false) = ($face_verification_confidence >= $face_manual_review_threshold && $face_verification_confidence < $face_auto_approve_threshold) || ($total_confidence >= $total_manual_review_threshold && $total_confidence < $total_auto_approve_threshold)
     *
     * Let's break it down:
     * $face_verification_confidence = 80
     * $face_manual_review_threshold = 90
     * $face_auto_approve_threshold = 91
     * $total_confidence = 80
     * $total_manual_review_threshold = 85
     * $total_auto_approve_threshold = 86
     *
     * So:
     * ($face_verification_confidence >= $face_manual_review_threshold && $face_verification_confidence < $face_auto_approve_threshold)
     * => (80 >= 90 && 80 < 91) => (false && true) => false
     *
     * ($total_confidence >= $total_manual_review_threshold && $total_confidence < $total_auto_approve_threshold)
     * => (80 >= 85 && 80 < 86) => (false && true) => false
     *
     * So the OR is (false || false) => false
     *
     * That's why the result is false.
     */
    private static function determine_verification_status($webhook_data) {
        // Get both confidence scores
        $face_verification_confidence = $webhook_data['data']['assureCard']['faceVerificationConfidence'] ?? 0;
        $total_confidence = $webhook_data['data']['assureCard']['totalConfidence'] ?? 0;

        $validation_code = $webhook_data['data']['assureCard']['validationResult']['code'] ?? '';

        // Check age requirement
        $calculated_age = $webhook_data['data']['assureCard']['individualCharacteristics']['calculatedAge'] ?? null;
        $age_check_failed = false;
        if ($calculated_age && !self::meets_age_requirement($calculated_age)) {
            $age_check_failed = true;
        }

        // Get thresholds for both verification types
        $face_auto_block_threshold = self::get_auto_block_threshold(true); // selfie thresholds
        $face_manual_review_threshold = self::get_manual_review_threshold(true);
        $face_auto_approve_threshold = self::get_auto_approve_threshold(true);

        $total_auto_block_threshold = intval(self::get_auto_block_threshold(false)); // regular thresholds
        $total_manual_review_threshold = self::get_manual_review_threshold(false);
        $total_auto_approve_threshold = self::get_auto_approve_threshold(false);

        $selfie_required = self::is_selfie_required();
        if(!$selfie_required) {
            $face_verification_confidence = 100;
        }

        // Check if we have assureCard validation result (for AssureCard product)
        $assure_card_valid = false;
        if (isset($webhook_data['data']['assureCard']['validationResult']['code'])) {
            $assure_card_valid = ($webhook_data['data']['assureCard']['validationResult']['code'] === '0');
        }

        // Initialize final status
        $final_status = 'pending';
        // Check for immediate blocking conditions first
        if ($face_verification_confidence <= $face_auto_block_threshold || 
            $total_confidence <= $total_auto_block_threshold || 
            $age_check_failed) {
            $final_status = 'block';
        }
        // Check if both verifications meet auto-approve thresholds
        elseif (
            $face_verification_confidence >= $face_auto_approve_threshold &&
            $total_confidence >= $total_auto_approve_threshold &&
            $assure_card_valid &&
            !$age_check_failed
        ) {
            $final_status = 'verified';
        }
        // Check if either verification is in manual review range
        elseif (
            ($face_verification_confidence > $face_auto_block_threshold && $face_verification_confidence <= $face_manual_review_threshold) ||
            ($total_confidence > $total_auto_block_threshold && $total_confidence <= $total_manual_review_threshold)
        ) {
            $final_status = 'manual_review';
        }
        // Check if one verification meets auto-approve but the other doesn't (mixed case)
        elseif (
            (($face_verification_confidence >= $face_auto_approve_threshold && $total_confidence < $total_auto_approve_threshold) ||
             ($total_confidence >= $total_auto_approve_threshold && $face_verification_confidence < $face_auto_approve_threshold)) &&
            $assure_card_valid &&
            !$age_check_failed
        ) {
            $final_status = 'manual_review';
        }

        // Log decision process for debugging (only if WP_DEBUG is enabled)
            $log_data = array(
                'face_verification_confidence' => $face_verification_confidence,
                'total_confidence' => $total_confidence,
                'face_thresholds' => array(
                    'auto_block' => $face_auto_block_threshold,
                    'manual_review' => $face_manual_review_threshold,
                    'auto_approve' => $face_auto_approve_threshold
                ),
                'total_thresholds' => array(
                    'auto_block' => $total_auto_block_threshold,
                    'manual_review' => $total_manual_review_threshold,
                    'auto_approve' => $total_auto_approve_threshold
                ),
                'validation_code' => $validation_code,
                'assure_card_valid' => $assure_card_valid,
                'age_check_failed' => $age_check_failed,
                'manual_review_condition' =>
                    ($face_verification_confidence >= $face_manual_review_threshold && $face_verification_confidence < $face_auto_approve_threshold) ||
                    ($total_confidence >= $total_manual_review_threshold && $total_confidence < $total_auto_approve_threshold),
                'final_status' => $final_status
            );
            error_log('X8 EVS Verification Decision: ' . json_encode($log_data));
      

        return $final_status;
    }
    

    /**
     * Get verification page
     */
    public static function get_verification_page() {
        return get_option('x8_evs_verification_page', 0);
    }
    
    /**
     * Get verification page URL
     */
    public static function get_verification_page_url() {
        $page_id = self::get_verification_page();
        if ($page_id) {
            return get_permalink($page_id);
        }
        return null;
    }
    
    /**
     * Get verification page title
     */
    public static function get_verification_page_title() {
        $page_id = self::get_verification_page();
        if ($page_id) {
            return get_the_title($page_id);
        }
        return __('Default Verification Form', 'x8-evs');
    }

    /**
     * Get verification trigger setting
     */
    public static function get_verification_trigger() {
        return get_option('x8_evs_verification_trigger', 'disabled');
    }
    
    /**
     * Check if verification should trigger at a specific point
     */
    public static function should_verify_at($trigger_point) {
        $setting = self::get_verification_trigger();
        return $setting === $trigger_point;
    }
    
    /**
     * Check if selfie is required for verification
     */
    public static function is_selfie_required() {
        return get_option('x8_evs_require_selfie', 1);
    }
    
    /**
     * Get blocked states
     */
    public static function get_blocked_states() {
        return get_option('x8_evs_blocked_states', array());
    }
    
    /**
     * Check if a state is blocked
     */
    public static function is_state_blocked($state_code) {
        $blocked_states = self::get_blocked_states();
        return in_array(strtoupper($state_code), $blocked_states);
    }
    
    /**
     * Get allowed countries
     */
    public static function get_allowed_countries() {
        return get_option('x8_evs_allowed_countries', array());
    }
    
    /**
     * Check if a country is allowed
     */
    public static function is_country_allowed($country_code) {
        $allowed_countries = self::get_allowed_countries();
        
        // If no countries are selected, allow all countries
        if (empty($allowed_countries)) {
            return true;
        }
        
        return in_array(strtoupper($country_code), $allowed_countries);
    }
    
    /**
     * Check if country filtering is enabled
     */
    public static function is_country_filtering_enabled() {
        $allowed_countries = self::get_allowed_countries();
        return !empty($allowed_countries);
    }
    
    /**
     * Check if blocking by geolocation is enabled
     */
    public static function is_block_by_geolocation_enabled() {
        return get_option('x8_evs_block_by_geolocation', false);
    }
    
    /**
     * Check if blocking by ID address is enabled
     */
    public static function is_block_by_id_address_enabled() {
        return get_option('x8_evs_block_by_id_address', false);
    }
    
    /**
     * Check if blocking by billing address is enabled
     */
    public static function is_block_by_billing_address_enabled() {
        return get_option('x8_evs_block_by_billing_address', false);
    }
    
    /**
     * Check if any blocking options are enabled
     */
    public static function has_blocking_options_enabled() {
        return self::is_block_by_geolocation_enabled() || 
               self::is_block_by_id_address_enabled() || 
               self::is_block_by_billing_address_enabled() ||
               self::is_vpn_blocking_enabled() ||
               self::is_country_filtering_enabled();
    }
    
    /**
     * Check if VPN blocking is enabled
     */
    public static function is_vpn_blocking_enabled() {
        return get_option('x8_evs_block_vpns', false);
    }
    
    /**
     * Sanitize blocked states array
     */
    public function sanitize_blocked_states($input) {
        if (!is_array($input)) {
            return array();
        }
        
        // Valid US state codes
        $valid_states = array(
            'AL', 'AK', 'AZ', 'AR', 'CA', 'CO', 'CT', 'DE', 'FL', 'GA',
            'HI', 'ID', 'IL', 'IN', 'IA', 'KS', 'KY', 'LA', 'ME', 'MD',
            'MA', 'MI', 'MN', 'MS', 'MO', 'MT', 'NE', 'NV', 'NH', 'NJ',
            'NM', 'NY', 'NC', 'ND', 'OH', 'OK', 'OR', 'PA', 'RI', 'SC',
            'SD', 'TN', 'TX', 'UT', 'VT', 'VA', 'WA', 'WV', 'WI', 'WY', 'DC'
        );
        
        // Filter and sanitize
        $sanitized = array();
        foreach ($input as $state) {
            $state = strtoupper(sanitize_text_field($state));
            if (in_array($state, $valid_states)) {
                $sanitized[] = $state;
            }
        }
        
        return array_unique($sanitized);
    }
    
    /**
     * Sanitize allowed countries array
     */
    public function sanitize_allowed_countries($input) {
        if (!is_array($input)) {
            return array();
        }
        
        // Valid country codes (ISO 3166-1 alpha-2)
        $valid_countries = array(
            'US', 'CA', 'GB', 'AU', 'DE', 'FR', 'IT', 'ES', 'NL', 'BE',
            'CH', 'AT', 'SE', 'NO', 'DK', 'FI', 'IE', 'PT', 'LU', 'IS',
            'MT', 'CY', 'GR', 'PL', 'CZ', 'HU', 'SK', 'SI', 'HR', 'BG',
            'RO', 'LT', 'LV', 'EE', 'JP', 'KR', 'SG', 'HK', 'TW', 'NZ',
            'BR', 'AR', 'CL', 'CO', 'MX', 'PE', 'VE', 'UY', 'PY', 'BO',
            'EC', 'GY', 'SR', 'GF', 'FK', 'ZA', 'EG', 'NG', 'KE', 'GH',
            'MA', 'TN', 'DZ', 'LY', 'SD', 'ET', 'UG', 'TZ', 'ZW', 'BW',
            'NA', 'SZ', 'LS', 'MW', 'ZM', 'AO', 'MZ', 'MG', 'MU', 'SC',
            'CN', 'IN', 'ID', 'TH', 'VN', 'PH', 'MY', 'BN', 'KH', 'LA',
            'MM', 'BD', 'LK', 'MV', 'NP', 'BT', 'PK', 'AF', 'IR', 'IQ',
            'SA', 'AE', 'QA', 'KW', 'BH', 'OM', 'YE', 'JO', 'LB', 'SY',
            'IL', 'PS', 'TR', 'RU', 'UA', 'BY', 'MD', 'GE', 'AM', 'AZ',
            'KZ', 'UZ', 'TM', 'TJ', 'KG', 'MN', 'KP', 'FJ', 'PG', 'SB',
            'VU', 'NC', 'PF', 'WS', 'TO', 'KI', 'TV', 'NR', 'PW', 'FM',
            'MH', 'AS', 'GU', 'MP', 'VI', 'PR', 'DO', 'HT', 'JM', 'CU',
            'BS', 'BB', 'TT', 'GD', 'LC', 'VC', 'AG', 'KN', 'DM', 'BZ',
            'GT', 'HN', 'SV', 'NI', 'CR', 'PA'
        );
        
        // Filter and sanitize
        $sanitized = array();
        foreach ($input as $country) {
            $country = strtoupper(sanitize_text_field($country));
            if (in_array($country, $valid_countries)) {
                $sanitized[] = $country;
            }
        }
        
        return array_unique($sanitized);
    }

    /**
     * Sanitize allowed document types (multi-select)
     */
    public function sanitize_document_types($input) {
        $valid = array_keys(self::get_document_types_map());
        if (!is_array($input)) {
            return array();
        }
        $sanitized = array();
        foreach ($input as $value) {
            $value = sanitize_text_field($value);
            if (in_array($value, $valid, true)) {
                $sanitized[] = $value;
            }
        }
        return array_unique($sanitized);
    }

    /**
     * Sanitize default document type: must be one of the allowed types.
     */
    public function sanitize_document_type_default($input) {
        $input = sanitize_text_field($input);
        $valid = array_keys(self::get_document_types_map());
        if (!in_array($input, $valid, true)) {
            return get_option('x8_evs_document_type', 'DriversLicense');
        }
        // When multiple types allowed, default must be in the allowed list (from POST or saved)
        $allowed = isset($_POST['x8_evs_document_types']) && is_array($_POST['x8_evs_document_types'])
            ? array_map('sanitize_text_field', $_POST['x8_evs_document_types'])
            : get_option('x8_evs_document_types', array());
        if (empty($allowed)) {
            $allowed = array(get_option('x8_evs_document_type', 'DriversLicense'));
        }
        return in_array($input, $allowed, true) ? $input : (reset($allowed) ?: 'DriversLicense');
    }

    /**
     * Get document type setting
     */
    public static function get_document_type() {
        $allowed = self::get_allowed_document_types();
        return !empty($allowed) ? $allowed[0] : get_option('x8_evs_document_type', 'DriversLicense');
    }

    /**
     * Get map of document type value => label (for admin and frontend)
     */
    public static function get_document_types_map() {
        return array(
            'DriversLicense' => __('Drivers License / State ID', 'x8-evs'),
            'PassportBook' => __('Passport Book', 'x8-evs'),
            'PassportCard' => __('Passport Card', 'x8-evs'),
            'CommonAccessCard' => __('Common Access Card', 'x8-evs'),
            'UniformedServicesId' => __('Uniformed Services ID', 'x8-evs'),
            'GreenCard' => __('Green Card', 'x8-evs'),
            'InternationalId' => __('International ID', 'x8-evs'),
        );
    }

    /**
     * Get allowed document types for customer to choose from.
     * If multi-select (x8_evs_document_types) is set, use that; else fallback to single x8_evs_document_type.
     */
    public static function get_allowed_document_types() {
        $multi = get_option('x8_evs_document_types', array());
        if (!empty($multi) && is_array($multi)) {
            return $multi;
        }
        $single = get_option('x8_evs_document_type', 'DriversLicense');
        return array($single);
    }

    /**
     * Check if customer can choose document type (multiple allowed).
     */
    public static function customer_chooses_document_type() {
        $multi = get_option('x8_evs_document_types', array());
        return is_array($multi) && count($multi) > 1;
    }

    /**
     * Get default document type (pre-selected on verification form). Always returns one of the allowed types.
     */
    public static function get_default_document_type() {
        $allowed = self::get_allowed_document_types();
        $default = get_option('x8_evs_document_type', 'DriversLicense');
        return in_array($default, $allowed, true) ? $default : (reset($allowed) ?: 'DriversLicense');
    }

    /**
     * Sanitize manual review notification emails
     */
    public function sanitize_manual_review_emails($input) {
        if (is_array($input)) {
            $input = implode(',', $input);
        }

        if (empty($input)) {
            return '';
        }

        $emails = array_filter(array_map('trim', explode(',', $input)));
        $valid_emails = array();

        foreach ($emails as $email) {
            $sanitized_email = sanitize_email($email);
            if (!empty($sanitized_email) && is_email($sanitized_email)) {
                $valid_emails[] = $sanitized_email;
            }
        }

        return implode(', ', array_unique($valid_emails));
    }

    /**
     * Sanitize auto request re-verification checkbox
     */
    public function sanitize_auto_request_reverification($input) {
        // Checkbox returns '1' when checked, nothing when unchecked
        // WordPress passes NULL when unchecked, so we need to handle that
        if ($input === null || $input === '' || $input === false) {
            return false;
        }
        if ($input === '1' || $input === 1 || $input === true) {
            return true;
        }
        return false;
    }

    /**
     * Sanitize block duplicate license checkbox
     */
    public function sanitize_block_duplicate_license($input) {
        if ($input === null || $input === '' || $input === false) {
            return false;
        }
        if ($input === '1' || $input === 1 || $input === true) {
            return true;
        }
        return false;
    }

    /**
     * Sanitize allow Google bots checkbox
     */
    public function sanitize_allow_google_bots($input) {
        if ($input === null || $input === '' || $input === false) {
            return false;
        }
        if ($input === '1' || $input === 1 || $input === true) {
            return true;
        }
        return false;
    }

    /**
     * Sanitize pending auto-delete days (0 = disabled, 1–60).
     *
     * @param mixed $input
     * @return int
     */
    public function sanitize_pending_auto_delete_days($input) {
        $val = absint($input);
        if ($val < 1 || $val > 60) {
            return 0;
        }
        return $val;
    }

    /**
     * Cron callback: delete users who have been pending longer than the configured days.
     * Only deletes users with account_status = 'pending'; uses x8_evs_pending_since or user_registered for age.
     */
    public static function run_pending_users_cleanup() {
        $days = (int) get_option('x8_evs_pending_auto_delete_days', 0);
        if ($days < 1) {
            return;
        }
        $cutoff = gmdate('Y-m-d H:i:s', strtotime("-{$days} days"));
        $user_query = new \WP_User_Query(array(
            'meta_query' => array(
                array('key' => 'account_status', 'value' => 'pending', 'compare' => '=')
            ),
            'number' => 500,
            'fields' => 'ID'
        ));
        $user_ids = $user_query->get_results();
        if (empty($user_ids)) {
            return;
        }
        $deleted = 0;
        foreach ($user_ids as $user_id) {
            $user_id = (int) $user_id;
            $user = get_userdata($user_id);
            if (!$user) {
                continue;
            }
            $pending_since = get_user_meta($user_id, 'x8_evs_pending_since', true);
            $compare_date = $pending_since ? $pending_since : $user->user_registered;
            if ($compare_date > $cutoff) {
                continue;
            }
            if (user_can($user_id, 'manage_options')) {
                continue;
            }
            require_once ABSPATH . 'wp-admin/includes/user.php';
            if (wp_delete_user($user_id)) {
                $deleted++;
            }
        }
        if ($deleted > 0 && defined('WP_DEBUG') && WP_DEBUG) {
            error_log(sprintf('X8 Verify: Pending cleanup deleted %d user(s) older than %d days.', $deleted, $days));
        }
    }

    /**
     * Sanitize the location detection provider selection
     */
    public function sanitize_location_provider($input) {
        $allowed = array('ipapi_co', 'ipgeolocation', 'evs_assurelocate');
        return in_array($input, $allowed, true) ? $input : 'ipapi_co';
    }

    /**
     * Sanitize the AssureLocate location trigger selection
     */
    public function sanitize_assurelocate_trigger($input) {
        $allowed = array('after_login', 'global');
        return in_array($input, $allowed, true) ? $input : 'after_login';
    }

    /**
     * Sanitize whitelist IP addresses textarea
     */
    public function sanitize_whitelist_ip_addresses($input) {
        if (empty($input)) {
            return '';
        }
        
        // Split by newlines and process each line
        $lines = explode("\n", $input);
        $valid_ips = array();
        
        foreach ($lines as $line) {
            $line = trim($line);
            if (empty($line)) {
                continue;
            }
            
            // Check if it's a valid IP or CIDR range
            if (self::is_valid_ip_or_range($line)) {
                $valid_ips[] = $line;
            }
        }
        
        return implode("\n", $valid_ips);
    }

    /**
     * Check if a string is a valid IP address or CIDR range
     */
    private static function is_valid_ip_or_range($ip_string) {
        // Check for CIDR notation (e.g., 192.168.1.0/24)
        if (strpos($ip_string, '/') !== false) {
            list($ip, $prefix) = explode('/', $ip_string, 2);
            if (filter_var($ip, FILTER_VALIDATE_IP) !== false && 
                is_numeric($prefix) && 
                $prefix >= 0 && 
                $prefix <= 128) {
                return true;
            }
        } else {
            // Check if it's a valid IP address
            if (filter_var($ip_string, FILTER_VALIDATE_IP) !== false) {
                return true;
            }
        }
        
        return false;
    }

    /**
     * Check if Google bots are allowed
     */
    public static function is_google_bots_allowed() {
        return get_option('x8_evs_allow_google_bots', false) === true;
    }

    /**
     * Check if an IP address is whitelisted
     */
    public static function is_ip_whitelisted($ip_address) {
        if (empty($ip_address)) {
            return false;
        }
        
        $whitelist = get_option('x8_evs_whitelist_ip_addresses', '');
        if (empty($whitelist)) {
            return false;
        }
        
        $whitelist_lines = explode("\n", $whitelist);
        
        foreach ($whitelist_lines as $line) {
            $line = trim($line);
            if (empty($line)) {
                continue;
            }
            
            // Check if it's a CIDR range
            if (strpos($line, '/') !== false) {
                if (self::ip_in_cidr($ip_address, $line)) {
                    return true;
                }
            } else {
                // Direct IP match
                if ($ip_address === $line) {
                    return true;
                }
            }
        }
        
        return false;
    }

    /**
     * Check if an IP address is within a CIDR range
     * Supports both IPv4 and IPv6
     */
    private static function ip_in_cidr($ip, $cidr) {
        list($subnet, $mask) = explode('/', $cidr);
        
        // Check if it's IPv6
        if (filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_IPV6) !== false) {
            // IPv6 CIDR check
            $ip_bin = inet_pton($ip);
            $subnet_bin = inet_pton($subnet);
            
            if ($ip_bin === false || $subnet_bin === false) {
                return false;
            }
            
            $mask_int = intval($mask);
            $bytes = intval($mask_int / 8);
            $bits = $mask_int % 8;
            
            // Compare bytes
            for ($i = 0; $i < $bytes; $i++) {
                if ($ip_bin[$i] !== $subnet_bin[$i]) {
                    return false;
                }
            }
            
            // Compare remaining bits
            if ($bits > 0) {
                $mask_byte = 0xFF << (8 - $bits);
                if ((ord($ip_bin[$bytes]) & $mask_byte) !== (ord($subnet_bin[$bytes]) & $mask_byte)) {
                    return false;
                }
            }
            
            return true;
        } else {
            // IPv4 CIDR check
            $ip_long = ip2long($ip);
            $subnet_long = ip2long($subnet);
            
            if ($ip_long === false || $subnet_long === false) {
                return false;
            }
            
            $mask_int = intval($mask);
            if ($mask_int < 0 || $mask_int > 32) {
                return false;
            }
            
            // Calculate the mask
            $mask_long = -1 << (32 - $mask_int);
            
            // Check if IP is in the subnet
            return ($ip_long & $mask_long) === ($subnet_long & $mask_long);
        }
    }

    /**
     * Check if the current request is from a Google bot
     */
    public static function is_google_bot() {
        $user_agent = $_SERVER['HTTP_USER_AGENT'] ?? '';
        
        if (empty($user_agent)) {
            return false;
        }
        
        // Google bot user agents
        $google_bot_patterns = array(
            'Googlebot',
            'Google-InspectionTool',
            'Google-Site-Verification',
            'Google Search Console',
            'Feedfetcher-Google',
            'Mediapartners-Google',
            'AdsBot-Google',
            'APIs-Google',
            'GoogleProducer'
        );
        
        foreach ($google_bot_patterns as $pattern) {
            if (stripos($user_agent, $pattern) !== false) {
                // Additional verification: Check if the IP is from Google's known ranges
                // This is a basic check - you might want to verify against Google's published IP ranges
                return true;
            }
        }
        
        return false;
    }
    
    /**
     * Get minimum age requirement
     */
    public static function get_minimum_age() {
        $age_setting = get_option('x8_evs_minimum_age', '21');
        
        if ($age_setting === 'none') {
            return null;
        } elseif ($age_setting === 'other') {
            return get_option('x8_evs_custom_age', 25);
        } else {
            return intval($age_setting);
        }
    }
    
    /**
     * Check if customer meets minimum age requirement
     */
    public static function meets_age_requirement($customer_age) {
        $minimum_age = self::get_minimum_age();
        
        // No age requirement
        if ($minimum_age === null) {
            return true;
        }
        
        // Check if customer meets minimum age
        return $customer_age >= $minimum_age;
    }
    
    /**
     * Get age requirement display text
     */
    public static function get_age_requirement_text() {
        $age_setting = get_option('x8_evs_minimum_age', '21');
        
        switch ($age_setting) {
            case 'none':
                return __('No age requirement', 'x8-evs');
            case '18':
                return __('18+ years old', 'x8-evs');
            case '21':
                return __('21+ years old', 'x8-evs');
            case 'other':
                $custom_age = get_option('x8_evs_custom_age', 25);
                return sprintf(__('%d+ years old', 'x8-evs'), $custom_age);
            default:
                return __('Unknown', 'x8-evs');
        }
    }

    /**
     * Get automatic block threshold
     */
    public static function get_auto_block_threshold($use_selfie_thresholds = false) {
        if ($use_selfie_thresholds && self::is_selfie_required()) {
            return get_option('x8_evs_selfie_auto_block_threshold', 75);
        }
        return get_option('x8_evs_auto_block_threshold', 70);
    }

    /**
     * Get manual review threshold
     */
    public static function get_manual_review_threshold($use_selfie_thresholds = false) {
        if ($use_selfie_thresholds && self::is_selfie_required()) {
            return get_option('x8_evs_selfie_manual_review_threshold', 90);
        }
        return get_option('x8_evs_manual_review_threshold', 85);
    }

    /**
     * Get automatic approval threshold
     */
    public static function get_auto_approve_threshold($use_selfie_thresholds = false) {
        if ($use_selfie_thresholds && self::is_selfie_required()) {
            return get_option('x8_evs_selfie_auto_approve_threshold', 91);
        }
        return get_option('x8_evs_auto_approve_threshold', 86);
    }

    /**
     * Get selfie-specific automatic block threshold
     */
    public static function get_selfie_auto_block_threshold() {
        return get_option('x8_evs_selfie_auto_block_threshold', 75);
    }

    /**
     * Get selfie-specific manual review threshold
     */
    public static function get_selfie_manual_review_threshold() {
        return get_option('x8_evs_selfie_manual_review_threshold', 90);
    }

    /**
     * Get selfie-specific automatic approval threshold
     */
    public static function get_selfie_auto_approve_threshold() {
        return get_option('x8_evs_selfie_auto_approve_threshold', 91);
    }

    /**
     * Determine verification status based on score
     */
    public static function determine_status_from_score($score, $use_selfie_thresholds = false) {
        $auto_block = self::get_auto_block_threshold($use_selfie_thresholds);
        $manual_review = self::get_manual_review_threshold($use_selfie_thresholds);
        $auto_approve = self::get_auto_approve_threshold($use_selfie_thresholds);
        
        if ($score <= $auto_block) {
            return 'block';
        } elseif ($score >= $auto_approve) {
            return 'verified';
        } else {
            return 'pending';
        }
    }

    /**
     * Get threshold ranges for display
     */
    public static function get_threshold_ranges($use_selfie_thresholds = false) {
        $auto_block = self::get_auto_block_threshold($use_selfie_thresholds);
        $manual_review = self::get_manual_review_threshold($use_selfie_thresholds);
        $auto_approve = self::get_auto_approve_threshold($use_selfie_thresholds);
        
        return array(
            'block' => array(0, $auto_block),
            'manual_review' => array($auto_block + 1, $manual_review),
            'auto_approve' => array($auto_approve, 100)
        );
    }

    /**
     * Get selfie threshold ranges for display
     */
    public static function get_selfie_threshold_ranges() {
        $auto_block = self::get_selfie_auto_block_threshold();
        $manual_review = self::get_selfie_manual_review_threshold();
        $auto_approve = self::get_selfie_auto_approve_threshold();
        
        return array(
            'block' => array(0, $auto_block),
            'manual_review' => array($auto_block + 1, $manual_review),
            'auto_approve' => array($auto_approve, 100)
        );
    }

    /**
     * Validate and sanitize threshold values to ensure logical order
     */
    public static function validate_thresholds($auto_block, $manual_review, $auto_approve) {
        $auto_block = absint($auto_block);
        $manual_review = absint($manual_review);
        $auto_approve = absint($auto_approve);
        
        // Ensure auto_block is less than manual_review
        if ($auto_block >= $manual_review) {
            $auto_block = max(0, $manual_review - 1);
        }
        
        // Ensure manual_review is less than auto_approve
        if ($manual_review >= $auto_approve) {
            $manual_review = max($auto_block + 1, $auto_approve - 1);
        }
        
        // Ensure auto_block is less than auto_approve
        if ($auto_block >= $auto_approve) {
            $auto_block = max(0, $auto_approve - 2);
            $manual_review = max($auto_block + 1, $auto_approve - 1);
        }
        
        return array(
            'auto_block' => $auto_block,
            'manual_review' => $manual_review,
            'auto_approve' => $auto_approve
        );
    }

    /**
     * Sanitize auto block threshold with validation
     */
    public static function sanitize_auto_block_threshold($value) {
        $manual_review = get_option('x8_evs_manual_review_threshold', 85);
        $auto_approve = get_option('x8_evs_auto_approve_threshold', 86);
        
        $validated = self::validate_thresholds($value, $manual_review, $auto_approve);
        return $validated['auto_block'];
    }

    /**
     * Sanitize manual review threshold with validation
     */
    public static function sanitize_manual_review_threshold($value) {
        $auto_block = get_option('x8_evs_auto_block_threshold', 70);
        $auto_approve = get_option('x8_evs_auto_approve_threshold', 86);
        
        $validated = self::validate_thresholds($auto_block, $value, $auto_approve);
        return $validated['manual_review'];
    }

    /**
     * Sanitize auto approve threshold with validation
     */
    public static function sanitize_auto_approve_threshold($value) {
        $auto_block = get_option('x8_evs_auto_block_threshold', 70);
        $manual_review = get_option('x8_evs_manual_review_threshold', 85);
        
        $validated = self::validate_thresholds($auto_block, $manual_review, $value);
        return $validated['auto_approve'];
    }

    /**
     * Sanitize selfie auto block threshold with validation
     */
    public static function sanitize_selfie_auto_block_threshold($value) {
        $manual_review = get_option('x8_evs_selfie_manual_review_threshold', 90);
        $auto_approve = get_option('x8_evs_selfie_auto_approve_threshold', 91);
        
        $validated = self::validate_thresholds($value, $manual_review, $auto_approve);
        return $validated['auto_block'];
    }

    /**
     * Sanitize selfie manual review threshold with validation
     */
    public static function sanitize_selfie_manual_review_threshold($value) {
        $auto_block = get_option('x8_evs_selfie_auto_block_threshold', 75);
        $auto_approve = get_option('x8_evs_selfie_auto_approve_threshold', 91);
        
        $validated = self::validate_thresholds($auto_block, $value, $auto_approve);
        return $validated['manual_review'];
    }

    /**
     * Sanitize selfie auto approve threshold with validation
     */
    public static function sanitize_selfie_auto_approve_threshold($value) {
        $auto_block = get_option('x8_evs_selfie_auto_block_threshold', 75);
        $manual_review = get_option('x8_evs_selfie_manual_review_threshold', 90);
        
        $validated = self::validate_thresholds($auto_block, $manual_review, $value);
        return $validated['auto_approve'];
    }

    /**
     * Handle API-based verification with direct image upload
     */
    private function handle_api_verification($customer_id, $verification_method) {
        // Get API credentials from settings
        $username = get_option('x8_evs_username', '');
        $password = get_option('x8_evs_password', '');
        
        if (empty($username) || empty($password)) {
            wp_send_json_error(__('API credentials not configured. Please contact the administrator.', 'x8-evs'));
        }
        
        // Check for required document images
        $document_front_image = null;
        $document_back_image = null;
        $document_portrait_image = null;
        
        // Save uploaded files and convert to base64 for API
        if (!empty($_FILES['document_front_image']['tmp_name']) && $_FILES['document_front_image']['error'] === UPLOAD_ERR_OK) {
            // Convert to base64 for API first (before moving the file)
            $document_front_image = $this->convert_image_to_base64($_FILES['document_front_image']);
            if ($document_front_image) {
                error_log('X8 EVS Debug - Front image converted to base64 successfully');
            } else {
                error_log('X8 EVS Debug - Front image conversion to base64 failed');
            }
            
            // Save the uploaded file
            $front_image_url = $this->handle_file_upload($_FILES['document_front_image'], $customer_id, 'front');
            if ($front_image_url) {
                update_user_meta($customer_id, 'document_front_image', $front_image_url);
                error_log('X8 EVS Debug - Front image saved successfully');
            }
        }
        
        if (!empty($_FILES['document_back_image']['tmp_name']) && $_FILES['document_back_image']['error'] === UPLOAD_ERR_OK) {
            // Convert to base64 for API first (before moving the file)
            $document_back_image = $this->convert_image_to_base64($_FILES['document_back_image']);
            if ($document_back_image) {
                error_log('X8 EVS Debug - Back image converted to base64 successfully');
            } else {
                error_log('X8 EVS Debug - Back image conversion to base64 failed');
            }
            
            // Save the uploaded file
            $back_image_url = $this->handle_file_upload($_FILES['document_back_image'], $customer_id, 'back');
            if ($back_image_url) {
                update_user_meta($customer_id, 'document_back_image', $back_image_url);
                error_log('X8 EVS Debug - Back image saved successfully');
            }
        }
        
        if (!empty($_FILES['document_portrait_image']['tmp_name']) && $_FILES['document_portrait_image']['error'] === UPLOAD_ERR_OK) {
            // Convert to base64 for API first (before moving the file)
            $document_portrait_image = $this->convert_image_to_base64($_FILES['document_portrait_image']);
            if ($document_portrait_image) {
                error_log('X8 EVS Debug - Portrait image converted to base64 successfully');
            } else {
                error_log('X8 EVS Debug - Portrait image conversion to base64 failed');
            }
            
            // Save the uploaded file
            $portrait_image_url = $this->handle_file_upload($_FILES['document_portrait_image'], $customer_id, 'portrait');
            if ($portrait_image_url) {
                update_user_meta($customer_id, 'document_portrait_image', $portrait_image_url);
                error_log('X8 EVS Debug - Portrait image saved successfully');
            }
        }
        
        // Check for existing stored images if no new ones provided
        if (!$document_front_image) {
            $existing_front_image = get_user_meta($customer_id, 'document_front_image', true);
            if ($existing_front_image) {
                $document_front_image = $this->convert_url_to_base64($existing_front_image);
            }
        }
        
        if (!$document_back_image) {
            $existing_back_image = get_user_meta($customer_id, 'document_back_image', true);
            if ($existing_back_image) {
                $document_back_image = $this->convert_url_to_base64($existing_back_image);
            }
        }
        
        if (!$document_portrait_image) {
            $existing_portrait_image = get_user_meta($customer_id, 'document_portrait_image', true);
            if ($existing_portrait_image) {
                $document_portrait_image = $this->convert_url_to_base64($existing_portrait_image);
            }
        }
        
        // Validate that we have at least front image
        if (!$document_front_image) {
            wp_send_json_error(__('Document front image is required for API verification.', 'x8-evs'));
        }
        
        // Get settings for the request
        $document_type = get_option('x8_evs_document_type', 'DriversLicense');
        
        // Prepare API request data
        $request_data = array(
            'meta' => array(
                'credentials' => array(
                    'username' => $username,
                    'password' => $password
                ),
                'customerReference' => (string)$customer_id
            ),
            'data' => array(
                'scanMode' => 'DirectImageUpload',
                'documentType' => $document_type,
                'frontImage' => $document_front_image
            )
        );
        
        // Add back image if available
        if ($document_back_image) {
            $request_data['data']['backImage'] = $document_back_image;
            error_log('X8 EVS Debug - Back image added to API request');
        }
        
        // Add portrait image if available and required
        if ($document_portrait_image && class_exists('X8_EVS_Admin_Settings') && X8_EVS_Admin_Settings::is_selfie_required()) {
            $request_data['data']['portraitImage'] = $document_portrait_image;
            error_log('X8 EVS Debug - Portrait image added to API request');
        }
        
        error_log('X8 EVS Debug - API request data prepared with scanMode: DirectImageUpload');
        error_log('X8 EVS Debug - Front image length: ' . strlen($document_front_image));
        
        if (class_exists('X8_EVS_Debug_Logger')) {
            X8_EVS_Debug_Logger::log('api_request', 'Admin API verification submitted to EVS AssureCard (DirectImageUpload)', array(
                'document_type' => $document_type,
                'has_front_image' => !empty($document_front_image),
                'has_back_image' => !empty($document_back_image),
                'has_portrait_image' => !empty($document_portrait_image)
            ), $customer_id);
        }
        
        // Make API request
        $response = wp_remote_post('https://blueassure.evssolutions.com/WebServices/Integrated/Main/V300/AssureCard', array(
            'headers' => array(
                'Content-Type' => 'application/json'
            ),
            'body' => json_encode($request_data),
            'timeout' => 60 // Increased timeout for image processing
        ));
        
        if (is_wp_error($response)) {
            if (class_exists('X8_EVS_Debug_Logger')) {
                X8_EVS_Debug_Logger::log('api_error', 'EVS API request failed: ' . $response->get_error_message(), array(), $customer_id);
            }
            wp_send_json_error(__('Connection error. Please try again later.', 'x8-evs'));
        }
        
        $body = wp_remote_retrieve_body($response);

        error_log('X8 EVS Debug - API response: ' . $body);


        $data = json_decode($body, true);
        
        // Check for API errors
        if (!$data) {
            if (class_exists('X8_EVS_Debug_Logger')) {
                X8_EVS_Debug_Logger::log('api_error', 'EVS API returned a non-JSON or empty response', array(
                    'http_code' => wp_remote_retrieve_response_code($response),
                    'body_preview' => substr((string) $body, 0, 500)
                ), $customer_id);
            }
            wp_send_json_error(__('Invalid response from verification API. Please try again.', 'x8-evs'));
        }
        
        // Check for API error response
        if (isset($data['error']) || (isset($data['errors']) && !empty($data['errors']))) {
            $first_error = isset($data['errors'][0]) && is_array($data['errors'][0]) ? $data['errors'][0] : array();
            $error_code = $data['error']['code'] ?? ($first_error['code'] ?? '');
            $error_message = $data['error']['message']
                ?? ($first_error['detail'] ?? ($first_error['message'] ?? __('API verification failed. Please try again.', 'x8-evs')));
            
            // Map BlueAssure account/authentication error codes to actionable hints (see API doc, Errors table)
            $auth_error_hints = array(
                '2000' => 'BlueAssure account is locked.',
                '2001' => 'BlueAssure account is disabled.',
                '2002' => 'BlueAssure account not found.',
                '2003' => 'BlueAssure web service user is locked.',
                '2004' => 'BlueAssure web service user is disabled.',
                '2005' => 'BlueAssure web service user not found - the API username/password configured in X8 Verify Settings is invalid or was regenerated. Check Integration Credentials on the BlueAssure Account Security page.',
                '2007' => 'BlueAssure account does not have access to this product.',
                '2008' => 'BlueAssure user is not allowed to run web service requests.',
                '2009' => 'BlueAssure account has reached its transaction limit.',
                '2010' => 'Server IP address is not whitelisted on the BlueAssure account (IP Restrictions on the Account Security page).'
            );
            $hint = $auth_error_hints[(string) $error_code] ?? '';
            
            if (class_exists('X8_EVS_Debug_Logger')) {
                X8_EVS_Debug_Logger::log('api_error', 'EVS API returned error ' . ($error_code !== '' ? '[code ' . $error_code . '] ' : '') . $error_message . ($hint ? ' — ' . $hint : ''), array(
                    'http_code' => wp_remote_retrieve_response_code($response),
                    'error_code' => $error_code,
                    'errors' => $data['errors'] ?? ($data['error'] ?? array()),
                    'transaction_id' => $data['meta']['transactionId'] ?? ''
                ), $customer_id);
            }
            wp_send_json_error($hint ? $error_message . ' — ' . $hint : $error_message);
        }
        
        update_user_meta($customer_id, 'verification_transaction_id', $data['meta']['transactionId'] ?? '');
        
        // If the API responded synchronously with verification results, process them
        // immediately using the same logic as the webhook (thresholds, age check, etc.).
        if (isset($data['data']['assureCard']) || isset($data['data']['workflowOutcome'])) {
            self::store_verification_data($customer_id, $data);
            
            $verification_status = get_user_meta($customer_id, 'account_status', true);
            update_user_meta($customer_id, 'verification_method', $verification_method);
            
            $current_user = wp_get_current_user();
            $admin_user_name = $current_user->display_name ?: $current_user->user_login;
            $this->log_status_change($customer_id, $verification_status, 'API verification result received', $admin_user_name, $verification_method);
            
            if (class_exists('X8_EVS_Debug_Logger')) {
                X8_EVS_Debug_Logger::log('api_result', 'EVS API returned a synchronous result; account status set to "' . $verification_status . '"', array(
                    'transaction_id' => $data['meta']['transactionId'] ?? '',
                    'total_confidence' => $data['data']['assureCard']['totalConfidence'] ?? null,
                    'face_confidence' => $data['data']['assureCard']['faceVerificationConfidence'] ?? null
                ), $customer_id);
            }
            
            wp_send_json_success(array(
                'message' => sprintf(__('API verification completed. Resulting status: %s', 'x8-evs'), $verification_status),
                'verification_status' => $verification_status,
                'transaction_id' => $data['meta']['transactionId'] ?? '',
                'api_response' => $data
            ));
        }
        
        // No synchronous result: mark the account as waiting for the EVS webhook callback.
        $verification_status = 'waiting';
        update_user_meta($customer_id, 'account_status', 'waiting');
        update_user_meta($customer_id, 'x8_evs_waiting_since', current_time('mysql'));
        
        if (class_exists('X8_EVS_Debug_Logger')) {
            X8_EVS_Debug_Logger::log('api_waiting', 'EVS API accepted the submission but returned no result; waiting for webhook callback', array(
                'transaction_id' => $data['meta']['transactionId'] ?? '',
                'webhook_url' => class_exists('X8_EVS_Webhook_Handler') ? X8_EVS_Webhook_Handler::get_webhook_url() : rest_url('x8-evs/v1/webhook'),
                'response_data_keys' => isset($data['data']) && is_array($data['data']) ? array_keys($data['data']) : array()
            ), $customer_id);
        }
        
        wp_send_json_success(array(
            'message' => __('API verification submitted successfully. Waiting for the verification result webhook from EVS.', 'x8-evs'),
            'verification_status' => $verification_status,
            'transaction_id' => $data['meta']['transactionId'] ?? '',
            'api_response' => $data
        ));
    }
    
    /**
     * Convert uploaded image file to base64
     */
    private function convert_image_to_base64($file) {
        if (!isset($file['tmp_name']) || !is_readable($file['tmp_name'])) {
            return false;
        }
        
        // Check file type to ensure it's an image
        $file_type = wp_check_filetype($file['name']);
        if (!in_array($file_type['type'], array('image/jpeg', 'image/jpg', 'image/png'))) {
            return false;
        }
        
        $image_data = file_get_contents($file['tmp_name']);
        if ($image_data === false) {
            return false;
        }
        
        return base64_encode($image_data);
    }
    
    /**
     * Convert image URL to base64
     */
    private function convert_url_to_base64($image_url) {
        // Handle both relative and absolute URLs
        if (strpos($image_url, 'http') !== 0) {
            $image_url = home_url($image_url);
        }
        
        $response = wp_remote_get($image_url);
        if (is_wp_error($response)) {
            return false;
        }
        
        $image_data = wp_remote_retrieve_body($response);
        if (empty($image_data)) {
            return false;
        }
        
        return base64_encode($image_data);
    }
    
    /**
     * Determine verification status from API response
     */
    private function determine_verification_status_from_api($api_data) {
        // Default to manual review for API responses
        $status = 'manual_review';
        
        if (!isset($api_data['data'])) {
            return $status;
        }
        
        $data = $api_data['data'];
        
        // Check for validation result
        if (isset($data['assureCard']['validationResult'])) {
            $validation_result = $data['assureCard']['validationResult'];
            
            // Check if validation was successful
            if (isset($validation_result['code']) && $validation_result['code'] === '0') {
                // Check confidence scores
                $total_confidence = $data['assureCard']['totalConfidence'] ?? 0;
                $face_confidence = $data['assureCard']['faceVerificationConfidence'] ?? 0;
                
                // Use thresholds to determine status
                $auto_approve_threshold = self::get_auto_approve_threshold();
                $manual_review_threshold = self::get_manual_review_threshold();
                $auto_block_threshold = self::get_auto_block_threshold();
                
                if ($total_confidence >= $auto_approve_threshold) {
                    $status = 'verified';
                } elseif ($total_confidence >= $manual_review_threshold) {
                    $status = 'manual_review';
                } else {
                    $status = 'block';
                }
            } else {
                // Validation failed
                $status = 'block';
            }
        }
        
        return $status;
    }

    /**
     * Log comprehensive customer activity for tracking and analytics
     */
    public static function log_customer_activity($user_id, $activity_type, $data = array()) {
        $current_time = current_time('mysql');
        $current_timestamp = time();
        
        // Get client information
        $client_info = self::get_client_information();
        
        // Create activity log entry
        $activity_entry = array(
            'timestamp' => $current_time,
            'unix_timestamp' => $current_timestamp,
            'activity_type' => $activity_type,
            'user_id' => $user_id,
            'ip_address' => $client_info['ip_address'],
            'user_agent' => $client_info['user_agent'],
            'geolocation' => $client_info['geolocation'],
            'data' => $data,
            'session_id' => session_id() ?: wp_generate_uuid4()
        );
        
        // Get existing activity log
        $activity_log = get_user_meta($user_id, 'x8_evs_activity_log', true);
        if (!is_array($activity_log)) {
            $activity_log = array();
        }
        
        // Add new entry
        $activity_log[] = $activity_entry;
        
        // Keep only last 100 entries per user (configurable)
        $max_entries = apply_filters('x8_evs_max_activity_entries', 100);
        if (count($activity_log) > $max_entries) {
            $activity_log = array_slice($activity_log, -$max_entries);
        }
        
        // Update user meta
        update_user_meta($user_id, 'x8_evs_activity_log', $activity_log);
        
        // Also store in global activity log for admin overview
        self::store_global_activity_log($activity_entry);
        
        return true;
    }
    
    /**
     * Get comprehensive client information including IP, geolocation, etc.
     */
    private static function get_client_information() {
        $ip_address = self::get_real_client_ip();
        $user_agent = $_SERVER['HTTP_USER_AGENT'] ?? 'Unknown';
        
        // Get geolocation information
        $geolocation = self::get_ip_geolocation($ip_address);
        
        return array(
            'ip_address' => $ip_address,
            'user_agent' => $user_agent,
            'geolocation' => $geolocation,
            'server_time' => current_time('mysql'),
            'timezone' => wp_timezone_string()
        );
    }
    
    /**
     * Get real client IP address (handles proxies, CDNs, etc.)
     */
    private static function get_real_client_ip() {
        $ip_headers = array(
            'HTTP_CF_CONNECTING_IP',     // Cloudflare
            'HTTP_X_REAL_IP',           // Nginx proxy
            'HTTP_X_FORWARDED_FOR',     // Load balancer/proxy
            'HTTP_X_FORWARDED',         // Proxy
            'HTTP_X_CLUSTER_CLIENT_IP', // Cluster
            'HTTP_CLIENT_IP',           // Proxy
            'REMOTE_ADDR'              // Standard
        );
        
        foreach ($ip_headers as $header) {
            if (!empty($_SERVER[$header])) {
                $ip = $_SERVER[$header];
                
                // Handle comma-separated IPs (X-Forwarded-For can contain multiple IPs)
                if (strpos($ip, ',') !== false) {
                    $ip_list = array_map('trim', explode(',', $ip));
                    $ip = $ip_list[0]; // Use the first IP
                }
                
                // Validate IP address
                if (filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE)) {
                    return $ip;
                }
            }
        }
        
        // Fallback to REMOTE_ADDR even if it's private/reserved
        return $_SERVER['REMOTE_ADDR'] ?? 'Unknown';
    }

    /**
     * Build activity-log geolocation from ipapi.co JSON (country + country_code are ISO; country_name is display name).
     *
     * @param array|null $data Decoded JSON from https://ipapi.co/{ip}/json/
     * @return array|null
     */
    private static function map_ipapi_co_geolocation($data) {
        if (!is_array($data)) {
            return null;
        }
        if (!empty($data['error']) || !empty($data['reserved']) || !empty($data['bogon'])) {
            return null;
        }
        $cc = '';
        if (!empty($data['country_code'])) {
            $cc = (string) $data['country_code'];
        } elseif (!empty($data['country']) && strlen((string) $data['country']) === 2) {
            $cc = (string) $data['country'];
        }
        if ($cc === '') {
            return null;
        }
        $display_country = !empty($data['country_name']) ? $data['country_name'] : $cc;

        return array(
            'country' => $display_country,
            'country_code' => $cc,
            'region' => $data['region'] ?? 'Unknown',
            'region_code' => $data['region_code'] ?? 'Unknown',
            'city' => $data['city'] ?? 'Unknown',
            'latitude' => isset($data['latitude']) ? $data['latitude'] : null,
            'longitude' => isset($data['longitude']) ? $data['longitude'] : null,
            'timezone' => $data['timezone'] ?? 'Unknown',
            'isp' => $data['org'] ?? 'Unknown'
        );
    }
    
    /**
     * Get IP geolocation information
     */
    private static function get_ip_geolocation($ip_address) {
        // Return cached result if available
        $cache_key = 'x8_evs_geo_' . md5($ip_address);
        $cached_result = get_transient($cache_key);
        if ($cached_result !== false) {
            return $cached_result;
        }
        
        $geolocation = array(
            'country' => 'Unknown',
            'country_code' => 'Unknown',
            'region' => 'Unknown',
            'region_code' => 'Unknown',
            'city' => 'Unknown',
            'latitude' => null,
            'longitude' => null,
            'timezone' => 'Unknown',
            'isp' => 'Unknown'
        );
        
        // Skip geolocation for local/private IPs
        if (!filter_var($ip_address, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE)) {
            $geolocation['country'] = 'Local/Private';
            $geolocation['region'] = 'Local/Private';
            $geolocation['city'] = 'Local/Private';
            return $geolocation;
        }
        
        $request_args = array(
            'timeout' => 5,
            'user-agent' => 'X8-Verify-Plugin/1.0'
        );

        // First: ipapi.co (when API key is configured)
        $ipapi_co_key = get_option('x8_evs_ipapi_co_api', '');
        if (!empty($ipapi_co_key)) {
            $api_url = 'https://ipapi.co/' . rawurlencode($ip_address) . '/json/?key=' . rawurlencode($ipapi_co_key);
            $response = wp_remote_get($api_url, $request_args);
            if (!is_wp_error($response)) {
                $data = json_decode(wp_remote_retrieve_body($response), true);
                $mapped = self::map_ipapi_co_geolocation($data);
                if ($mapped !== null) {
                    $geolocation = $mapped;
                }
            }
        }

        // Second: IPGeolocation.io
        if ($geolocation['country_code'] === 'Unknown') {
            $ipgeo_key = get_option('x8_evs_ipgeolocation_api', '');
            if (!empty($ipgeo_key)) {
                $api_url = 'https://api.ipgeolocation.io/v2/ipgeo?apiKey=' . rawurlencode($ipgeo_key) . '&ip=' . rawurlencode($ip_address);
                $response = wp_remote_get($api_url, $request_args);
                if (!is_wp_error($response)) {
                    $data = json_decode(wp_remote_retrieve_body($response), true);
                    if ($data && !empty($data['location'])) {
                        $loc = $data['location'];
                        $state_code = '';
                        if (!empty($loc['state_code'])) {
                            $parts = explode('-', $loc['state_code']);
                            $state_code = end($parts);
                        } elseif (!empty($loc['state_prov'])) {
                            $state_code = $loc['state_prov'];
                        }
                        $geolocation = array(
                            'country' => $loc['country_name'] ?? 'Unknown',
                            'country_code' => $loc['country_code2'] ?? 'Unknown',
                            'region' => $loc['state_prov'] ?? 'Unknown',
                            'region_code' => $state_code ?: 'Unknown',
                            'city' => $loc['city'] ?? 'Unknown',
                            'latitude' => isset($loc['latitude']) ? $loc['latitude'] : null,
                            'longitude' => isset($loc['longitude']) ? $loc['longitude'] : null,
                            'timezone' => 'Unknown',
                            'isp' => 'Unknown'
                        );
                    }
                }
            }
        }

        // Fallback: ip-api.com
        if ($geolocation['country_code'] === 'Unknown') {
            $api_url = "http://ip-api.com/json/{$ip_address}?fields=status,message,country,countryCode,region,regionName,city,lat,lon,timezone,isp";
            $response = wp_remote_get($api_url, $request_args);
            if (!is_wp_error($response)) {
                $data = json_decode(wp_remote_retrieve_body($response), true);
                if ($data && isset($data['status']) && $data['status'] === 'success') {
                    $geolocation = array(
                        'country' => $data['country'] ?? 'Unknown',
                        'country_code' => $data['countryCode'] ?? 'Unknown',
                        'region' => $data['regionName'] ?? 'Unknown',
                        'region_code' => $data['region'] ?? 'Unknown',
                        'city' => $data['city'] ?? 'Unknown',
                        'latitude' => $data['lat'] ?? null,
                        'longitude' => $data['lon'] ?? null,
                        'timezone' => $data['timezone'] ?? 'Unknown',
                        'isp' => $data['isp'] ?? 'Unknown'
                    );
                }
            }
        }

        // Last resort: ipapi.co without key
        if ($geolocation['country_code'] === 'Unknown') {
            $api_url = 'https://ipapi.co/' . rawurlencode($ip_address) . '/json/';
            $response = wp_remote_get($api_url, $request_args);
            if (!is_wp_error($response)) {
                $data = json_decode(wp_remote_retrieve_body($response), true);
                $mapped = self::map_ipapi_co_geolocation($data);
                if ($mapped !== null) {
                    $geolocation = $mapped;
                }
            }
        }
        
        // Cache result for 24 hours
        set_transient($cache_key, $geolocation, DAY_IN_SECONDS);
        
        return $geolocation;
    }
    
    /**
     * Store activity in global log for admin overview
     */
    private static function store_global_activity_log($activity_entry) {
        $global_log = get_option('x8_evs_global_activity_log', array());
        
        // Add new entry
        $global_log[] = $activity_entry;
        
        // Keep only last 1000 entries globally (configurable)
        $max_global_entries = apply_filters('x8_evs_max_global_activity_entries', 1000);
        if (count($global_log) > $max_global_entries) {
            $global_log = array_slice($global_log, -$max_global_entries);
        }
        
        update_option('x8_evs_global_activity_log', $global_log);
    }
    
    /**
     * Check if IP or region is blocked
     */
    public static function check_blocking_status($user_id, $ip_address = null, $geolocation = null) {
        if (!$ip_address) {
            $ip_address = self::get_real_client_ip();
        }
        
        if (!$geolocation) {
            $geolocation = self::get_ip_geolocation($ip_address);
        }
        
        $blocking_info = array(
            'ip_blocked' => false,
            'region_blocked' => false,
            'country_blocked' => false,
            'reason' => '',
            'blocked_by' => ''
        );
        
        // Check IP blocking
        $blocked_ips = get_option('x8_evs_blocked_ips', array());
        if (in_array($ip_address, $blocked_ips)) {
            $blocking_info['ip_blocked'] = true;
            $blocking_info['reason'] = 'IP address is blocked';
            $blocking_info['blocked_by'] = 'ip_list';
        }
        
        // Check country blocking
        $blocked_countries = get_option('x8_evs_blocked_countries', array());
        if (in_array($geolocation['country_code'], $blocked_countries)) {
            $blocking_info['country_blocked'] = true;
            $blocking_info['reason'] = 'Country is blocked: ' . $geolocation['country'];
            $blocking_info['blocked_by'] = 'country_list';
        }
        
        // Check region/state blocking
        $blocked_regions = get_option('x8_evs_blocked_regions', array());
        $region_key = $geolocation['country_code'] . '_' . $geolocation['region_code'];
        if (in_array($region_key, $blocked_regions)) {
            $blocking_info['region_blocked'] = true;
            $blocking_info['reason'] = 'Region is blocked: ' . $geolocation['region'];
            $blocking_info['blocked_by'] = 'region_list';
        }
        
        // Log blocking attempt if any blocking is active
        if ($blocking_info['ip_blocked'] || $blocking_info['region_blocked'] || $blocking_info['country_blocked']) {
            self::log_customer_activity($user_id, 'access_blocked', array(
                'blocking_info' => $blocking_info,
                'ip_address' => $ip_address,
                'geolocation' => $geolocation
            ));
        }
        
        return $blocking_info;
    }

    /**
     * Track Traffic admin page
     */
    public function track_traffic_page() {
        global $wpdb;
        
        $table_name = $wpdb->prefix . 'x8_evs_track_traffic';
        
        // Ensure table exists and has all required columns
        $this->ensure_track_traffic_table_exists();
        
        // Verify geolocation_service column exists (double-check)
        $column_check = $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA = %s AND TABLE_NAME = %s AND COLUMN_NAME = 'geolocation_service'",
            DB_NAME,
            $table_name
        ));
        
        if (empty($column_check) || $column_check == 0) {
            // Try to add the column
            $wpdb->query("ALTER TABLE {$table_name} ADD COLUMN geolocation_service varchar(50) DEFAULT NULL AFTER isp");
        }
        
        // Handle pagination
        $per_page = 50;
        $current_page = isset($_GET['paged']) ? max(1, intval($_GET['paged'])) : 1;
        $offset = ($current_page - 1) * $per_page;
        
        // Handle filtering
        $where_clauses = array();
        $where_values = array();
        
        if (isset($_GET['filter_ip']) && !empty($_GET['filter_ip'])) {
            $where_clauses[] = "(ip_address LIKE %s OR real_ip_address LIKE %s)";
            $search_ip = '%' . $wpdb->esc_like(sanitize_text_field($_GET['filter_ip'])) . '%';
            $where_values[] = $search_ip;
            $where_values[] = $search_ip;
        }
        
        if (isset($_GET['filter_block_type']) && !empty($_GET['filter_block_type'])) {
            $where_clauses[] = "block_type = %s";
            $where_values[] = sanitize_text_field($_GET['filter_block_type']);
        }
        
        if (isset($_GET['filter_country']) && !empty($_GET['filter_country'])) {
            $where_clauses[] = "country = %s";
            $where_values[] = sanitize_text_field($_GET['filter_country']);
        }
        
        $where_sql = !empty($where_clauses) ? 'WHERE ' . implode(' AND ', $where_clauses) : '';
        
        // Get total count (only if table exists)
        $total_items = 0;
        $items = array();
        $table_check = $wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $table_name));
        
        if ($table_check === $table_name) {
            if (!empty($where_values)) {
                $total_query = "SELECT COUNT(*) FROM {$table_name} {$where_sql}";
                $total_items = $wpdb->get_var($wpdb->prepare($total_query, $where_values));
            } else {
                $total_items = $wpdb->get_var("SELECT COUNT(*) FROM {$table_name}");
            }
            
            if ($total_items === false) {
                $total_items = 0;
            }
            
            $total_pages = ceil($total_items / $per_page);
            
            // Get data
            $query = "SELECT * FROM {$table_name} {$where_sql} ORDER BY created_at DESC LIMIT %d OFFSET %d";
            $query_values = array_merge($where_values, array($per_page, $offset));
            
            if (!empty($where_values)) {
                $items = $wpdb->get_results($wpdb->prepare($query, $query_values));
            } else {
                $items = $wpdb->get_results($wpdb->prepare("SELECT * FROM {$table_name} ORDER BY created_at DESC LIMIT %d OFFSET %d", $per_page, $offset));
            }
            
            if ($items === false) {
                $items = array();
            }
        } else {
            $total_pages = 0;
        }
        
        // Get unique block types for filter
        $block_types = array();
        $countries = array();
        
        // Only query if table exists
        $table_check = $wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $table_name));
        if ($table_check === $table_name) {
            $block_types = $wpdb->get_col("SELECT DISTINCT block_type FROM {$table_name} ORDER BY block_type");
            if ($block_types === false) {
                $block_types = array();
            }
            
            // Get unique countries for filter
            $countries = $wpdb->get_col("SELECT DISTINCT country FROM {$table_name} WHERE country IS NOT NULL ORDER BY country");
            if ($countries === false) {
                $countries = array();
            }
        }
        
        ?>
        <div class="wrap">
            <h1><?php _e('Track Traffic', 'x8-evs'); ?></h1>
            <p class="description"><?php _e('View all blocked user access attempts with IP addresses and location information.', 'x8-evs'); ?></p>
            
            <?php
            // Check table status
            $table_check = $wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $table_name));
            if ($table_check !== $table_name) {
                echo '<div class="notice notice-error"><p><strong>' . __('Error:', 'x8-evs') . '</strong> ' . __('Track Traffic table does not exist. Please refresh this page to create it.', 'x8-evs') . '</p></div>';
            } else {
                $table_count = $wpdb->get_var("SELECT COUNT(*) FROM {$table_name}");
                if ($table_count == 0) {
                    echo '<div class="notice notice-info"><p>' . __('No blocked traffic has been recorded yet. The table is ready and will track users when they are blocked.', 'x8-evs') . '</p></div>';
                }
            }
            ?>
            
            <!-- Filters -->
            <div class="x8-evs-filters" style="background: #fff; padding: 15px; margin: 20px 0; border: 1px solid #ccd0d4; box-shadow: 0 1px 1px rgba(0,0,0,.04);">
                <form method="get" action="">
                    <input type="hidden" name="page" value="x8-evs-track-traffic">
                    
                    <table class="form-table">
                        <tr>
                            <th scope="row">
                                <label for="filter_ip"><?php _e('IP Address', 'x8-evs'); ?></label>
                            </th>
                            <td>
                                <input type="text" id="filter_ip" name="filter_ip" value="<?php echo isset($_GET['filter_ip']) ? esc_attr($_GET['filter_ip']) : ''; ?>" class="regular-text" placeholder="<?php _e('Search by IP...', 'x8-evs'); ?>">
                            </td>
                        </tr>
                        <tr>
                            <th scope="row">
                                <label for="filter_block_type"><?php _e('Block Type', 'x8-evs'); ?></label>
                            </th>
                            <td>
                                <select id="filter_block_type" name="filter_block_type">
                                    <option value=""><?php _e('All Types', 'x8-evs'); ?></option>
                                    <?php foreach ($block_types as $type): ?>
                                        <option value="<?php echo esc_attr($type); ?>" <?php selected(isset($_GET['filter_block_type']) ? $_GET['filter_block_type'] : '', $type); ?>>
                                            <?php echo esc_html(ucfirst(str_replace('_', ' ', $type))); ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row">
                                <label for="filter_country"><?php _e('Country', 'x8-evs'); ?></label>
                            </th>
                            <td>
                                <select id="filter_country" name="filter_country">
                                    <option value=""><?php _e('All Countries', 'x8-evs'); ?></option>
                                    <?php foreach ($countries as $country): ?>
                                        <option value="<?php echo esc_attr($country); ?>" <?php selected(isset($_GET['filter_country']) ? $_GET['filter_country'] : '', $country); ?>>
                                            <?php echo esc_html($country); ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </td>
                        </tr>
                    </table>
                    
                    <p class="submit">
                        <input type="submit" class="button button-primary" value="<?php _e('Filter', 'x8-evs'); ?>">
                        <a href="<?php echo admin_url('admin.php?page=x8-evs-track-traffic'); ?>" class="button"><?php _e('Reset', 'x8-evs'); ?></a>
                    </p>
                </form>
            </div>
            
            <!-- Results -->
            <div class="x8-evs-track-traffic-results">
                <?php if (empty($items)): ?>
                    <div class="notice notice-info">
                        <p><?php _e('No blocked traffic found.', 'x8-evs'); ?></p>
                    </div>
                <?php else: ?>
                    <p style="margin: 10px 0;">
                        <strong><?php printf(_n('%d blocked access', '%d blocked accesses', $total_items, 'x8-evs'), $total_items); ?></strong>
                    </p>
                    
                    <table class="wp-list-table widefat fixed striped">
                        <thead>
                            <tr>
                                <th style="width: 120px;"><?php _e('Date/Time', 'x8-evs'); ?></th>
                                <th style="width: 150px;"><?php _e('IP Address', 'x8-evs'); ?></th>
                                <th style="width: 150px;"><?php _e('Real IP', 'x8-evs'); ?></th>
                                <th style="width: 100px;"><?php _e('Country', 'x8-evs'); ?></th>
                                <th style="width: 100px;"><?php _e('State', 'x8-evs'); ?></th>
                                <th style="width: 150px;"><?php _e('City', 'x8-evs'); ?></th>
                                <th style="width: 120px;"><?php _e('Geo Service', 'x8-evs'); ?></th>
                                <th style="width: 120px;"><?php _e('Block Type', 'x8-evs'); ?></th>
                                <th style="width: 150px;"><?php _e('User', 'x8-evs'); ?></th>
                                <th><?php _e('Block Reason', 'x8-evs'); ?></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($items as $item): ?>
                                <tr>
                                    <td><?php echo esc_html(date_i18n(get_option('date_format') . ' ' . get_option('time_format'), strtotime($item->created_at))); ?></td>
                                    <td>
                                        <strong><?php echo esc_html($item->ip_address ?: '-'); ?></strong>
                                    </td>
                                    <td>
                                        <?php if ($item->real_ip_address && $item->real_ip_address !== $item->ip_address): ?>
                                            <strong style="color: #d63638;"><?php echo esc_html($item->real_ip_address); ?></strong>
                                            <span class="dashicons dashicons-warning" style="color: #d63638;" title="<?php _e('Different from detected IP - possible proxy/VPN', 'x8-evs'); ?>"></span>
                                        <?php else: ?>
                                            <span style="color: #999;"><?php echo esc_html($item->real_ip_address ?: '-'); ?></span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php if ($item->country): ?>
                                            <?php echo esc_html($item->country); ?>
                                            <?php if ($item->country_name): ?>
                                                <br><small style="color: #666;"><?php echo esc_html($item->country_name); ?></small>
                                            <?php endif; ?>
                                        <?php else: ?>
                                            -
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php if ($item->state): ?>
                                            <?php echo esc_html($item->state); ?>
                                            <?php if ($item->state_name): ?>
                                                <br><small style="color: #666;"><?php echo esc_html($item->state_name); ?></small>
                                            <?php endif; ?>
                                        <?php else: ?>
                                            -
                                        <?php endif; ?>
                                    </td>
                                    <td><?php echo esc_html($item->city ?: '-'); ?></td>
                                    <td>
                                        <?php if ($item->geolocation_service): ?>
                                            <span class="x8-evs-geo-service" style="display: inline-block; padding: 3px 8px; border-radius: 3px; font-size: 11px; font-weight: 600; background: #e7f5ff; color: #0066cc;">
                                                <?php 
                                                $service_name = $item->geolocation_service;
                                                // Format service name for display
                                                if ($service_name === 'ipgeolocation') {
                                                    echo 'IPGeolocation';
                                                } elseif ($service_name === 'ip-api') {
                                                    echo 'IP-API';
                                                } elseif ($service_name === 'ipapi') {
                                                    echo 'IPAPI';
                                                } else {
                                                    echo esc_html(ucfirst($service_name));
                                                }
                                                ?>
                                            </span>
                                        <?php else: ?>
                                            <span style="color: #999;">-</span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <span class="x8-evs-block-type x8-evs-block-type-<?php echo esc_attr($item->block_type); ?>">
                                            <?php echo esc_html(ucfirst(str_replace('_', ' ', $item->block_type))); ?>
                                        </span>
                                    </td>
                                    <td>
                                        <?php if ($item->user_id): ?>
                                            <a href="<?php echo admin_url('user-edit.php?user_id=' . $item->user_id); ?>">
                                                <?php echo esc_html($item->user_email ?: 'User #' . $item->user_id); ?>
                                            </a>
                                        <?php else: ?>
                                            <span style="color: #999;"><?php _e('Guest', 'x8-evs'); ?></span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <small><?php echo esc_html($item->block_reason ?: '-'); ?></small>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                    
                    <!-- Pagination -->
                    <?php if ($total_pages > 1): ?>
                        <div class="tablenav">
                            <div class="tablenav-pages">
                                <?php
                                $page_links = paginate_links(array(
                                    'base' => add_query_arg('paged', '%#%'),
                                    'format' => '',
                                    'prev_text' => __('&laquo;'),
                                    'next_text' => __('&raquo;'),
                                    'total' => $total_pages,
                                    'current' => $current_page
                                ));
                                
                                if ($page_links) {
                                    echo '<span class="displaying-num">' . sprintf(_n('%s item', '%s items', $total_items, 'x8-evs'), number_format_i18n($total_items)) . '</span>';
                                    echo $page_links;
                                }
                                ?>
                            </div>
                        </div>
                    <?php endif; ?>
                <?php endif; ?>
            </div>
        </div>
        
        <style>
            .x8-evs-block-type {
                display: inline-block;
                padding: 3px 8px;
                border-radius: 3px;
                font-size: 11px;
                font-weight: 600;
            }
            .x8-evs-block-type-geolocation_country,
            .x8-evs-block-type-geolocation_state {
                background: #fff3cd;
                color: #856404;
            }
            .x8-evs-block-type-vpn {
                background: #f8d7da;
                color: #721c24;
            }
            .x8-evs-block-type-id_address {
                background: #d1ecf1;
                color: #0c5460;
            }
        </style>
        <?php
    }

    /**
     * Ensure track traffic table exists, create if it doesn't
     */
    private function ensure_track_traffic_table_exists() {
        global $wpdb;
        
        $table_name = $wpdb->prefix . 'x8_evs_track_traffic';
        
        // Check if table exists using SHOW TABLES (more reliable)
        $table_exists = $wpdb->get_var($wpdb->prepare(
            "SHOW TABLES LIKE %s",
            $table_name
        ));
        
        if ($table_exists !== $table_name) {
            $charset_collate = $wpdb->get_charset_collate();
            
            $track_sql = "CREATE TABLE $table_name (
                id bigint(20) NOT NULL AUTO_INCREMENT,
                ip_address varchar(45) NOT NULL,
                real_ip_address varchar(45) DEFAULT NULL,
                country varchar(10) DEFAULT NULL,
                country_name varchar(100) DEFAULT NULL,
                state varchar(10) DEFAULT NULL,
                state_name varchar(100) DEFAULT NULL,
                city varchar(100) DEFAULT NULL,
                region varchar(100) DEFAULT NULL,
                isp varchar(255) DEFAULT NULL,
                geolocation_service varchar(50) DEFAULT NULL,
                block_type varchar(50) NOT NULL,
                block_reason text,
                user_id bigint(20) DEFAULT NULL,
                user_email varchar(255) DEFAULT NULL,
                user_agent text,
                request_uri text,
                is_blocked tinyint(1) DEFAULT 1,
                created_at datetime DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY (id),
                KEY ip_address (ip_address),
                KEY real_ip_address (real_ip_address),
                KEY block_type (block_type),
                KEY created_at (created_at),
                KEY user_id (user_id)
            ) $charset_collate;";
            
            require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
            dbDelta($track_sql);
            
            // Show admin notice
            add_action('admin_notices', function() {
                echo '<div class="notice notice-success is-dismissible"><p>' . __('Track Traffic table created successfully.', 'x8-evs') . '</p></div>';
            });
        } else {
            // Check if geolocation_service column exists, add it if not
            $column_check = $wpdb->get_var($wpdb->prepare(
                "SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA = %s AND TABLE_NAME = %s AND COLUMN_NAME = 'geolocation_service'",
                DB_NAME,
                $table_name
            ));
            
            if (empty($column_check) || $column_check == 0) {
                $result = $wpdb->query("ALTER TABLE {$table_name} ADD COLUMN geolocation_service varchar(50) DEFAULT NULL AFTER isp");
                
                if (defined('WP_DEBUG') && WP_DEBUG) {
                    if ($result !== false) {
                        error_log('X8 Verify: Added geolocation_service column to track traffic table');
                    } else {
                        error_log('X8 Verify: Failed to add geolocation_service column - ' . $wpdb->last_error);
                    }
                }
            }
        }
    }
} 