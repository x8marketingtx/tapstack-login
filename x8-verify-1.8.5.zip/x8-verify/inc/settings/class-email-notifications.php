<?php
/**
 * Email notifications for user verification status changes
 */

if (!defined('ABSPATH')) {
	exit;
}

class X8_EVS_Email_Notifications {

	public static function init() {
		// Fire when user meta is added or updated
		add_action('added_user_meta', array(__CLASS__, 'maybe_send_on_meta_change'), 10, 4);
		add_action('updated_user_meta', array(__CLASS__, 'maybe_send_on_meta_change'), 10, 4);
		// Log init for diagnostics
		if (defined('WP_DEBUG') && WP_DEBUG) {
			error_log('[X8_EVS_Email_Notifications] initialized');
		}
	}

	/**
	 * Detect account_status changes and send the appropriate email.
	 */
	public static function maybe_send_on_meta_change($meta_id, $user_id, $meta_key, $meta_value) {
		if ($meta_key !== 'account_status') {
			return;
		}

		// Basic de-dupe: avoid multiple emails for the same new status in quick succession
		$dedupe_key = 'x8_evs_status_email_' . intval($user_id);
		$recent_status = get_transient($dedupe_key);
		if ($recent_status && $recent_status === $meta_value) {
			return;
		}
		set_transient($dedupe_key, $meta_value, 10);

		if (defined('WP_DEBUG') && WP_DEBUG) {
			error_log(sprintf('[X8_EVS_Email_Notifications] account_status meta change for user %d: %s', $user_id, $meta_value));
		}
		self::send_status_email($user_id, $meta_value);
	}

	/**
	 * Send an email to the user based on their verification status.
	 */
	public static function send_status_email($user_id, $status) {
		$user = get_userdata($user_id);
		if (!$user || empty($user->user_email)) {
			return false;
		}

		// Skip email for pending status only if it's part of document request process or auto reverification
		if ($status === 'pending' && (get_user_meta($user_id, '_document_request_in_progress', true) === '1' || get_user_meta($user_id, '_auto_reverification_requested', true) === '1')) {
			// Clear the auto reverification flag after skipping email
			if (get_user_meta($user_id, '_auto_reverification_requested', true) === '1') {
				delete_user_meta($user_id, '_auto_reverification_requested');
			}
			return false;
		}

		$site_name = wp_specialchars_decode(get_bloginfo('name'), ENT_QUOTES);
		$admin_email = class_exists('X8_EVS_Admin_Settings') ? X8_EVS_Admin_Settings::get_contact_email() : get_option('admin_email');
		$support_email = apply_filters('x8_evs_support_email', $admin_email);
		$headers = array('Content-Type: text/html; charset=UTF-8');

		$cta_url = function_exists('wc_get_page_permalink') ? wc_get_page_permalink('myaccount') : home_url('/my-account');
		if (empty($cta_url)) {
			$cta_url = home_url('/');
		}

		$verification_link = get_user_meta($user_id, 'verification_link', true);
		if ($verification_link) {
			$cta_verify_url = $verification_link;
		} else {
			// Get the verification page ID from options and create the URL
			$verification_page_id = get_option('x8_evs_verification_page', 0);
			if ($verification_page_id && get_post_status($verification_page_id) === 'publish') {
				$cta_verify_url = get_permalink($verification_page_id);
			} else {
				$cta_verify_url = home_url('/');
			}
		}

		$notes = get_user_meta($user_id, 'verification_notes', true);
		$error_detail = get_user_meta($user_id, 'verification_error_detail', true);

		$subject = '';
		$body = '';

		switch ($status) {
			case 'verified':
				$subject = sprintf(__('Your identity is verified on %s', 'x8-evs'), $site_name);
				$body = self::wrap_email_html(
					self::h1(__('Identity Verified', 'x8-evs')) .
					self::p(sprintf(__('Hi %s,', 'x8-evs'), esc_html($user->display_name ?: $user->user_login))) .
					self::p(sprintf(__('Great news — your identity has been successfully verified on %s. You can now continue using all features.', 'x8-evs'), esc_html($site_name))) .
					self::button(__('Go to my account', 'x8-evs'), esc_url($cta_url))
				);
				break;

			case 'block':
				// Custom email when blocked due to duplicate license number
				$duplicate_license = get_user_meta($user_id, '_duplicate_license_block', true);
				if ($duplicate_license === '1' || $duplicate_license === true) {
					delete_user_meta($user_id, '_duplicate_license_block');
					$subject = sprintf(__('Account already exists on %s', 'x8-evs'), $site_name);
					$body = self::wrap_email_html(
						self::h1(__('Account already exists', 'x8-evs')) .
						self::p(sprintf(__('Hi %s,', 'x8-evs'), esc_html($user->display_name ?: $user->user_login))) .
						self::p(__('An account already exists with this person\'s information. You cannot create a new account using the same identity document (license number).', 'x8-evs')) .
						self::p(__('If you already have an account, please sign in to that account. If you believe this is a mistake, please contact us.', 'x8-evs')) .
						self::p(sprintf(__('Contact support: %s', 'x8-evs'), esc_html($support_email)))
					);
					$subject = apply_filters('x8_evs_email_subject_duplicate_license', $subject, $user_id);
					$body = apply_filters('x8_evs_email_body_duplicate_license', $body, $user_id);
					$sent = wp_mail($user->user_email, $subject, $body, $headers);
					if (defined('WP_DEBUG') && WP_DEBUG) {
						error_log(sprintf('[X8_EVS_Email_Notifications] duplicate-license email %s for user %d to %s', $sent ? 'SENT' : 'FAILED', $user_id, $user->user_email));
					}
					return $sent;
				}
				$subject = sprintf(__('Verification failed on %s', 'x8-evs'), $site_name);
				$details = '';
				$body = self::wrap_email_html(
					self::h1(__('Verification Unsuccessful', 'x8-evs')) .
					self::p(sprintf(__('Hi %s,', 'x8-evs'), esc_html($user->display_name ?: $user->user_login))) .
					self::p(__('We were unable to complete your verification. For your security, access may be limited.', 'x8-evs')) .
					$details .
					self::p(sprintf(__('If you believe this is a mistake, please contact us at %s and we will assist you.', 'x8-evs'), esc_html($support_email)))
				);
				break;

			case 'manual_review':
				// Check if auto request re-verification is enabled
				$auto_request_reverification = get_option('x8_evs_auto_request_reverification', false);
				// Handle both boolean and string '1' values (WordPress checkboxes save as '1')
				$auto_request_reverification = ($auto_request_reverification === true || $auto_request_reverification === '1' || $auto_request_reverification === 1);
				
				if (defined('WP_DEBUG') && WP_DEBUG) {
					error_log(sprintf('[X8_EVS_Email_Notifications] manual_review for user %d, auto_request_reverification setting: %s (enabled: %s)', $user_id, var_export(get_option('x8_evs_auto_request_reverification', false), true), $auto_request_reverification ? 'YES' : 'NO'));
				}
				
				if ($auto_request_reverification) {
					// Set flag FIRST to prevent pending email from being sent when we change status
					update_user_meta($user_id, '_auto_reverification_requested', '1');
					
					if (defined('WP_DEBUG') && WP_DEBUG) {
						error_log(sprintf('[X8_EVS_Email_Notifications] Setting _auto_reverification_requested flag for user %d', $user_id));
					}
					
					// Send custom email requesting new verification
					$subject = sprintf(__('Please try verification again on %s', 'x8-evs'), $site_name);
					$body = self::wrap_email_html(
						self::h1(__('Verification Update', 'x8-evs')) .
						self::p(sprintf(__('Hi %s,', 'x8-evs'), esc_html($user->display_name ?: $user->user_login))) .
						self::p(__('Your documentation and/or selfie failed our verification. Please click the button below and try again.', 'x8-evs')) .
						self::button(__('Please Reverify', 'x8-evs'), esc_url($cta_verify_url))
					);
					
					// Apply filters before sending
					$subject = apply_filters('x8_evs_email_subject_manual_review', $subject, $user_id, 'manual_review');
					$body = apply_filters('x8_evs_email_body_manual_review', $body, $user_id, 'manual_review');
					
					// Send the email first
					$sent = wp_mail($user->user_email, $subject, $body, $headers);
					if (defined('WP_DEBUG') && WP_DEBUG) {
						error_log(sprintf('[X8_EVS_Email_Notifications] auto-reverification email %s for user %d to %s', $sent ? 'SENT' : 'FAILED', $user_id, $user->user_email));
					}
					
					// Change user status to pending for next review
					// The hook will fire, but the pending email will be skipped due to the flag
					if (defined('WP_DEBUG') && WP_DEBUG) {
						error_log(sprintf('[X8_EVS_Email_Notifications] Changing user %d status from manual_review to pending', $user_id));
					}
					update_user_meta($user_id, 'account_status', 'pending');
					
					// Verify the status was changed
					$new_status = get_user_meta($user_id, 'account_status', true);
					if (defined('WP_DEBUG') && WP_DEBUG) {
						error_log(sprintf('[X8_EVS_Email_Notifications] User %d status after update: %s', $user_id, $new_status));
					}
					
					// Return early to prevent the email from being sent again at the end
					return $sent;
				} else {
					// Send default manual review email
					$subject = sprintf(__('Your verification is under review at %s', 'x8-evs'), $site_name);
					$details = '';
					$body = self::wrap_email_html(
						self::h1(__('Verification Under Review', 'x8-evs')) .
						self::p(sprintf(__('Hi %s,', 'x8-evs'), esc_html($user->display_name ?: $user->user_login))) .
						self::p(__('We received your documents and our team is reviewing them. This typically takes 24–48 hours.', 'x8-evs')) .
						$details .
						self::p(__('We will email you as soon as the review is complete.', 'x8-evs'))
					);
				}
				break;

			case 'error':
				$subject = sprintf(__('There was an issue with your verification on %s', 'x8-evs'), $site_name);
				$details = $error_detail ? self::p(esc_html($error_detail)) : '';
				$body = self::wrap_email_html(
					self::h1(__('Verification Error', 'x8-evs')) .
					self::p(sprintf(__('Hi %s,', 'x8-evs'), esc_html($user->display_name ?: $user->user_login))) .
					self::p(__('We ran into an unexpected error while processing your verification. You can try again using the link below, or contact support for help.', 'x8-evs')) .
					$details .
					self::button(__('Try verification again', 'x8-evs'), esc_url($cta_verify_url)) .
					self::p(sprintf(__('Need help? Email us at %s', 'x8-evs'), esc_html($support_email)))
				);
				break;

			case 'fresh_data':
				$subject = sprintf(__('New documents requested for verification on %s', 'x8-evs'), $site_name);
				$body = self::wrap_email_html(
					self::h1(__('New Documents Requested', 'x8-evs')) .
					self::p(sprintf(__('Hi %s,', 'x8-evs'), esc_html($user->display_name ?: $user->user_login))) .
					self::p(__('After reviewing your verification, we are unable to complete it. This is due to the uploaded documents not meeting the requirements. Please try uploading your documents again. Be sure the images are clear, fully visible and have no reflections or shadows on them.', 'x8-evs')) .
					self::button(__('Submit new documents', 'x8-evs'), esc_url($cta_verify_url))
				);
				break;

			case 'pending':
			default:
				$subject = sprintf(__('Your verification is in progress at %s', 'x8-evs'), $site_name);
				$body = self::wrap_email_html(
					self::h1(__('Verification Started', 'x8-evs')) .
					self::p(sprintf(__('Hi %s,', 'x8-evs'), esc_html($user->display_name ?: $user->user_login))) .
					self::p(__('We received your verification request. If you did not finish, you can resume using the link below.', 'x8-evs')) .
					self::button(__('Resume verification', 'x8-evs'), esc_url($cta_verify_url))
				);
		}

		$subject = apply_filters('x8_evs_email_subject_' . $status, $subject, $user_id, $status);
		$body = apply_filters('x8_evs_email_body_' . $status, $body, $user_id, $status);

		$sent = wp_mail($user->user_email, $subject, $body, $headers);
		if (defined('WP_DEBUG') && WP_DEBUG) {
			error_log(sprintf('[X8_EVS_Email_Notifications] email %s for user %d status "%s" to %s', $sent ? 'SENT' : 'FAILED', $user_id, $status, $user->user_email));
		}
		return $sent;
	}

	private static function wrap_email_html($content) {
		$styles_wrapper = 'margin:0;padding:0;background-color:#f5f6f8;font-family:-apple-system,BlinkMacSystemFont,Segoe UI,Roboto,Helvetica,Arial,sans-serif;color:#111';
		$styles_container = 'max-width:560px;margin:24px auto;background:#ffffff;border-radius:8px;overflow:hidden;box-shadow:0 1px 2px rgba(0,0,0,.06)';
		$styles_header = 'background:#111827;color:#ffffff;padding:16px 20px;font-weight:600;font-size:16px';
		$styles_body = 'padding:20px 20px 8px;font-size:15px;line-height:1.6;color:#111827';
		$styles_footer = 'padding:16px 20px;color:#6b7280;font-size:12px';

		$site_name = wp_specialchars_decode(get_bloginfo('name'), ENT_QUOTES);
		$home = esc_url(home_url('/'));

		return '<div style="' . esc_attr($styles_wrapper) . '">' .
			'<div style="' . esc_attr($styles_container) . '">' .
				'<div style="' . esc_attr($styles_header) . '">' . esc_html($site_name) . '</div>' .
				'<div style="' . esc_attr($styles_body) . '">' . $content . '</div>' .
				'<div style="' . esc_attr($styles_footer) . '">' . sprintf(__('Sent by %s • %s', 'x8-evs'), esc_html($site_name), $home) . '</div>' .
			'</div>' .
		'</div>';
	}

	private static function h1($text) {
		return '<h1 style="margin:0 0 12px;font-size:20px;line-height:1.3">' . wp_kses_post($text) . '</h1>';
	}

	private static function p($text) {
		return '<p style="margin:0 0 12px">' . wp_kses_post($text) . '</p>';
	}



	private static function button($label, $url) {
		$style = 'display:inline-block;background:#0ea5e9;color:#fff !important;text-decoration:none;padding:10px 14px;border-radius:6px;font-weight:600;margin:8px 0';
		return '<p style="margin:16px 0"><a href="' . esc_url($url) . '" style="' . esc_attr($style) . '">' . esc_html($label) . '</a></p>';
	}
}


