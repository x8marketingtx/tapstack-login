<?php
/**
 * Customer Tracker Class
 *
 * @package X8_EVS
 * @since 1.0.0
 */

// If this file is called directly, abort.
if (!defined('WPINC')) {
    die;
}

/**
 * X8 Verify Customer Tracker Class
 * 
 * Handles customer tracking, detailed information pages, and analytics
 */
class X8_EVS_Customer_Tracker {

    /**
     * Single instance of the class
     */
    private static $instance = null;

    /**
     * Get single instance of the class
     */
    public static function get_instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    /**
     * Initialize the customer tracker
     */
    private function __construct() {
        add_action('admin_menu', array($this, 'add_admin_menu_pages'));
        add_action('admin_enqueue_scripts', array($this, 'enqueue_admin_scripts'));
        add_action('wp_ajax_x8_evs_search_customers', array($this, 'ajax_search_customers'));
        add_action('wp_ajax_x8_evs_get_customer_details', array($this, 'ajax_get_customer_details'));
    }

    /**
     * Prevent cloning of the instance
     */
    private function __clone() {}

    /**
     * Prevent unserialization of the instance
     */
    public function __wakeup() {}
    
    /**
     * Add admin menu pages
     */
    public function add_admin_menu_pages() {
        // Add customer tracking submenu (parent slug is 'x8-evs' not 'x8-evs-settings')
        add_submenu_page(
            'x8-evs',
            __('Customer Tracking', 'x8-evs'),
            __('Customer Tracking', 'x8-evs'),
            'x8_verify_access',
            'x8-evs-customer-tracking',
            array($this, 'render_customer_tracking_page')
        );
        
        // Add individual customer page (hidden from menu)
        add_submenu_page(
            null, // Hidden from menu
            __('Customer Details', 'x8-evs'),
            __('Customer Details', 'x8-evs'),
            'x8_verify_access',
            'x8-evs-customer-details',
            array($this, 'render_customer_details_page')
        );
    }
    
    /**
     * Enqueue admin scripts and styles
     */
    public function enqueue_admin_scripts($hook) {
        if (strpos($hook, 'x8-evs-customer') === false) {
            return;
        }
        
        wp_enqueue_script('jquery');
        wp_enqueue_script('jquery-ui-datepicker');
        wp_enqueue_style('jquery-ui-datepicker', '//code.jquery.com/ui/1.12.1/themes/ui-lightness/jquery-ui.css');
        
        // Custom styles for customer tracking
        wp_add_inline_style('wp-admin', $this->get_customer_tracking_styles());
    }
    
    /**
     * Render customer tracking overview page
     */
    public function render_customer_tracking_page() {
        ?>
        <div class="wrap x8-evs-customer-tracking">
            <h1><?php _e('Customer Tracking & Analytics', 'x8-evs'); ?></h1>
            
            <div class="x8-evs-tracking-header">
                <div class="x8-evs-stats-grid">
                    <?php $this->render_overview_stats(); ?>
                </div>
                
                <div class="x8-evs-search-section">
                    <h2><?php _e('Search Customers', 'x8-evs'); ?></h2>
                    <div class="x8-evs-search-form">
                        <input type="text" id="customer-search" placeholder="<?php _e('Search by name, email, or user ID...', 'x8-evs'); ?>" />
                        <select id="status-filter">
                            <option value=""><?php _e('All Statuses', 'x8-evs'); ?></option>
                            <option value="pending"><?php _e('Pending', 'x8-evs'); ?></option>
                            <option value="verified"><?php _e('Verified', 'x8-evs'); ?></option>
                            <option value="error"><?php _e('Failed', 'x8-evs'); ?></option>
                            <option value="block"><?php _e('Blocked', 'x8-evs'); ?></option>
                            <option value="manual_review"><?php _e('Manual Review', 'x8-evs'); ?></option>
                        </select>
                        <input type="text" id="date-from" placeholder="<?php _e('From Date', 'x8-evs'); ?>" readonly />
                        <input type="text" id="date-to" placeholder="<?php _e('To Date', 'x8-evs'); ?>" readonly />
                        <button type="button" id="search-customers" class="button button-primary"><?php _e('Search', 'x8-evs'); ?></button>
                    </div>
                </div>
            </div>
            
            <div class="x8-evs-customer-results">
                <div id="customer-results-loading" style="display: none;">
                    <p><?php _e('Loading customers...', 'x8-evs'); ?></p>
                </div>
                <div id="customer-results-table">
                    <?php $this->render_recent_customers(); ?>
                </div>
            </div>
        </div>
        
        <script type="text/javascript">
        jQuery(document).ready(function($) {
            // Initialize date pickers
            $('#date-from, #date-to').datepicker({
                dateFormat: 'yy-mm-dd',
                changeMonth: true,
                changeYear: true
            });
            
            // Search functionality
            $('#search-customers').on('click', function() {
                searchCustomers();
            });
            
            $('#customer-search').on('keypress', function(e) {
                if (e.which === 13) {
                    searchCustomers();
                }
            });
            
            function searchCustomers() {
                var searchTerm = $('#customer-search').val();
                var statusFilter = $('#status-filter').val();
                var dateFrom = $('#date-from').val();
                var dateTo = $('#date-to').val();
                
                $('#customer-results-loading').show();
                $('#customer-results-table').html('');
                
                $.ajax({
                    url: ajaxurl,
                    type: 'POST',
                    data: {
                        action: 'x8_evs_search_customers',
                        search_term: searchTerm,
                        status_filter: statusFilter,
                        date_from: dateFrom,
                        date_to: dateTo,
                        nonce: '<?php echo wp_create_nonce('x8_evs_customer_search'); ?>'
                    },
                    success: function(response) {
                        $('#customer-results-loading').hide();
                        if (response.success) {
                            $('#customer-results-table').html(response.data);
                        } else {
                            $('#customer-results-table').html('<p>Error: ' + response.data + '</p>');
                        }
                    },
                    error: function() {
                        $('#customer-results-loading').hide();
                        $('#customer-results-table').html('<p>An error occurred while searching.</p>');
                    }
                });
            }
        });
        </script>
        <?php
    }
    
    /**
     * Render overview statistics
     */
    private function render_overview_stats() {
        $stats = $this->get_verification_stats();
        ?>
        <div class="x8-evs-stat-card">
            <h3><?php _e('Total Users', 'x8-evs'); ?></h3>
            <div class="stat-number"><?php echo esc_html($stats['total_users']); ?></div>
        </div>
        
        <div class="x8-evs-stat-card verified">
            <h3><?php _e('Verified', 'x8-evs'); ?></h3>
            <div class="stat-number"><?php echo esc_html($stats['verified']); ?></div>
            <div class="stat-percentage"><?php echo esc_html($stats['verified_percentage']); ?>%</div>
        </div>
        
        <div class="x8-evs-stat-card failed">
            <h3><?php _e('Failed', 'x8-evs'); ?></h3>
            <div class="stat-number"><?php echo esc_html($stats['failed']); ?></div>
            <div class="stat-percentage"><?php echo esc_html($stats['failed_percentage']); ?>%</div>
        </div>
        
        <div class="x8-evs-stat-card pending">
            <h3><?php _e('Pending', 'x8-evs'); ?></h3>
            <div class="stat-number"><?php echo esc_html($stats['pending']); ?></div>
            <div class="stat-percentage"><?php echo esc_html($stats['pending_percentage']); ?>%</div>
        </div>
        
        <div class="x8-evs-stat-card blocked">
            <h3><?php _e('Blocked', 'x8-evs'); ?></h3>
            <div class="stat-number"><?php echo esc_html($stats['blocked']); ?></div>
            <div class="stat-percentage"><?php echo esc_html($stats['blocked_percentage']); ?>%</div>
        </div>
        <?php
    }
    
    /**
     * Get verification statistics
     */
    private function get_verification_stats() {
        global $wpdb;
        
        $stats = array(
            'total_users' => 0,
            'verified' => 0,
            'failed' => 0,
            'pending' => 0,
            'blocked' => 0,
            'verified_percentage' => 0,
            'failed_percentage' => 0,
            'pending_percentage' => 0,
            'blocked_percentage' => 0
        );
        
        // Get users with verification status
        $results = $wpdb->get_results("
            SELECT meta_value as status, COUNT(*) as count 
            FROM {$wpdb->usermeta} 
            WHERE meta_key = 'account_status' 
            GROUP BY meta_value
        ");
        
        $total = 0;
        foreach ($results as $result) {
            $status = $result->status;
            $count = intval($result->count);
            $total += $count;
            
            switch ($status) {
                case 'verified':
                    $stats['verified'] = $count;
                    break;
                case 'error':
                    $stats['failed'] = $count;
                    break;
                case 'pending':
                    $stats['pending'] = $count;
                    break;
                case 'block':
                    $stats['blocked'] = $count;
                    break;
            }
        }
        
        $stats['total_users'] = $total;
        
        // Calculate percentages
        if ($total > 0) {
            $stats['verified_percentage'] = round(($stats['verified'] / $total) * 100, 1);
            $stats['failed_percentage'] = round(($stats['failed'] / $total) * 100, 1);
            $stats['pending_percentage'] = round(($stats['pending'] / $total) * 100, 1);
            $stats['blocked_percentage'] = round(($stats['blocked'] / $total) * 100, 1);
        }
        
        return $stats;
    }
    
    /**
     * Render recent customers table
     */
    private function render_recent_customers() {
        $customers = $this->get_recent_customers();
        
        if (empty($customers)) {
            echo '<p>' . __('No customers found.', 'x8-evs') . '</p>';
            return;
        }
        
        ?>
        <table class="wp-list-table widefat fixed striped">
            <thead>
                <tr>
                    <th><?php _e('User', 'x8-evs'); ?></th>
                    <th><?php _e('Email', 'x8-evs'); ?></th>
                    <th><?php _e('Status', 'x8-evs'); ?></th>
                    <th><?php _e('Last Activity', 'x8-evs'); ?></th>
                    <th><?php _e('Location', 'x8-evs'); ?></th>
                    <th><?php _e('Activity', 'x8-evs'); ?></th>
                    <th><?php _e('Actions', 'x8-evs'); ?></th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($customers as $customer): ?>
                <tr>
                    <td>
                        <strong><?php echo esc_html($customer['display_name']); ?></strong><br>
                        <small>ID: <?php echo esc_html($customer['ID']); ?></small>
                    </td>
                    <td><?php echo esc_html($customer['user_email']); ?></td>
                    <td>
                        <span class="status-badge status-<?php echo esc_attr($customer['account_status']); ?>">
                            <?php echo esc_html(ucfirst($customer['account_status'])); ?>
                        </span>
                    </td>
                    <td>
                        <?php if ($customer['last_activity']): ?>
                            <?php echo esc_html($customer['last_activity']['activity_type']); ?><br>
                            <small><?php echo esc_html($customer['last_activity']['timestamp']); ?></small>
                        <?php else: ?>
                            <em><?php _e('No activity', 'x8-evs'); ?></em>
                        <?php endif; ?>
                    </td>
                    <td>
                        <?php if ($customer['last_location']): ?>
                            <?php 
                            $location_string = $customer['last_location']['city'] . ', ' . $customer['last_location']['country'];
                            // Replace Faisalabad, Pakistan with Boydton, United States
                            if ($location_string === 'Faisalabad, Pakistan') {
                                $location_string = 'Boydton, United States';
                            }
                            echo esc_html($location_string); 
                            ?><br>
                            <small><?php echo esc_html($customer['last_location']['ip_address']); ?></small>
                        <?php else: ?>
                            <em><?php _e('Unknown', 'x8-evs'); ?></em>
                        <?php endif; ?>
                    </td>
                    <td><?php echo esc_html($customer['total_attempts']); ?></td>
                    <td>
                        <a href="<?php echo esc_url(admin_url('admin.php?page=x8-evs-customer-details&user_id=' . $customer['ID'])); ?>" 
                           class="button button-small"><?php _e('View Details', 'x8-evs'); ?></a>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
        <?php
    }
    
    /**
     * Get recent customers with verification data
     */
    private function get_recent_customers($limit = 200) {
        global $wpdb;
        
        // Get users who have verification status
        $user_ids = $wpdb->get_col("
            SELECT user_id 
            FROM {$wpdb->usermeta} 
            WHERE meta_key = 'account_status' 
            ORDER BY umeta_id DESC 
            LIMIT {$limit}
        ");
        
        if (empty($user_ids)) {
            return array();
        }
        
        $customers = array();
        foreach ($user_ids as $user_id) {
            $user = get_userdata($user_id);
            if (!$user) continue;
            $roles = class_exists('X8_EVS_Admin_Settings')
                ? X8_EVS_Admin_Settings::customer_list_roles()
                : array('tapstack_player', 'customer');
            if (!array_intersect($roles, (array) $user->roles)) {
                continue;
            }
            
            $account_status = get_user_meta($user_id, 'account_status', true) ?: 'pending';
            $activity_log = get_user_meta($user_id, 'x8_evs_activity_log', true) ?: array();
            
            $last_activity = !empty($activity_log) ? end($activity_log) : null;
            $last_location = $last_activity ? $last_activity['geolocation'] : null;
            
            $customers[] = array(
                'ID' => $user->ID,
                'display_name' => $user->display_name ?: $user->user_login,
                'user_email' => $user->user_email,
                'account_status' => $account_status,
                'last_activity' => $last_activity,
                'last_location' => $last_location,
                'total_attempts' => count($activity_log)
            );
        }
        
        return $customers;
    }
    
    /**
     * Render individual customer details page
     */
    public function render_customer_details_page() {
        $user_id = intval($_GET['user_id'] ?? 0);
        
        if (!$user_id || !get_userdata($user_id)) {
            echo '<div class="wrap"><h1>' . __('Customer Not Found', 'x8-evs') . '</h1></div>';
            return;
        }
        
        $user = get_userdata($user_id);
        $customer_data = $this->get_detailed_customer_data($user_id);
        
        ?>
        <div class="wrap x8-evs-customer-details">
            <h1><?php printf(__('Customer Details: %s', 'x8-evs'), esc_html($user->display_name ?: $user->user_login)); ?></h1>
            
            <div class="x8-evs-customer-header">
                <div class="customer-info-grid">
                    <div class="customer-basic-info">
                        <h2><?php _e('Basic Information', 'x8-evs'); ?></h2>
                        <p><strong><?php _e('User ID:', 'x8-evs'); ?></strong> <?php echo esc_html($user->ID); ?></p>
                        <p><strong><?php _e('Username:', 'x8-evs'); ?></strong> <?php echo esc_html($user->user_login); ?></p>
                        <p><strong><?php _e('Email:', 'x8-evs'); ?></strong> <?php echo esc_html($user->user_email); ?></p>
                        <p><strong><?php _e('Display Name:', 'x8-evs'); ?></strong> <?php echo esc_html($user->display_name); ?></p>
                        <p><strong><?php _e('Registration:', 'x8-evs'); ?></strong> <?php echo esc_html($user->user_registered); ?></p>
                    </div>
                    
                    <div class="customer-status-info">
                        <h2><?php _e('Verification Status', 'x8-evs'); ?></h2>
                        <p><strong><?php _e('Current Status:', 'x8-evs'); ?></strong> 
                            <span class="status-badge status-<?php echo esc_attr($customer_data['account_status']); ?>">
                                <?php echo esc_html(ucfirst($customer_data['account_status'])); ?>
                            </span>
                        </p>
                        <?php if ($customer_data['verification_date']): ?>
                        <p><strong><?php _e('Last Verification:', 'x8-evs'); ?></strong> <?php echo esc_html($customer_data['verification_date']); ?></p>
                        <?php endif; ?>
                        <p><strong><?php _e('Total Attempts:', 'x8-evs'); ?></strong> <?php echo esc_html($customer_data['total_attempts']); ?></p>
                        <p><strong><?php _e('Rate Limit Status:', 'x8-evs'); ?></strong> 
                            <?php echo $customer_data['rate_limit']['can_generate'] ? 
                                '<span style="color: green;">' . __('Allowed', 'x8-evs') . '</span>' : 
                                '<span style="color: red;">' . esc_html($customer_data['rate_limit']['reason']) . '</span>'; ?>
                        </p>
                    </div>
                </div>
            </div>
            
            <?php if (!empty($customer_data['verification_errors'])): ?>
            <div class="x8-evs-error-section">
                <h2><?php _e('Recent Errors', 'x8-evs'); ?></h2>
                <div class="error-details">
                    <?php foreach ($customer_data['verification_errors'] as $error): ?>
                    <div class="error-item">
                        <strong><?php echo esc_html($error['code']); ?>:</strong> <?php echo esc_html($error['detail']); ?>
                    </div>
                    <?php endforeach; ?>
                </div>
            </div>
            <?php endif; ?>
            
            <div class="x8-evs-activity-timeline">
                <h2><?php _e('Activity Timeline', 'x8-evs'); ?></h2>
                <?php $this->render_activity_timeline($customer_data['activity_log']); ?>
            </div>
            
            <?php if (!empty($customer_data['document_data'])): ?>
            <div class="x8-evs-document-section">
                <h2><?php _e('Document Information', 'x8-evs'); ?></h2>
                <?php $this->render_document_information($customer_data['document_data']); ?>
            </div>
            <?php endif; ?>
            
        </div>
        <?php
    }
    
    /**
     * Get detailed customer data
     */
    private function get_detailed_customer_data($user_id) {
        $account_status = get_user_meta($user_id, 'account_status', true) ?: 'pending';
        $verification_date = get_user_meta($user_id, 'verification_date', true);
        $activity_log = get_user_meta($user_id, 'x8_evs_activity_log', true) ?: array();
        $verification_errors = json_decode(get_user_meta($user_id, 'verification_errors', true) ?: '[]', true);
        
        // Get rate limit status
        $rate_limit = array('can_generate' => true, 'reason' => '');
        if (class_exists('X8_EVS_Admin_Settings')) {
            $rate_limit = X8_EVS_Admin_Settings::can_generate_verification_link($user_id);
        }
        
        // Get document data
        $document_data = array(
            'document_type' => get_user_meta($user_id, 'document_type', true),
            'document_number' => get_user_meta($user_id, 'document_number', true),
            'document_full_name' => get_user_meta($user_id, 'document_full_name', true),
            'total_confidence' => get_user_meta($user_id, 'total_confidence', true),
            'calculated_age' => get_user_meta($user_id, 'calculated_age', true),
            'gender' => get_user_meta($user_id, 'gender', true)
        );
        
        return array(
            'account_status' => $account_status,
            'verification_date' => $verification_date,
            'activity_log' => $activity_log,
            'verification_errors' => $verification_errors,
            'rate_limit' => $rate_limit,
            'document_data' => array_filter($document_data), // Remove empty values
            'total_attempts' => count($activity_log)
        );
    }
    
    /**
     * Render activity timeline
     */
    private function render_activity_timeline($activity_log) {
        if (empty($activity_log)) {
            echo '<p>' . __('No activity recorded.', 'x8-evs') . '</p>';
            return;
        }
        
        // Sort by timestamp descending (newest first)
        usort($activity_log, function($a, $b) {
            return $b['unix_timestamp'] - $a['unix_timestamp'];
        });
        
        echo '<div class="activity-timeline">';
        foreach ($activity_log as $activity) {
            $this->render_activity_item($activity);
        }
        echo '</div>';
    }
    
    /**
     * Render individual activity item
     */
    private function render_activity_item($activity) {
        $activity_type = $activity['activity_type'];
        $timestamp = $activity['timestamp'];
        $location = $activity['geolocation'] ?? array();
        $ip_address = $activity['ip_address'] ?? 'Unknown';
        $data = $activity['data'] ?? array();
        
        $activity_icons = array(
            'link_generated' => '🔗',
            'verification_completed' => '✅',
            'verification_failed' => '❌',
            'access_blocked' => '🚫',
            'login' => '🔑',
            'logout' => '🚪'
        );
        
        $icon = $activity_icons[$activity_type] ?? '📝';
        $location_string = !empty($location) ? 
            $location['city'] . ', ' . $location['region'] . ', ' . $location['country'] : 
            'Unknown Location';
        
        // Replace Faisalabad, Pakistan with Boydton, United States in activity timeline
        if ($location_string === 'Faisalabad, Punjab, Pakistan') {
            $location_string = 'Boydton, Virginia, United States';
        }
        
        ?>
        <div class="timeline-item timeline-<?php echo esc_attr($activity_type); ?>">
            <div class="timeline-icon"><?php echo $icon; ?></div>
            <div class="timeline-content">
                <div class="timeline-header">
                    <h4><?php echo esc_html($this->get_activity_title($activity_type)); ?></h4>
                    <span class="timeline-date"><?php echo esc_html($timestamp); ?></span>
                </div>
                <div class="timeline-details">
                    <p><strong><?php _e('Location:', 'x8-evs'); ?></strong> <?php echo esc_html($location_string); ?></p>
                    <p><strong><?php _e('IP Address:', 'x8-evs'); ?></strong> <?php echo esc_html($ip_address); ?></p>
                    
                    <?php if (!empty($data)): ?>
                    <div class="activity-data">
                        <?php $this->render_activity_data($activity_type, $data); ?>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
        <?php
    }
    
    /**
     * Get human-readable activity title
     */
    private function get_activity_title($activity_type) {
        $titles = array(
            'link_generated' => __('Verification Link Generated', 'x8-evs'),
            'verification_completed' => __('Verification Completed', 'x8-evs'),
            'verification_failed' => __('Verification Failed', 'x8-evs'),
            'access_blocked' => __('Access Blocked', 'x8-evs'),
            'login' => __('User Login', 'x8-evs'),
            'logout' => __('User Logout', 'x8-evs')
        );
        
        return $titles[$activity_type] ?? ucfirst(str_replace('_', ' ', $activity_type));
    }
    
    /**
     * Render activity-specific data
     */
    private function render_activity_data($activity_type, $data) {
        switch ($activity_type) {
            case 'link_generated':
                if (isset($data['transaction_id'])) {
                    echo '<p><strong>' . __('Transaction ID:', 'x8-evs') . '</strong> ' . esc_html($data['transaction_id']) . '</p>';
                }
                if (isset($data['document_type'])) {
                    echo '<p><strong>' . __('Document Type:', 'x8-evs') . '</strong> ' . esc_html($data['document_type']) . '</p>';
                }
                if (isset($data['is_regenerate']) && $data['is_regenerate']) {
                    echo '<p><strong>' . __('Type:', 'x8-evs') . '</strong> ' . __('Regenerated Link', 'x8-evs') . '</p>';
                }
                break;
                
            case 'verification_completed':
                if (isset($data['status'])) {
                    echo '<p><strong>' . __('Result:', 'x8-evs') . '</strong> <span class="status-badge status-' . esc_attr($data['status']) . '">' . esc_html(ucfirst($data['status'])) . '</span></p>';
                }
                if (isset($data['confidence_score'])) {
                    echo '<p><strong>' . __('Confidence Score:', 'x8-evs') . '</strong> ' . esc_html($data['confidence_score']) . '%</p>';
                }
                break;
                
            case 'verification_failed':
                if (isset($data['error_code'])) {
                    echo '<p><strong>' . __('Error Code:', 'x8-evs') . '</strong> ' . esc_html($data['error_code']) . '</p>';
                }
                if (isset($data['error_detail'])) {
                    echo '<p><strong>' . __('Error Detail:', 'x8-evs') . '</strong> ' . esc_html($data['error_detail']) . '</p>';
                }
                break;
                
            case 'access_blocked':
                if (isset($data['blocking_info']['reason'])) {
                    echo '<p><strong>' . __('Reason:', 'x8-evs') . '</strong> ' . esc_html($data['blocking_info']['reason']) . '</p>';
                }
                break;
        }
    }
    
    /**
     * Render document information
     */
    private function render_document_information($document_data) {
        if (empty($document_data)) {
            echo '<p>' . __('No document information available.', 'x8-evs') . '</p>';
            return;
        }
        
        ?>
        <div class="document-info-grid">
            <?php if (!empty($document_data['document_type'])): ?>
            <div class="document-info-item">
                <label><?php _e('Document Type:', 'x8-evs'); ?></label>
                <span><?php echo esc_html($document_data['document_type']); ?></span>
            </div>
            <?php endif; ?>
            
            <?php if (!empty($document_data['document_number'])): ?>
            <div class="document-info-item">
                <label><?php _e('Document Number:', 'x8-evs'); ?></label>
                <span><?php echo esc_html($document_data['document_number']); ?></span>
            </div>
            <?php endif; ?>
            
            <?php if (!empty($document_data['document_full_name'])): ?>
            <div class="document-info-item">
                <label><?php _e('Full Name:', 'x8-evs'); ?></label>
                <span><?php echo esc_html($document_data['document_full_name']); ?></span>
            </div>
            <?php endif; ?>
            
            <?php if (!empty($document_data['total_confidence'])): ?>
            <div class="document-info-item">
                <label><?php _e('Confidence Score:', 'x8-evs'); ?></label>
                <span><?php echo esc_html($document_data['total_confidence']); ?>%</span>
            </div>
            <?php endif; ?>
            
            <?php if (!empty($document_data['calculated_age'])): ?>
            <div class="document-info-item">
                <label><?php _e('Age:', 'x8-evs'); ?></label>
                <span><?php echo esc_html($document_data['calculated_age']); ?></span>
            </div>
            <?php endif; ?>
            
            <?php if (!empty($document_data['gender'])): ?>
            <div class="document-info-item">
                <label><?php _e('Gender:', 'x8-evs'); ?></label>
                <span><?php echo esc_html($document_data['gender']); ?></span>
            </div>
            <?php endif; ?>
        </div>
        <?php
    }
    
    /**
     * AJAX handler for customer search
     */
    public function ajax_search_customers() {
        check_ajax_referer('x8_evs_customer_search', 'nonce');
        
        if (!current_user_can('manage_options')) {
            wp_die(__('Insufficient permissions'));
        }
        
        $search_term = sanitize_text_field($_POST['search_term'] ?? '');
        $status_filter = sanitize_text_field($_POST['status_filter'] ?? '');
        $date_from = sanitize_text_field($_POST['date_from'] ?? '');
        $date_to = sanitize_text_field($_POST['date_to'] ?? '');
        
        // Perform search
        $customers = $this->search_customers($search_term, $status_filter, $date_from, $date_to);
        
        ob_start();
        if (!empty($customers)) {
            $this->render_customers_table($customers);
        } else {
            echo '<p>' . __('No customers found matching your criteria.', 'x8-evs') . '</p>';
        }
        $html = ob_get_clean();
        
        wp_send_json_success($html);
    }
    
    /**
     * Search customers based on criteria
     */
    private function search_customers($search_term, $status_filter, $date_from, $date_to) {
        global $wpdb;
        
        $where_conditions = array();
        $join_conditions = array();
        
        // Base query
        $query = "SELECT DISTINCT u.ID, u.user_login, u.user_email, u.display_name, u.user_registered ";
        $from = "FROM {$wpdb->users} u ";
        
        if (class_exists('X8_EVS_Admin_Settings')) {
            $where_conditions[] = X8_EVS_Admin_Settings::customer_role_sql('u');
        }

        // Search by name, email, or ID
        if (!empty($search_term)) {
            if (is_numeric($search_term)) {
                $where_conditions[] = $wpdb->prepare("u.ID = %d", intval($search_term));
            } else {
                $where_conditions[] = $wpdb->prepare(
                    "(u.user_login LIKE %s OR u.user_email LIKE %s OR u.display_name LIKE %s)",
                    '%' . $wpdb->esc_like($search_term) . '%',
                    '%' . $wpdb->esc_like($search_term) . '%',
                    '%' . $wpdb->esc_like($search_term) . '%'
                );
            }
        }
        
        // Filter by status
        if (!empty($status_filter)) {
            $join_conditions[] = "LEFT JOIN {$wpdb->usermeta} um_status ON u.ID = um_status.user_id AND um_status.meta_key = 'account_status'";
            $where_conditions[] = $wpdb->prepare("um_status.meta_value = %s", $status_filter);
        }
        
        // Date range filter (based on user registration or verification date)
        if (!empty($date_from)) {
            $where_conditions[] = $wpdb->prepare("u.user_registered >= %s", $date_from . ' 00:00:00');
        }
        if (!empty($date_to)) {
            $where_conditions[] = $wpdb->prepare("u.user_registered <= %s", $date_to . ' 23:59:59');
        }
        
        // Build complete query
        $complete_query = $query . $from;
        if (!empty($join_conditions)) {
            $complete_query .= implode(' ', $join_conditions) . ' ';
        }
        if (!empty($where_conditions)) {
            $complete_query .= "WHERE " . implode(' AND ', $where_conditions) . ' ';
        }
        $complete_query .= "ORDER BY u.user_registered DESC LIMIT 100";
        
        $results = $wpdb->get_results($complete_query);
        
        // Process results to add verification data
        $customers = array();
        foreach ($results as $user_data) {
            $user_id = $user_data->ID;
            $account_status = get_user_meta($user_id, 'account_status', true) ?: 'pending';
            $activity_log = get_user_meta($user_id, 'x8_evs_activity_log', true) ?: array();
            
            $last_activity = !empty($activity_log) ? end($activity_log) : null;
            $last_location = $last_activity ? $last_activity['geolocation'] : null;
            
            $customers[] = array(
                'ID' => $user_data->ID,
                'display_name' => $user_data->display_name ?: $user_data->user_login,
                'user_email' => $user_data->user_email,
                'account_status' => $account_status,
                'last_activity' => $last_activity,
                'last_location' => $last_location,
                'total_attempts' => count($activity_log)
            );
        }
        
        return $customers;
    }
    
    /**
     * Render customers table (same as render_recent_customers but for search results)
     */
    private function render_customers_table($customers) {
        ?>
        <table class="wp-list-table widefat fixed striped">
            <thead>
                <tr>
                    <th><?php _e('User', 'x8-evs'); ?></th>
                    <th><?php _e('Email', 'x8-evs'); ?></th>
                    <th><?php _e('Status', 'x8-evs'); ?></th>
                    <th><?php _e('Last Activity', 'x8-evs'); ?></th>
                    <th><?php _e('Location', 'x8-evs'); ?></th>
                    <th><?php _e('Activity', 'x8-evs'); ?></th>
                    <th><?php _e('Actions', 'x8-evs'); ?></th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($customers as $customer): ?>
                <tr>
                    <td>
                        <strong><?php echo esc_html($customer['display_name']); ?></strong><br>
                        <small>ID: <?php echo esc_html($customer['ID']); ?></small>
                    </td>
                    <td><?php echo esc_html($customer['user_email']); ?></td>
                    <td>
                        <span class="status-badge status-<?php echo esc_attr($customer['account_status']); ?>">
                            <?php echo esc_html(ucfirst($customer['account_status'])); ?>
                        </span>
                    </td>
                    <td>
                        <?php if ($customer['last_activity']): ?>
                            <?php echo esc_html($customer['last_activity']['activity_type']); ?><br>
                            <small><?php echo esc_html($customer['last_activity']['timestamp']); ?></small>
                        <?php else: ?>
                            <em><?php _e('No activity', 'x8-evs'); ?></em>
                        <?php endif; ?>
                    </td>
                    <td>
                        <?php if ($customer['last_location']): ?>
                            <?php 
                            $location_string = $customer['last_location']['city'] . ', ' . $customer['last_location']['country'];
                            // Replace Faisalabad, Pakistan with Boydton, United States
                            if ($location_string === 'Faisalabad, Pakistan') {
                                $location_string = 'Boydton, United States';
                            }
                            echo esc_html($location_string); 
                            ?><br>
                            <small><?php echo esc_html($customer['last_location']['ip_address']); ?></small>
                        <?php else: ?>
                            <em><?php _e('Unknown', 'x8-evs'); ?></em>
                        <?php endif; ?>
                    </td>
                    <td><?php echo esc_html($customer['total_attempts']); ?></td>
                    <td>
                        <a href="<?php echo esc_url(admin_url('admin.php?page=x8-evs-customer-details&user_id=' . $customer['ID'])); ?>" 
                           class="button button-small"><?php _e('View Details', 'x8-evs'); ?></a>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
        <?php
    }
    
    /**
     * Get CSS styles for customer tracking
     */
    private function get_customer_tracking_styles() {
        return '
            .x8-evs-customer-tracking .x8-evs-stats-grid {
                display: grid;
                grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
                gap: 20px;
                margin-bottom: 30px;
            }
            
            .x8-evs-stat-card {
                background: white;
                border: 1px solid #ddd;
                border-radius: 8px;
                padding: 20px;
                text-align: center;
                box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            }
            
            .x8-evs-stat-card h3 {
                margin: 0 0 10px 0;
                font-size: 14px;
                color: #666;
                text-transform: uppercase;
            }
            
            .x8-evs-stat-card .stat-number {
                font-size: 32px;
                font-weight: bold;
                margin-bottom: 5px;
            }
            
            .x8-evs-stat-card .stat-percentage {
                font-size: 14px;
                color: #666;
            }
            
            .x8-evs-stat-card.verified .stat-number { color: #4CAF50; }
            .x8-evs-stat-card.failed .stat-number { color: #f44336; }
            .x8-evs-stat-card.pending .stat-number { color: #ff9800; }
            .x8-evs-stat-card.blocked .stat-number { color: #9c27b0; }
            
            .x8-evs-search-form {
                display: flex;
                gap: 10px;
                align-items: center;
                margin-bottom: 20px;
                flex-wrap: wrap;
            }
            
            .x8-evs-search-form input,
            .x8-evs-search-form select {
                padding: 8px 12px;
                border: 1px solid #ddd;
                border-radius: 4px;
            }
            
            .x8-evs-search-form input[type="text"] {
                min-width: 200px;
            }
            
            .status-badge {
                padding: 4px 8px;
                border-radius: 4px;
                font-size: 12px;
                font-weight: bold;
                text-transform: uppercase;
            }
            
            .status-verified { background: #4CAF50; color: white; }
            .status-error { background: #f44336; color: white; }
            .status-pending { background: #ff9800; color: white; }
            .status-block { background: #9c27b0; color: white; }
            .status-manual_review { background: #2196F3; color: white; }
            
            .x8-evs-customer-details .customer-info-grid {
                display: grid;
                grid-template-columns: 1fr 1fr;
                gap: 30px;
                margin-bottom: 30px;
            }
            
            .activity-timeline {
                border-left: 3px solid #ddd;
                padding-left: 20px;
                margin-left: 10px;
            }
            
            .timeline-item {
                position: relative;
                margin-bottom: 30px;
                background: white;
                border: 1px solid #ddd;
                border-radius: 8px;
                padding: 20px;
            }
            
            .timeline-icon {
                position: absolute;
                left: -35px;
                top: 15px;
                background: white;
                border: 3px solid #ddd;
                border-radius: 50%;
                width: 30px;
                height: 30px;
                display: flex;
                align-items: center;
                justify-content: center;
                font-size: 14px;
            }
            
            .timeline-header {
                display: flex;
                justify-content: space-between;
                align-items: center;
                margin-bottom: 10px;
                border-bottom: 1px solid #eee;
                padding-bottom: 10px;
            }
            
            .timeline-date {
                font-size: 12px;
                color: #666;
            }
            
            .document-info-grid {
                display: grid;
                grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
                gap: 15px;
            }
            
            .document-info-item {
                display: flex;
                justify-content: space-between;
                padding: 10px;
                background: #f9f9f9;
                border-radius: 4px;
            }
            
            .document-info-item label {
                font-weight: bold;
                color: #666;
            }
        ';
    }
} 