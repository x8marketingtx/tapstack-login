<?php
/**
 * Webhook Handler Class
 *
 * @package X8_EVS
 * @since 1.0.0
 */

// If this file is called directly, abort.
if (!defined('WPINC')) {
    die;
}

/**
 * X8 Verify Webhook Handler Class
 * 
 * Handles incoming webhook requests from EVS API using WordPress REST API
 */
class X8_EVS_Webhook_Handler {

    /**
     * Initialize the webhook handler
     */
    public function __construct() {
        add_action('rest_api_init', array($this, 'register_webhook_endpoint'));
    }
    
    /**
     * Register webhook REST API endpoint
     */
    public function register_webhook_endpoint() {
        register_rest_route('x8-evs/v1', '/webhook', array(
            'methods' => 'POST',
            'callback' => array($this, 'handle_webhook_request'),
            'permission_callback' => '__return_true', // No authentication required for webhook
            'args' => array()
        ));
        
        // Test endpoint for webhook validation
        register_rest_route('x8-evs/v1', '/webhook/test', array(
            'methods' => 'GET',
            'callback' => array($this, 'handle_test_request'),
            'permission_callback' => '__return_true',
            'args' => array()
        ));
        
        // Image webhook endpoint for handling document images
        register_rest_route('x8-evs/v1', '/webhook/images', array(
            'methods' => 'POST',
            'callback' => array($this, 'handle_image_webhook_request'),
            'permission_callback' => '__return_true', // No authentication required for webhook
            'args' => array()
        ));
    }
    
    /**
     * Handle incoming webhook requests
     */
    public function handle_webhook_request($request) {
        // Get the request body
        $body = $request->get_body();
        
        if (empty($body)) {
            $this->debug_log('webhook_rejected', 'Webhook received with empty body', array(
                'ip' => $this->get_client_ip($request)
            ));
            return new WP_Error('no_data', 'No data received', array('status' => 400));
        }
        
        // Decode JSON data
        $webhook_data = json_decode($body, true);
        
        if (json_last_error() !== JSON_ERROR_NONE) {
            $this->debug_log('webhook_rejected', 'Webhook body is not valid JSON: ' . json_last_error_msg(), array(
                'ip' => $this->get_client_ip($request),
                'body_preview' => substr($body, 0, 500)
            ));
            return new WP_Error('invalid_json', 'Invalid JSON data', array('status' => 400));
        }
        
        // Log incoming webhook data for debugging
        $this->log_webhook_data($webhook_data, $request);
        
        // Extract customer reference (user ID) early so rejections can be tied to the user
        $customer_reference = $webhook_data['meta']['customerReference'] ?? '';
        $trail_user_id = intval($customer_reference);
        
        $this->debug_log('webhook_received', 'Webhook received from ' . $this->get_client_ip($request), array(
            'transaction_id' => $webhook_data['meta']['transactionId'] ?? '',
            'product_name' => $webhook_data['meta']['productName'] ?? '',
            'customer_reference' => $customer_reference,
            'has_assure_card' => isset($webhook_data['data']['assureCard']),
            'has_workflow_outcome' => isset($webhook_data['data']['workflowOutcome']),
            'has_assure_locate' => isset($webhook_data['data']['assureLocate']),
            'has_images' => isset($webhook_data['data']['frontImage']) || isset($webhook_data['data']['backImage']) || isset($webhook_data['data']['portraitImage']),
            'has_errors' => isset($webhook_data['errors']) && !empty($webhook_data['errors'])
        ), $trail_user_id);
        
        // Validate required fields
        if (!$this->validate_webhook_data($webhook_data)) {
            $this->debug_log('webhook_rejected', 'Webhook has invalid structure (missing meta/transactionId/customerReference or no recognizable data payload)', array(
                'top_level_keys' => array_keys($webhook_data),
                'data_keys' => isset($webhook_data['data']) && is_array($webhook_data['data']) ? array_keys($webhook_data['data']) : array()
            ), $trail_user_id);
            return new WP_Error('invalid_structure', 'Invalid webhook data structure', array('status' => 400));
        }
        
        if (empty($customer_reference)) {
            $this->debug_log('webhook_rejected', 'Webhook missing customerReference; cannot match to a user');
            return new WP_Error('missing_customer_ref', 'Customer reference is required', array('status' => 400));
        }

        $this->ensure_assurelocate_handler();

        $is_identity = $this->is_identity_webhook($webhook_data);
        $is_locate = $this->is_locate_webhook($webhook_data);
        $has_images = $this->webhook_has_images($webhook_data);
        $has_errors = isset($webhook_data['errors']) && !empty($webhook_data['errors']);

        // Location-only callbacks (including error and image dumps) must never
        // overwrite identity verification results or document images. Guest
        // references are also handled here before WordPress user validation.
        if ($is_locate && !$is_identity) {
            return $this->respond_locate_webhook($customer_reference, $webhook_data, $trail_user_id);
        }
        
        // Identity verification webhooks: customerReference must be a valid user ID
        $user_id = intval($customer_reference);
        $user = get_user_by('id', $user_id);
        
        if (!$user) {
            $this->debug_log('webhook_rejected', 'Webhook customerReference does not match any WordPress user', array(
                'customer_reference' => $customer_reference
            ));
            return new WP_Error('user_not_found', 'User not found', array('status' => 404));
        }
        
        // Process the webhook data
        try {
            $processed_data = array();
            
            // Identity error webhook
            if ($has_errors && $is_identity) {
                if (class_exists('X8_EVS_Admin_Settings')) {
                    $result = X8_EVS_Admin_Settings::store_verification_error($user_id, $webhook_data);
                    
                    if ($result) {
                        delete_user_meta($user_id, 'verification_link');
                        delete_user_meta($user_id, 'verification_link_created');
                        
                        $processed_data['error_processed'] = true;
                        $processed_data['error_count'] = count($webhook_data['errors']);
                        
                        $this->debug_log('webhook_processed', 'Error webhook processed; account status set to "error"', array(
                            'errors' => $webhook_data['errors']
                        ), $user_id);
                    } else {
                        $this->debug_log('webhook_failed', 'store_verification_error() returned false', array(), $user_id);
                        return new WP_Error('error_processing_failed', 'Failed to process verification error', array('status' => 500));
                    }
                } else {
                    $this->debug_log('webhook_failed', 'X8_EVS_Admin_Settings class not available while processing error webhook', array(), $user_id);
                    return new WP_Error('admin_settings_unavailable', 'Admin settings class not available', array('status' => 500));
                }
            }
            // Identity result (AssureCard / AssureID). Do not treat workflowOutcome
            // alone as identity data — AssureLocate also sends workflowOutcome.
            elseif ($is_identity) {
                if (class_exists('X8_EVS_Admin_Settings')) {
                    $result = X8_EVS_Admin_Settings::store_verification_data($user_id, $webhook_data);
                    
                    if ($result) {
                        delete_user_meta($user_id, 'verification_link');
                        delete_user_meta($user_id, 'verification_link_created');
                        
                        $account_status = get_user_meta($user_id, 'account_status', true);
                        $processed_data['verification_status'] = $account_status;
                        
                        $this->debug_log('webhook_processed', 'Verification webhook processed; account status set to "' . $account_status . '"', array(
                            'transaction_id' => $webhook_data['meta']['transactionId'] ?? '',
                            'total_confidence' => $webhook_data['data']['assureCard']['totalConfidence'] ?? null,
                            'face_confidence' => $webhook_data['data']['assureCard']['faceVerificationConfidence'] ?? null
                        ), $user_id);
                    } else {
                        $this->debug_log('webhook_failed', 'store_verification_data() returned false', array(), $user_id);
                        return new WP_Error('processing_failed', 'Failed to process verification data', array('status' => 500));
                    }
                } else {
                    $this->debug_log('webhook_failed', 'X8_EVS_Admin_Settings class not available while processing verification webhook', array(), $user_id);
                    return new WP_Error('admin_settings_unavailable', 'Admin settings class not available', array('status' => 500));
                }

                // Bundled EVS workflow: identity result also includes locate data.
                if ($is_locate) {
                    $locate_result = X8_EVS_AssureLocate_Handler::process_webhook_reference($customer_reference, $webhook_data);
                    if (!is_wp_error($locate_result)) {
                        $processed_data['assurelocate'] = $locate_result;
                    } else {
                        $this->debug_log('webhook_failed', 'Bundled AssureLocate processing failed: ' . $locate_result->get_error_message(), array(
                            'customer_reference' => $customer_reference
                        ), $user_id);
                    }
                }
            } elseif ($has_errors) {
                // Error payload that was not identified as identity. Prefer locate
                // handling over wiping the customer's identity verification status.
                return $this->respond_locate_webhook($customer_reference, $webhook_data, $user_id);
            } elseif (isset($webhook_data['data']['workflowOutcome'])) {
                // Outcome-only payload with no AssureCard. This is how AssureLocate
                // results often arrive; never let it replace identity verification.
                return $this->respond_locate_webhook($customer_reference, $webhook_data, $user_id);
            }
            
            if ($has_images) {
                if ($this->should_store_identity_images($user_id, $webhook_data, $is_identity)) {
                    $image_result = $this->store_document_images($user_id, $webhook_data);
                    if ($image_result) {
                        $processed_data['images_stored'] = true;
                        $this->debug_log('webhook_processed', 'Document images stored from webhook', array(), $user_id);
                    } else {
                        $this->debug_log('webhook_failed', 'Failed to store document images from webhook', array(), $user_id);
                        return new WP_Error('image_processing_failed', 'Failed to process document images', array('status' => 500));
                    }
                } else {
                    $processed_data['images_skipped'] = true;
                    $this->debug_log('webhook_processed', 'Skipped storing webhook images so existing identity document images are not replaced', array(
                        'transaction_id' => $webhook_data['meta']['transactionId'] ?? '',
                        'product_name' => $webhook_data['meta']['productName'] ?? '',
                        'is_identity' => $is_identity,
                        'is_locate' => $is_locate
                    ), $user_id);
                }
            }
            
            return rest_ensure_response(array(
                'success' => true,
                'message' => 'Webhook processed successfully',
                'user_id' => $user_id,
                'transaction_id' => $webhook_data['meta']['transactionId'] ?? '',
                'processed_data' => $processed_data
            ));
            
        } catch (Exception $e) {
            $this->debug_log('webhook_failed', 'Exception while processing webhook: ' . $e->getMessage(), array(), $user_id);
            return new WP_Error('processing_error', 'Processing error: ' . $e->getMessage(), array('status' => 500));
        }
    }

    /**
     * Image-only EVS webhook endpoint. Uses the same routing as the main
     * webhook so AssureLocate image dumps cannot replace ID document images.
     */
    public function handle_image_webhook_request($request) {
        return $this->handle_webhook_request($request);
    }
    
    /**
     * Write to the always-on verification debug log (file + per-user trail).
     */
    private function debug_log($event, $message, $context = array(), $user_id = 0) {
        if (class_exists('X8_EVS_Debug_Logger')) {
            X8_EVS_Debug_Logger::log($event, $message, $context, $user_id);
        }
    }

    /**
     * Load the AssureLocate handler if it is not already available.
     */
    private function ensure_assurelocate_handler() {
        if (!class_exists('X8_EVS_AssureLocate_Handler')) {
            require_once X8_EVS_PLUGIN_PATH . 'inc/frontend/class-assurelocate-handler.php';
        }
    }

    /**
     * Whether this payload is an identity (AssureCard / AssureID) webhook.
     * workflowOutcome alone is not enough — AssureLocate uses that field too.
     */
    private function is_identity_webhook($webhook_data) {
        if (isset($webhook_data['data']['assureCard']) || isset($webhook_data['data']['assureId'])) {
            return true;
        }

        $product = strtolower(trim((string) ($webhook_data['meta']['productName'] ?? '')));
        $product_compact = str_replace(array(' ', '-', '_'), '', $product);

        if ($product_compact === '') {
            return false;
        }

        foreach (array('assurecard', 'assureid') as $identity_product) {
            if (strpos($product_compact, $identity_product) !== false) {
                return true;
            }
        }

        return false;
    }

    /**
     * Whether this payload belongs to AssureLocate location verification.
     */
    private function is_locate_webhook($webhook_data) {
        $this->ensure_assurelocate_handler();
        return X8_EVS_AssureLocate_Handler::is_locate_webhook($webhook_data);
    }

    /**
     * Whether the webhook includes document/map image fields.
     */
    private function webhook_has_images($webhook_data) {
        return isset($webhook_data['data']['frontImage'])
            || isset($webhook_data['data']['backImage'])
            || isset($webhook_data['data']['portraitImage']);
    }

    /**
     * Store ID document images only when the payload belongs to identity
     * verification. Location image dumps (maps, device captures) must not
     * replace existing document images.
     */
    private function should_store_identity_images($user_id, $webhook_data, $from_identity_webhook) {
        if ($this->is_locate_webhook($webhook_data) && !$from_identity_webhook) {
            return false;
        }

        if ($from_identity_webhook) {
            return true;
        }

        $txn = trim((string) ($webhook_data['meta']['transactionId'] ?? ''));
        $identity_txn = trim((string) get_user_meta($user_id, 'transaction_id', true));
        if ($txn !== '' && $identity_txn !== '' && $txn === $identity_txn) {
            return true;
        }

        if (get_user_meta($user_id, 'verification_link', true)) {
            return true;
        }

        $has_existing = get_user_meta($user_id, 'document_front_image', true)
            || get_user_meta($user_id, 'document_back_image', true)
            || get_user_meta($user_id, 'document_portrait_image', true);

        if ($has_existing) {
            return false;
        }

        return true;
    }

    /**
     * Process an AssureLocate webhook and return a REST response without
     * touching identity verification user meta.
     */
    private function respond_locate_webhook($customer_reference, $webhook_data, $user_id) {
        $this->ensure_assurelocate_handler();

        $locate_data = X8_EVS_AssureLocate_Handler::get_locate_data($webhook_data);
        $result = X8_EVS_AssureLocate_Handler::process_webhook_reference($customer_reference, $webhook_data);

        if (is_wp_error($result)) {
            // A late image/result callback after the location record is already
            // closed should be acknowledged, not allowed to fall through into
            // identity storage (and not retried forever by EVS).
            if ($result->get_error_code() === 'record_not_found') {
                $this->debug_log('webhook_processed', 'AssureLocate webhook acknowledged with no open location record; identity data left unchanged', array(
                    'customer_reference' => $customer_reference,
                    'transaction_id' => $webhook_data['meta']['transactionId'] ?? '',
                    'product_name' => $webhook_data['meta']['productName'] ?? ''
                ), $user_id);

                return rest_ensure_response(array(
                    'success' => true,
                    'message' => 'AssureLocate webhook acknowledged; no open location record',
                    'user_id' => $user_id,
                    'transaction_id' => $webhook_data['meta']['transactionId'] ?? ''
                ));
            }

            $this->debug_log('webhook_failed', 'AssureLocate webhook processing failed: ' . $result->get_error_message(), array(
                'customer_reference' => $customer_reference
            ), $user_id);
            return $result;
        }

        $this->debug_log('webhook_processed', 'AssureLocate webhook processed', array(
            'transaction_id' => $webhook_data['meta']['transactionId'] ?? '',
            'result' => $result['assurelocate'] ?? '',
            'vpn_probability' => $result['vpn_probability'] ?? '',
            'workflow_outcome' => $webhook_data['data']['workflowOutcome'] ?? null,
            'device_location' => array(
                'city' => $locate_data['deviceLocation']['city'] ?? '',
                'province' => $locate_data['deviceLocation']['province'] ?? '',
                'country' => $locate_data['deviceLocation']['country'] ?? ''
            ),
            'ip_location' => array(
                'ip' => $locate_data['ipLocation']['ipAddress'] ?? '',
                'city' => $locate_data['ipLocation']['city'] ?? '',
                'iso_country' => $locate_data['ipLocation']['isoCountry'] ?? ''
            )
        ), $user_id);

        return rest_ensure_response(array(
            'success' => true,
            'message' => 'AssureLocate webhook processed successfully',
            'user_id' => $user_id,
            'transaction_id' => $webhook_data['meta']['transactionId'] ?? '',
            'processed_data' => $result
        ));
    }
    
    /**
     * Handle test request to verify webhook endpoint is working
     */
    public function handle_test_request($request) {
        return rest_ensure_response(array(
            'success' => true,
            'message' => 'X8 Verify webhook endpoint is working correctly',
            'timestamp' => current_time('mysql'),
            'endpoint' => rest_url('x8-evs/v1/webhook'),
            'version' => X8_EVS_VERSION ?? '1.0.0'
        ));
    }
    
    /**
     * Validate webhook data structure
     */
    private function validate_webhook_data($data) {
        // Check for required top-level keys
        if (!isset($data['meta'])) {
            return false;
        }
        
        // Check for required meta fields
        if (!isset($data['meta']['transactionId']) || !isset($data['meta']['customerReference'])) {
            return false;
        }
        
        // Check if this is an error webhook
        if (isset($data['errors']) && !empty($data['errors'])) {
            return true; // Error webhooks are valid
        }
        
        // Check for required data structure - verification results, AssureLocate results, or images
        $has_verification_data = isset($data['data']['assureCard']) || isset($data['data']['workflowOutcome']);
        $has_assurelocate_data = isset($data['data']['assureLocate']);
        $has_image_data = isset($data['data']['frontImage']) || isset($data['data']['backImage']) || isset($data['data']['portraitImage']);
        
        if (!$has_verification_data && !$has_assurelocate_data && !$has_image_data) {
            return false;
        }
        
        return true;
    }
    
    /**
     * Log webhook data for debugging
     */
    private function log_webhook_data($data, $request) {
        // Only log if debugging is enabled
        if (defined('WP_DEBUG') && WP_DEBUG) {
            $log_entry = array(
                'timestamp' => current_time('mysql'),
                'data' => $data,
                'user_agent' => $request->get_header('user_agent') ?: 'Unknown',
                'ip_address' => $this->get_client_ip($request),
                'content_type' => $request->get_header('content_type') ?: 'Unknown'
            );
            
            // Log to a custom log file
            $log_file = WP_CONTENT_DIR . '/x8-evs-webhook.log';
            error_log(date('Y-m-d H:i:s') . ' - Webhook received: ' . json_encode($log_entry) . "\n", 3, $log_file);
        }
    }
    
    /**
     * Get client IP address from request
     */
    private function get_client_ip($request) {
        // Check for various IP headers
        $ip_headers = array(
            'HTTP_X_FORWARDED_FOR',
            'HTTP_X_REAL_IP',
            'HTTP_CLIENT_IP',
            'REMOTE_ADDR'
        );
        
        foreach ($ip_headers as $header) {
            $ip = $request->get_header(strtolower(str_replace('HTTP_', '', $header)));
            if ($ip) {
                // Handle comma-separated IPs
                $ips = explode(',', $ip);
                $ip = trim($ips[0]);
                
                if (filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE) !== false) {
                    return $ip;
                }
            }
        }
        
        // Fallback to $_SERVER
        return $_SERVER['REMOTE_ADDR'] ?? 'Unknown';
    }
    
    /**
     * Store document images from webhook data
     */
    private function store_document_images($user_id, $webhook_data) {
        $upload_dir = wp_upload_dir();
        $x8_evs_dir = $upload_dir['basedir'] . '/x8-evs-documents/' . $user_id;
        
        // Create directory if it doesn't exist
        if (!file_exists($x8_evs_dir)) {
            wp_mkdir_p($x8_evs_dir);
        }
        
        $stored_images = array();
        
        // Process front image
        if (isset($webhook_data['data']['frontImage']) && !empty($webhook_data['data']['frontImage'])) {
            $front_image_path = $this->save_base64_image($webhook_data['data']['frontImage'], $x8_evs_dir, 'front');
            if ($front_image_path) {
                $stored_images['front'] = $front_image_path;
                update_user_meta($user_id, 'document_front_image', $front_image_path);
            }
        }
        
        // Process back image
        if (isset($webhook_data['data']['backImage']) && !empty($webhook_data['data']['backImage'])) {
            $back_image_path = $this->save_base64_image($webhook_data['data']['backImage'], $x8_evs_dir, 'back');
            if ($back_image_path) {
                $stored_images['back'] = $back_image_path;
                update_user_meta($user_id, 'document_back_image', $back_image_path);
            }
        }
        
        // Process portrait image
        if (isset($webhook_data['data']['portraitImage']) && !empty($webhook_data['data']['portraitImage'])) {
            $portrait_image_path = $this->save_base64_image($webhook_data['data']['portraitImage'], $x8_evs_dir, 'portrait');
            if ($portrait_image_path) {
                $stored_images['portrait'] = $portrait_image_path;
                update_user_meta($user_id, 'document_portrait_image', $portrait_image_path);
            }
        }
        
        // Store transaction metadata
        if (isset($webhook_data['meta'])) {
            update_user_meta($user_id, 'document_transaction_id', $webhook_data['meta']['transactionId'] ?? '');
            update_user_meta($user_id, 'document_transaction_date', $webhook_data['meta']['transactionDate'] ?? '');
        }
        
        return !empty($stored_images);
    }
    
    /**
     * Save base64 image to file
     */
    private function save_base64_image($base64_string, $directory, $type) {
        // Remove data URL prefix if present
        $base64_string = preg_replace('/^data:image\/[a-zA-Z]+;base64,/', '', $base64_string);
        
        // Decode base64
        $image_data = base64_decode($base64_string);
        
        if ($image_data === false) {
            return false;
        }
        
        // Generate filename
        $filename = 'document_' . $type . '_' . time() . '.jpg';
        $file_path = $directory . '/' . $filename;
        
        // Save file
        if (file_put_contents($file_path, $image_data)) {
            return $file_path;
        }
        
        return false;
    }
    
    /**
     * Get webhook endpoint URL
     */
    public static function get_webhook_url() {
        return rest_url('x8-evs/v1/webhook');
    }
}

// Initialize the webhook handler
new X8_EVS_Webhook_Handler(); 